package org.spongepowered.asm.mixin.injection;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target({ElementType.PARAMETER})
public @interface Coerce {}


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\org\spongepowered\asm\mixin\injection\Coerce.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */