package org.spongepowered.asm.lib.util;

import java.util.Map;
import org.spongepowered.asm.lib.Label;

public interface ASMifiable {
  void asmify(StringBuffer paramStringBuffer, String paramString, Map<Label, String> paramMap);
}


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\org\spongepowered\asm\li\\util\ASMifiable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */