package org.json.simple;

public interface JSONAware {
  String toJSONString();
}


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\org\json\simple\JSONAware.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */