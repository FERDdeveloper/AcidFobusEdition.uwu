/*    */ package me.earth.phobos.features.command;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import me.earth.phobos.Phobos;
/*    */ import me.earth.phobos.features.Feature;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.TextComponentBase;
/*    */ import net.minecraft.util.text.TextComponentString;
/*    */ 
/*    */ public abstract class Command
/*    */   extends Feature
/*    */ {
/*    */   protected String name;
/*    */   protected String[] commands;
/*    */   
/*    */   public Command(String name) {
/* 18 */     super(name);
/* 19 */     this.name = name;
/* 20 */     this.commands = new String[] { "" };
/*    */   }
/*    */   
/*    */   public Command(String name, String[] commands) {
/* 24 */     super(name);
/* 25 */     this.name = name;
/* 26 */     this.commands = commands;
/*    */   }
/*    */   
/*    */   public static void sendMessage(String message, boolean notification) {
/* 30 */     sendSilentMessage(Phobos.commandManager.getClientMessage() + " §r" + message);
/* 31 */     if (notification) {
/* 32 */       Phobos.notificationManager.addNotification(message, 3000L);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void sendMessage(String message) {
/* 37 */     sendSilentMessage(Phobos.commandManager.getClientMessage() + " §r" + message);
/*    */   }
/*    */   
/*    */   public static void sendSilentMessage(String message) {
/* 41 */     if (nullCheck()) {
/*    */       return;
/*    */     }
/* 44 */     mc.field_71439_g.func_145747_a((ITextComponent)new ChatMessage(message));
/*    */   }
/*    */   
/*    */   public static void sendOverwriteMessage(String message, int id, boolean notification) {
/* 48 */     TextComponentString component = new TextComponentString(message);
/* 49 */     mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)component, id);
/* 50 */     if (notification) {
/* 51 */       Phobos.notificationManager.addNotification(message, 3000L);
/*    */     }
/*    */   }
/*    */   
/*    */   public static String getCommandPrefix() {
/* 56 */     return Phobos.commandManager.getPrefix();
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract void execute(String[] paramArrayOfString);
/*    */   
/*    */   public String getName() {
/* 63 */     return this.name;
/*    */   }
/*    */   
/*    */   public String[] getCommands() {
/* 67 */     return this.commands;
/*    */   }
/*    */   
/*    */   public static class ChatMessage
/*    */     extends TextComponentBase {
/*    */     private final String text;
/*    */     
/*    */     public ChatMessage(String text) {
/* 75 */       Pattern pattern = Pattern.compile("&[0123456789abcdefrlosmk]");
/* 76 */       Matcher matcher = pattern.matcher(text);
/* 77 */       StringBuffer stringBuffer = new StringBuffer();
/* 78 */       while (matcher.find()) {
/* 79 */         String replacement = "§" + matcher.group().substring(1);
/* 80 */         matcher.appendReplacement(stringBuffer, replacement);
/*    */       } 
/* 82 */       matcher.appendTail(stringBuffer);
/* 83 */       this.text = stringBuffer.toString();
/*    */     }
/*    */     
/*    */     public String func_150261_e() {
/* 87 */       return this.text;
/*    */     }
/*    */     
/*    */     public ITextComponent func_150259_f() {
/* 91 */       return (ITextComponent)new ChatMessage(this.text);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\command\Command.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */