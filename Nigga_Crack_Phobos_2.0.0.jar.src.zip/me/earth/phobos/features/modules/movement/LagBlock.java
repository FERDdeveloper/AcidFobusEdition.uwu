/*    */ package me.earth.phobos.features.modules.movement;
/*    */ 
/*    */ import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
/*    */ import me.earth.phobos.features.modules.Module;
/*    */ import me.earth.phobos.features.setting.Setting;
/*    */ import me.earth.phobos.util.BlockUtil;
/*    */ import me.earth.phobos.util.InventoryUtil;
/*    */ import me.earth.phobos.util.RotationUtil;
/*    */ import me.earth.phobos.util.Timer;
/*    */ import net.minecraft.block.BlockChest;
/*    */ import net.minecraft.block.BlockObsidian;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ import net.minecraft.util.EnumHand;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ import net.minecraft.util.math.Vec3i;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class LagBlock extends Module {
/* 21 */   private final Timer timer = new Timer(); private static LagBlock INSTANCE;
/* 22 */   private final Setting<Boolean> packet = register(new Setting("Packet", Boolean.valueOf(true)));
/* 23 */   private final Setting<Boolean> invalidPacket = register(new Setting("InvalidPacket", Boolean.valueOf(false)));
/* 24 */   private final Setting<Integer> rotations = register(new Setting("Rotations", Integer.valueOf(5), Integer.valueOf(1), Integer.valueOf(10)));
/* 25 */   private final Setting<Integer> timeOut = register(new Setting("TimeOut", Integer.valueOf(194), Integer.valueOf(0), Integer.valueOf(1000)));
/*    */   private BlockPos startPos;
/* 27 */   private int lastHotbarSlot = -1;
/* 28 */   private int blockSlot = -1;
/*    */   
/*    */   public LagBlock() {
/* 31 */     super("Burrow", "I think you can guess what this does.", Module.Category.MOVEMENT, true, false, false);
/* 32 */     INSTANCE = this;
/*    */   }
/*    */   
/*    */   public static LagBlock getInstance() {
/* 36 */     if (INSTANCE == null) {
/* 37 */       INSTANCE = new LagBlock();
/*    */     }
/* 39 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 44 */     this.lastHotbarSlot = -1;
/* 45 */     this.blockSlot = -1;
/* 46 */     if (fullNullCheck()) {
/* 47 */       disable();
/*    */       return;
/*    */     } 
/* 50 */     this.blockSlot = findBlockSlot();
/* 51 */     this.startPos = new BlockPos(mc.field_71439_g.func_174791_d());
/*    */     
/* 53 */     mc.field_71439_g.func_70664_aZ();
/* 54 */     this.timer.reset();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/* 59 */     if (event.getStage() != 0 || !this.timer.passedMs(((Integer)this.timeOut.getValue()).intValue())) {
/*    */       return;
/*    */     }
/* 62 */     this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/* 63 */     InventoryUtil.switchToHotbarSlot(this.blockSlot, false);
/* 64 */     for (int i = 0; i < ((Integer)this.rotations.getValue()).intValue(); i++) {
/* 65 */       RotationUtil.faceVector(new Vec3d((Vec3i)this.startPos), true);
/*    */     }
/* 67 */     BlockUtil.placeBlock(this.startPos, (this.blockSlot == -2) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, false, ((Boolean)this.packet.getValue()).booleanValue(), mc.field_71439_g.func_70093_af());
/* 68 */     InventoryUtil.switchToHotbarSlot(this.lastHotbarSlot, false);
/* 69 */     if (((Boolean)this.invalidPacket.getValue()).booleanValue()) {
/* 70 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, 1337.0D, mc.field_71439_g.field_70161_v, true));
/*    */     }
/* 72 */     disable();
/*    */   }
/*    */   
/*    */   private int findBlockSlot() {
/* 76 */     int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 77 */     if (obbySlot == -1) {
/* 78 */       if (InventoryUtil.isBlock(mc.field_71439_g.func_184592_cb().func_77973_b(), BlockObsidian.class)) {
/* 79 */         return -2;
/*    */       }
/* 81 */       int chestSlot = InventoryUtil.findHotbarBlock(BlockChest.class);
/* 82 */       if (chestSlot == -1 && InventoryUtil.isBlock(mc.field_71439_g.func_184592_cb().func_77973_b(), BlockChest.class)) {
/* 83 */         return -2;
/*    */       }
/*    */       
/* 86 */       return -1;
/*    */     } 
/* 88 */     return obbySlot;
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\movement\LagBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */