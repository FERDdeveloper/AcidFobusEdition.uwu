/*    */ package me.earth.phobos.features.modules.movement;
/*    */ 
/*    */ import me.earth.phobos.Phobos;
/*    */ import me.earth.phobos.event.events.KeyEvent;
/*    */ import me.earth.phobos.event.events.PacketEvent;
/*    */ import me.earth.phobos.features.modules.Module;
/*    */ import me.earth.phobos.features.setting.Setting;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.client.event.InputUpdateEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoSlowDown
/*    */   extends Module
/*    */ {
/* 22 */   private static NoSlowDown INSTANCE = new NoSlowDown();
/* 23 */   private static final KeyBinding[] keys = new KeyBinding[] { mc.field_71474_y.field_74351_w, mc.field_71474_y.field_74368_y, mc.field_71474_y.field_74370_x, mc.field_71474_y.field_74366_z, mc.field_71474_y.field_74314_A, mc.field_71474_y.field_151444_V };
/* 24 */   public final Setting<Double> webHorizontalFactor = register(new Setting("WebHSpeed", Double.valueOf(2.0D), Double.valueOf(0.0D), Double.valueOf(100.0D)));
/* 25 */   public final Setting<Double> webVerticalFactor = register(new Setting("WebVSpeed", Double.valueOf(2.0D), Double.valueOf(0.0D), Double.valueOf(100.0D)));
/* 26 */   public Setting<Boolean> guiMove = register(new Setting("GuiMove", Boolean.valueOf(true)));
/* 27 */   public Setting<Boolean> noSlow = register(new Setting("NoSlow", Boolean.valueOf(true)));
/* 28 */   public Setting<Boolean> soulSand = register(new Setting("SoulSand", Boolean.valueOf(true)));
/* 29 */   public Setting<Boolean> strict = register(new Setting("Strict", Boolean.valueOf(false)));
/* 30 */   public Setting<Boolean> webs = register(new Setting("Webs", Boolean.valueOf(false)));
/*    */   
/*    */   public NoSlowDown() {
/* 33 */     super("NoSlowDown", "Prevents you from getting slowed down.", Module.Category.MOVEMENT, true, false, false);
/* 34 */     setInstance();
/*    */   }
/*    */   
/*    */   public static NoSlowDown getInstance() {
/* 38 */     if (INSTANCE == null) {
/* 39 */       INSTANCE = new NoSlowDown();
/*    */     }
/* 41 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 45 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 50 */     if (((Boolean)this.guiMove.getValue()).booleanValue())
/* 51 */       if (mc.field_71462_r instanceof net.minecraft.client.gui.GuiOptions || mc.field_71462_r instanceof net.minecraft.client.gui.GuiVideoSettings || mc.field_71462_r instanceof net.minecraft.client.gui.GuiScreenOptionsSounds || mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiContainer || mc.field_71462_r instanceof net.minecraft.client.gui.GuiIngameMenu) {
/* 52 */         for (KeyBinding bind : keys) {
/* 53 */           KeyBinding.func_74510_a(bind.func_151463_i(), Keyboard.isKeyDown(bind.func_151463_i()));
/*    */         }
/* 55 */       } else if (mc.field_71462_r == null) {
/* 56 */         for (KeyBinding bind : keys) {
/* 57 */           if (!Keyboard.isKeyDown(bind.func_151463_i())) {
/* 58 */             KeyBinding.func_74510_a(bind.func_151463_i(), false);
/*    */           }
/*    */         } 
/*    */       }  
/* 62 */     if (((Boolean)this.webs.getValue()).booleanValue() && ((Flight)Phobos.moduleManager.getModuleByClass(Flight.class)).isDisabled() && ((Phase)Phobos.moduleManager.getModuleByClass(Phase.class)).isDisabled() && mc.field_71439_g.field_70134_J) {
/* 63 */       mc.field_71439_g.field_70159_w *= ((Double)this.webHorizontalFactor.getValue()).doubleValue();
/* 64 */       mc.field_71439_g.field_70179_y *= ((Double)this.webHorizontalFactor.getValue()).doubleValue();
/* 65 */       mc.field_71439_g.field_70181_x *= ((Double)this.webVerticalFactor.getValue()).doubleValue();
/*    */     } 
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onInput(InputUpdateEvent event) {
/* 71 */     if (((Boolean)this.noSlow.getValue()).booleanValue() && mc.field_71439_g.func_184587_cr() && !mc.field_71439_g.func_184218_aH()) {
/* 72 */       (event.getMovementInput()).field_78902_a *= 5.0F;
/* 73 */       (event.getMovementInput()).field_192832_b *= 5.0F;
/*    */     } 
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onKeyEvent(KeyEvent event) {
/* 79 */     if (((Boolean)this.guiMove.getValue()).booleanValue() && event.getStage() == 0 && !(mc.field_71462_r instanceof net.minecraft.client.gui.GuiChat)) {
/* 80 */       event.info = event.pressed;
/*    */     }
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPacket(PacketEvent.Send event) {
/* 86 */     if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketPlayer && ((Boolean)this.strict.getValue()).booleanValue() && ((Boolean)this.noSlow.getValue()).booleanValue() && mc.field_71439_g.func_184587_cr() && !mc.field_71439_g.func_184218_aH())
/* 87 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, new BlockPos(Math.floor(mc.field_71439_g.field_70165_t), Math.floor(mc.field_71439_g.field_70163_u), Math.floor(mc.field_71439_g.field_70161_v)), EnumFacing.DOWN)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\movement\NoSlowDown.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */