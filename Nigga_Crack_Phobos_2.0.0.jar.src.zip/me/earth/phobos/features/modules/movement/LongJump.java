/*     */ package me.earth.phobos.features.modules.movement;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.MoveEvent;
/*     */ import me.earth.phobos.event.events.PacketEvent;
/*     */ import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.MovementInput;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*     */ 
/*     */ public class LongJump
/*     */   extends Module
/*     */ {
/*  29 */   private final Setting<Integer> timeout = register(new Setting("TimeOut", Integer.valueOf(2000), Integer.valueOf(0), Integer.valueOf(5000)));
/*  30 */   private final Setting<Float> boost = register(new Setting("Boost", Float.valueOf(4.48F), Float.valueOf(1.0F), Float.valueOf(20.0F)));
/*  31 */   private final Setting<Mode> mode = register(new Setting("Mode", Mode.VIRTUE));
/*  32 */   private final Setting<Boolean> lagOff = register(new Setting("LagOff", Boolean.valueOf(false)));
/*  33 */   private final Setting<Boolean> autoOff = register(new Setting("AutoOff", Boolean.valueOf(false)));
/*  34 */   private final Setting<Boolean> disableStrafe = register(new Setting("DisableStrafe", Boolean.valueOf(false)));
/*  35 */   private final Setting<Boolean> strafeOff = register(new Setting("StrafeOff", Boolean.valueOf(false)));
/*  36 */   private final Setting<Boolean> step = register(new Setting("SetStep", Boolean.valueOf(false)));
/*  37 */   private final Timer timer = new Timer();
/*     */   private int stage;
/*     */   private int lastHDistance;
/*     */   private int airTicks;
/*     */   private int headStart;
/*     */   private int groundTicks;
/*     */   private double moveSpeed;
/*     */   private double lastDist;
/*     */   private boolean isSpeeding;
/*     */   private boolean beganJump = false;
/*     */   
/*     */   public LongJump() {
/*  49 */     super("LongJump", "Jumps long", Module.Category.MOVEMENT, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  54 */     this.timer.reset();
/*  55 */     this.headStart = 4;
/*  56 */     this.groundTicks = 0;
/*  57 */     this.stage = 0;
/*  58 */     this.beganJump = false;
/*  59 */     if (Strafe.getInstance().isOn() && ((Boolean)this.disableStrafe.getValue()).booleanValue()) {
/*  60 */       Strafe.getInstance().disable();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  66 */     Phobos.timerManager.setTimer(1.0F);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.Receive event) {
/*  71 */     if (((Boolean)this.lagOff.getValue()).booleanValue() && event.getPacket() instanceof net.minecraft.network.play.server.SPacketPlayerPosLook) {
/*  72 */       disable();
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMove(MoveEvent event) {
/*  78 */     if (event.getStage() != 0) {
/*     */       return;
/*     */     }
/*  81 */     if (!this.timer.passedMs(((Integer)this.timeout.getValue()).intValue())) {
/*  82 */       event.setX(0.0D);
/*  83 */       event.setY(0.0D);
/*  84 */       event.setZ(0.0D);
/*     */       return;
/*     */     } 
/*  87 */     if (((Boolean)this.step.getValue()).booleanValue()) {
/*  88 */       mc.field_71439_g.field_70138_W = 0.6F;
/*     */     }
/*  90 */     doVirtue(event);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onTickEvent(TickEvent.ClientTickEvent event) {
/*  95 */     if (fullNullCheck() || event.phase != TickEvent.Phase.START) {
/*     */       return;
/*     */     }
/*  98 */     if (Strafe.getInstance().isOn() && ((Boolean)this.strafeOff.getValue()).booleanValue()) {
/*  99 */       disable();
/*     */       return;
/*     */     } 
/* 102 */     switch ((Mode)this.mode.getValue()) {
/*     */       case TICK:
/* 104 */         doNormal((UpdateWalkingPlayerEvent)null);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/* 111 */     if (event.getStage() != 0) {
/*     */       return;
/*     */     }
/* 114 */     if (!this.timer.passedMs(((Integer)this.timeout.getValue()).intValue())) {
/* 115 */       event.setCanceled(true);
/*     */       return;
/*     */     } 
/* 118 */     doNormal(event); } private void doNormal(UpdateWalkingPlayerEvent event) {
/*     */     float direction;
/*     */     float xDir;
/*     */     float zDir;
/* 122 */     if (((Boolean)this.autoOff.getValue()).booleanValue() && this.beganJump && mc.field_71439_g.field_70122_E) {
/* 123 */       disable();
/*     */       return;
/*     */     } 
/* 126 */     switch ((Mode)this.mode.getValue()) {
/*     */       case VIRTUE:
/* 128 */         if (mc.field_71439_g.field_191988_bg != 0.0F || mc.field_71439_g.field_70702_br != 0.0F) {
/* 129 */           double xDist = mc.field_71439_g.field_70165_t - mc.field_71439_g.field_70169_q;
/* 130 */           double zDist = mc.field_71439_g.field_70161_v - mc.field_71439_g.field_70166_s;
/* 131 */           this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
/*     */           break;
/*     */         } 
/* 134 */         event.setCanceled(true);
/*     */         break;
/*     */       
/*     */       case TICK:
/* 138 */         if (event != null) {
/*     */           return;
/*     */         }
/*     */       
/*     */       case DIRECT:
/* 143 */         if (EntityUtil.isInLiquid() || EntityUtil.isOnLiquid())
/* 144 */           break;  if (mc.field_71439_g.field_70122_E) {
/* 145 */           this.lastHDistance = 0;
/*     */         }
/* 147 */         direction = mc.field_71439_g.field_70177_z + ((mc.field_71439_g.field_191988_bg < 0.0F) ? '´' : false) + ((mc.field_71439_g.field_70702_br > 0.0F) ? (-90.0F * ((mc.field_71439_g.field_191988_bg < 0.0F) ? -0.5F : ((mc.field_71439_g.field_191988_bg > 0.0F) ? 0.5F : 1.0F))) : 0.0F) - ((mc.field_71439_g.field_70702_br < 0.0F) ? (-90.0F * ((mc.field_71439_g.field_191988_bg < 0.0F) ? -0.5F : ((mc.field_71439_g.field_191988_bg > 0.0F) ? 0.5F : 1.0F))) : 0.0F);
/* 148 */         xDir = (float)Math.cos((direction + 90.0F) * Math.PI / 180.0D);
/* 149 */         zDir = (float)Math.sin((direction + 90.0F) * Math.PI / 180.0D);
/* 150 */         if (!mc.field_71439_g.field_70124_G) {
/* 151 */           this.airTicks++;
/* 152 */           this.isSpeeding = true;
/* 153 */           if (mc.field_71474_y.field_74311_E.func_151470_d()) {
/* 154 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(0.0D, 2.147483647E9D, 0.0D, false));
/*     */           }
/* 156 */           this.groundTicks = 0;
/* 157 */           if (!mc.field_71439_g.field_70124_G) {
/* 158 */             if (mc.field_71439_g.field_70181_x == -0.07190068807140403D) {
/* 159 */               mc.field_71439_g.field_70181_x *= 0.3499999940395355D;
/* 160 */             } else if (mc.field_71439_g.field_70181_x == -0.10306193759436909D) {
/* 161 */               mc.field_71439_g.field_70181_x *= 0.550000011920929D;
/* 162 */             } else if (mc.field_71439_g.field_70181_x == -0.13395038817442878D) {
/* 163 */               mc.field_71439_g.field_70181_x *= 0.6700000166893005D;
/* 164 */             } else if (mc.field_71439_g.field_70181_x == -0.16635183030382D) {
/* 165 */               mc.field_71439_g.field_70181_x *= 0.6899999976158142D;
/* 166 */             } else if (mc.field_71439_g.field_70181_x == -0.19088711097794803D) {
/* 167 */               mc.field_71439_g.field_70181_x *= 0.7099999785423279D;
/* 168 */             } else if (mc.field_71439_g.field_70181_x == -0.21121925191528862D) {
/* 169 */               mc.field_71439_g.field_70181_x *= 0.20000000298023224D;
/* 170 */             } else if (mc.field_71439_g.field_70181_x == -0.11979897632390576D) {
/* 171 */               mc.field_71439_g.field_70181_x *= 0.9300000071525574D;
/* 172 */             } else if (mc.field_71439_g.field_70181_x == -0.18758479151225355D) {
/* 173 */               mc.field_71439_g.field_70181_x *= 0.7200000286102295D;
/* 174 */             } else if (mc.field_71439_g.field_70181_x == -0.21075983825251726D) {
/* 175 */               mc.field_71439_g.field_70181_x *= 0.7599999904632568D;
/*     */             } 
/* 177 */             if (mc.field_71439_g.field_70181_x < -0.2D && mc.field_71439_g.field_70181_x > -0.24D) {
/* 178 */               mc.field_71439_g.field_70181_x *= 0.7D;
/*     */             }
/* 180 */             if (mc.field_71439_g.field_70181_x < -0.25D && mc.field_71439_g.field_70181_x > -0.32D) {
/* 181 */               mc.field_71439_g.field_70181_x *= 0.8D;
/*     */             }
/* 183 */             if (mc.field_71439_g.field_70181_x < -0.35D && mc.field_71439_g.field_70181_x > -0.8D) {
/* 184 */               mc.field_71439_g.field_70181_x *= 0.98D;
/*     */             }
/* 186 */             if (mc.field_71439_g.field_70181_x < -0.8D && mc.field_71439_g.field_70181_x > -1.6D) {
/* 187 */               mc.field_71439_g.field_70181_x *= 0.99D;
/*     */             }
/*     */           } 
/* 190 */           Phobos.timerManager.setTimer(0.85F);
/* 191 */           double[] speedVals = { 0.420606D, 0.417924D, 0.415258D, 0.412609D, 0.409977D, 0.407361D, 0.404761D, 0.402178D, 0.399611D, 0.39706D, 0.394525D, 0.392D, 0.3894D, 0.38644D, 0.383655D, 0.381105D, 0.37867D, 0.37625D, 0.37384D, 0.37145D, 0.369D, 0.3666D, 0.3642D, 0.3618D, 0.35945D, 0.357D, 0.354D, 0.351D, 0.348D, 0.345D, 0.342D, 0.339D, 0.336D, 0.333D, 0.33D, 0.327D, 0.324D, 0.321D, 0.318D, 0.315D, 0.312D, 0.309D, 0.307D, 0.305D, 0.303D, 0.3D, 0.297D, 0.295D, 0.293D, 0.291D, 0.289D, 0.287D, 0.285D, 0.283D, 0.281D, 0.279D, 0.277D, 0.275D, 0.273D, 0.271D, 0.269D, 0.267D, 0.265D, 0.263D, 0.261D, 0.259D, 0.257D, 0.255D, 0.253D, 0.251D, 0.249D, 0.247D, 0.245D, 0.243D, 0.241D, 0.239D, 0.237D };
/* 192 */           if (mc.field_71474_y.field_74351_w.field_74513_e) {
/*     */             try {
/* 194 */               mc.field_71439_g.field_70159_w = xDir * speedVals[this.airTicks - 1] * 3.0D;
/* 195 */               mc.field_71439_g.field_70179_y = zDir * speedVals[this.airTicks - 1] * 3.0D;
/*     */             }
/* 197 */             catch (ArrayIndexOutOfBoundsException e) {
/*     */               return;
/*     */             }  break;
/*     */           } 
/* 201 */           mc.field_71439_g.field_70159_w = 0.0D;
/* 202 */           mc.field_71439_g.field_70179_y = 0.0D;
/*     */           break;
/*     */         } 
/* 205 */         Phobos.timerManager.setTimer(1.0F);
/* 206 */         this.airTicks = 0;
/* 207 */         this.groundTicks++;
/* 208 */         this.headStart--;
/* 209 */         mc.field_71439_g.field_70159_w /= 13.0D;
/* 210 */         mc.field_71439_g.field_70179_y /= 13.0D;
/* 211 */         if (this.groundTicks == 1) {
/* 212 */           updatePosition(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
/* 213 */           updatePosition(mc.field_71439_g.field_70165_t + 0.0624D, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
/* 214 */           updatePosition(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.419D, mc.field_71439_g.field_70161_v);
/* 215 */           updatePosition(mc.field_71439_g.field_70165_t + 0.0624D, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
/* 216 */           updatePosition(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.419D, mc.field_71439_g.field_70161_v);
/*     */           break;
/*     */         } 
/* 219 */         if (this.groundTicks <= 2)
/* 220 */           break;  this.groundTicks = 0;
/* 221 */         mc.field_71439_g.field_70159_w = xDir * 0.3D;
/* 222 */         mc.field_71439_g.field_70179_y = zDir * 0.3D;
/* 223 */         mc.field_71439_g.field_70181_x = 0.42399999499320984D;
/* 224 */         this.beganJump = true;
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void doVirtue(MoveEvent event) {
/* 230 */     if (this.mode.getValue() == Mode.VIRTUE && (mc.field_71439_g.field_191988_bg != 0.0F || (mc.field_71439_g.field_70702_br != 0.0F && !EntityUtil.isOnLiquid() && !EntityUtil.isInLiquid()))) {
/* 231 */       if (this.stage == 0) {
/* 232 */         this.moveSpeed = ((Float)this.boost.getValue()).floatValue() * getBaseMoveSpeed();
/* 233 */       } else if (this.stage == 1) {
/* 234 */         mc.field_71439_g.field_70181_x = 0.42D;
/* 235 */         event.setY(0.42D);
/* 236 */         this.moveSpeed *= 2.149D;
/* 237 */       } else if (this.stage == 2) {
/* 238 */         double difference = 0.66D * (this.lastDist - getBaseMoveSpeed());
/* 239 */         this.moveSpeed = this.lastDist - difference;
/*     */       } else {
/* 241 */         this.moveSpeed = this.lastDist - this.lastDist / 159.0D;
/*     */       } 
/* 243 */       this.moveSpeed = Math.max(getBaseMoveSpeed(), this.moveSpeed);
/* 244 */       setMoveSpeed(event, this.moveSpeed);
/* 245 */       List collidingList = mc.field_71441_e.func_184144_a((Entity)mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72317_d(0.0D, mc.field_71439_g.field_70181_x, 0.0D));
/* 246 */       List collidingList2 = mc.field_71441_e.func_184144_a((Entity)mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72317_d(0.0D, -0.4D, 0.0D));
/* 247 */       if (!mc.field_71439_g.field_70124_G && (collidingList.size() > 0 || collidingList2.size() > 0)) {
/* 248 */         mc.field_71439_g.field_70181_x = -0.001D;
/* 249 */         event.setY(-0.001D);
/*     */       } 
/* 251 */       this.stage++;
/* 252 */     } else if (this.stage > 0) {
/* 253 */       disable();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void invalidPacket() {
/* 258 */     updatePosition(0.0D, 2.147483647E9D, 0.0D);
/*     */   }
/*     */   
/*     */   private void updatePosition(double x, double y, double z) {
/* 262 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(x, y, z, mc.field_71439_g.field_70122_E));
/*     */   }
/*     */   
/*     */   private Block getBlock(BlockPos pos) {
/* 266 */     return mc.field_71441_e.func_180495_p(pos).func_177230_c();
/*     */   }
/*     */   
/*     */   private double getDistance(EntityPlayer player, double distance) {
/* 270 */     List<AxisAlignedBB> boundingBoxes = player.field_70170_p.func_184144_a((Entity)player, player.func_174813_aQ().func_72317_d(0.0D, -distance, 0.0D));
/* 271 */     if (boundingBoxes.isEmpty()) {
/* 272 */       return 0.0D;
/*     */     }
/* 274 */     double y = 0.0D;
/* 275 */     for (AxisAlignedBB boundingBox : boundingBoxes) {
/* 276 */       if (boundingBox.field_72337_e <= y)
/* 277 */         continue;  y = boundingBox.field_72337_e;
/*     */     } 
/* 279 */     return player.field_70163_u - y;
/*     */   }
/*     */   
/*     */   private void setMoveSpeed(MoveEvent event, double speed) {
/* 283 */     MovementInput movementInput = mc.field_71439_g.field_71158_b;
/* 284 */     double forward = movementInput.field_192832_b;
/* 285 */     double strafe = movementInput.field_78902_a;
/* 286 */     float yaw = mc.field_71439_g.field_70177_z;
/* 287 */     if (forward == 0.0D && strafe == 0.0D) {
/* 288 */       event.setX(0.0D);
/* 289 */       event.setZ(0.0D);
/*     */     } else {
/* 291 */       if (forward != 0.0D) {
/* 292 */         if (strafe > 0.0D) {
/* 293 */           yaw += ((forward > 0.0D) ? -45 : 45);
/* 294 */         } else if (strafe < 0.0D) {
/* 295 */           yaw += ((forward > 0.0D) ? 45 : -45);
/*     */         } 
/* 297 */         strafe = 0.0D;
/* 298 */         if (forward > 0.0D) {
/* 299 */           forward = 1.0D;
/* 300 */         } else if (forward < 0.0D) {
/* 301 */           forward = -1.0D;
/*     */         } 
/*     */       } 
/* 304 */       event.setX(forward * speed * Math.cos(Math.toRadians((yaw + 90.0F))) + strafe * speed * Math.sin(Math.toRadians((yaw + 90.0F))));
/* 305 */       event.setZ(forward * speed * Math.sin(Math.toRadians((yaw + 90.0F))) - strafe * speed * Math.cos(Math.toRadians((yaw + 90.0F))));
/*     */     } 
/*     */   }
/*     */   
/*     */   private double getBaseMoveSpeed() {
/* 310 */     double baseSpeed = 0.2873D;
/* 311 */     if (mc.field_71439_g != null && mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
/* 312 */       int amplifier = ((PotionEffect)Objects.<PotionEffect>requireNonNull(mc.field_71439_g.func_70660_b(MobEffects.field_76424_c))).func_76458_c();
/* 313 */       baseSpeed *= 1.0D + 0.2D * (amplifier + 1);
/*     */     } 
/* 315 */     return baseSpeed;
/*     */   }
/*     */   
/*     */   public enum Mode {
/* 319 */     VIRTUE,
/* 320 */     DIRECT,
/* 321 */     TICK;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\movement\LongJump.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */