/*     */ package me.earth.phobos.features.modules.movement;
/*     */ 
/*     */ import java.util.Random;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.ClientEvent;
/*     */ import me.earth.phobos.event.events.MoveEvent;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.BlockUtil;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.MathUtil;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.MovementInput;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class Speed
/*     */   extends Module
/*     */ {
/*  19 */   private static Speed INSTANCE = new Speed();
/*  20 */   public Setting<Mode> mode = register(new Setting("Mode", Mode.INSTANT));
/*  21 */   public Setting<Boolean> strafeJump = register(new Setting("Jump", Boolean.valueOf(false), v -> (this.mode.getValue() == Mode.INSTANT)));
/*  22 */   public Setting<Boolean> noShake = register(new Setting("NoShake", Boolean.valueOf(true), v -> (this.mode.getValue() != Mode.INSTANT)));
/*  23 */   public Setting<Boolean> useTimer = register(new Setting("UseTimer", Boolean.valueOf(false), v -> (this.mode.getValue() != Mode.INSTANT)));
/*  24 */   public double startY = 0.0D;
/*     */   public boolean antiShake = false;
/*  26 */   private double highChainVal = 0.0D;
/*  27 */   private double lowChainVal = 0.0D;
/*     */   private boolean oneTime = false;
/*  29 */   private double bounceHeight = 0.4D;
/*  30 */   private float move = 0.26F;
/*     */   
/*     */   public Speed() {
/*  33 */     super("Speed", "Makes you faster", Module.Category.MOVEMENT, true, false, false);
/*  34 */     setInstance();
/*     */   }
/*     */   
/*     */   public static Speed getInstance() {
/*  38 */     if (INSTANCE == null) {
/*  39 */       INSTANCE = new Speed();
/*     */     }
/*  41 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  45 */     INSTANCE = this;
/*     */   }
/*     */   
/*     */   private boolean shouldReturn() {
/*  49 */     return (Phobos.moduleManager.isModuleEnabled("Freecam") || Phobos.moduleManager.isModuleEnabled("Phase") || Phobos.moduleManager.isModuleEnabled("ElytraFlight") || Phobos.moduleManager.isModuleEnabled("Strafe") || Phobos.moduleManager.isModuleEnabled("Flight"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  54 */     if (shouldReturn() || mc.field_71439_g.func_70093_af() || mc.field_71439_g.func_70090_H() || mc.field_71439_g.func_180799_ab()) {
/*     */       return;
/*     */     }
/*  57 */     switch ((Mode)this.mode.getValue()) {
/*     */       case BOOST:
/*  59 */         doBoost();
/*     */         break;
/*     */       
/*     */       case ACCEL:
/*  63 */         doAccel();
/*     */         break;
/*     */       
/*     */       case ONGROUND:
/*  67 */         doOnground();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void doBoost() {
/*  74 */     this.bounceHeight = 0.4D;
/*  75 */     this.move = 0.26F;
/*  76 */     if (mc.field_71439_g.field_70122_E) {
/*  77 */       this.startY = mc.field_71439_g.field_70163_u;
/*     */     }
/*  79 */     if (EntityUtil.getEntitySpeed((Entity)mc.field_71439_g) <= 1.0D) {
/*  80 */       this.lowChainVal = 1.0D;
/*  81 */       this.highChainVal = 1.0D;
/*     */     } 
/*  83 */     if (EntityUtil.isEntityMoving((Entity)mc.field_71439_g) && !mc.field_71439_g.field_70123_F && !BlockUtil.isBlockAboveEntitySolid((Entity)mc.field_71439_g) && BlockUtil.isBlockBelowEntitySolid((Entity)mc.field_71439_g)) {
/*  84 */       this.oneTime = true;
/*  85 */       this.antiShake = (((Boolean)this.noShake.getValue()).booleanValue() && mc.field_71439_g.func_184187_bx() == null);
/*  86 */       Random random = new Random();
/*  87 */       boolean rnd = random.nextBoolean();
/*  88 */       if (mc.field_71439_g.field_70163_u >= this.startY + this.bounceHeight) {
/*  89 */         mc.field_71439_g.field_70181_x = -this.bounceHeight;
/*  90 */         this.lowChainVal++;
/*  91 */         if (this.lowChainVal == 1.0D) {
/*  92 */           this.move = 0.075F;
/*     */         }
/*  94 */         if (this.lowChainVal == 2.0D) {
/*  95 */           this.move = 0.15F;
/*     */         }
/*  97 */         if (this.lowChainVal == 3.0D) {
/*  98 */           this.move = 0.175F;
/*     */         }
/* 100 */         if (this.lowChainVal == 4.0D) {
/* 101 */           this.move = 0.2F;
/*     */         }
/* 103 */         if (this.lowChainVal == 5.0D) {
/* 104 */           this.move = 0.225F;
/*     */         }
/* 106 */         if (this.lowChainVal == 6.0D) {
/* 107 */           this.move = 0.25F;
/*     */         }
/* 109 */         if (this.lowChainVal >= 7.0D) {
/* 110 */           this.move = 0.27895F;
/*     */         }
/* 112 */         if (((Boolean)this.useTimer.getValue()).booleanValue()) {
/* 113 */           Phobos.timerManager.setTimer(1.0F);
/*     */         }
/*     */       } 
/* 116 */       if (mc.field_71439_g.field_70163_u == this.startY) {
/* 117 */         mc.field_71439_g.field_70181_x = this.bounceHeight;
/* 118 */         this.highChainVal++;
/* 119 */         if (this.highChainVal == 1.0D) {
/* 120 */           this.move = 0.075F;
/*     */         }
/* 122 */         if (this.highChainVal == 2.0D) {
/* 123 */           this.move = 0.175F;
/*     */         }
/* 125 */         if (this.highChainVal == 3.0D) {
/* 126 */           this.move = 0.325F;
/*     */         }
/* 128 */         if (this.highChainVal == 4.0D) {
/* 129 */           this.move = 0.375F;
/*     */         }
/* 131 */         if (this.highChainVal == 5.0D) {
/* 132 */           this.move = 0.4F;
/*     */         }
/* 134 */         if (this.highChainVal >= 6.0D) {
/* 135 */           this.move = 0.43395F;
/*     */         }
/* 137 */         if (((Boolean)this.useTimer.getValue()).booleanValue()) {
/* 138 */           if (rnd) {
/* 139 */             Phobos.timerManager.setTimer(1.3F);
/*     */           } else {
/* 141 */             Phobos.timerManager.setTimer(1.0F);
/*     */           } 
/*     */         }
/*     */       } 
/* 145 */       EntityUtil.moveEntityStrafe(this.move, (Entity)mc.field_71439_g);
/*     */     } else {
/* 147 */       if (this.oneTime) {
/* 148 */         mc.field_71439_g.field_70181_x = -0.1D;
/* 149 */         this.oneTime = false;
/*     */       } 
/* 151 */       this.highChainVal = 0.0D;
/* 152 */       this.lowChainVal = 0.0D;
/* 153 */       this.antiShake = false;
/* 154 */       speedOff();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void doAccel() {
/* 159 */     this.bounceHeight = 0.4D;
/* 160 */     this.move = 0.26F;
/* 161 */     if (mc.field_71439_g.field_70122_E) {
/* 162 */       this.startY = mc.field_71439_g.field_70163_u;
/*     */     }
/* 164 */     if (EntityUtil.getEntitySpeed((Entity)mc.field_71439_g) <= 1.0D) {
/* 165 */       this.lowChainVal = 1.0D;
/* 166 */       this.highChainVal = 1.0D;
/*     */     } 
/* 168 */     if (EntityUtil.isEntityMoving((Entity)mc.field_71439_g) && !mc.field_71439_g.field_70123_F && !BlockUtil.isBlockAboveEntitySolid((Entity)mc.field_71439_g) && BlockUtil.isBlockBelowEntitySolid((Entity)mc.field_71439_g)) {
/* 169 */       this.oneTime = true;
/* 170 */       this.antiShake = (((Boolean)this.noShake.getValue()).booleanValue() && mc.field_71439_g.func_184187_bx() == null);
/* 171 */       Random random = new Random();
/* 172 */       boolean rnd = random.nextBoolean();
/* 173 */       if (mc.field_71439_g.field_70163_u >= this.startY + this.bounceHeight) {
/* 174 */         mc.field_71439_g.field_70181_x = -this.bounceHeight;
/* 175 */         this.lowChainVal++;
/* 176 */         if (this.lowChainVal == 1.0D) {
/* 177 */           this.move = 0.075F;
/*     */         }
/* 179 */         if (this.lowChainVal == 2.0D) {
/* 180 */           this.move = 0.175F;
/*     */         }
/* 182 */         if (this.lowChainVal == 3.0D) {
/* 183 */           this.move = 0.275F;
/*     */         }
/* 185 */         if (this.lowChainVal == 4.0D) {
/* 186 */           this.move = 0.35F;
/*     */         }
/* 188 */         if (this.lowChainVal == 5.0D) {
/* 189 */           this.move = 0.375F;
/*     */         }
/* 191 */         if (this.lowChainVal == 6.0D) {
/* 192 */           this.move = 0.4F;
/*     */         }
/* 194 */         if (this.lowChainVal == 7.0D) {
/* 195 */           this.move = 0.425F;
/*     */         }
/* 197 */         if (this.lowChainVal == 8.0D) {
/* 198 */           this.move = 0.45F;
/*     */         }
/* 200 */         if (this.lowChainVal == 9.0D) {
/* 201 */           this.move = 0.475F;
/*     */         }
/* 203 */         if (this.lowChainVal == 10.0D) {
/* 204 */           this.move = 0.5F;
/*     */         }
/* 206 */         if (this.lowChainVal == 11.0D) {
/* 207 */           this.move = 0.5F;
/*     */         }
/* 209 */         if (this.lowChainVal == 12.0D) {
/* 210 */           this.move = 0.525F;
/*     */         }
/* 212 */         if (this.lowChainVal == 13.0D) {
/* 213 */           this.move = 0.525F;
/*     */         }
/* 215 */         if (this.lowChainVal == 14.0D) {
/* 216 */           this.move = 0.535F;
/*     */         }
/* 218 */         if (this.lowChainVal == 15.0D) {
/* 219 */           this.move = 0.535F;
/*     */         }
/* 221 */         if (this.lowChainVal == 16.0D) {
/* 222 */           this.move = 0.545F;
/*     */         }
/* 224 */         if (this.lowChainVal >= 17.0D) {
/* 225 */           this.move = 0.545F;
/*     */         }
/* 227 */         if (((Boolean)this.useTimer.getValue()).booleanValue()) {
/* 228 */           Phobos.timerManager.setTimer(1.0F);
/*     */         }
/*     */       } 
/* 231 */       if (mc.field_71439_g.field_70163_u == this.startY) {
/* 232 */         mc.field_71439_g.field_70181_x = this.bounceHeight;
/* 233 */         this.highChainVal++;
/* 234 */         if (this.highChainVal == 1.0D) {
/* 235 */           this.move = 0.075F;
/*     */         }
/* 237 */         if (this.highChainVal == 2.0D) {
/* 238 */           this.move = 0.175F;
/*     */         }
/* 240 */         if (this.highChainVal == 3.0D) {
/* 241 */           this.move = 0.375F;
/*     */         }
/* 243 */         if (this.highChainVal == 4.0D) {
/* 244 */           this.move = 0.6F;
/*     */         }
/* 246 */         if (this.highChainVal == 5.0D) {
/* 247 */           this.move = 0.775F;
/*     */         }
/* 249 */         if (this.highChainVal == 6.0D) {
/* 250 */           this.move = 0.825F;
/*     */         }
/* 252 */         if (this.highChainVal == 7.0D) {
/* 253 */           this.move = 0.875F;
/*     */         }
/* 255 */         if (this.highChainVal == 8.0D) {
/* 256 */           this.move = 0.925F;
/*     */         }
/* 258 */         if (this.highChainVal == 9.0D) {
/* 259 */           this.move = 0.975F;
/*     */         }
/* 261 */         if (this.highChainVal == 10.0D) {
/* 262 */           this.move = 1.05F;
/*     */         }
/* 264 */         if (this.highChainVal == 11.0D) {
/* 265 */           this.move = 1.1F;
/*     */         }
/* 267 */         if (this.highChainVal == 12.0D) {
/* 268 */           this.move = 1.1F;
/*     */         }
/* 270 */         if (this.highChainVal == 13.0D) {
/* 271 */           this.move = 1.15F;
/*     */         }
/* 273 */         if (this.highChainVal == 14.0D) {
/* 274 */           this.move = 1.15F;
/*     */         }
/* 276 */         if (this.highChainVal == 15.0D) {
/* 277 */           this.move = 1.175F;
/*     */         }
/* 279 */         if (this.highChainVal == 16.0D) {
/* 280 */           this.move = 1.175F;
/*     */         }
/* 282 */         if (this.highChainVal >= 17.0D) {
/* 283 */           this.move = 1.175F;
/*     */         }
/* 285 */         if (((Boolean)this.useTimer.getValue()).booleanValue()) {
/* 286 */           if (rnd) {
/* 287 */             Phobos.timerManager.setTimer(1.3F);
/*     */           } else {
/* 289 */             Phobos.timerManager.setTimer(1.0F);
/*     */           } 
/*     */         }
/*     */       } 
/* 293 */       EntityUtil.moveEntityStrafe(this.move, (Entity)mc.field_71439_g);
/*     */     } else {
/* 295 */       if (this.oneTime) {
/* 296 */         mc.field_71439_g.field_70181_x = -0.1D;
/* 297 */         this.oneTime = false;
/*     */       } 
/* 299 */       this.antiShake = false;
/* 300 */       this.highChainVal = 0.0D;
/* 301 */       this.lowChainVal = 0.0D;
/* 302 */       speedOff();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void doOnground() {
/* 307 */     this.bounceHeight = 0.4D;
/* 308 */     this.move = 0.26F;
/* 309 */     if (mc.field_71439_g.field_70122_E) {
/* 310 */       this.startY = mc.field_71439_g.field_70163_u;
/*     */     }
/* 312 */     if (EntityUtil.getEntitySpeed((Entity)mc.field_71439_g) <= 1.0D) {
/* 313 */       this.lowChainVal = 1.0D;
/* 314 */       this.highChainVal = 1.0D;
/*     */     } 
/* 316 */     if (EntityUtil.isEntityMoving((Entity)mc.field_71439_g) && !mc.field_71439_g.field_70123_F && !BlockUtil.isBlockAboveEntitySolid((Entity)mc.field_71439_g) && BlockUtil.isBlockBelowEntitySolid((Entity)mc.field_71439_g)) {
/* 317 */       this.oneTime = true;
/* 318 */       this.antiShake = (((Boolean)this.noShake.getValue()).booleanValue() && mc.field_71439_g.func_184187_bx() == null);
/* 319 */       Random random = new Random();
/* 320 */       boolean rnd = random.nextBoolean();
/* 321 */       if (mc.field_71439_g.field_70163_u >= this.startY + this.bounceHeight) {
/* 322 */         mc.field_71439_g.field_70181_x = -this.bounceHeight;
/* 323 */         this.lowChainVal++;
/* 324 */         if (this.lowChainVal == 1.0D) {
/* 325 */           this.move = 0.075F;
/*     */         }
/* 327 */         if (this.lowChainVal == 2.0D) {
/* 328 */           this.move = 0.175F;
/*     */         }
/* 330 */         if (this.lowChainVal == 3.0D) {
/* 331 */           this.move = 0.275F;
/*     */         }
/* 333 */         if (this.lowChainVal == 4.0D) {
/* 334 */           this.move = 0.35F;
/*     */         }
/* 336 */         if (this.lowChainVal == 5.0D) {
/* 337 */           this.move = 0.375F;
/*     */         }
/* 339 */         if (this.lowChainVal == 6.0D) {
/* 340 */           this.move = 0.4F;
/*     */         }
/* 342 */         if (this.lowChainVal == 7.0D) {
/* 343 */           this.move = 0.425F;
/*     */         }
/* 345 */         if (this.lowChainVal == 8.0D) {
/* 346 */           this.move = 0.45F;
/*     */         }
/* 348 */         if (this.lowChainVal == 9.0D) {
/* 349 */           this.move = 0.475F;
/*     */         }
/* 351 */         if (this.lowChainVal == 10.0D) {
/* 352 */           this.move = 0.5F;
/*     */         }
/* 354 */         if (this.lowChainVal == 11.0D) {
/* 355 */           this.move = 0.5F;
/*     */         }
/* 357 */         if (this.lowChainVal == 12.0D) {
/* 358 */           this.move = 0.525F;
/*     */         }
/* 360 */         if (this.lowChainVal == 13.0D) {
/* 361 */           this.move = 0.525F;
/*     */         }
/* 363 */         if (this.lowChainVal == 14.0D) {
/* 364 */           this.move = 0.535F;
/*     */         }
/* 366 */         if (this.lowChainVal == 15.0D) {
/* 367 */           this.move = 0.535F;
/*     */         }
/* 369 */         if (this.lowChainVal == 16.0D) {
/* 370 */           this.move = 0.545F;
/*     */         }
/* 372 */         if (this.lowChainVal >= 17.0D) {
/* 373 */           this.move = 0.545F;
/*     */         }
/* 375 */         if (((Boolean)this.useTimer.getValue()).booleanValue()) {
/* 376 */           Phobos.timerManager.setTimer(1.0F);
/*     */         }
/*     */       } 
/* 379 */       if (mc.field_71439_g.field_70163_u == this.startY) {
/* 380 */         mc.field_71439_g.field_70181_x = this.bounceHeight;
/* 381 */         this.highChainVal++;
/* 382 */         if (this.highChainVal == 1.0D) {
/* 383 */           this.move = 0.075F;
/*     */         }
/* 385 */         if (this.highChainVal == 2.0D) {
/* 386 */           this.move = 0.175F;
/*     */         }
/* 388 */         if (this.highChainVal == 3.0D) {
/* 389 */           this.move = 0.375F;
/*     */         }
/* 391 */         if (this.highChainVal == 4.0D) {
/* 392 */           this.move = 0.6F;
/*     */         }
/* 394 */         if (this.highChainVal == 5.0D) {
/* 395 */           this.move = 0.775F;
/*     */         }
/* 397 */         if (this.highChainVal == 6.0D) {
/* 398 */           this.move = 0.825F;
/*     */         }
/* 400 */         if (this.highChainVal == 7.0D) {
/* 401 */           this.move = 0.875F;
/*     */         }
/* 403 */         if (this.highChainVal == 8.0D) {
/* 404 */           this.move = 0.925F;
/*     */         }
/* 406 */         if (this.highChainVal == 9.0D) {
/* 407 */           this.move = 0.975F;
/*     */         }
/* 409 */         if (this.highChainVal == 10.0D) {
/* 410 */           this.move = 1.05F;
/*     */         }
/* 412 */         if (this.highChainVal == 11.0D) {
/* 413 */           this.move = 1.1F;
/*     */         }
/* 415 */         if (this.highChainVal == 12.0D) {
/* 416 */           this.move = 1.1F;
/*     */         }
/* 418 */         if (this.highChainVal == 13.0D) {
/* 419 */           this.move = 1.15F;
/*     */         }
/* 421 */         if (this.highChainVal == 14.0D) {
/* 422 */           this.move = 1.15F;
/*     */         }
/* 424 */         if (this.highChainVal == 15.0D) {
/* 425 */           this.move = 1.175F;
/*     */         }
/* 427 */         if (this.highChainVal == 16.0D) {
/* 428 */           this.move = 1.175F;
/*     */         }
/* 430 */         if (this.highChainVal >= 17.0D) {
/* 431 */           this.move = 1.2F;
/*     */         }
/* 433 */         if (((Boolean)this.useTimer.getValue()).booleanValue()) {
/* 434 */           if (rnd) {
/* 435 */             Phobos.timerManager.setTimer(1.3F);
/*     */           } else {
/* 437 */             Phobos.timerManager.setTimer(1.0F);
/*     */           } 
/*     */         }
/*     */       } 
/* 441 */       EntityUtil.moveEntityStrafe(this.move, (Entity)mc.field_71439_g);
/*     */     } else {
/* 443 */       if (this.oneTime) {
/* 444 */         mc.field_71439_g.field_70181_x = -0.1D;
/* 445 */         this.oneTime = false;
/*     */       } 
/* 447 */       this.antiShake = false;
/* 448 */       this.highChainVal = 0.0D;
/* 449 */       this.lowChainVal = 0.0D;
/* 450 */       speedOff();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 456 */     if (this.mode.getValue() == Mode.ONGROUND || this.mode.getValue() == Mode.BOOST) {
/* 457 */       mc.field_71439_g.field_70181_x = -0.1D;
/*     */     }
/* 459 */     Phobos.timerManager.setTimer(1.0F);
/* 460 */     this.highChainVal = 0.0D;
/* 461 */     this.lowChainVal = 0.0D;
/* 462 */     this.antiShake = false;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onSettingChange(ClientEvent event) {
/* 467 */     if (event.getStage() == 2 && event.getSetting().equals(this.mode) && this.mode.getPlannedValue() == Mode.INSTANT) {
/* 468 */       mc.field_71439_g.field_70181_x = -0.1D;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/* 474 */     return this.mode.currentEnumName();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMode(MoveEvent event) {
/* 479 */     if (!shouldReturn() && event.getStage() == 0 && this.mode.getValue() == Mode.INSTANT && !nullCheck() && !mc.field_71439_g.func_70093_af() && !mc.field_71439_g.func_70090_H() && !mc.field_71439_g.func_180799_ab() && (mc.field_71439_g.field_71158_b.field_192832_b != 0.0F || mc.field_71439_g.field_71158_b.field_78902_a != 0.0F)) {
/* 480 */       if (mc.field_71439_g.field_70122_E && ((Boolean)this.strafeJump.getValue()).booleanValue()) {
/* 481 */         mc.field_71439_g.field_70181_x = 0.4D;
/* 482 */         event.setY(0.4D);
/*     */       } 
/* 484 */       MovementInput movementInput = mc.field_71439_g.field_71158_b;
/* 485 */       float moveForward = movementInput.field_192832_b;
/* 486 */       float moveStrafe = movementInput.field_78902_a;
/* 487 */       float rotationYaw = mc.field_71439_g.field_70177_z;
/* 488 */       if (moveForward == 0.0D && moveStrafe == 0.0D) {
/* 489 */         event.setX(0.0D);
/* 490 */         event.setZ(0.0D);
/*     */       } else {
/* 492 */         if (moveForward != 0.0D) {
/* 493 */           if (moveStrafe > 0.0D) {
/* 494 */             rotationYaw += ((moveForward > 0.0D) ? -45 : 45);
/* 495 */           } else if (moveStrafe < 0.0D) {
/* 496 */             rotationYaw += ((moveForward > 0.0D) ? 45 : -45);
/*     */           } 
/* 498 */           moveStrafe = 0.0F;
/* 499 */           float f = (moveForward == 0.0F) ? moveForward : (moveForward = (moveForward > 0.0D) ? 1.0F : -1.0F);
/*     */         } 
/* 501 */         moveStrafe = (moveStrafe == 0.0F) ? moveStrafe : ((moveStrafe > 0.0D) ? 1.0F : -1.0F);
/* 502 */         event.setX(moveForward * EntityUtil.getMaxSpeed() * Math.cos(Math.toRadians((rotationYaw + 90.0F))) + moveStrafe * EntityUtil.getMaxSpeed() * Math.sin(Math.toRadians((rotationYaw + 90.0F))));
/* 503 */         event.setZ(moveForward * EntityUtil.getMaxSpeed() * Math.sin(Math.toRadians((rotationYaw + 90.0F))) - moveStrafe * EntityUtil.getMaxSpeed() * Math.cos(Math.toRadians((rotationYaw + 90.0F))));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void speedOff() {
/* 509 */     float yaw = (float)Math.toRadians(mc.field_71439_g.field_70177_z);
/* 510 */     if (BlockUtil.isBlockAboveEntitySolid((Entity)mc.field_71439_g)) {
/* 511 */       if (mc.field_71474_y.field_74351_w.func_151470_d() && !mc.field_71474_y.field_74311_E.func_151470_d() && mc.field_71439_g.field_70122_E) {
/* 512 */         mc.field_71439_g.field_70159_w -= MathUtil.sin(yaw) * 0.15D;
/* 513 */         mc.field_71439_g.field_70179_y += MathUtil.cos(yaw) * 0.15D;
/*     */       } 
/* 515 */     } else if (mc.field_71439_g.field_70123_F) {
/* 516 */       if (mc.field_71474_y.field_74351_w.func_151470_d() && !mc.field_71474_y.field_74311_E.func_151470_d() && mc.field_71439_g.field_70122_E) {
/* 517 */         mc.field_71439_g.field_70159_w -= MathUtil.sin(yaw) * 0.03D;
/* 518 */         mc.field_71439_g.field_70179_y += MathUtil.cos(yaw) * 0.03D;
/*     */       } 
/* 520 */     } else if (!BlockUtil.isBlockBelowEntitySolid((Entity)mc.field_71439_g)) {
/* 521 */       if (mc.field_71474_y.field_74351_w.func_151470_d() && !mc.field_71474_y.field_74311_E.func_151470_d() && mc.field_71439_g.field_70122_E) {
/* 522 */         mc.field_71439_g.field_70159_w -= MathUtil.sin(yaw) * 0.03D;
/* 523 */         mc.field_71439_g.field_70179_y += MathUtil.cos(yaw) * 0.03D;
/*     */       } 
/*     */     } else {
/* 526 */       mc.field_71439_g.field_70159_w = 0.0D;
/* 527 */       mc.field_71439_g.field_70179_y = 0.0D;
/*     */     } 
/*     */   }
/*     */   
/*     */   public enum Mode {
/* 532 */     INSTANT,
/* 533 */     ONGROUND,
/* 534 */     ACCEL,
/* 535 */     BOOST;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\movement\Speed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */