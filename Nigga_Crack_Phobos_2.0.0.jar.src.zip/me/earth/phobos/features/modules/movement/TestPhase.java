/*     */ package me.earth.phobos.features.modules.movement;
/*     */ 
/*     */ import io.netty.util.internal.ConcurrentSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import me.earth.phobos.event.events.MoveEvent;
/*     */ import me.earth.phobos.event.events.PacketEvent;
/*     */ import me.earth.phobos.event.events.PushEvent;
/*     */ import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
/*     */ import me.earth.phobos.features.Feature;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketConfirmTeleport;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.server.SPacketPlayerPosLook;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ public class TestPhase
/*     */   extends Module
/*     */ {
/*     */   private static TestPhase instance;
/*  30 */   private final Set<CPacketPlayer> packets = (Set<CPacketPlayer>)new ConcurrentSet();
/*  31 */   private final Map<Integer, IDtime> teleportmap = new ConcurrentHashMap<>();
/*  32 */   public Setting<Boolean> flight = register(new Setting("Flight", Boolean.valueOf(true)));
/*  33 */   public Setting<Integer> flightMode = register(new Setting("FMode", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1)));
/*  34 */   public Setting<Boolean> doAntiFactor = register(new Setting("Factorize", Boolean.valueOf(true)));
/*  35 */   public Setting<Double> antiFactor = register(new Setting("AntiFactor", Double.valueOf(2.5D), Double.valueOf(0.1D), Double.valueOf(3.0D)));
/*  36 */   public Setting<Double> extraFactor = register(new Setting("ExtraFactor", Double.valueOf(1.0D), Double.valueOf(0.1D), Double.valueOf(3.0D)));
/*  37 */   public Setting<Boolean> strafeFactor = register(new Setting("StrafeFactor", Boolean.valueOf(true)));
/*  38 */   public Setting<Integer> loops = register(new Setting("Loops", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(10)));
/*  39 */   public Setting<Boolean> clearTeleMap = register(new Setting("ClearMap", Boolean.valueOf(true)));
/*  40 */   public Setting<Integer> mapTime = register(new Setting("ClearTime", Integer.valueOf(30), Integer.valueOf(1), Integer.valueOf(500)));
/*  41 */   public Setting<Boolean> clearIDs = register(new Setting("ClearIDs", Boolean.valueOf(true)));
/*  42 */   public Setting<Boolean> setYaw = register(new Setting("SetYaw", Boolean.valueOf(true)));
/*  43 */   public Setting<Boolean> setID = register(new Setting("SetID", Boolean.valueOf(true)));
/*  44 */   public Setting<Boolean> setMove = register(new Setting("SetMove", Boolean.valueOf(false)));
/*  45 */   public Setting<Boolean> nocliperino = register(new Setting("NoClip", Boolean.valueOf(false)));
/*  46 */   public Setting<Boolean> sendTeleport = register(new Setting("Teleport", Boolean.valueOf(true)));
/*  47 */   public Setting<Boolean> resetID = register(new Setting("ResetID", Boolean.valueOf(true)));
/*  48 */   public Setting<Boolean> setPos = register(new Setting("SetPos", Boolean.valueOf(false)));
/*  49 */   public Setting<Boolean> invalidPacket = register(new Setting("InvalidPacket", Boolean.valueOf(true)));
/*  50 */   private int flightCounter = 0;
/*  51 */   private int teleportID = 0;
/*     */   
/*     */   public TestPhase() {
/*  54 */     super("Packetfly", "Uses packets to fly!", Module.Category.MOVEMENT, true, false, false);
/*  55 */     instance = this;
/*     */   }
/*     */   
/*     */   public static TestPhase getInstance() {
/*  59 */     if (instance == null) {
/*  60 */       instance = new TestPhase();
/*     */     }
/*  62 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onToggle() {}
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  71 */     this.teleportmap.entrySet().removeIf(idTime -> (((Boolean)this.clearTeleMap.getValue()).booleanValue() && ((IDtime)idTime.getValue()).getTimer().passedS(((Integer)this.mapTime.getValue()).intValue())));
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/*  76 */     if (event.getStage() == 1) {
/*     */       return;
/*     */     }
/*  79 */     mc.field_71439_g.func_70016_h(0.0D, 0.0D, 0.0D);
/*  80 */     double speed = 0.0D;
/*  81 */     boolean checkCollisionBoxes = checkHitBoxes();
/*  82 */     speed = (mc.field_71439_g.field_71158_b.field_78901_c && (checkCollisionBoxes || !EntityUtil.isMoving())) ? ((((Boolean)this.flight.getValue()).booleanValue() && !checkCollisionBoxes) ? ((((Integer)this.flightMode.getValue()).intValue() == 0) ? (resetCounter(10) ? -0.032D : 0.062D) : (resetCounter(20) ? -0.032D : 0.062D)) : 0.062D) : (mc.field_71439_g.field_71158_b.field_78899_d ? -0.062D : (!checkCollisionBoxes ? (resetCounter(4) ? (((Boolean)this.flight.getValue()).booleanValue() ? -0.04D : 0.0D) : 0.0D) : 0.0D));
/*  83 */     if (((Boolean)this.doAntiFactor.getValue()).booleanValue() && checkCollisionBoxes && EntityUtil.isMoving() && speed != 0.0D) {
/*  84 */       speed /= ((Double)this.antiFactor.getValue()).doubleValue();
/*     */     }
/*  86 */     double[] strafing = getMotion((((Boolean)this.strafeFactor.getValue()).booleanValue() && checkCollisionBoxes) ? 0.031D : 0.26D);
/*  87 */     for (int i = 1; i < ((Integer)this.loops.getValue()).intValue() + 1; i++) {
/*  88 */       mc.field_71439_g.field_70159_w = strafing[0] * i * ((Double)this.extraFactor.getValue()).doubleValue();
/*  89 */       mc.field_71439_g.field_70181_x = speed * i;
/*  90 */       mc.field_71439_g.field_70179_y = strafing[1] * i * ((Double)this.extraFactor.getValue()).doubleValue();
/*  91 */       sendPackets(mc.field_71439_g.field_70159_w, mc.field_71439_g.field_70181_x, mc.field_71439_g.field_70179_y, ((Boolean)this.sendTeleport.getValue()).booleanValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMove(MoveEvent event) {
/*  97 */     if (((Boolean)this.setMove.getValue()).booleanValue() && this.flightCounter != 0) {
/*  98 */       event.setX(mc.field_71439_g.field_70159_w);
/*  99 */       event.setY(mc.field_71439_g.field_70181_x);
/* 100 */       event.setZ(mc.field_71439_g.field_70179_y);
/* 101 */       if (((Boolean)this.nocliperino.getValue()).booleanValue() && checkHitBoxes()) {
/* 102 */         mc.field_71439_g.field_70145_X = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.Send event) {
/*     */     CPacketPlayer packet;
/* 110 */     if (event.getPacket() instanceof CPacketPlayer && !this.packets.remove(packet = (CPacketPlayer)event.getPacket())) {
/* 111 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPushOutOfBlocks(PushEvent event) {
/* 117 */     if (event.getStage() == 1) {
/* 118 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.Receive event) {
/* 124 */     if (event.getPacket() instanceof SPacketPlayerPosLook && !Feature.fullNullCheck()) {
/* 125 */       SPacketPlayerPosLook packet = (SPacketPlayerPosLook)event.getPacket();
/*     */ 
/*     */       
/*     */       BlockPos pos;
/*     */       
/* 130 */       if (mc.field_71439_g.func_70089_S() && mc.field_71441_e.func_175668_a(pos = new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v), false) && !(mc.field_71462_r instanceof net.minecraft.client.gui.GuiDownloadTerrain) && ((Boolean)this.clearIDs.getValue()).booleanValue()) {
/* 131 */         this.teleportmap.remove(Integer.valueOf(packet.func_186965_f()));
/*     */       }
/* 133 */       if (((Boolean)this.setYaw.getValue()).booleanValue()) {
/* 134 */         packet.field_148936_d = mc.field_71439_g.field_70177_z;
/* 135 */         packet.field_148937_e = mc.field_71439_g.field_70125_A;
/*     */       } 
/* 137 */       if (((Boolean)this.setID.getValue()).booleanValue()) {
/* 138 */         this.teleportID = packet.func_186965_f();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean checkHitBoxes() {
/* 144 */     return !mc.field_71441_e.func_184144_a((Entity)mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72321_a(-0.0625D, -0.0625D, -0.0625D)).isEmpty();
/*     */   }
/*     */   
/*     */   private boolean resetCounter(int counter) {
/* 148 */     if (++this.flightCounter >= counter) {
/* 149 */       this.flightCounter = 0;
/* 150 */       return true;
/*     */     } 
/* 152 */     return false;
/*     */   }
/*     */   
/*     */   private double[] getMotion(double speed) {
/* 156 */     float moveForward = mc.field_71439_g.field_71158_b.field_192832_b;
/* 157 */     float moveStrafe = mc.field_71439_g.field_71158_b.field_78902_a;
/* 158 */     float rotationYaw = mc.field_71439_g.field_70126_B + (mc.field_71439_g.field_70177_z - mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
/* 159 */     if (moveForward != 0.0F) {
/* 160 */       if (moveStrafe > 0.0F) {
/* 161 */         rotationYaw += ((moveForward > 0.0F) ? -45 : 45);
/* 162 */       } else if (moveStrafe < 0.0F) {
/* 163 */         rotationYaw += ((moveForward > 0.0F) ? 45 : -45);
/*     */       } 
/* 165 */       moveStrafe = 0.0F;
/* 166 */       if (moveForward > 0.0F) {
/* 167 */         moveForward = 1.0F;
/* 168 */       } else if (moveForward < 0.0F) {
/* 169 */         moveForward = -1.0F;
/*     */       } 
/*     */     } 
/* 172 */     double posX = moveForward * speed * -Math.sin(Math.toRadians(rotationYaw)) + moveStrafe * speed * Math.cos(Math.toRadians(rotationYaw));
/* 173 */     double posZ = moveForward * speed * Math.cos(Math.toRadians(rotationYaw)) - moveStrafe * speed * -Math.sin(Math.toRadians(rotationYaw));
/* 174 */     return new double[] { posX, posZ };
/*     */   }
/*     */   
/*     */   private void sendPackets(double x, double y, double z, boolean teleport) {
/* 178 */     Vec3d vec = new Vec3d(x, y, z);
/* 179 */     Vec3d position = mc.field_71439_g.func_174791_d().func_178787_e(vec);
/* 180 */     Vec3d outOfBoundsVec = outOfBoundsVec(vec, position);
/* 181 */     packetSender((CPacketPlayer)new CPacketPlayer.Position(position.field_72450_a, position.field_72448_b, position.field_72449_c, mc.field_71439_g.field_70122_E));
/* 182 */     if (((Boolean)this.invalidPacket.getValue()).booleanValue()) {
/* 183 */       packetSender((CPacketPlayer)new CPacketPlayer.Position(outOfBoundsVec.field_72450_a, outOfBoundsVec.field_72448_b, outOfBoundsVec.field_72449_c, mc.field_71439_g.field_70122_E));
/*     */     }
/* 185 */     if (((Boolean)this.setPos.getValue()).booleanValue()) {
/* 186 */       mc.field_71439_g.func_70107_b(position.field_72450_a, position.field_72448_b, position.field_72449_c);
/*     */     }
/* 188 */     teleportPacket(position, teleport);
/*     */   }
/*     */   
/*     */   private void teleportPacket(Vec3d pos, boolean shouldTeleport) {
/* 192 */     if (shouldTeleport) {
/* 193 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketConfirmTeleport(++this.teleportID));
/* 194 */       this.teleportmap.put(Integer.valueOf(this.teleportID), new IDtime(pos, new Timer()));
/*     */     } 
/*     */   }
/*     */   
/*     */   private Vec3d outOfBoundsVec(Vec3d offset, Vec3d position) {
/* 199 */     return position.func_72441_c(0.0D, 1337.0D, 0.0D);
/*     */   }
/*     */   
/*     */   private void packetSender(CPacketPlayer packet) {
/* 203 */     this.packets.add(packet);
/* 204 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)packet);
/*     */   }
/*     */   
/*     */   private void clean() {
/* 208 */     this.teleportmap.clear();
/* 209 */     this.flightCounter = 0;
/* 210 */     if (((Boolean)this.resetID.getValue()).booleanValue()) {
/* 211 */       this.teleportID = 0;
/*     */     }
/* 213 */     this.packets.clear();
/*     */   }
/*     */   
/*     */   public static class IDtime {
/*     */     private final Vec3d pos;
/*     */     private final Timer timer;
/*     */     
/*     */     public IDtime(Vec3d pos, Timer timer) {
/* 221 */       this.pos = pos;
/* 222 */       this.timer = timer;
/* 223 */       this.timer.reset();
/*     */     }
/*     */     
/*     */     public Vec3d getPos() {
/* 227 */       return this.pos;
/*     */     }
/*     */     
/*     */     public Timer getTimer() {
/* 231 */       return this.timer;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\movement\TestPhase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */