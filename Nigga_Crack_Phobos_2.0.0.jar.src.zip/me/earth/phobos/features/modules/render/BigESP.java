/*    */ package me.earth.phobos.features.modules.render;
/*    */ 
/*    */ import me.earth.phobos.event.events.Render3DEvent;
/*    */ import me.earth.phobos.features.modules.Module;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class BigESP
/*    */   extends Module {
/*    */   public BigESP() {
/* 10 */     super("BigModule", "Big fucking module", Module.Category.RENDER, true, false, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onRender3D(Render3DEvent event) {
/* 15 */     if (!fullNullCheck()) {
/* 16 */       for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 17 */         double x = interpolate(player.field_70142_S, player.field_70165_t, event.getPartialTicks()) - (mc.func_175598_ae()).field_78725_b;
/* 18 */         double y = interpolate(player.field_70137_T, player.field_70163_u, event.getPartialTicks()) - (mc.func_175598_ae()).field_78726_c;
/* 19 */         double z = interpolate(player.field_70136_U, player.field_70161_v, event.getPartialTicks()) - (mc.func_175598_ae()).field_78723_d;
/* 20 */         renderBigESP(player, x, y, z, event.getPartialTicks());
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void renderBigESP(EntityPlayer player, double x, double y, double z, float delta) {}
/*    */   
/*    */   private double interpolate(double previous, double current, float delta) {
/* 29 */     return previous + (current - previous) * delta;
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\render\BigESP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */