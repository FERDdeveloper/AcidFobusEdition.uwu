/*   */ package me.earth.phobos.features.modules.render;
/*   */ 
/*   */ import me.earth.phobos.event.events.Render3DEvent;
/*   */ import me.earth.phobos.features.modules.Module;
/*   */ 
/*   */ public class RenderTest
/*   */   extends Module {
/*   */   public RenderTest() {
/* 9 */     super("RenderTest", "RenderTest", Module.Category.RENDER, true, false, false);
/*   */   }
/*   */   
/*   */   public void onRender3D(Render3DEvent event) {}
/*   */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\render\RenderTest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */