/*    */ package me.earth.phobos.features.modules.render;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.util.ArrayList;
/*    */ import me.earth.phobos.Phobos;
/*    */ import me.earth.phobos.event.events.Render3DEvent;
/*    */ import me.earth.phobos.features.modules.Module;
/*    */ import me.earth.phobos.features.setting.Setting;
/*    */ import me.earth.phobos.util.EntityUtil;
/*    */ import me.earth.phobos.util.RenderUtil;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.math.RayTraceResult;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class Ranges
/*    */   extends Module
/*    */ {
/* 22 */   private final Setting<Boolean> hitSpheres = register(new Setting("HitSpheres", Boolean.valueOf(false)));
/* 23 */   private final Setting<Boolean> circle = register(new Setting("Circle", Boolean.valueOf(true)));
/* 24 */   private final Setting<Boolean> ownSphere = register(new Setting("OwnSphere", Boolean.valueOf(false), v -> ((Boolean)this.hitSpheres.getValue()).booleanValue()));
/* 25 */   private final Setting<Boolean> raytrace = register(new Setting("RayTrace", Boolean.valueOf(false), v -> ((Boolean)this.circle.getValue()).booleanValue()));
/* 26 */   private final Setting<Float> lineWidth = register(new Setting("LineWidth", Float.valueOf(1.5F), Float.valueOf(0.1F), Float.valueOf(5.0F)));
/* 27 */   private final Setting<Double> radius = register(new Setting("Radius", Double.valueOf(4.5D), Double.valueOf(0.1D), Double.valueOf(8.0D)));
/*    */   
/*    */   public Ranges() {
/* 30 */     super("Ranges", "Draws a circle around the player.", Module.Category.RENDER, false, false, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onRender3D(Render3DEvent event) {
/* 35 */     if (((Boolean)this.circle.getValue()).booleanValue()) {
/* 36 */       GlStateManager.func_179094_E();
/* 37 */       RenderUtil.GLPre(((Float)this.lineWidth.getValue()).floatValue());
/* 38 */       GlStateManager.func_179147_l();
/* 39 */       GlStateManager.func_187441_d(3.0F);
/* 40 */       GlStateManager.func_179090_x();
/* 41 */       GlStateManager.func_179132_a(false);
/* 42 */       GlStateManager.func_179097_i();
/* 43 */       GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 44 */       RenderManager renderManager = mc.func_175598_ae();
/* 45 */       Color color = Color.RED;
/* 46 */       ArrayList<Vec3d> hVectors = new ArrayList<>();
/* 47 */       double x = mc.field_71439_g.field_70142_S + (mc.field_71439_g.field_70165_t - mc.field_71439_g.field_70142_S) * event.getPartialTicks() - renderManager.field_78725_b;
/* 48 */       double y = mc.field_71439_g.field_70137_T + (mc.field_71439_g.field_70163_u - mc.field_71439_g.field_70137_T) * event.getPartialTicks() - renderManager.field_78726_c;
/* 49 */       double z = mc.field_71439_g.field_70136_U + (mc.field_71439_g.field_70161_v - mc.field_71439_g.field_70136_U) * event.getPartialTicks() - renderManager.field_78723_d;
/* 50 */       GL11.glColor4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/* 51 */       GL11.glLineWidth(((Float)this.lineWidth.getValue()).floatValue());
/* 52 */       GL11.glBegin(1);
/* 53 */       for (int i = 0; i <= 360; i++) {
/* 54 */         Vec3d vec = new Vec3d(x + Math.sin(i * Math.PI / 180.0D) * ((Double)this.radius.getValue()).doubleValue(), y + 0.1D, z + Math.cos(i * Math.PI / 180.0D) * ((Double)this.radius.getValue()).doubleValue());
/* 55 */         RayTraceResult result = mc.field_71441_e.func_147447_a(new Vec3d(x, y + 0.1D, z), vec, false, true, false);
/* 56 */         if (result != null && ((Boolean)this.raytrace.getValue()).booleanValue()) {
/* 57 */           hVectors.add(result.field_72307_f);
/*    */         } else {
/*    */           
/* 60 */           hVectors.add(vec);
/*    */         } 
/* 62 */       }  for (int j = 0; j < hVectors.size() - 1; j++) {
/* 63 */         GL11.glVertex3d(((Vec3d)hVectors.get(j)).field_72450_a, ((Vec3d)hVectors.get(j)).field_72448_b, ((Vec3d)hVectors.get(j)).field_72449_c);
/* 64 */         GL11.glVertex3d(((Vec3d)hVectors.get(j + 1)).field_72450_a, ((Vec3d)hVectors.get(j + 1)).field_72448_b, ((Vec3d)hVectors.get(j + 1)).field_72449_c);
/*    */       } 
/* 66 */       GL11.glEnd();
/* 67 */       GlStateManager.func_179117_G();
/* 68 */       GlStateManager.func_179126_j();
/* 69 */       GlStateManager.func_179132_a(true);
/* 70 */       GlStateManager.func_179098_w();
/* 71 */       GlStateManager.func_179084_k();
/* 72 */       RenderUtil.GlPost();
/* 73 */       GlStateManager.func_179121_F();
/*    */     } 
/* 75 */     if (((Boolean)this.hitSpheres.getValue()).booleanValue())
/* 76 */       for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 77 */         if (player == null || (player.equals(mc.field_71439_g) && !((Boolean)this.ownSphere.getValue()).booleanValue()))
/*    */           continue; 
/* 79 */         Vec3d interpolated = EntityUtil.interpolateEntity((Entity)player, event.getPartialTicks());
/* 80 */         if (Phobos.friendManager.isFriend(player.func_70005_c_())) {
/* 81 */           GL11.glColor4f(0.15F, 0.15F, 1.0F, 1.0F);
/* 82 */         } else if (mc.field_71439_g.func_70032_d((Entity)player) >= 64.0F) {
/* 83 */           GL11.glColor4f(0.0F, 1.0F, 0.0F, 1.0F);
/*    */         } else {
/* 85 */           GL11.glColor4f(1.0F, mc.field_71439_g.func_70032_d((Entity)player) / 150.0F, 0.0F, 1.0F);
/*    */         } 
/* 87 */         RenderUtil.drawSphere(interpolated.field_72450_a, interpolated.field_72448_b, interpolated.field_72449_c, ((Double)this.radius.getValue()).floatValue(), 20, 15);
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\render\Ranges.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */