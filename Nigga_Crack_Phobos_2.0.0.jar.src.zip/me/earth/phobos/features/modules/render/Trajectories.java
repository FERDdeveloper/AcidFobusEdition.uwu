/*     */ package me.earth.phobos.features.modules.render;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import me.earth.phobos.event.events.Render3DEvent;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.util.glu.Cylinder;
/*     */ 
/*     */ public class Trajectories
/*     */   extends Module {
/*     */   public Trajectories() {
/*  23 */     super("Trajectories", "Shows the way of projectiles.", Module.Category.RENDER, false, false, false);
/*     */   }
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/*  27 */     if (mc.field_71441_e == null || mc.field_71439_g == null)
/*     */       return; 
/*  29 */     drawTrajectories((EntityPlayer)mc.field_71439_g, event.getPartialTicks());
/*     */   }
/*     */   
/*     */   public void enableGL3D(float lineWidth) {
/*  33 */     GL11.glDisable(3008);
/*  34 */     GL11.glEnable(3042);
/*  35 */     GL11.glBlendFunc(770, 771);
/*  36 */     GL11.glDisable(3553);
/*  37 */     GL11.glDisable(2929);
/*  38 */     GL11.glDepthMask(false);
/*  39 */     GL11.glEnable(2884);
/*  40 */     mc.field_71460_t.func_175072_h();
/*  41 */     GL11.glEnable(2848);
/*  42 */     GL11.glHint(3154, 4354);
/*  43 */     GL11.glHint(3155, 4354);
/*  44 */     GL11.glLineWidth(lineWidth);
/*     */   }
/*     */   
/*     */   public void disableGL3D() {
/*  48 */     GL11.glEnable(3553);
/*  49 */     GL11.glEnable(2929);
/*  50 */     GL11.glDisable(3042);
/*  51 */     GL11.glEnable(3008);
/*  52 */     GL11.glDepthMask(true);
/*  53 */     GL11.glCullFace(1029);
/*  54 */     GL11.glDisable(2848);
/*  55 */     GL11.glHint(3154, 4352);
/*  56 */     GL11.glHint(3155, 4352);
/*     */   }
/*     */   
/*     */   private void drawTrajectories(EntityPlayer player, float partialTicks) {
/*  60 */     double renderPosX = player.field_70142_S + (player.field_70165_t - player.field_70142_S) * partialTicks;
/*  61 */     double renderPosY = player.field_70137_T + (player.field_70163_u - player.field_70137_T) * partialTicks;
/*  62 */     double renderPosZ = player.field_70136_U + (player.field_70161_v - player.field_70136_U) * partialTicks;
/*  63 */     player.func_184586_b(EnumHand.MAIN_HAND);
/*  64 */     if (mc.field_71474_y.field_74320_O != 0 || (!(player.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemBow) && !(player.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemFishingRod) && !(player.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemEnderPearl) && !(player.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemEgg) && !(player.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemSnowball) && !(player.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemExpBottle)))
/*     */       return; 
/*  66 */     GL11.glPushMatrix();
/*  67 */     Item item = player.func_184586_b(EnumHand.MAIN_HAND).func_77973_b();
/*  68 */     double posX = renderPosX - (MathHelper.func_76134_b(player.field_70177_z / 180.0F * 3.1415927F) * 0.16F);
/*  69 */     double posY = renderPosY + player.func_70047_e() - 0.1000000014901161D;
/*  70 */     double posZ = renderPosZ - (MathHelper.func_76126_a(player.field_70177_z / 180.0F * 3.1415927F) * 0.16F);
/*  71 */     double motionX = (-MathHelper.func_76126_a(player.field_70177_z / 180.0F * 3.1415927F) * MathHelper.func_76134_b(player.field_70125_A / 180.0F * 3.1415927F)) * ((item instanceof net.minecraft.item.ItemBow) ? 1.0D : 0.4D);
/*  72 */     double motionY = -MathHelper.func_76126_a(player.field_70125_A / 180.0F * 3.1415927F) * ((item instanceof net.minecraft.item.ItemBow) ? 1.0D : 0.4D);
/*  73 */     double motionZ = (MathHelper.func_76134_b(player.field_70177_z / 180.0F * 3.1415927F) * MathHelper.func_76134_b(player.field_70125_A / 180.0F * 3.1415927F)) * ((item instanceof net.minecraft.item.ItemBow) ? 1.0D : 0.4D);
/*  74 */     int var6 = 72000 - player.func_184605_cv();
/*  75 */     float power = var6 / 20.0F;
/*  76 */     power = (power * power + power * 2.0F) / 3.0F;
/*  77 */     if (power > 1.0F)
/*  78 */       power = 1.0F; 
/*  79 */     float distance = MathHelper.func_76133_a(motionX * motionX + motionY * motionY + motionZ * motionZ);
/*  80 */     motionX /= distance;
/*  81 */     motionY /= distance;
/*  82 */     motionZ /= distance;
/*  83 */     float pow = (item instanceof net.minecraft.item.ItemBow) ? (power * 2.0F) : ((item instanceof net.minecraft.item.ItemFishingRod) ? 1.25F : ((player.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.9F : 1.0F));
/*  84 */     motionX *= (pow * ((item instanceof net.minecraft.item.ItemFishingRod) ? 0.75F : ((player.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.75F : 1.5F)));
/*  85 */     motionY *= (pow * ((item instanceof net.minecraft.item.ItemFishingRod) ? 0.75F : ((player.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.75F : 1.5F)));
/*  86 */     motionZ *= (pow * ((item instanceof net.minecraft.item.ItemFishingRod) ? 0.75F : ((player.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.75F : 1.5F)));
/*  87 */     enableGL3D(2.0F);
/*  88 */     if (power > 0.6F) {
/*  89 */       GlStateManager.func_179131_c(0.0F, 1.0F, 0.0F, 1.0F);
/*     */     } else {
/*  91 */       GlStateManager.func_179131_c(0.8F, 0.5F, 0.0F, 1.0F);
/*     */     } 
/*  93 */     GL11.glEnable(2848);
/*  94 */     float size = (float)((item instanceof net.minecraft.item.ItemBow) ? 0.3D : 0.25D);
/*  95 */     boolean hasLanded = false;
/*  96 */     Entity landingOnEntity = null;
/*  97 */     RayTraceResult landingPosition = null;
/*  98 */     while (!hasLanded && posY > 0.0D) {
/*  99 */       Vec3d present = new Vec3d(posX, posY, posZ);
/* 100 */       Vec3d future = new Vec3d(posX + motionX, posY + motionY, posZ + motionZ);
/* 101 */       RayTraceResult possibleLandingStrip = mc.field_71441_e.func_147447_a(present, future, false, true, false);
/* 102 */       if (possibleLandingStrip != null && possibleLandingStrip.field_72313_a != RayTraceResult.Type.MISS) {
/* 103 */         landingPosition = possibleLandingStrip;
/* 104 */         hasLanded = true;
/*     */       } 
/* 106 */       AxisAlignedBB arrowBox = new AxisAlignedBB(posX - size, posY - size, posZ - size, posX + size, posY + size, posZ + size);
/* 107 */       List<Entity> entities = getEntitiesWithinAABB(arrowBox.func_72317_d(motionX, motionY, motionZ).func_72321_a(1.0D, 1.0D, 1.0D));
/* 108 */       for (Entity entity : entities) {
/* 109 */         Entity boundingBox = entity;
/* 110 */         if (boundingBox.func_70067_L() && boundingBox != player) {
/* 111 */           float var7 = 0.3F;
/* 112 */           AxisAlignedBB var8 = boundingBox.func_174813_aQ().func_72321_a(var7, var7, var7);
/* 113 */           RayTraceResult possibleEntityLanding = var8.func_72327_a(present, future);
/* 114 */           if (possibleEntityLanding == null)
/*     */             continue; 
/* 116 */           hasLanded = true;
/* 117 */           landingOnEntity = boundingBox;
/* 118 */           landingPosition = possibleEntityLanding;
/*     */         } 
/*     */       } 
/* 121 */       if (landingOnEntity != null)
/* 122 */         GlStateManager.func_179131_c(1.0F, 0.0F, 0.0F, 1.0F); 
/* 123 */       posX += motionX;
/* 124 */       posY += motionY;
/* 125 */       posZ += motionZ;
/* 126 */       float motionAdjustment = 0.99F;
/* 127 */       motionX *= motionAdjustment;
/* 128 */       motionY *= motionAdjustment;
/* 129 */       motionZ *= motionAdjustment;
/* 130 */       motionY -= (item instanceof net.minecraft.item.ItemBow) ? 0.05D : 0.03D;
/*     */     } 
/* 132 */     if (landingPosition != null && landingPosition.field_72313_a == RayTraceResult.Type.BLOCK) {
/* 133 */       GlStateManager.func_179137_b(posX - renderPosX, posY - renderPosY, posZ - renderPosZ);
/* 134 */       int side = landingPosition.field_178784_b.func_176745_a();
/* 135 */       if (side == 2) {
/* 136 */         GlStateManager.func_179114_b(90.0F, 1.0F, 0.0F, 0.0F);
/* 137 */       } else if (side == 3) {
/* 138 */         GlStateManager.func_179114_b(90.0F, 1.0F, 0.0F, 0.0F);
/* 139 */       } else if (side == 4) {
/* 140 */         GlStateManager.func_179114_b(90.0F, 0.0F, 0.0F, 1.0F);
/* 141 */       } else if (side == 5) {
/* 142 */         GlStateManager.func_179114_b(90.0F, 0.0F, 0.0F, 1.0F);
/*     */       } 
/* 144 */       Cylinder c = new Cylinder();
/* 145 */       GlStateManager.func_179114_b(-90.0F, 1.0F, 0.0F, 0.0F);
/* 146 */       c.setDrawStyle(100011);
/* 147 */       if (landingOnEntity != null) {
/* 148 */         GlStateManager.func_179131_c(0.0F, 0.0F, 0.0F, 1.0F);
/* 149 */         GL11.glLineWidth(2.5F);
/* 150 */         c.draw(0.6F, 0.3F, 0.0F, 4, 1);
/* 151 */         GL11.glLineWidth(0.1F);
/* 152 */         GlStateManager.func_179131_c(1.0F, 0.0F, 0.0F, 1.0F);
/*     */       } 
/* 154 */       c.draw(0.6F, 0.3F, 0.0F, 4, 1);
/*     */     } 
/* 156 */     disableGL3D();
/* 157 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */   private List<Entity> getEntitiesWithinAABB(AxisAlignedBB bb) {
/* 161 */     ArrayList<Entity> list = new ArrayList<>();
/* 162 */     int chunkMinX = MathHelper.func_76128_c((bb.field_72340_a - 2.0D) / 16.0D);
/* 163 */     int chunkMaxX = MathHelper.func_76128_c((bb.field_72336_d + 2.0D) / 16.0D);
/* 164 */     int chunkMinZ = MathHelper.func_76128_c((bb.field_72339_c - 2.0D) / 16.0D);
/* 165 */     int chunkMaxZ = MathHelper.func_76128_c((bb.field_72334_f + 2.0D) / 16.0D);
/* 166 */     for (int x = chunkMinX; x <= chunkMaxX; x++) {
/* 167 */       for (int z = chunkMinZ; z <= chunkMaxZ; z++) {
/* 168 */         if (mc.field_71441_e.func_72863_F().func_186026_b(x, z) != null)
/* 169 */           mc.field_71441_e.func_72964_e(x, z).func_177414_a((Entity)mc.field_71439_g, bb, list, null); 
/*     */       } 
/*     */     } 
/* 172 */     return list;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\render\Trajectories.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */