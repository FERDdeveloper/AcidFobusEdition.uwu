/*     */ package me.earth.phobos.features.modules.render;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.gui.BossInfoClient;
/*     */ import net.minecraft.client.gui.GuiBossOverlay;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.BossInfo;
/*     */ import net.minecraft.world.GameType;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ import net.minecraftforge.client.event.RenderLivingEvent;
/*     */ import net.minecraftforge.event.entity.PlaySoundAtEntityEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class NoRender
/*     */   extends Module {
/*  33 */   private static NoRender INSTANCE = new NoRender();
/*  34 */   public Setting<Boolean> fire = register(new Setting("Fire", Boolean.valueOf(false), "Removes the portal overlay."));
/*  35 */   public Setting<Boolean> portal = register(new Setting("Portal", Boolean.valueOf(false), "Removes the portal overlay."));
/*  36 */   public Setting<Boolean> pumpkin = register(new Setting("Pumpkin", Boolean.valueOf(false), "Removes the pumpkin overlay."));
/*  37 */   public Setting<Boolean> totemPops = register(new Setting("TotemPop", Boolean.valueOf(false), "Removes the Totem overlay."));
/*  38 */   public Setting<Boolean> items = register(new Setting("Items", Boolean.valueOf(false), "Removes items on the ground."));
/*  39 */   public Setting<Boolean> nausea = register(new Setting("Nausea", Boolean.valueOf(false), "Removes Portal Nausea."));
/*  40 */   public Setting<Boolean> hurtcam = register(new Setting("HurtCam", Boolean.valueOf(false), "Removes shaking after taking damage."));
/*  41 */   public Setting<Fog> fog = register(new Setting("Fog", Fog.NONE, "Removes Fog."));
/*  42 */   public Setting<Boolean> noWeather = register(new Setting("Weather", Boolean.valueOf(false), "AntiWeather"));
/*  43 */   public Setting<Boss> boss = register(new Setting("BossBars", Boss.NONE, "Modifies the bossbars."));
/*  44 */   public Setting<Float> scale = register(new Setting("Scale", Float.valueOf(0.0F), Float.valueOf(0.5F), Float.valueOf(1.0F), v -> (this.boss.getValue() == Boss.MINIMIZE || this.boss.getValue() != Boss.STACK), "Scale of the bars."));
/*  45 */   public Setting<Boolean> bats = register(new Setting("Bats", Boolean.valueOf(false), "Removes bats."));
/*  46 */   public Setting<NoArmor> noArmor = register(new Setting("NoArmor", NoArmor.NONE, "Doesnt Render Armor on players."));
/*  47 */   public Setting<Skylight> skylight = register(new Setting("Skylight", Skylight.NONE));
/*  48 */   public Setting<Boolean> barriers = register(new Setting("Barriers", Boolean.valueOf(false), "Barriers"));
/*  49 */   public Setting<Boolean> blocks = register(new Setting("Blocks", Boolean.valueOf(false), "Blocks"));
/*  50 */   public Setting<Boolean> advancements = register(new Setting("Advancements", Boolean.valueOf(false)));
/*     */   
/*     */   public NoRender() {
/*  53 */     super("NoRender", "Allows you to stop rendering stuff", Module.Category.RENDER, true, false, false);
/*  54 */     setInstance();
/*     */   }
/*     */   
/*     */   public static NoRender getInstance() {
/*  58 */     if (INSTANCE == null)
/*  59 */       INSTANCE = new NoRender(); 
/*  60 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  64 */     INSTANCE = this;
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*  68 */     if (((Boolean)this.items.getValue()).booleanValue())
/*  69 */       mc.field_71441_e.field_72996_f.stream().filter(EntityItem.class::isInstance).map(EntityItem.class::cast).forEach(Entity::func_70106_y); 
/*  70 */     if (((Boolean)this.noWeather.getValue()).booleanValue() && mc.field_71441_e.func_72896_J())
/*  71 */       mc.field_71441_e.func_72894_k(0.0F); 
/*     */   }
/*     */   
/*     */   public void doVoidFogParticles(int posX, int posY, int posZ) {
/*  75 */     int i = 32;
/*  76 */     Random random = new Random();
/*  77 */     ItemStack itemstack = mc.field_71439_g.func_184614_ca();
/*  78 */     boolean flag = (!((Boolean)this.barriers.getValue()).booleanValue() || (mc.field_71442_b.func_178889_l() == GameType.CREATIVE && !itemstack.func_190926_b() && itemstack.func_77973_b() == Item.func_150898_a(Blocks.field_180401_cv)));
/*  79 */     BlockPos.MutableBlockPos blockpos$mutableblockpos = new BlockPos.MutableBlockPos();
/*  80 */     for (int j = 0; j < 667; j++) {
/*  81 */       showBarrierParticles(posX, posY, posZ, 16, random, flag, blockpos$mutableblockpos);
/*  82 */       showBarrierParticles(posX, posY, posZ, 32, random, flag, blockpos$mutableblockpos);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void showBarrierParticles(int x, int y, int z, int offset, Random random, boolean holdingBarrier, BlockPos.MutableBlockPos pos) {
/*  87 */     int i = x + mc.field_71441_e.field_73012_v.nextInt(offset) - mc.field_71441_e.field_73012_v.nextInt(offset);
/*  88 */     int j = y + mc.field_71441_e.field_73012_v.nextInt(offset) - mc.field_71441_e.field_73012_v.nextInt(offset);
/*  89 */     int k = z + mc.field_71441_e.field_73012_v.nextInt(offset) - mc.field_71441_e.field_73012_v.nextInt(offset);
/*  90 */     pos.func_181079_c(i, j, k);
/*  91 */     IBlockState iblockstate = mc.field_71441_e.func_180495_p((BlockPos)pos);
/*  92 */     iblockstate.func_177230_c().func_180655_c(iblockstate, (World)mc.field_71441_e, (BlockPos)pos, random);
/*  93 */     if (!holdingBarrier && iblockstate.func_177230_c() == Blocks.field_180401_cv)
/*  94 */       mc.field_71441_e.func_175688_a(EnumParticleTypes.BARRIER, (i + 0.5F), (j + 0.5F), (k + 0.5F), 0.0D, 0.0D, 0.0D, new int[0]); 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderPre(RenderGameOverlayEvent.Pre event) {
/*  99 */     if (event.getType() == RenderGameOverlayEvent.ElementType.BOSSINFO && this.boss.getValue() != Boss.NONE)
/* 100 */       event.setCanceled(true); 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderPost(RenderGameOverlayEvent.Post event) {
/* 105 */     if (event.getType() == RenderGameOverlayEvent.ElementType.BOSSINFO && this.boss.getValue() != Boss.NONE)
/* 106 */       if (this.boss.getValue() == Boss.MINIMIZE) {
/* 107 */         Map<UUID, BossInfoClient> map = (mc.field_71456_v.func_184046_j()).field_184060_g;
/* 108 */         if (map == null)
/*     */           return; 
/* 110 */         ScaledResolution scaledresolution = new ScaledResolution(mc);
/* 111 */         int i = scaledresolution.func_78326_a();
/* 112 */         int j = 12;
/* 113 */         for (Map.Entry<UUID, BossInfoClient> entry : map.entrySet()) {
/* 114 */           BossInfoClient info = entry.getValue();
/* 115 */           String text = info.func_186744_e().func_150254_d();
/* 116 */           int k = (int)(i / ((Float)this.scale.getValue()).floatValue() / 2.0F - 91.0F);
/* 117 */           GL11.glScaled(((Float)this.scale.getValue()).floatValue(), ((Float)this.scale.getValue()).floatValue(), 1.0D);
/* 118 */           if (!event.isCanceled()) {
/* 119 */             GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 120 */             mc.func_110434_K().func_110577_a(GuiBossOverlay.field_184058_a);
/* 121 */             mc.field_71456_v.func_184046_j().func_184052_a(k, j, (BossInfo)info);
/* 122 */             mc.field_71466_p.func_175063_a(text, i / ((Float)this.scale.getValue()).floatValue() / 2.0F - (mc.field_71466_p.func_78256_a(text) / 2), (j - 9), 16777215);
/*     */           } 
/* 124 */           GL11.glScaled(1.0D / ((Float)this.scale.getValue()).floatValue(), 1.0D / ((Float)this.scale.getValue()).floatValue(), 1.0D);
/* 125 */           j += 10 + mc.field_71466_p.field_78288_b;
/*     */         } 
/* 127 */       } else if (this.boss.getValue() == Boss.STACK) {
/* 128 */         Map<UUID, BossInfoClient> map = (mc.field_71456_v.func_184046_j()).field_184060_g;
/* 129 */         HashMap<String, Pair<BossInfoClient, Integer>> to = new HashMap<>();
/* 130 */         for (Map.Entry<UUID, BossInfoClient> entry : map.entrySet()) {
/* 131 */           String s = ((BossInfoClient)entry.getValue()).func_186744_e().func_150254_d();
/* 132 */           if (to.containsKey(s)) {
/* 133 */             Pair<BossInfoClient, Integer> pair = to.get(s);
/* 134 */             pair = new Pair<>(pair.getKey(), Integer.valueOf(((Integer)pair.getValue()).intValue() + 1));
/* 135 */             to.put(s, pair);
/*     */             continue;
/*     */           } 
/* 138 */           Pair<BossInfoClient, Integer> p = new Pair<>(entry.getValue(), Integer.valueOf(1));
/* 139 */           to.put(s, p);
/*     */         } 
/* 141 */         ScaledResolution scaledresolution = new ScaledResolution(mc);
/* 142 */         int i = scaledresolution.func_78326_a();
/* 143 */         int j = 12;
/* 144 */         for (Map.Entry<String, Pair<BossInfoClient, Integer>> entry : to.entrySet()) {
/* 145 */           String text = entry.getKey();
/* 146 */           BossInfoClient info = (BossInfoClient)((Pair)entry.getValue()).getKey();
/* 147 */           int a = ((Integer)((Pair)entry.getValue()).getValue()).intValue();
/* 148 */           text = text + " x" + a;
/* 149 */           int k = (int)(i / ((Float)this.scale.getValue()).floatValue() / 2.0F - 91.0F);
/* 150 */           GL11.glScaled(((Float)this.scale.getValue()).floatValue(), ((Float)this.scale.getValue()).floatValue(), 1.0D);
/* 151 */           if (!event.isCanceled()) {
/* 152 */             GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 153 */             mc.func_110434_K().func_110577_a(GuiBossOverlay.field_184058_a);
/* 154 */             mc.field_71456_v.func_184046_j().func_184052_a(k, j, (BossInfo)info);
/* 155 */             mc.field_71466_p.func_175063_a(text, i / ((Float)this.scale.getValue()).floatValue() / 2.0F - (mc.field_71466_p.func_78256_a(text) / 2), (j - 9), 16777215);
/*     */           } 
/* 157 */           GL11.glScaled(1.0D / ((Float)this.scale.getValue()).floatValue(), 1.0D / ((Float)this.scale.getValue()).floatValue(), 1.0D);
/* 158 */           j += 10 + mc.field_71466_p.field_78288_b;
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderLiving(RenderLivingEvent.Pre<?> event) {
/* 165 */     if (((Boolean)this.bats.getValue()).booleanValue() && event.getEntity() instanceof net.minecraft.entity.passive.EntityBat)
/* 166 */       event.setCanceled(true); 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlaySound(PlaySoundAtEntityEvent event) {
/* 171 */     if ((((Boolean)this.bats.getValue()).booleanValue() && event.getSound().equals(SoundEvents.field_187740_w)) || event
/* 172 */       .getSound().equals(SoundEvents.field_187742_x) || event
/* 173 */       .getSound().equals(SoundEvents.field_187743_y) || event
/* 174 */       .getSound().equals(SoundEvents.field_189108_z) || event
/* 175 */       .getSound().equals(SoundEvents.field_187744_z)) {
/* 176 */       event.setVolume(0.0F);
/* 177 */       event.setPitch(0.0F);
/* 178 */       event.setCanceled(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   public enum Skylight {
/* 183 */     NONE, WORLD, ENTITY, ALL;
/*     */   }
/*     */   
/*     */   public enum Fog {
/* 187 */     NONE, AIR, NOFOG;
/*     */   }
/*     */   
/*     */   public enum Boss {
/* 191 */     NONE, REMOVE, STACK, MINIMIZE;
/*     */   }
/*     */   
/*     */   public enum NoArmor {
/* 195 */     NONE, ALL, HELMET;
/*     */   }
/*     */   
/*     */   public static class Pair<T, S>
/*     */   {
/*     */     private T key;
/*     */     private S value;
/*     */     
/*     */     public Pair(T key, S value) {
/* 204 */       this.key = key;
/* 205 */       this.value = value;
/*     */     }
/*     */     
/*     */     public T getKey() {
/* 209 */       return this.key;
/*     */     }
/*     */     
/*     */     public void setKey(T key) {
/* 213 */       this.key = key;
/*     */     }
/*     */     
/*     */     public S getValue() {
/* 217 */       return this.value;
/*     */     }
/*     */     
/*     */     public void setValue(S value) {
/* 221 */       this.value = value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\render\NoRender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */