/*     */ package me.earth.phobos.features.modules.player;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.BlockEvent;
/*     */ import me.earth.phobos.event.events.PacketEvent;
/*     */ import me.earth.phobos.event.events.Render3DEvent;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.BlockUtil;
/*     */ import me.earth.phobos.util.InventoryUtil;
/*     */ import me.earth.phobos.util.MathUtil;
/*     */ import me.earth.phobos.util.RenderUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemSword;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class Speedmine
/*     */   extends Module {
/*  31 */   private static Speedmine INSTANCE = new Speedmine();
/*  32 */   private final Setting<Float> range = register(new Setting("Range", Float.valueOf(10.0F), Float.valueOf(0.0F), Float.valueOf(50.0F)));
/*  33 */   private final Timer timer = new Timer();
/*  34 */   public Setting<Boolean> tweaks = register(new Setting("Tweaks", Boolean.valueOf(true)));
/*  35 */   public Setting<Mode> mode = register(new Setting("Mode", Mode.PACKET, v -> ((Boolean)this.tweaks.getValue()).booleanValue()));
/*  36 */   public Setting<Boolean> reset = register(new Setting("Reset", Boolean.valueOf(true)));
/*  37 */   public Setting<Float> damage = register(new Setting("Damage", Float.valueOf(0.7F), Float.valueOf(0.0F), Float.valueOf(1.0F), v -> (this.mode.getValue() == Mode.DAMAGE && ((Boolean)this.tweaks.getValue()).booleanValue())));
/*  38 */   public Setting<Boolean> noBreakAnim = register(new Setting("NoBreakAnim", Boolean.valueOf(false)));
/*  39 */   public Setting<Boolean> noDelay = register(new Setting("NoDelay", Boolean.valueOf(false)));
/*  40 */   public Setting<Boolean> noSwing = register(new Setting("NoSwing", Boolean.valueOf(false)));
/*  41 */   public Setting<Boolean> noTrace = register(new Setting("NoTrace", Boolean.valueOf(false)));
/*  42 */   public Setting<Boolean> allow = register(new Setting("AllowMultiTask", Boolean.valueOf(false)));
/*  43 */   public Setting<Boolean> pickaxe = register(new Setting("Pickaxe", Boolean.valueOf(true), v -> ((Boolean)this.noTrace.getValue()).booleanValue()));
/*  44 */   public Setting<Boolean> doubleBreak = register(new Setting("DoubleBreak", Boolean.valueOf(false)));
/*  45 */   public Setting<Boolean> webSwitch = register(new Setting("WebSwitch", Boolean.valueOf(false)));
/*  46 */   public Setting<Boolean> silentSwitch = register(new Setting("SilentSwitch", Boolean.valueOf(false)));
/*  47 */   public Setting<Boolean> render = register(new Setting("Render", Boolean.valueOf(false)));
/*  48 */   public Setting<Boolean> box = register(new Setting("Box", Boolean.valueOf(false), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  49 */   private final Setting<Integer> boxAlpha = register(new Setting("BoxAlpha", Integer.valueOf(85), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.box.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  50 */   public Setting<Boolean> outline = register(new Setting("Outline", Boolean.valueOf(true), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  51 */   private final Setting<Float> lineWidth = register(new Setting("LineWidth", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(5.0F), v -> (((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*     */   public BlockPos currentPos;
/*     */   public IBlockState currentBlockState;
/*     */   private boolean isMining = false;
/*  55 */   private BlockPos lastPos = null;
/*  56 */   private EnumFacing lastFacing = null;
/*     */   
/*     */   public Speedmine() {
/*  59 */     super("Speedmine", "Speeds up mining.", Module.Category.PLAYER, true, false, false);
/*  60 */     setInstance();
/*     */   }
/*     */   
/*     */   public static Speedmine getInstance() {
/*  64 */     if (INSTANCE == null) {
/*  65 */       INSTANCE = new Speedmine();
/*     */     }
/*  67 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  71 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  76 */     if (this.currentPos != null) {
/*  77 */       if (mc.field_71439_g != null && mc.field_71439_g.func_174818_b(this.currentPos) > MathUtil.square(((Float)this.range.getValue()).floatValue())) {
/*  78 */         this.currentPos = null;
/*  79 */         this.currentBlockState = null;
/*     */         return;
/*     */       } 
/*  82 */       if (mc.field_71439_g != null && ((Boolean)this.silentSwitch.getValue()).booleanValue() && this.timer.passedMs((int)(2000.0F * Phobos.serverManager.getTpsFactor())) && getPickSlot() != -1) {
/*  83 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(getPickSlot()));
/*     */       }
/*  85 */       if (!mc.field_71441_e.func_180495_p(this.currentPos).equals(this.currentBlockState) || mc.field_71441_e.func_180495_p(this.currentPos).func_177230_c() == Blocks.field_150350_a) {
/*  86 */         this.currentPos = null;
/*  87 */         this.currentBlockState = null;
/*  88 */       } else if (((Boolean)this.webSwitch.getValue()).booleanValue() && this.currentBlockState.func_177230_c() == Blocks.field_150321_G && mc.field_71439_g.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemPickaxe) {
/*  89 */         InventoryUtil.switchToHotbarSlot(ItemSword.class, false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  96 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/*  99 */     if (((Boolean)this.noDelay.getValue()).booleanValue()) {
/* 100 */       mc.field_71442_b.field_78781_i = 0;
/*     */     }
/* 102 */     if (this.isMining && this.lastPos != null && this.lastFacing != null && ((Boolean)this.noBreakAnim.getValue()).booleanValue()) {
/* 103 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, this.lastPos, this.lastFacing));
/*     */     }
/* 105 */     if (((Boolean)this.reset.getValue()).booleanValue() && mc.field_71474_y.field_74313_G.func_151470_d() && !((Boolean)this.allow.getValue()).booleanValue()) {
/* 106 */       mc.field_71442_b.field_78778_j = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/* 112 */     if (((Boolean)this.render.getValue()).booleanValue() && this.currentPos != null) {
/* 113 */       Color color = new Color(this.timer.passedMs((int)(2000.0F * Phobos.serverManager.getTpsFactor())) ? 0 : 255, this.timer.passedMs((int)(2000.0F * Phobos.serverManager.getTpsFactor())) ? 255 : 0, 0, 255);
/* 114 */       RenderUtil.drawBoxESP(this.currentPos, color, false, color, ((Float)this.lineWidth.getValue()).floatValue(), ((Boolean)this.outline.getValue()).booleanValue(), ((Boolean)this.box.getValue()).booleanValue(), ((Integer)this.boxAlpha.getValue()).intValue(), false);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.Send event) {
/* 120 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/* 123 */     if (event.getStage() == 0) {
/*     */       
/* 125 */       if (((Boolean)this.noSwing.getValue()).booleanValue() && event.getPacket() instanceof net.minecraft.network.play.client.CPacketAnimation)
/* 126 */         event.setCanceled(true); 
/*     */       CPacketPlayerDigging packet;
/* 128 */       if (((Boolean)this.noBreakAnim.getValue()).booleanValue() && event.getPacket() instanceof CPacketPlayerDigging && (packet = (CPacketPlayerDigging)event.getPacket()) != null && packet.func_179715_a() != null) {
/*     */         try {
/* 130 */           for (Entity entity : mc.field_71441_e.func_72839_b(null, new AxisAlignedBB(packet.func_179715_a()))) {
/* 131 */             if (!(entity instanceof net.minecraft.entity.item.EntityEnderCrystal))
/* 132 */               continue;  showAnimation();
/*     */             return;
/*     */           } 
/* 135 */         } catch (Exception exception) {}
/*     */ 
/*     */         
/* 138 */         if (packet.func_180762_c().equals(CPacketPlayerDigging.Action.START_DESTROY_BLOCK)) {
/* 139 */           showAnimation(true, packet.func_179715_a(), packet.func_179714_b());
/*     */         }
/* 141 */         if (packet.func_180762_c().equals(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK)) {
/* 142 */           showAnimation();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onBlockEvent(BlockEvent event) {
/* 150 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/* 153 */     if (event.getStage() == 3 && ((Boolean)this.reset.getValue()).booleanValue() && mc.field_71442_b.field_78770_f > 0.1F) {
/* 154 */       mc.field_71442_b.field_78778_j = true;
/*     */     }
/* 156 */     if (event.getStage() == 4 && ((Boolean)this.tweaks.getValue()).booleanValue()) {
/*     */       
/* 158 */       if (BlockUtil.canBreak(event.pos)) {
/* 159 */         if (((Boolean)this.reset.getValue()).booleanValue()) {
/* 160 */           mc.field_71442_b.field_78778_j = false;
/*     */         }
/* 162 */         switch ((Mode)this.mode.getValue()) {
/*     */           case PACKET:
/* 164 */             if (this.currentPos == null) {
/* 165 */               this.currentPos = event.pos;
/* 166 */               this.currentBlockState = mc.field_71441_e.func_180495_p(this.currentPos);
/* 167 */               this.timer.reset();
/*     */             } 
/* 169 */             mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 170 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.pos, event.facing));
/* 171 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
/* 172 */             event.setCanceled(true);
/*     */             break;
/*     */           
/*     */           case DAMAGE:
/* 176 */             if (mc.field_71442_b.field_78770_f < ((Float)this.damage.getValue()).floatValue())
/*     */               break; 
/* 178 */             mc.field_71442_b.field_78770_f = 1.0F;
/*     */             break;
/*     */           
/*     */           case INSTANT:
/* 182 */             mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 183 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.pos, event.facing));
/* 184 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
/* 185 */             mc.field_71442_b.func_187103_a(event.pos);
/* 186 */             mc.field_71441_e.func_175698_g(event.pos); break;
/*     */         } 
/*     */       } 
/*     */       BlockPos above;
/* 190 */       if (((Boolean)this.doubleBreak.getValue()).booleanValue() && BlockUtil.canBreak(above = event.pos.func_177982_a(0, 1, 0)) && mc.field_71439_g.func_70011_f(above.func_177958_n(), above.func_177956_o(), above.func_177952_p()) <= 5.0D) {
/* 191 */         mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 192 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, above, event.facing));
/* 193 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, above, event.facing));
/* 194 */         mc.field_71442_b.func_187103_a(above);
/* 195 */         mc.field_71441_e.func_175698_g(above);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getPickSlot() {
/* 201 */     for (int i = 0; i < 9; ) {
/* 202 */       if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() != Items.field_151046_w) { i++; continue; }
/* 203 */        return i;
/*     */     } 
/* 205 */     return -1;
/*     */   }
/*     */   
/*     */   private void showAnimation(boolean isMining, BlockPos lastPos, EnumFacing lastFacing) {
/* 209 */     this.isMining = isMining;
/* 210 */     this.lastPos = lastPos;
/* 211 */     this.lastFacing = lastFacing;
/*     */   }
/*     */   
/*     */   public void showAnimation() {
/* 215 */     showAnimation(false, (BlockPos)null, (EnumFacing)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/* 220 */     return this.mode.currentEnumName();
/*     */   }
/*     */   
/*     */   public enum Mode {
/* 224 */     PACKET,
/* 225 */     DAMAGE,
/* 226 */     INSTANT;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\player\Speedmine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */