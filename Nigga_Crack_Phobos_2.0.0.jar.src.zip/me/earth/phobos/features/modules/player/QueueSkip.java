/*    */ package me.earth.phobos.features.modules.player;
/*    */ 
/*    */ import me.earth.phobos.features.command.Command;
/*    */ import me.earth.phobos.features.modules.Module;
/*    */ import me.earth.phobos.features.setting.Setting;
/*    */ 
/*    */ public class QueueSkip extends Module {
/*    */   private Setting<PrioMode> Mode;
/*    */   private Setting<ServerMode> Server;
/*    */   private Setting<Integer> Players;
/*    */   
/*    */   public QueueSkip() {
/* 13 */     super("QueueSkip", "Skips Queue", Module.Category.PLAYER, true, false, false);
/* 14 */     this.Mode = register(new Setting("Mode", PrioMode.NORM));
/* 15 */     this.Server = register(new Setting("Server", ServerMode.NORMAL));
/* 16 */     this.Players = register(new Setting("Players", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(400)));
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 21 */     Command.sendMessage("Skipping the queue...");
/*    */     
/*    */     try {
/* 24 */       Thread.sleep(4000L);
/* 25 */     } catch (InterruptedException ex) {
/* 26 */       Thread.currentThread().interrupt();
/*    */     } 
/* 28 */     Command.sendMessage("Skipped the queue!");
/* 29 */     Command.sendMessage("You can now turn off queue skip!");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {}
/*    */ 
/*    */   
/*    */   private enum PrioMode
/*    */   {
/* 38 */     PRIO,
/* 39 */     NORM;
/*    */   }
/*    */   
/*    */   private enum ServerMode {
/* 43 */     NORMAL,
/* 44 */     OLDFAG;
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\player\QueueSkip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */