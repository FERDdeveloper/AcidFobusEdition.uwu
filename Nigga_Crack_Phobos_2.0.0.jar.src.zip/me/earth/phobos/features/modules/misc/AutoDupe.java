/*    */ package me.earth.phobos.features.modules.misc;
/*    */ 
/*    */ import java.util.Random;
/*    */ import me.earth.phobos.features.command.Command;
/*    */ import me.earth.phobos.features.modules.Module;
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraft.client.multiplayer.WorldClient;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class AutoDupe
/*    */   extends Module {
/* 14 */   private final Random random = new Random();
/*    */   
/*    */   public AutoDupe() {
/* 17 */     super("AutoDupe", "Dupes for you!", Module.Category.MISC, true, false, false);
/*    */   }
/*    */   
/*    */   public void onEnable() {
/* 21 */     EntityPlayerSP player = mc.field_71439_g;
/* 22 */     WorldClient world = mc.field_71441_e;
/*    */     
/* 24 */     if (player == null || mc.field_71441_e == null)
/*    */       return; 
/* 26 */     ItemStack itemStack = player.func_184614_ca();
/*    */     
/* 28 */     if (itemStack.func_190926_b()) {
/* 29 */       Command.sendMessage("Hold an item in your hand!");
/* 30 */       disable();
/*    */       
/*    */       return;
/*    */     } 
/* 34 */     int count = this.random.nextInt(31) + 1;
/*    */     
/* 36 */     for (int i = 0; i <= count; i++) {
/* 37 */       EntityItem entityItem = player.func_146097_a(itemStack.func_77946_l(), false, true);
/* 38 */       if (entityItem != null) world.func_73027_a(entityItem.field_145783_c, (Entity)entityItem);
/*    */     
/*    */     } 
/* 41 */     int total = count * itemStack.func_190916_E();
/* 42 */     disable();
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\misc\AutoDupe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */