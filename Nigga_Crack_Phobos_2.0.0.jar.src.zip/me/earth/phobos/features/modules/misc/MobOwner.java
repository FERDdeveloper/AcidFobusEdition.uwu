/*    */ package me.earth.phobos.features.modules.misc;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import me.earth.phobos.features.modules.Module;
/*    */ import me.earth.phobos.util.PlayerUtil;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.passive.AbstractHorse;
/*    */ import net.minecraft.entity.passive.EntityTameable;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class MobOwner extends Module {
/* 14 */   private final Map<Entity, String> owners = new HashMap<>();
/*    */   
/* 16 */   private final Map<Entity, UUID> toLookUp = new ConcurrentHashMap<>();
/*    */   
/* 18 */   private final List<Entity> lookedUp = new ArrayList<>();
/*    */   
/*    */   public MobOwner() {
/* 21 */     super("MobOwner", "Shows you who owns mobs.", Module.Category.MISC, false, false, false);
/*    */   }
/*    */   
/*    */   public void onUpdate() {
/* 25 */     if (fullNullCheck())
/*    */       return; 
/* 27 */     if (PlayerUtil.timer.passedS(5.0D))
/* 28 */       for (Map.Entry<Entity, UUID> entry : this.toLookUp.entrySet()) {
/* 29 */         Entity entity = entry.getKey();
/* 30 */         UUID uuid = entry.getValue();
/* 31 */         if (uuid != null) {
/* 32 */           EntityPlayer owner = mc.field_71441_e.func_152378_a(uuid);
/* 33 */           if (owner != null) {
/* 34 */             this.owners.put(entity, owner.func_70005_c_());
/* 35 */             this.lookedUp.add(entity);
/*    */             continue;
/*    */           } 
/*    */           try {
/* 39 */             String name = PlayerUtil.getNameFromUUID(uuid);
/* 40 */             if (name != null) {
/* 41 */               this.owners.put(entity, name);
/* 42 */               this.lookedUp.add(entity);
/*    */             } 
/* 44 */           } catch (Exception e) {
/* 45 */             this.lookedUp.add(entity);
/* 46 */             this.toLookUp.remove(entry);
/*    */           } 
/* 48 */           PlayerUtil.timer.reset();
/*    */           break;
/*    */         } 
/* 51 */         this.lookedUp.add(entity);
/* 52 */         this.toLookUp.remove(entry);
/*    */       }  
/* 54 */     for (Entity entity : mc.field_71441_e.func_72910_y()) {
/* 55 */       if (!entity.func_174833_aM()) {
/* 56 */         if (entity instanceof EntityTameable) {
/* 57 */           EntityTameable tameableEntity = (EntityTameable)entity;
/* 58 */           if (tameableEntity.func_70909_n() && tameableEntity.func_184753_b() != null) {
/* 59 */             if (this.owners.get(tameableEntity) != null) {
/* 60 */               tameableEntity.func_174805_g(true);
/* 61 */               tameableEntity.func_96094_a(this.owners.get(tameableEntity));
/*    */               continue;
/*    */             } 
/* 64 */             if (!this.lookedUp.contains(entity))
/* 65 */               this.toLookUp.put(tameableEntity, tameableEntity.func_184753_b()); 
/*    */           } 
/*    */           continue;
/*    */         } 
/* 69 */         if (entity instanceof AbstractHorse) {
/* 70 */           AbstractHorse tameableEntity = (AbstractHorse)entity;
/* 71 */           if (tameableEntity.func_110248_bS() && tameableEntity.func_184780_dh() != null) {
/* 72 */             if (this.owners.get(tameableEntity) != null) {
/* 73 */               tameableEntity.func_174805_g(true);
/* 74 */               tameableEntity.func_96094_a(this.owners.get(tameableEntity));
/*    */               continue;
/*    */             } 
/* 77 */             if (!this.lookedUp.contains(entity))
/* 78 */               this.toLookUp.put(tameableEntity, tameableEntity.func_184780_dh()); 
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void onDisable() {
/* 86 */     for (Entity entity : mc.field_71441_e.field_72996_f) {
/* 87 */       if (entity instanceof EntityTameable || entity instanceof AbstractHorse)
/*    */         try {
/* 89 */           entity.func_174805_g(false);
/* 90 */         } catch (Exception exception) {} 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\misc\MobOwner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */