/*     */ package me.earth.phobos.features.modules.misc;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.DeathEvent;
/*     */ import me.earth.phobos.event.events.PacketEvent;
/*     */ import me.earth.phobos.features.command.Command;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.modules.combat.AutoCrystal;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.manager.FileManager;
/*     */ import me.earth.phobos.util.MathUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketChatMessage;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.event.entity.player.AttackEntityEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class AutoGG
/*     */   extends Module
/*     */ {
/*     */   private static final String path = "phobos/autogg.txt";
/*  31 */   private final Setting<Boolean> greentext = register(new Setting("Greentext", Boolean.valueOf(false)));
/*  32 */   private final Setting<Boolean> loadFiles = register(new Setting("LoadFiles", Boolean.valueOf(false)));
/*  33 */   private final Setting<Integer> targetResetTimer = register(new Setting("Reset", Integer.valueOf(30), Integer.valueOf(0), Integer.valueOf(90)));
/*  34 */   private final Setting<Integer> delay = register(new Setting("Delay", Integer.valueOf(10), Integer.valueOf(0), Integer.valueOf(30)));
/*  35 */   private final Setting<Boolean> test = register(new Setting("Test", Boolean.valueOf(false)));
/*  36 */   public Map<EntityPlayer, Integer> targets = new ConcurrentHashMap<>();
/*  37 */   public List<String> messages = new ArrayList<>();
/*     */   public EntityPlayer cauraTarget;
/*  39 */   private final Timer timer = new Timer();
/*  40 */   private final Timer cooldownTimer = new Timer();
/*     */   private boolean cooldown;
/*     */   
/*     */   public AutoGG() {
/*  44 */     super("AutoGG", "Automatically GGs", Module.Category.MISC, true, false, false);
/*  45 */     File file = new File("phobos/autogg.txt");
/*  46 */     if (!file.exists()) {
/*     */       try {
/*  48 */         file.createNewFile();
/*  49 */       } catch (Exception e) {
/*  50 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  57 */     loadMessages();
/*  58 */     this.timer.reset();
/*  59 */     this.cooldownTimer.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  64 */     if (((Boolean)this.loadFiles.getValue()).booleanValue()) {
/*  65 */       loadMessages();
/*  66 */       Command.sendMessage("<AutoGG> Loaded messages.");
/*  67 */       this.loadFiles.setValue(Boolean.valueOf(false));
/*     */     } 
/*  69 */     if (AutoCrystal.target != null && this.cauraTarget != AutoCrystal.target) {
/*  70 */       this.cauraTarget = AutoCrystal.target;
/*     */     }
/*  72 */     if (((Boolean)this.test.getValue()).booleanValue()) {
/*  73 */       announceDeath((EntityPlayer)mc.field_71439_g);
/*  74 */       this.test.setValue(Boolean.valueOf(false));
/*     */     } 
/*  76 */     if (!this.cooldown) {
/*  77 */       this.cooldownTimer.reset();
/*     */     }
/*  79 */     if (this.cooldownTimer.passedS(((Integer)this.delay.getValue()).intValue()) && this.cooldown) {
/*  80 */       this.cooldown = false;
/*  81 */       this.cooldownTimer.reset();
/*     */     } 
/*  83 */     if (AutoCrystal.target != null) {
/*  84 */       this.targets.put(AutoCrystal.target, Integer.valueOf((int)(this.timer.getPassedTimeMs() / 1000L)));
/*     */     }
/*  86 */     this.targets.replaceAll((p, v) -> Integer.valueOf((int)(this.timer.getPassedTimeMs() / 1000L)));
/*  87 */     for (EntityPlayer player : this.targets.keySet()) {
/*  88 */       if (((Integer)this.targets.get(player)).intValue() <= ((Integer)this.targetResetTimer.getValue()).intValue())
/*  89 */         continue;  this.targets.remove(player);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntityDeath(DeathEvent event) {
/*  95 */     if (this.targets.containsKey(event.player) && !this.cooldown) {
/*  96 */       announceDeath(event.player);
/*  97 */       this.cooldown = true;
/*  98 */       this.targets.remove(event.player);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onAttackEntity(AttackEntityEvent event) {
/* 104 */     if (event.getTarget() instanceof EntityPlayer && !Phobos.friendManager.isFriend(event.getEntityPlayer())) {
/* 105 */       this.targets.put((EntityPlayer)event.getTarget(), Integer.valueOf(0));
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onSendAttackPacket(PacketEvent.Send event) {
/*     */     CPacketUseEntity packet;
/* 112 */     if (event.getPacket() instanceof CPacketUseEntity && (packet = (CPacketUseEntity)event.getPacket()).func_149565_c() == CPacketUseEntity.Action.ATTACK && packet.func_149564_a((World)mc.field_71441_e) instanceof EntityPlayer && !Phobos.friendManager.isFriend((EntityPlayer)packet.func_149564_a((World)mc.field_71441_e))) {
/* 113 */       this.targets.put((EntityPlayer)packet.func_149564_a((World)mc.field_71441_e), Integer.valueOf(0));
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadMessages() {
/* 118 */     this.messages = FileManager.readTextFileAllLines("phobos/autogg.txt");
/*     */   }
/*     */   
/*     */   public String getRandomMessage() {
/* 122 */     loadMessages();
/* 123 */     Random rand = new Random();
/* 124 */     if (this.messages.size() == 0) {
/* 125 */       return "<player> is a noob hahaha fobus on tope";
/*     */     }
/* 127 */     if (this.messages.size() == 1) {
/* 128 */       return this.messages.get(0);
/*     */     }
/* 130 */     return this.messages.get(MathUtil.clamp(rand.nextInt(this.messages.size()), 0, this.messages.size() - 1));
/*     */   }
/*     */   
/*     */   public void announceDeath(EntityPlayer target) {
/* 134 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage((((Boolean)this.greentext.getValue()).booleanValue() ? ">" : "") + getRandomMessage().replaceAll("<player>", target.getDisplayNameString())));
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\misc\AutoGG.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */