/*     */ package me.earth.phobos.features.modules.combat;
/*     */ 
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.PacketEvent;
/*     */ import me.earth.phobos.event.events.ProcessRightClickBlockEvent;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Bind;
/*     */ import me.earth.phobos.features.setting.EnumConverter;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.InventoryUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.block.BlockWeb;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.InputEvent;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Offhand
/*     */   extends Module
/*     */ {
/*     */   private static Offhand instance;
/*  48 */   private final Queue<InventoryUtil.Task> taskList = new ConcurrentLinkedQueue<>();
/*  49 */   public Setting<Type> type = register(new Setting("Mode", Type.NEW));
/*  50 */   public Setting<Boolean> cycle = register(new Setting("Cycle", Boolean.valueOf(false), v -> (this.type.getValue() == Type.OLD)));
/*  51 */   public Setting<Bind> cycleKey = register(new Setting("Key", new Bind(-1), v -> (((Boolean)this.cycle.getValue()).booleanValue() && this.type.getValue() == Type.OLD)));
/*  52 */   public Setting<Bind> offHandGapple = register(new Setting("Gapple", new Bind(-1)));
/*  53 */   public Setting<Float> gappleHealth = register(new Setting("G-Health", Float.valueOf(13.0F), Float.valueOf(0.1F), Float.valueOf(36.0F)));
/*  54 */   public Setting<Float> gappleHoleHealth = register(new Setting("G-H-Health", Float.valueOf(3.5F), Float.valueOf(0.1F), Float.valueOf(36.0F)));
/*  55 */   public Setting<Bind> offHandCrystal = register(new Setting("Crystal", new Bind(-1)));
/*  56 */   public Setting<Float> crystalHealth = register(new Setting("C-Health", Float.valueOf(13.0F), Float.valueOf(0.1F), Float.valueOf(36.0F)));
/*  57 */   public Setting<Float> crystalHoleHealth = register(new Setting("C-H-Health", Float.valueOf(3.5F), Float.valueOf(0.1F), Float.valueOf(36.0F)));
/*  58 */   public Setting<Float> cTargetDistance = register(new Setting("C-Distance", Float.valueOf(10.0F), Float.valueOf(1.0F), Float.valueOf(20.0F)));
/*  59 */   public Setting<Bind> obsidian = register(new Setting("Obsidian", new Bind(-1)));
/*  60 */   public Setting<Float> obsidianHealth = register(new Setting("O-Health", Float.valueOf(13.0F), Float.valueOf(0.1F), Float.valueOf(36.0F)));
/*  61 */   public Setting<Float> obsidianHoleHealth = register(new Setting("O-H-Health", Float.valueOf(8.0F), Float.valueOf(0.1F), Float.valueOf(36.0F)));
/*  62 */   public Setting<Bind> webBind = register(new Setting("Webs", new Bind(-1)));
/*  63 */   public Setting<Float> webHealth = register(new Setting("W-Health", Float.valueOf(13.0F), Float.valueOf(0.1F), Float.valueOf(36.0F)));
/*  64 */   public Setting<Float> webHoleHealth = register(new Setting("W-H-Health", Float.valueOf(8.0F), Float.valueOf(0.1F), Float.valueOf(36.0F)));
/*  65 */   public Setting<Boolean> holeCheck = register(new Setting("Hole-Check", Boolean.valueOf(true)));
/*  66 */   public Setting<Boolean> crystalCheck = register(new Setting("Crystal-Check", Boolean.valueOf(false)));
/*  67 */   public Setting<Boolean> gapSwap = register(new Setting("Gap-Swap", Boolean.valueOf(true)));
/*  68 */   public Setting<Integer> updates = register(new Setting("Updates", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(2)));
/*  69 */   public Setting<Boolean> cycleObby = register(new Setting("CycleObby", Boolean.valueOf(false), v -> (this.type.getValue() == Type.OLD)));
/*  70 */   public Setting<Boolean> cycleWebs = register(new Setting("CycleWebs", Boolean.valueOf(false), v -> (this.type.getValue() == Type.OLD)));
/*  71 */   public Setting<Boolean> crystalToTotem = register(new Setting("Crystal-Totem", Boolean.valueOf(true), v -> (this.type.getValue() == Type.OLD)));
/*  72 */   public Setting<Boolean> absorption = register(new Setting("Absorption", Boolean.valueOf(false), v -> (this.type.getValue() == Type.OLD)));
/*  73 */   public Setting<Boolean> autoGapple = register(new Setting("AutoGapple", Boolean.valueOf(false), v -> (this.type.getValue() == Type.OLD)));
/*  74 */   public Setting<Boolean> onlyWTotem = register(new Setting("OnlyWTotem", Boolean.valueOf(true), v -> (((Boolean)this.autoGapple.getValue()).booleanValue() && this.type.getValue() == Type.OLD)));
/*  75 */   public Setting<Boolean> unDrawTotem = register(new Setting("DrawTotems", Boolean.valueOf(true), v -> (this.type.getValue() == Type.OLD)));
/*  76 */   public Setting<Boolean> noOffhandGC = register(new Setting("NoOGC", Boolean.valueOf(false)));
/*  77 */   public Setting<Boolean> retardOGC = register(new Setting("RetardOGC", Boolean.valueOf(false)));
/*  78 */   public Setting<Boolean> returnToCrystal = register(new Setting("RecoverySwitch", Boolean.valueOf(false)));
/*  79 */   public Setting<Integer> timeout = register(new Setting("Timeout", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(500)));
/*  80 */   public Setting<Integer> timeout2 = register(new Setting("Timeout2", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(500)));
/*  81 */   public Setting<Integer> actions = register(new Setting("Actions", Integer.valueOf(4), Integer.valueOf(1), Integer.valueOf(4), v -> (this.type.getValue() == Type.OLD)));
/*  82 */   public Setting<NameMode> displayNameChange = register(new Setting("Name", NameMode.TOTEM, v -> (this.type.getValue() == Type.OLD)));
/*  83 */   public Setting<Boolean> guis = register(new Setting("Guis", Boolean.valueOf(false)));
/*  84 */   public Mode mode = Mode.CRYSTALS;
/*  85 */   public Mode oldMode = Mode.CRYSTALS;
/*  86 */   public Mode2 currentMode = Mode2.TOTEMS;
/*  87 */   public int totems = 0;
/*  88 */   public int crystals = 0;
/*  89 */   public int gapples = 0;
/*  90 */   public int obby = 0;
/*  91 */   public int webs = 0;
/*  92 */   public int lastTotemSlot = -1;
/*  93 */   public int lastGappleSlot = -1;
/*  94 */   public int lastCrystalSlot = -1;
/*  95 */   public int lastObbySlot = -1;
/*  96 */   public int lastWebSlot = -1;
/*     */   public boolean holdingCrystal = false;
/*     */   public boolean holdingTotem = false;
/*     */   public boolean holdingGapple = false;
/*     */   public boolean holdingObby = false;
/*     */   public boolean holdingWeb = false;
/*     */   public boolean didSwitchThisTick = false;
/* 103 */   private int oldSlot = -1;
/*     */   private boolean swapToTotem = false;
/*     */   private boolean eatingApple = false;
/*     */   private boolean oldSwapToTotem = false;
/*     */   private boolean autoGappleSwitch = false;
/* 108 */   private final Timer timer = new Timer();
/* 109 */   private final Timer secondTimer = new Timer();
/*     */   private boolean second = false;
/*     */   private boolean switchedForHealthReason = false;
/*     */   
/*     */   public Offhand() {
/* 114 */     super("Offhand", "Allows you to switch up your Offhand.", Module.Category.COMBAT, true, false, false);
/* 115 */     instance = this;
/*     */   }
/*     */   
/*     */   public static Offhand getInstance() {
/* 119 */     if (instance == null) {
/* 120 */       instance = new Offhand();
/*     */     }
/* 122 */     return instance;
/*     */   }
/*     */   
/*     */   public void onItemFinish(ItemStack stack, EntityLivingBase base) {
/* 126 */     if (((Boolean)this.noOffhandGC.getValue()).booleanValue() && base.equals(mc.field_71439_g) && stack.func_77973_b() == mc.field_71439_g.func_184592_cb().func_77973_b()) {
/* 127 */       this.secondTimer.reset();
/* 128 */       this.second = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/* 134 */     if (nullCheck() || ((Integer)this.updates.getValue()).intValue() == 1) {
/*     */       return;
/*     */     }
/* 137 */     doOffhand();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(ProcessRightClickBlockEvent event) {
/* 142 */     if (((Boolean)this.noOffhandGC.getValue()).booleanValue() && event.hand == EnumHand.MAIN_HAND && event.stack.func_77973_b() == Items.field_185158_cP && mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71476_x != null && event.pos == mc.field_71476_x.func_178782_a()) {
/* 143 */       event.setCanceled(true);
/* 144 */       mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
/* 145 */       mc.field_71442_b.func_187101_a((EntityPlayer)mc.field_71439_g, (World)mc.field_71441_e, EnumHand.OFF_HAND);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 151 */     if (((Boolean)this.noOffhandGC.getValue()).booleanValue() && ((Boolean)this.retardOGC.getValue()).booleanValue()) {
/* 152 */       if (this.timer.passedMs(((Integer)this.timeout.getValue()).intValue())) {
/* 153 */         if (mc.field_71439_g != null && mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP && Mouse.isButtonDown(1)) {
/* 154 */           mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
/* 155 */           mc.field_71474_y.field_74313_G.field_74513_e = Mouse.isButtonDown(1);
/*     */         } 
/* 157 */       } else if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP) {
/* 158 */         mc.field_71474_y.field_74313_G.field_74513_e = false;
/*     */       } 
/*     */     }
/* 161 */     if (nullCheck() || ((Integer)this.updates.getValue()).intValue() == 2) {
/*     */       return;
/*     */     }
/* 164 */     doOffhand();
/* 165 */     if (this.secondTimer.passedMs(((Integer)this.timeout2.getValue()).intValue()) && this.second) {
/* 166 */       this.second = false;
/* 167 */       this.timer.reset();
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.NORMAL, receiveCanceled = true)
/*     */   public void onKeyInput(InputEvent.KeyInputEvent event) {
/* 173 */     if (Keyboard.getEventKeyState()) {
/* 174 */       if (this.type.getValue() == Type.NEW) {
/* 175 */         if (((Bind)this.offHandCrystal.getValue()).getKey() == Keyboard.getEventKey()) {
/* 176 */           if (this.mode == Mode.CRYSTALS) {
/* 177 */             setSwapToTotem(!isSwapToTotem());
/*     */           } else {
/* 179 */             setSwapToTotem(false);
/*     */           } 
/* 181 */           setMode(Mode.CRYSTALS);
/*     */         } 
/* 183 */         if (((Bind)this.offHandGapple.getValue()).getKey() == Keyboard.getEventKey()) {
/* 184 */           if (this.mode == Mode.GAPPLES) {
/* 185 */             setSwapToTotem(!isSwapToTotem());
/*     */           } else {
/* 187 */             setSwapToTotem(false);
/*     */           } 
/* 189 */           setMode(Mode.GAPPLES);
/*     */         } 
/* 191 */         if (((Bind)this.obsidian.getValue()).getKey() == Keyboard.getEventKey()) {
/* 192 */           if (this.mode == Mode.OBSIDIAN) {
/* 193 */             setSwapToTotem(!isSwapToTotem());
/*     */           } else {
/* 195 */             setSwapToTotem(false);
/*     */           } 
/* 197 */           setMode(Mode.OBSIDIAN);
/*     */         } 
/* 199 */         if (((Bind)this.webBind.getValue()).getKey() == Keyboard.getEventKey()) {
/* 200 */           if (this.mode == Mode.WEBS) {
/* 201 */             setSwapToTotem(!isSwapToTotem());
/*     */           } else {
/* 203 */             setSwapToTotem(false);
/*     */           } 
/* 205 */           setMode(Mode.WEBS);
/*     */         } 
/* 207 */       } else if (((Boolean)this.cycle.getValue()).booleanValue()) {
/* 208 */         if (((Bind)this.cycleKey.getValue()).getKey() == Keyboard.getEventKey()) {
/* 209 */           Mode2 newMode = (Mode2)EnumConverter.increaseEnum(this.currentMode);
/* 210 */           if ((newMode == Mode2.OBSIDIAN && !((Boolean)this.cycleObby.getValue()).booleanValue()) || (newMode == Mode2.WEBS && !((Boolean)this.cycleWebs.getValue()).booleanValue())) {
/* 211 */             newMode = Mode2.TOTEMS;
/*     */           }
/* 213 */           setMode(newMode);
/*     */         } 
/*     */       } else {
/* 216 */         if (((Bind)this.offHandCrystal.getValue()).getKey() == Keyboard.getEventKey()) {
/* 217 */           setMode(Mode2.CRYSTALS);
/*     */         }
/* 219 */         if (((Bind)this.offHandGapple.getValue()).getKey() == Keyboard.getEventKey()) {
/* 220 */           setMode(Mode2.GAPPLES);
/*     */         }
/* 222 */         if (((Bind)this.obsidian.getValue()).getKey() == Keyboard.getEventKey()) {
/* 223 */           setMode(Mode2.OBSIDIAN);
/*     */         }
/* 225 */         if (((Bind)this.webBind.getValue()).getKey() == Keyboard.getEventKey()) {
/* 226 */           setMode(Mode2.WEBS);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.Send event) {
/* 234 */     if (((Boolean)this.noOffhandGC.getValue()).booleanValue() && !fullNullCheck() && mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP && mc.field_71474_y.field_74313_G.func_151470_d())
/*     */     {
/* 236 */       if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock)
/* 237 */       { CPacketPlayerTryUseItemOnBlock packet2 = (CPacketPlayerTryUseItemOnBlock)event.getPacket();
/* 238 */         if (packet2.func_187022_c() == EnumHand.MAIN_HAND && !AutoCrystal.placedPos.contains(packet2.func_187023_a())) {
/* 239 */           if (this.timer.passedMs(((Integer)this.timeout.getValue()).intValue())) {
/* 240 */             mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
/* 241 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItem(EnumHand.OFF_HAND));
/*     */           } 
/* 243 */           event.setCanceled(true);
/*     */         }  }
/* 245 */       else { CPacketPlayerTryUseItem packet; if (event.getPacket() instanceof CPacketPlayerTryUseItem && (packet = (CPacketPlayerTryUseItem)event.getPacket()).func_187028_a() == EnumHand.OFF_HAND && !this.timer.passedMs(((Integer)this.timeout.getValue()).intValue())) {
/* 246 */           event.setCanceled(true);
/*     */         } }
/*     */     
/*     */     }
/*     */   }
/*     */   
/*     */   public String getDisplayInfo() {
/* 253 */     if (this.type.getValue() == Type.NEW) {
/* 254 */       return String.valueOf(getStackSize());
/*     */     }
/* 256 */     switch ((NameMode)this.displayNameChange.getValue()) {
/*     */       case GAPPLES:
/* 258 */         return EnumConverter.getProperName(this.currentMode);
/*     */       
/*     */       case WEBS:
/* 261 */         if (this.currentMode == Mode2.TOTEMS) {
/* 262 */           return this.totems + "";
/*     */         }
/* 264 */         return EnumConverter.getProperName(this.currentMode);
/*     */     } 
/*     */     
/* 267 */     switch (this.currentMode) {
/*     */       case GAPPLES:
/* 269 */         return this.totems + "";
/*     */       
/*     */       case WEBS:
/* 272 */         return this.gapples + "";
/*     */     } 
/*     */     
/* 275 */     return this.crystals + "";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayName() {
/* 280 */     if (this.type.getValue() == Type.NEW) {
/* 281 */       if (!shouldTotem()) {
/* 282 */         switch (this.mode) {
/*     */           case GAPPLES:
/* 284 */             return "OffhandGapple";
/*     */           
/*     */           case WEBS:
/* 287 */             return "OffhandWebs";
/*     */           
/*     */           case OBSIDIAN:
/* 290 */             return "OffhandObby";
/*     */         } 
/*     */         
/* 293 */         return "OffhandCrystal";
/*     */       } 
/* 295 */       return "AutoTotem" + (!isSwapToTotem() ? ("-" + getModeStr()) : "");
/*     */     } 
/* 297 */     switch ((NameMode)this.displayNameChange.getValue()) {
/*     */       case GAPPLES:
/* 299 */         return (String)this.displayName.getValue();
/*     */       
/*     */       case WEBS:
/* 302 */         if (this.currentMode == Mode2.TOTEMS) {
/* 303 */           return "AutoTotem";
/*     */         }
/* 305 */         return (String)this.displayName.getValue();
/*     */     } 
/*     */     
/* 308 */     switch (this.currentMode) {
/*     */       case GAPPLES:
/* 310 */         return "AutoTotem";
/*     */       
/*     */       case WEBS:
/* 313 */         return "OffhandGapple";
/*     */       
/*     */       case OBSIDIAN:
/* 316 */         return "OffhandWebs";
/*     */       
/*     */       case CRYSTALS:
/* 319 */         return "OffhandObby";
/*     */     } 
/*     */     
/* 322 */     return "OffhandCrystal";
/*     */   }
/*     */   
/*     */   public void doOffhand() {
/* 326 */     if (this.type.getValue() == Type.NEW) {
/* 327 */       if (mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiContainer && !((Boolean)this.guis.getValue()).booleanValue() && !(mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiInventory)) {
/*     */         return;
/*     */       }
/* 330 */       if (((Boolean)this.gapSwap.getValue()).booleanValue()) {
/* 331 */         if ((getSlot(Mode.GAPPLES) != -1 || mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao) && mc.field_71439_g.func_184614_ca().func_77973_b() != Items.field_151153_ao && mc.field_71474_y.field_74313_G.func_151470_d()) {
/* 332 */           setMode(Mode.GAPPLES);
/* 333 */           this.eatingApple = true;
/* 334 */           this.swapToTotem = false;
/* 335 */         } else if (this.eatingApple) {
/* 336 */           setMode(this.oldMode);
/* 337 */           this.swapToTotem = this.oldSwapToTotem;
/* 338 */           this.eatingApple = false;
/*     */         } else {
/* 340 */           this.oldMode = this.mode;
/* 341 */           this.oldSwapToTotem = this.swapToTotem;
/*     */         } 
/*     */       }
/* 344 */       if (!shouldTotem()) {
/* 345 */         if (mc.field_71439_g.func_184592_cb() == ItemStack.field_190927_a || !isItemInOffhand()) {
/*     */           
/* 347 */           int slot = (getSlot(this.mode) < 9) ? (getSlot(this.mode) + 36) : getSlot(this.mode), n = slot;
/* 348 */           if (getSlot(this.mode) != -1) {
/* 349 */             if (this.oldSlot != -1) {
/* 350 */               mc.field_71442_b.func_187098_a(0, 45, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 351 */               mc.field_71442_b.func_187098_a(0, this.oldSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/*     */             } 
/* 353 */             this.oldSlot = slot;
/* 354 */             mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 355 */             mc.field_71442_b.func_187098_a(0, 45, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 356 */             mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/*     */           } 
/*     */         } 
/* 359 */       } else if (!this.eatingApple && (mc.field_71439_g.func_184592_cb() == ItemStack.field_190927_a || mc.field_71439_g.func_184592_cb().func_77973_b() != Items.field_190929_cY)) {
/*     */         
/* 361 */         int slot = (getTotemSlot() < 9) ? (getTotemSlot() + 36) : getTotemSlot(), n = slot;
/* 362 */         if (getTotemSlot() != -1) {
/* 363 */           mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 364 */           mc.field_71442_b.func_187098_a(0, 45, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 365 */           mc.field_71442_b.func_187098_a(0, this.oldSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 366 */           this.oldSlot = -1;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 370 */       if (!((Boolean)this.unDrawTotem.getValue()).booleanValue()) {
/* 371 */         manageDrawn();
/*     */       }
/* 373 */       this.didSwitchThisTick = false;
/* 374 */       this.holdingCrystal = (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP);
/* 375 */       this.holdingTotem = (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY);
/* 376 */       this.holdingGapple = (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao);
/* 377 */       this.holdingObby = InventoryUtil.isBlock(mc.field_71439_g.func_184592_cb().func_77973_b(), BlockObsidian.class);
/* 378 */       this.holdingWeb = InventoryUtil.isBlock(mc.field_71439_g.func_184592_cb().func_77973_b(), BlockWeb.class);
/* 379 */       this.totems = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_190929_cY)).mapToInt(ItemStack::func_190916_E).sum();
/* 380 */       if (this.holdingTotem) {
/* 381 */         this.totems += mc.field_71439_g.field_71071_by.field_184439_c.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_190929_cY)).mapToInt(ItemStack::func_190916_E).sum();
/*     */       }
/* 383 */       this.crystals = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_185158_cP)).mapToInt(ItemStack::func_190916_E).sum();
/* 384 */       if (this.holdingCrystal) {
/* 385 */         this.crystals += mc.field_71439_g.field_71071_by.field_184439_c.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_185158_cP)).mapToInt(ItemStack::func_190916_E).sum();
/*     */       }
/* 387 */       this.gapples = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_151153_ao)).mapToInt(ItemStack::func_190916_E).sum();
/* 388 */       if (this.holdingGapple) {
/* 389 */         this.gapples += mc.field_71439_g.field_71071_by.field_184439_c.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_151153_ao)).mapToInt(ItemStack::func_190916_E).sum();
/*     */       }
/* 391 */       if (this.currentMode == Mode2.WEBS || this.currentMode == Mode2.OBSIDIAN) {
/* 392 */         this.obby = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> InventoryUtil.isBlock(itemStack.func_77973_b(), BlockObsidian.class)).mapToInt(ItemStack::func_190916_E).sum();
/* 393 */         if (this.holdingObby) {
/* 394 */           this.obby += mc.field_71439_g.field_71071_by.field_184439_c.stream().filter(itemStack -> InventoryUtil.isBlock(itemStack.func_77973_b(), BlockObsidian.class)).mapToInt(ItemStack::func_190916_E).sum();
/*     */         }
/* 396 */         this.webs = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> InventoryUtil.isBlock(itemStack.func_77973_b(), BlockWeb.class)).mapToInt(ItemStack::func_190916_E).sum();
/* 397 */         if (this.holdingWeb) {
/* 398 */           this.webs += mc.field_71439_g.field_71071_by.field_184439_c.stream().filter(itemStack -> InventoryUtil.isBlock(itemStack.func_77973_b(), BlockWeb.class)).mapToInt(ItemStack::func_190916_E).sum();
/*     */         }
/*     */       } 
/* 401 */       doSwitch();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void manageDrawn() {
/* 406 */     if (this.currentMode == Mode2.TOTEMS && ((Boolean)this.drawn.getValue()).booleanValue()) {
/* 407 */       this.drawn.setValue(Boolean.valueOf(false));
/*     */     }
/* 409 */     if (this.currentMode != Mode2.TOTEMS && !((Boolean)this.drawn.getValue()).booleanValue())
/* 410 */       this.drawn.setValue(Boolean.valueOf(true)); 
/*     */   }
/*     */   
/*     */   public void doSwitch() {
/*     */     int lastSlot;
/* 415 */     if (((Boolean)this.autoGapple.getValue()).booleanValue()) {
/* 416 */       if (mc.field_71474_y.field_74313_G.func_151470_d()) {
/* 417 */         if (mc.field_71439_g.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemSword && (!((Boolean)this.onlyWTotem.getValue()).booleanValue() || mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY)) {
/* 418 */           setMode(Mode.GAPPLES);
/* 419 */           this.autoGappleSwitch = true;
/*     */         } 
/* 421 */       } else if (this.autoGappleSwitch) {
/* 422 */         setMode(Mode2.TOTEMS);
/* 423 */         this.autoGappleSwitch = false;
/*     */       } 
/*     */     }
/* 426 */     if ((this.currentMode == Mode2.GAPPLES && ((!EntityUtil.isSafe((Entity)mc.field_71439_g) && EntityUtil.getHealth((Entity)mc.field_71439_g, ((Boolean)this.absorption.getValue()).booleanValue()) <= ((Float)this.gappleHealth.getValue()).floatValue()) || EntityUtil.getHealth((Entity)mc.field_71439_g, ((Boolean)this.absorption.getValue()).booleanValue()) <= ((Float)this.gappleHoleHealth.getValue()).floatValue())) || (this.currentMode == Mode2.CRYSTALS && ((!EntityUtil.isSafe((Entity)mc.field_71439_g) && EntityUtil.getHealth((Entity)mc.field_71439_g, ((Boolean)this.absorption.getValue()).booleanValue()) <= ((Float)this.crystalHealth.getValue()).floatValue()) || EntityUtil.getHealth((Entity)mc.field_71439_g, ((Boolean)this.absorption.getValue()).booleanValue()) <= ((Float)this.crystalHoleHealth.getValue()).floatValue())) || (this.currentMode == Mode2.OBSIDIAN && ((!EntityUtil.isSafe((Entity)mc.field_71439_g) && EntityUtil.getHealth((Entity)mc.field_71439_g, ((Boolean)this.absorption.getValue()).booleanValue()) <= ((Float)this.obsidianHealth.getValue()).floatValue()) || EntityUtil.getHealth((Entity)mc.field_71439_g, ((Boolean)this.absorption.getValue()).booleanValue()) <= ((Float)this.obsidianHoleHealth.getValue()).floatValue())) || (this.currentMode == Mode2.WEBS && ((!EntityUtil.isSafe((Entity)mc.field_71439_g) && EntityUtil.getHealth((Entity)mc.field_71439_g, ((Boolean)this.absorption.getValue()).booleanValue()) <= ((Float)this.webHealth.getValue()).floatValue()) || EntityUtil.getHealth((Entity)mc.field_71439_g, ((Boolean)this.absorption.getValue()).booleanValue()) <= ((Float)this.webHoleHealth.getValue()).floatValue()))) {
/* 427 */       if (((Boolean)this.returnToCrystal.getValue()).booleanValue() && this.currentMode == Mode2.CRYSTALS) {
/* 428 */         this.switchedForHealthReason = true;
/*     */       }
/* 430 */       setMode(Mode2.TOTEMS);
/*     */     } 
/* 432 */     if (this.switchedForHealthReason && ((EntityUtil.isSafe((Entity)mc.field_71439_g) && EntityUtil.getHealth((Entity)mc.field_71439_g, ((Boolean)this.absorption.getValue()).booleanValue()) > ((Float)this.crystalHoleHealth.getValue()).floatValue()) || EntityUtil.getHealth((Entity)mc.field_71439_g, ((Boolean)this.absorption.getValue()).booleanValue()) > ((Float)this.crystalHealth.getValue()).floatValue())) {
/* 433 */       setMode(Mode2.CRYSTALS);
/* 434 */       this.switchedForHealthReason = false;
/*     */     } 
/* 436 */     if (mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiContainer && !((Boolean)this.guis.getValue()).booleanValue() && !(mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiInventory)) {
/*     */       return;
/*     */     }
/* 439 */     Item currentOffhandItem = mc.field_71439_g.func_184592_cb().func_77973_b();
/* 440 */     switch (this.currentMode) {
/*     */       case GAPPLES:
/* 442 */         if (this.totems <= 0 || this.holdingTotem)
/* 443 */           break;  this.lastTotemSlot = InventoryUtil.findItemInventorySlot(Items.field_190929_cY, false);
/* 444 */         lastSlot = getLastSlot(currentOffhandItem, this.lastTotemSlot);
/* 445 */         putItemInOffhand(this.lastTotemSlot, lastSlot);
/*     */         break;
/*     */       
/*     */       case WEBS:
/* 449 */         if (this.gapples <= 0 || this.holdingGapple)
/* 450 */           break;  this.lastGappleSlot = InventoryUtil.findItemInventorySlot(Items.field_151153_ao, false);
/* 451 */         lastSlot = getLastSlot(currentOffhandItem, this.lastGappleSlot);
/* 452 */         putItemInOffhand(this.lastGappleSlot, lastSlot);
/*     */         break;
/*     */       
/*     */       case OBSIDIAN:
/* 456 */         if (this.webs <= 0 || this.holdingWeb)
/* 457 */           break;  this.lastWebSlot = InventoryUtil.findInventoryBlock(BlockWeb.class, false);
/* 458 */         lastSlot = getLastSlot(currentOffhandItem, this.lastWebSlot);
/* 459 */         putItemInOffhand(this.lastWebSlot, lastSlot);
/*     */         break;
/*     */       
/*     */       case CRYSTALS:
/* 463 */         if (this.obby <= 0 || this.holdingObby)
/* 464 */           break;  this.lastObbySlot = InventoryUtil.findInventoryBlock(BlockObsidian.class, false);
/* 465 */         lastSlot = getLastSlot(currentOffhandItem, this.lastObbySlot);
/* 466 */         putItemInOffhand(this.lastObbySlot, lastSlot);
/*     */         break;
/*     */       
/*     */       default:
/* 470 */         if (this.crystals <= 0 || this.holdingCrystal)
/* 471 */           break;  this.lastCrystalSlot = InventoryUtil.findItemInventorySlot(Items.field_185158_cP, false);
/* 472 */         lastSlot = getLastSlot(currentOffhandItem, this.lastCrystalSlot);
/* 473 */         putItemInOffhand(this.lastCrystalSlot, lastSlot);
/*     */         break;
/*     */     } 
/* 476 */     for (int i = 0; i < ((Integer)this.actions.getValue()).intValue(); i++) {
/* 477 */       InventoryUtil.Task task = this.taskList.poll();
/* 478 */       if (task != null) {
/* 479 */         task.run();
/* 480 */         if (task.isSwitching())
/* 481 */           this.didSwitchThisTick = true; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private int getLastSlot(Item item, int slotIn) {
/* 486 */     if (item == Items.field_185158_cP) {
/* 487 */       return this.lastCrystalSlot;
/*     */     }
/* 489 */     if (item == Items.field_151153_ao) {
/* 490 */       return this.lastGappleSlot;
/*     */     }
/* 492 */     if (item == Items.field_190929_cY) {
/* 493 */       return this.lastTotemSlot;
/*     */     }
/* 495 */     if (InventoryUtil.isBlock(item, BlockObsidian.class)) {
/* 496 */       return this.lastObbySlot;
/*     */     }
/* 498 */     if (InventoryUtil.isBlock(item, BlockWeb.class)) {
/* 499 */       return this.lastWebSlot;
/*     */     }
/* 501 */     if (item == Items.field_190931_a) {
/* 502 */       return -1;
/*     */     }
/* 504 */     return slotIn;
/*     */   }
/*     */   
/*     */   private void putItemInOffhand(int slotIn, int slotOut) {
/* 508 */     if (slotIn != -1 && this.taskList.isEmpty()) {
/* 509 */       this.taskList.add(new InventoryUtil.Task(slotIn));
/* 510 */       this.taskList.add(new InventoryUtil.Task(45));
/* 511 */       this.taskList.add(new InventoryUtil.Task(slotOut));
/* 512 */       this.taskList.add(new InventoryUtil.Task());
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean noNearbyPlayers() {
/* 517 */     return (this.mode == Mode.CRYSTALS && mc.field_71441_e.field_73010_i.stream().noneMatch(e -> (e != mc.field_71439_g && !Phobos.friendManager.isFriend(e) && mc.field_71439_g.func_70032_d((Entity)e) <= ((Float)this.cTargetDistance.getValue()).floatValue())));
/*     */   }
/*     */   
/*     */   private boolean isItemInOffhand() {
/* 521 */     switch (this.mode) {
/*     */       case GAPPLES:
/* 523 */         return (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao);
/*     */       
/*     */       case CRYSTALS:
/* 526 */         return (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP);
/*     */       
/*     */       case OBSIDIAN:
/* 529 */         return (mc.field_71439_g.func_184592_cb().func_77973_b() instanceof ItemBlock && ((ItemBlock)mc.field_71439_g.func_184592_cb().func_77973_b()).field_150939_a == Blocks.field_150343_Z);
/*     */       
/*     */       case WEBS:
/* 532 */         return (mc.field_71439_g.func_184592_cb().func_77973_b() instanceof ItemBlock && ((ItemBlock)mc.field_71439_g.func_184592_cb().func_77973_b()).field_150939_a == Blocks.field_150321_G);
/*     */     } 
/*     */     
/* 535 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isHeldInMainHand() {
/* 539 */     switch (this.mode) {
/*     */       case GAPPLES:
/* 541 */         return (mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_151153_ao);
/*     */       
/*     */       case CRYSTALS:
/* 544 */         return (mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP);
/*     */       
/*     */       case OBSIDIAN:
/* 547 */         return (mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemBlock && ((ItemBlock)mc.field_71439_g.func_184614_ca().func_77973_b()).field_150939_a == Blocks.field_150343_Z);
/*     */       
/*     */       case WEBS:
/* 550 */         return (mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemBlock && ((ItemBlock)mc.field_71439_g.func_184614_ca().func_77973_b()).field_150939_a == Blocks.field_150321_G);
/*     */     } 
/*     */     
/* 553 */     return false;
/*     */   }
/*     */   
/*     */   private boolean shouldTotem() {
/* 557 */     if (isHeldInMainHand() || isSwapToTotem()) {
/* 558 */       return true;
/*     */     }
/* 560 */     if (((Boolean)this.holeCheck.getValue()).booleanValue() && EntityUtil.isInHole((Entity)mc.field_71439_g)) {
/* 561 */       return (mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj() <= getHoleHealth() || mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() == Items.field_185160_cR || mc.field_71439_g.field_70143_R >= 3.0F || noNearbyPlayers() || (((Boolean)this.crystalCheck.getValue()).booleanValue() && isCrystalsAABBEmpty()));
/*     */     }
/* 563 */     return (mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj() <= getHealth() || mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() == Items.field_185160_cR || mc.field_71439_g.field_70143_R >= 3.0F || noNearbyPlayers() || (((Boolean)this.crystalCheck.getValue()).booleanValue() && isCrystalsAABBEmpty()));
/*     */   }
/*     */   
/*     */   private boolean isNotEmpty(BlockPos pos) {
/* 567 */     return mc.field_71441_e.func_72839_b(null, new AxisAlignedBB(pos)).stream().anyMatch(e -> e instanceof net.minecraft.entity.item.EntityEnderCrystal);
/*     */   }
/*     */   
/*     */   private float getHealth() {
/* 571 */     switch (this.mode) {
/*     */       case CRYSTALS:
/* 573 */         return ((Float)this.crystalHealth.getValue()).floatValue();
/*     */       
/*     */       case GAPPLES:
/* 576 */         return ((Float)this.gappleHealth.getValue()).floatValue();
/*     */       
/*     */       case OBSIDIAN:
/* 579 */         return ((Float)this.obsidianHealth.getValue()).floatValue();
/*     */     } 
/*     */     
/* 582 */     return ((Float)this.webHealth.getValue()).floatValue();
/*     */   }
/*     */   
/*     */   private float getHoleHealth() {
/* 586 */     switch (this.mode) {
/*     */       case CRYSTALS:
/* 588 */         return ((Float)this.crystalHoleHealth.getValue()).floatValue();
/*     */       
/*     */       case GAPPLES:
/* 591 */         return ((Float)this.gappleHoleHealth.getValue()).floatValue();
/*     */       
/*     */       case OBSIDIAN:
/* 594 */         return ((Float)this.obsidianHoleHealth.getValue()).floatValue();
/*     */     } 
/*     */     
/* 597 */     return ((Float)this.webHoleHealth.getValue()).floatValue();
/*     */   }
/*     */   
/*     */   private boolean isCrystalsAABBEmpty() {
/* 601 */     return (isNotEmpty(mc.field_71439_g.func_180425_c().func_177982_a(1, 0, 0)) || isNotEmpty(mc.field_71439_g.func_180425_c().func_177982_a(-1, 0, 0)) || isNotEmpty(mc.field_71439_g.func_180425_c().func_177982_a(0, 0, 1)) || isNotEmpty(mc.field_71439_g.func_180425_c().func_177982_a(0, 0, -1)) || isNotEmpty(mc.field_71439_g.func_180425_c()));
/*     */   }
/*     */   
/*     */   int getStackSize() {
/* 605 */     int size = 0;
/* 606 */     if (shouldTotem()) {
/* 607 */       for (int i = 45; i > 0; i--) {
/* 608 */         if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Items.field_190929_cY)
/* 609 */           size += mc.field_71439_g.field_71071_by.func_70301_a(i).func_190916_E(); 
/*     */       } 
/* 611 */     } else if (this.mode == Mode.OBSIDIAN) {
/* 612 */       for (int i = 45; i > 0; i--) {
/* 613 */         if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() instanceof ItemBlock && ((ItemBlock)mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b()).field_150939_a == Blocks.field_150343_Z)
/*     */         {
/* 615 */           size += mc.field_71439_g.field_71071_by.func_70301_a(i).func_190916_E(); } 
/*     */       } 
/* 617 */     } else if (this.mode == Mode.WEBS) {
/* 618 */       for (int i = 45; i > 0; i--) {
/* 619 */         if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() instanceof ItemBlock && ((ItemBlock)mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b()).field_150939_a == Blocks.field_150321_G)
/*     */         {
/* 621 */           size += mc.field_71439_g.field_71071_by.func_70301_a(i).func_190916_E(); } 
/*     */       } 
/*     */     } else {
/* 624 */       for (int i = 45; i > 0; i--) {
/* 625 */         if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == ((this.mode == Mode.CRYSTALS) ? Items.field_185158_cP : Items.field_151153_ao))
/*     */         {
/* 627 */           size += mc.field_71439_g.field_71071_by.func_70301_a(i).func_190916_E(); } 
/*     */       } 
/*     */     } 
/* 630 */     return size;
/*     */   }
/*     */   
/*     */   int getSlot(Mode m) {
/* 634 */     int slot = -1;
/* 635 */     if (m == Mode.OBSIDIAN) {
/* 636 */       for (int i = 45; i > 0; ) {
/* 637 */         if (!(mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() instanceof ItemBlock) || ((ItemBlock)mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b()).field_150939_a != Blocks.field_150343_Z) {
/*     */           i--; continue;
/* 639 */         }  slot = i;
/*     */       }
/*     */     
/* 642 */     } else if (m == Mode.WEBS) {
/* 643 */       for (int i = 45; i > 0; ) {
/* 644 */         if (!(mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() instanceof ItemBlock) || ((ItemBlock)mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b()).field_150939_a != Blocks.field_150321_G) {
/*     */           i--; continue;
/* 646 */         }  slot = i;
/*     */       } 
/*     */     } else {
/*     */       
/* 650 */       for (int i = 45; i > 0; ) {
/* 651 */         if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() != ((m == Mode.CRYSTALS) ? Items.field_185158_cP : Items.field_151153_ao)) {
/*     */           i--; continue;
/* 653 */         }  slot = i;
/*     */       } 
/*     */     } 
/*     */     
/* 657 */     return slot;
/*     */   }
/*     */   
/*     */   int getTotemSlot() {
/* 661 */     int totemSlot = -1;
/* 662 */     for (int i = 45; i > 0; ) {
/* 663 */       if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() != Items.field_190929_cY) { i--; continue; }
/* 664 */        totemSlot = i;
/*     */     } 
/*     */     
/* 667 */     return totemSlot;
/*     */   }
/*     */   
/*     */   private String getModeStr() {
/* 671 */     switch (this.mode) {
/*     */       case GAPPLES:
/* 673 */         return "G";
/*     */       
/*     */       case WEBS:
/* 676 */         return "W";
/*     */       
/*     */       case OBSIDIAN:
/* 679 */         return "O";
/*     */     } 
/*     */     
/* 682 */     return "C";
/*     */   }
/*     */   
/*     */   public void setMode(Mode mode) {
/* 686 */     this.mode = mode;
/*     */   }
/*     */   
/*     */   public void setMode(Mode2 mode) {
/* 690 */     this.currentMode = (this.currentMode == mode) ? Mode2.TOTEMS : ((!((Boolean)this.cycle.getValue()).booleanValue() && ((Boolean)this.crystalToTotem.getValue()).booleanValue() && (this.currentMode == Mode2.CRYSTALS || this.currentMode == Mode2.OBSIDIAN || this.currentMode == Mode2.WEBS) && mode == Mode2.GAPPLES) ? Mode2.TOTEMS : mode);
/*     */   }
/*     */   
/*     */   public boolean isSwapToTotem() {
/* 694 */     return this.swapToTotem;
/*     */   }
/*     */   
/*     */   public void setSwapToTotem(boolean swapToTotem) {
/* 698 */     this.swapToTotem = swapToTotem;
/*     */   }
/*     */   
/*     */   public enum NameMode {
/* 702 */     MODE,
/* 703 */     TOTEM,
/* 704 */     AMOUNT;
/*     */   }
/*     */   
/*     */   public enum Mode2
/*     */   {
/* 709 */     TOTEMS,
/* 710 */     GAPPLES,
/* 711 */     CRYSTALS,
/* 712 */     OBSIDIAN,
/* 713 */     WEBS;
/*     */   }
/*     */   
/*     */   public enum Type
/*     */   {
/* 718 */     OLD,
/* 719 */     NEW;
/*     */   }
/*     */   
/*     */   public enum Mode
/*     */   {
/* 724 */     CRYSTALS,
/* 725 */     GAPPLES,
/* 726 */     OBSIDIAN,
/* 727 */     WEBS;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\combat\Offhand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */