/*     */ package me.earth.phobos.features.modules.combat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
/*     */ import me.earth.phobos.features.command.Command;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.BlockUtil;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.InventoryUtil;
/*     */ import me.earth.phobos.util.MathUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.block.BlockWeb;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class Webaura extends Module {
/*  24 */   private final Setting<Integer> delay = register(new Setting("Delay/Place", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(250))); public static boolean isPlacing = false;
/*  25 */   private final Setting<Integer> blocksPerPlace = register(new Setting("Block/Place", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  26 */   private final Setting<Double> targetRange = register(new Setting("TargetRange", Double.valueOf(10.0D), Double.valueOf(0.0D), Double.valueOf(20.0D)));
/*  27 */   private final Setting<Double> range = register(new Setting("PlaceRange", Double.valueOf(6.0D), Double.valueOf(0.0D), Double.valueOf(10.0D)));
/*  28 */   private final Setting<TargetMode> targetMode = register(new Setting("Target", TargetMode.CLOSEST));
/*  29 */   private final Setting<InventoryUtil.Switch> switchMode = register(new Setting("Switch", InventoryUtil.Switch.NORMAL));
/*  30 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  31 */   private final Setting<Boolean> raytrace = register(new Setting("Raytrace", Boolean.valueOf(false)));
/*  32 */   private final Setting<Double> speed = register(new Setting("Speed", Double.valueOf(30.0D), Double.valueOf(0.0D), Double.valueOf(30.0D)));
/*  33 */   private final Setting<Boolean> upperBody = register(new Setting("Upper", Boolean.valueOf(false)));
/*  34 */   private final Setting<Boolean> lowerbody = register(new Setting("Lower", Boolean.valueOf(true)));
/*  35 */   private final Setting<Boolean> ylower = register(new Setting("Y-1", Boolean.valueOf(false)));
/*  36 */   private final Setting<Boolean> antiSelf = register(new Setting("AntiSelf", Boolean.valueOf(false)));
/*  37 */   private final Setting<Integer> eventMode = register(new Setting("Updates", Integer.valueOf(3), Integer.valueOf(1), Integer.valueOf(3)));
/*  38 */   private final Setting<Boolean> freecam = register(new Setting("Freecam", Boolean.valueOf(false)));
/*  39 */   private final Setting<Boolean> info = register(new Setting("Info", Boolean.valueOf(false)));
/*  40 */   private final Setting<Boolean> disable = register(new Setting("TSelfMove", Boolean.valueOf(false)));
/*  41 */   private final Setting<Boolean> packet = register(new Setting("Packet", Boolean.valueOf(false)));
/*  42 */   private final Timer timer = new Timer();
/*     */   public EntityPlayer target;
/*     */   private boolean didPlace = false;
/*     */   private boolean switchedItem;
/*     */   private boolean isSneaking;
/*     */   private int lastHotbarSlot;
/*  48 */   private int placements = 0;
/*     */   private boolean smartRotate = false;
/*  50 */   private BlockPos startPos = null;
/*     */   
/*     */   public Webaura() {
/*  53 */     super("Webaura", "Traps other players in webs", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  58 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/*  61 */     this.startPos = EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g);
/*  62 */     this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  67 */     if (((Integer)this.eventMode.getValue()).intValue() == 3) {
/*  68 */       this.smartRotate = false;
/*  69 */       doTrap();
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/*  75 */     if (event.getStage() == 0 && ((Integer)this.eventMode.getValue()).intValue() == 2) {
/*  76 */       this.smartRotate = (((Boolean)this.rotate.getValue()).booleanValue() && ((Integer)this.blocksPerPlace.getValue()).intValue() == 1);
/*  77 */       doTrap();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  83 */     if (((Integer)this.eventMode.getValue()).intValue() == 1) {
/*  84 */       this.smartRotate = false;
/*  85 */       doTrap();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/*  91 */     if (((Boolean)this.info.getValue()).booleanValue() && this.target != null) {
/*  92 */       return this.target.func_70005_c_();
/*     */     }
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  99 */     isPlacing = false;
/* 100 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 101 */     switchItem(true);
/*     */   }
/*     */   
/*     */   private void doTrap() {
/* 105 */     if (check()) {
/*     */       return;
/*     */     }
/* 108 */     doWebTrap();
/* 109 */     if (this.didPlace) {
/* 110 */       this.timer.reset();
/*     */     }
/*     */   }
/*     */   
/*     */   private void doWebTrap() {
/* 115 */     List<Vec3d> placeTargets = getPlacements();
/* 116 */     placeList(placeTargets);
/*     */   }
/*     */   
/*     */   private List<Vec3d> getPlacements() {
/* 120 */     ArrayList<Vec3d> list = new ArrayList<>();
/* 121 */     Vec3d baseVec = this.target.func_174791_d();
/* 122 */     if (((Boolean)this.ylower.getValue()).booleanValue()) {
/* 123 */       list.add(baseVec.func_72441_c(0.0D, -1.0D, 0.0D));
/*     */     }
/* 125 */     if (((Boolean)this.lowerbody.getValue()).booleanValue()) {
/* 126 */       list.add(baseVec);
/*     */     }
/* 128 */     if (((Boolean)this.upperBody.getValue()).booleanValue()) {
/* 129 */       list.add(baseVec.func_72441_c(0.0D, 1.0D, 0.0D));
/*     */     }
/* 131 */     return list;
/*     */   }
/*     */   
/*     */   private void placeList(List<Vec3d> list) {
/* 135 */     list.sort((vec3d, vec3d2) -> Double.compare(mc.field_71439_g.func_70092_e(vec3d2.field_72450_a, vec3d2.field_72448_b, vec3d2.field_72449_c), mc.field_71439_g.func_70092_e(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c)));
/* 136 */     list.sort(Comparator.comparingDouble(vec3d -> vec3d.field_72448_b));
/* 137 */     for (Vec3d vec3d3 : list) {
/* 138 */       BlockPos position = new BlockPos(vec3d3);
/* 139 */       int placeability = BlockUtil.isPositionPlaceable(position, ((Boolean)this.raytrace.getValue()).booleanValue());
/* 140 */       if ((placeability != 3 && placeability != 1) || (((Boolean)this.antiSelf.getValue()).booleanValue() && MathUtil.areVec3dsAligned(mc.field_71439_g.func_174791_d(), vec3d3)))
/*     */         continue; 
/* 142 */       placeBlock(position);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean check() {
/* 147 */     isPlacing = false;
/* 148 */     this.didPlace = false;
/* 149 */     this.placements = 0;
/* 150 */     int obbySlot = InventoryUtil.findHotbarBlock(BlockWeb.class);
/* 151 */     if (isOff()) {
/* 152 */       return true;
/*     */     }
/* 154 */     if (((Boolean)this.disable.getValue()).booleanValue() && !this.startPos.equals(EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g))) {
/* 155 */       disable();
/* 156 */       return true;
/*     */     } 
/* 158 */     if (obbySlot == -1) {
/* 159 */       if (this.switchMode.getValue() != InventoryUtil.Switch.NONE) {
/* 160 */         if (((Boolean)this.info.getValue()).booleanValue()) {
/* 161 */           Command.sendMessage("<" + getDisplayName() + "> §cYou are out of Webs.");
/*     */         }
/* 163 */         disable();
/*     */       } 
/* 165 */       return true;
/*     */     } 
/* 167 */     if (mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && mc.field_71439_g.field_71071_by.field_70461_c != obbySlot) {
/* 168 */       this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */     }
/* 170 */     switchItem(true);
/* 171 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 172 */     this.target = getTarget(((Double)this.targetRange.getValue()).doubleValue(), (this.targetMode.getValue() == TargetMode.UNTRAPPED));
/* 173 */     return (this.target == null || (Phobos.moduleManager.isModuleEnabled("Freecam") && !((Boolean)this.freecam.getValue()).booleanValue()) || !this.timer.passedMs(((Integer)this.delay.getValue()).intValue()) || (this.switchMode.getValue() == InventoryUtil.Switch.NONE && mc.field_71439_g.field_71071_by.field_70461_c != InventoryUtil.findHotbarBlock(BlockWeb.class)));
/*     */   }
/*     */   
/*     */   private EntityPlayer getTarget(double range, boolean trapped) {
/* 177 */     EntityPlayer target = null;
/* 178 */     double distance = Math.pow(range, 2.0D) + 1.0D;
/* 179 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 180 */       if (EntityUtil.isntValid((Entity)player, range) || (trapped && player.field_70134_J) || (EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g).equals(EntityUtil.getRoundedBlockPos((Entity)player)) && ((Boolean)this.antiSelf.getValue()).booleanValue()) || Phobos.speedManager.getPlayerSpeed(player) > ((Double)this.speed.getValue()).doubleValue())
/*     */         continue; 
/* 182 */       if (target == null) {
/* 183 */         target = player;
/* 184 */         distance = mc.field_71439_g.func_70068_e((Entity)player);
/*     */         continue;
/*     */       } 
/* 187 */       if (mc.field_71439_g.func_70068_e((Entity)player) >= distance)
/* 188 */         continue;  target = player;
/* 189 */       distance = mc.field_71439_g.func_70068_e((Entity)player);
/*     */     } 
/* 191 */     return target;
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 195 */     if (this.placements < ((Integer)this.blocksPerPlace.getValue()).intValue() && mc.field_71439_g.func_174818_b(pos) <= MathUtil.square(((Double)this.range.getValue()).doubleValue()) && switchItem(false)) {
/* 196 */       isPlacing = true;
/* 197 */       this.isSneaking = this.smartRotate ? BlockUtil.placeBlockSmartRotate(pos, EnumHand.MAIN_HAND, true, ((Boolean)this.packet.getValue()).booleanValue(), this.isSneaking) : BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), this.isSneaking);
/* 198 */       this.didPlace = true;
/* 199 */       this.placements++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean switchItem(boolean back) {
/* 204 */     boolean[] value = InventoryUtil.switchItem(back, this.lastHotbarSlot, this.switchedItem, (InventoryUtil.Switch)this.switchMode.getValue(), BlockWeb.class);
/* 205 */     this.switchedItem = value[0];
/* 206 */     return value[1];
/*     */   }
/*     */   
/*     */   public enum TargetMode {
/* 210 */     CLOSEST,
/* 211 */     UNTRAPPED;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\combat\Webaura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */