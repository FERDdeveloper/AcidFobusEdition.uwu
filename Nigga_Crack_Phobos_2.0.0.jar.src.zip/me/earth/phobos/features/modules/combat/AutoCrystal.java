/*      */ package me.earth.phobos.features.modules.combat;
/*      */ import com.mojang.authlib.GameProfile;
/*      */ import java.awt.Color;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Queue;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentLinkedQueue;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import me.earth.phobos.Phobos;
/*      */ import me.earth.phobos.event.events.ClientEvent;
/*      */ import me.earth.phobos.event.events.PacketEvent;
/*      */ import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
/*      */ import me.earth.phobos.features.command.Command;
/*      */ import me.earth.phobos.features.modules.Module;
/*      */ import me.earth.phobos.features.modules.client.Colors;
/*      */ import me.earth.phobos.features.setting.Bind;
/*      */ import me.earth.phobos.features.setting.Setting;
/*      */ import me.earth.phobos.util.BlockUtil;
/*      */ import me.earth.phobos.util.DamageUtil;
/*      */ import me.earth.phobos.util.EntityUtil;
/*      */ import me.earth.phobos.util.InventoryUtil;
/*      */ import me.earth.phobos.util.MathUtil;
/*      */ import me.earth.phobos.util.RenderUtil;
/*      */ import me.earth.phobos.util.Timer;
/*      */ import net.minecraft.block.Block;
/*      */ import net.minecraft.block.state.IBlockState;
/*      */ import net.minecraft.client.entity.EntityOtherPlayerMP;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.player.EntityPlayer;
/*      */ import net.minecraft.init.Items;
/*      */ import net.minecraft.init.SoundEvents;
/*      */ import net.minecraft.item.ItemEndCrystal;
/*      */ import net.minecraft.network.Packet;
/*      */ import net.minecraft.network.play.client.CPacketPlayer;
/*      */ import net.minecraft.network.play.client.CPacketUseEntity;
/*      */ import net.minecraft.network.play.server.SPacketDestroyEntities;
/*      */ import net.minecraft.network.play.server.SPacketEntityStatus;
/*      */ import net.minecraft.network.play.server.SPacketExplosion;
/*      */ import net.minecraft.network.play.server.SPacketSoundEffect;
/*      */ import net.minecraft.network.play.server.SPacketSpawnObject;
/*      */ import net.minecraft.util.EnumFacing;
/*      */ import net.minecraft.util.EnumHand;
/*      */ import net.minecraft.util.SoundCategory;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.RayTraceResult;
/*      */ import net.minecraft.util.math.Vec3d;
/*      */ import net.minecraft.world.World;
/*      */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*      */ import org.lwjgl.input.Keyboard;
/*      */ import org.lwjgl.input.Mouse;
/*      */ 
/*      */ public class AutoCrystal extends Module {
/*   58 */   public static EntityPlayer target = null;
/*   59 */   public static Set<BlockPos> lowDmgPos = (Set<BlockPos>)new ConcurrentSet();
/*   60 */   public static Set<BlockPos> placedPos = new HashSet<>();
/*   61 */   public static Set<BlockPos> brokenPos = new HashSet<>();
/*      */   private static AutoCrystal instance;
/*   63 */   public final Timer threadTimer = new Timer();
/*   64 */   private final Setting<Settings> setting = register(new Setting("Settings", Settings.PLACE));
/*   65 */   public final Setting<Boolean> attackOppositeHand = register(new Setting("OppositeHand", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV)));
/*   66 */   public final Setting<Boolean> removeAfterAttack = register(new Setting("AttackRemove", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV)));
/*   67 */   private final Setting<Integer> switchCooldown = register(new Setting("Cooldown", Integer.valueOf(500), Integer.valueOf(0), Integer.valueOf(1000), v -> (this.setting.getValue() == Settings.MISC)));
/*   68 */   private final Setting<Integer> eventMode = register(new Setting("Updates", Integer.valueOf(3), Integer.valueOf(1), Integer.valueOf(3), v -> (this.setting.getValue() == Settings.DEV)));
/*   69 */   private final Timer switchTimer = new Timer();
/*   70 */   private final Timer manualTimer = new Timer();
/*   71 */   private final Timer breakTimer = new Timer();
/*   72 */   private final Timer placeTimer = new Timer();
/*   73 */   private final Timer syncTimer = new Timer();
/*   74 */   private final Timer predictTimer = new Timer();
/*   75 */   private final Timer renderTimer = new Timer();
/*   76 */   private final AtomicBoolean shouldInterrupt = new AtomicBoolean(false);
/*   77 */   private final Timer syncroTimer = new Timer();
/*   78 */   private final Map<EntityPlayer, Timer> totemPops = new ConcurrentHashMap<>();
/*   79 */   private final Queue<CPacketUseEntity> packetUseEntities = new LinkedList<>();
/*   80 */   private final AtomicBoolean threadOngoing = new AtomicBoolean(false);
/*   81 */   public Setting<Raytrace> raytrace = register(new Setting("Raytrace", Raytrace.NONE, v -> (this.setting.getValue() == Settings.MISC)));
/*   82 */   public Setting<Boolean> place = register(new Setting("Place", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.PLACE)));
/*   83 */   public Setting<Integer> placeDelay = register(new Setting("PlaceDelay", Integer.valueOf(25), Integer.valueOf(0), Integer.valueOf(500), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue())));
/*   84 */   public Setting<Float> placeRange = register(new Setting("PlaceRange", Float.valueOf(6.0F), Float.valueOf(0.0F), Float.valueOf(10.0F), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue())));
/*   85 */   public Setting<Float> minDamage = register(new Setting("MinDamage", Float.valueOf(7.0F), Float.valueOf(0.1F), Float.valueOf(20.0F), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue())));
/*   86 */   public Setting<Float> maxSelfPlace = register(new Setting("MaxSelfPlace", Float.valueOf(10.0F), Float.valueOf(0.1F), Float.valueOf(36.0F), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue())));
/*   87 */   public Setting<Integer> wasteAmount = register(new Setting("WasteAmount", Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(5), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue())));
/*   88 */   public Setting<Boolean> wasteMinDmgCount = register(new Setting("CountMinDmg", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue())));
/*   89 */   public Setting<Float> facePlace = register(new Setting("FacePlace", Float.valueOf(8.0F), Float.valueOf(0.1F), Float.valueOf(20.0F), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue())));
/*   90 */   public Setting<Float> placetrace = register(new Setting("Placetrace", Float.valueOf(4.5F), Float.valueOf(0.0F), Float.valueOf(10.0F), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue() && this.raytrace.getValue() != Raytrace.NONE && this.raytrace.getValue() != Raytrace.BREAK)));
/*   91 */   public Setting<Boolean> antiSurround = register(new Setting("AntiSurround", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue())));
/*   92 */   public Setting<Boolean> limitFacePlace = register(new Setting("LimitFacePlace", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue())));
/*   93 */   public Setting<Boolean> oneDot15 = register(new Setting("1.15", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue())));
/*   94 */   public Setting<Boolean> doublePop = register(new Setting("AntiTotem", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue())));
/*   95 */   public Setting<Double> popHealth = register(new Setting("PopHealth", Double.valueOf(1.0D), Double.valueOf(0.0D), Double.valueOf(3.0D), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.doublePop.getValue()).booleanValue())));
/*   96 */   public Setting<Float> popDamage = register(new Setting("PopDamage", Float.valueOf(4.0F), Float.valueOf(0.0F), Float.valueOf(6.0F), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.doublePop.getValue()).booleanValue())));
/*   97 */   public Setting<Integer> popTime = register(new Setting("PopTime", Integer.valueOf(500), Integer.valueOf(0), Integer.valueOf(1000), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.doublePop.getValue()).booleanValue())));
/*   98 */   public Setting<Boolean> explode = register(new Setting("Break", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.BREAK)));
/*   99 */   public Setting<Switch> switchMode = register(new Setting("Attack", Switch.BREAKSLOT, v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue())));
/*  100 */   public Setting<Integer> breakDelay = register(new Setting("BreakDelay", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(500), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue())));
/*  101 */   public Setting<Float> breakRange = register(new Setting("BreakRange", Float.valueOf(6.0F), Float.valueOf(0.0F), Float.valueOf(10.0F), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue())));
/*  102 */   public Setting<Integer> packets = register(new Setting("Packets", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(6), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue())));
/*  103 */   public Setting<Float> maxSelfBreak = register(new Setting("MaxSelfBreak", Float.valueOf(10.0F), Float.valueOf(0.1F), Float.valueOf(36.0F), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue())));
/*  104 */   public Setting<Float> breaktrace = register(new Setting("Breaktrace", Float.valueOf(4.5F), Float.valueOf(0.0F), Float.valueOf(10.0F), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue() && this.raytrace.getValue() != Raytrace.NONE && this.raytrace.getValue() != Raytrace.PLACE)));
/*  105 */   public Setting<Boolean> manual = register(new Setting("Manual", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.BREAK)));
/*  106 */   public Setting<Boolean> manualMinDmg = register(new Setting("ManMinDmg", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.manual.getValue()).booleanValue())));
/*  107 */   public Setting<Integer> manualBreak = register(new Setting("ManualDelay", Integer.valueOf(500), Integer.valueOf(0), Integer.valueOf(500), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.manual.getValue()).booleanValue())));
/*  108 */   public Setting<Boolean> sync = register(new Setting("Sync", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.BREAK && (((Boolean)this.explode.getValue()).booleanValue() || ((Boolean)this.manual.getValue()).booleanValue()))));
/*  109 */   public Setting<Boolean> instant = register(new Setting("Predict", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue() && ((Boolean)this.place.getValue()).booleanValue())));
/*  110 */   public Setting<PredictTimer> instantTimer = register(new Setting("PredictTimer", PredictTimer.NONE, v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue() && ((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.instant.getValue()).booleanValue())));
/*  111 */   public Setting<Boolean> resetBreakTimer = register(new Setting("ResetBreakTimer", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue() && ((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.instant.getValue()).booleanValue())));
/*  112 */   public Setting<Integer> predictDelay = register(new Setting("PredictDelay", Integer.valueOf(12), Integer.valueOf(0), Integer.valueOf(500), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue() && ((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.instant.getValue()).booleanValue() && this.instantTimer.getValue() == PredictTimer.PREDICT)));
/*  113 */   public Setting<Boolean> predictCalc = register(new Setting("PredictCalc", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue() && ((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.instant.getValue()).booleanValue())));
/*  114 */   public Setting<Boolean> superSafe = register(new Setting("SuperSafe", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue() && ((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.instant.getValue()).booleanValue())));
/*  115 */   public Setting<Boolean> antiCommit = register(new Setting("AntiOverCommit", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.BREAK && ((Boolean)this.explode.getValue()).booleanValue() && ((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.instant.getValue()).booleanValue())));
/*  116 */   public Setting<Boolean> render = register(new Setting("Render", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.RENDER)));
/*  117 */   private final Setting<Integer> red = register(new Setting("Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue())));
/*  118 */   private final Setting<Integer> green = register(new Setting("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue())));
/*  119 */   private final Setting<Integer> blue = register(new Setting("Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue())));
/*  120 */   private final Setting<Integer> alpha = register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue())));
/*  121 */   public Setting<Boolean> colorSync = register(new Setting("CSync", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.RENDER)));
/*  122 */   public Setting<Boolean> box = register(new Setting("Box", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue())));
/*  123 */   private final Setting<Integer> boxAlpha = register(new Setting("BoxAlpha", Integer.valueOf(125), Integer.valueOf(0), Integer.valueOf(255), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.box.getValue()).booleanValue())));
/*  124 */   public Setting<Boolean> outline = register(new Setting("Outline", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue())));
/*  125 */   private final Setting<Float> lineWidth = register(new Setting("LineWidth", Float.valueOf(1.5F), Float.valueOf(0.1F), Float.valueOf(5.0F), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue())));
/*  126 */   public Setting<Boolean> text = register(new Setting("Text", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue())));
/*  127 */   public Setting<Boolean> customOutline = register(new Setting("CustomLine", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue())));
/*  128 */   private final Setting<Integer> cRed = register(new Setting("OL-Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue())));
/*  129 */   private final Setting<Integer> cGreen = register(new Setting("OL-Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue())));
/*  130 */   private final Setting<Integer> cBlue = register(new Setting("OL-Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue())));
/*  131 */   private final Setting<Integer> cAlpha = register(new Setting("OL-Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (this.setting.getValue() == Settings.RENDER && ((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue())));
/*  132 */   public Setting<Boolean> holdFacePlace = register(new Setting("HoldFacePlace", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.MISC)));
/*  133 */   public Setting<Boolean> holdFaceBreak = register(new Setting("HoldSlowBreak", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.MISC && ((Boolean)this.holdFacePlace.getValue()).booleanValue())));
/*  134 */   public Setting<Boolean> slowFaceBreak = register(new Setting("SlowFaceBreak", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.MISC)));
/*  135 */   public Setting<Boolean> actualSlowBreak = register(new Setting("ActuallySlow", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.MISC)));
/*  136 */   public Setting<Integer> facePlaceSpeed = register(new Setting("FaceSpeed", Integer.valueOf(500), Integer.valueOf(0), Integer.valueOf(500), v -> (this.setting.getValue() == Settings.MISC)));
/*  137 */   public Setting<Boolean> antiNaked = register(new Setting("AntiNaked", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.MISC)));
/*  138 */   public Setting<Float> range = register(new Setting("Range", Float.valueOf(12.0F), Float.valueOf(0.1F), Float.valueOf(20.0F), v -> (this.setting.getValue() == Settings.MISC)));
/*  139 */   public Setting<Target> targetMode = register(new Setting("Target", Target.CLOSEST, v -> (this.setting.getValue() == Settings.MISC)));
/*  140 */   public Setting<Integer> minArmor = register(new Setting("MinArmor", Integer.valueOf(5), Integer.valueOf(0), Integer.valueOf(125), v -> (this.setting.getValue() == Settings.MISC)));
/*  141 */   public Setting<AutoSwitch> autoSwitch = register(new Setting("Switch", AutoSwitch.TOGGLE, v -> (this.setting.getValue() == Settings.MISC)));
/*  142 */   public Setting<Bind> switchBind = register(new Setting("SwitchBind", new Bind(-1), v -> (this.setting.getValue() == Settings.MISC && this.autoSwitch.getValue() == AutoSwitch.TOGGLE)));
/*  143 */   public Setting<Boolean> offhandSwitch = register(new Setting("Offhand", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.MISC && this.autoSwitch.getValue() != AutoSwitch.NONE)));
/*  144 */   public Setting<Boolean> switchBack = register(new Setting("Switchback", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.MISC && this.autoSwitch.getValue() != AutoSwitch.NONE && ((Boolean)this.offhandSwitch.getValue()).booleanValue())));
/*  145 */   public Setting<Boolean> lethalSwitch = register(new Setting("LethalSwitch", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.MISC && this.autoSwitch.getValue() != AutoSwitch.NONE)));
/*  146 */   public Setting<Boolean> mineSwitch = register(new Setting("MineSwitch", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.MISC && this.autoSwitch.getValue() != AutoSwitch.NONE)));
/*  147 */   public Setting<Rotate> rotate = register(new Setting("Rotate", Rotate.OFF, v -> (this.setting.getValue() == Settings.MISC)));
/*  148 */   public Setting<Boolean> suicide = register(new Setting("Suicide", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.MISC)));
/*  149 */   public Setting<Boolean> webAttack = register(new Setting("WebAttack", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.MISC && this.targetMode.getValue() != Target.DAMAGE)));
/*  150 */   public Setting<Boolean> fullCalc = register(new Setting("ExtraCalc", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.MISC)));
/*  151 */   public Setting<Boolean> sound = register(new Setting("Sound", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.MISC)));
/*  152 */   public Setting<Float> soundRange = register(new Setting("SoundRange", Float.valueOf(12.0F), Float.valueOf(0.0F), Float.valueOf(12.0F), v -> (this.setting.getValue() == Settings.MISC)));
/*  153 */   public Setting<Float> soundPlayer = register(new Setting("SoundPlayer", Float.valueOf(6.0F), Float.valueOf(0.0F), Float.valueOf(12.0F), v -> (this.setting.getValue() == Settings.MISC)));
/*  154 */   public Setting<Boolean> soundConfirm = register(new Setting("SoundConfirm", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.MISC)));
/*  155 */   public Setting<Boolean> extraSelfCalc = register(new Setting("MinSelfDmg", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.MISC)));
/*  156 */   public Setting<AntiFriendPop> antiFriendPop = register(new Setting("FriendPop", AntiFriendPop.NONE, v -> (this.setting.getValue() == Settings.MISC)));
/*  157 */   public Setting<Boolean> noCount = register(new Setting("AntiCount", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.MISC && (this.antiFriendPop.getValue() == AntiFriendPop.ALL || this.antiFriendPop.getValue() == AntiFriendPop.BREAK))));
/*  158 */   public Setting<Boolean> calcEvenIfNoDamage = register(new Setting("BigFriendCalc", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.MISC && (this.antiFriendPop.getValue() == AntiFriendPop.ALL || this.antiFriendPop.getValue() == AntiFriendPop.BREAK) && this.targetMode.getValue() != Target.DAMAGE)));
/*  159 */   public Setting<Boolean> predictFriendDmg = register(new Setting("PredictFriend", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.MISC && (this.antiFriendPop.getValue() == AntiFriendPop.ALL || this.antiFriendPop.getValue() == AntiFriendPop.BREAK) && ((Boolean)this.instant.getValue()).booleanValue())));
/*  160 */   public Setting<Float> minMinDmg = register(new Setting("MinMinDmg", Float.valueOf(0.0F), Float.valueOf(0.0F), Float.valueOf(3.0F), v -> (this.setting.getValue() == Settings.DEV && ((Boolean)this.place.getValue()).booleanValue())));
/*  161 */   public Setting<Boolean> breakSwing = register(new Setting("BreakSwing", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.DEV)));
/*  162 */   public Setting<Boolean> placeSwing = register(new Setting("PlaceSwing", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV)));
/*  163 */   public Setting<Boolean> exactHand = register(new Setting("ExactHand", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV && ((Boolean)this.placeSwing.getValue()).booleanValue())));
/*  164 */   public Setting<Boolean> justRender = register(new Setting("JustRender", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV)));
/*  165 */   public Setting<Boolean> fakeSwing = register(new Setting("FakeSwing", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV && ((Boolean)this.justRender.getValue()).booleanValue())));
/*  166 */   public Setting<Logic> logic = register(new Setting("Logic", Logic.BREAKPLACE, v -> (this.setting.getValue() == Settings.DEV)));
/*  167 */   public Setting<DamageSync> damageSync = register(new Setting("DamageSync", DamageSync.NONE, v -> (this.setting.getValue() == Settings.DEV)));
/*  168 */   public Setting<Integer> damageSyncTime = register(new Setting("SyncDelay", Integer.valueOf(500), Integer.valueOf(0), Integer.valueOf(500), v -> (this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE)));
/*  169 */   public Setting<Float> dropOff = register(new Setting("DropOff", Float.valueOf(5.0F), Float.valueOf(0.0F), Float.valueOf(10.0F), v -> (this.setting.getValue() == Settings.DEV && this.damageSync.getValue() == DamageSync.BREAK)));
/*  170 */   public Setting<Integer> confirm = register(new Setting("Confirm", Integer.valueOf(250), Integer.valueOf(0), Integer.valueOf(1000), v -> (this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE)));
/*  171 */   public Setting<Boolean> syncedFeetPlace = register(new Setting("FeetSync", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE)));
/*  172 */   public Setting<Boolean> fullSync = register(new Setting("FullSync", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && ((Boolean)this.syncedFeetPlace.getValue()).booleanValue())));
/*  173 */   public Setting<Boolean> syncCount = register(new Setting("SyncCount", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && ((Boolean)this.syncedFeetPlace.getValue()).booleanValue())));
/*  174 */   public Setting<Boolean> hyperSync = register(new Setting("HyperSync", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && ((Boolean)this.syncedFeetPlace.getValue()).booleanValue())));
/*  175 */   public Setting<Boolean> gigaSync = register(new Setting("GigaSync", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && ((Boolean)this.syncedFeetPlace.getValue()).booleanValue())));
/*  176 */   public Setting<Boolean> syncySync = register(new Setting("SyncySync", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && ((Boolean)this.syncedFeetPlace.getValue()).booleanValue())));
/*  177 */   public Setting<Boolean> enormousSync = register(new Setting("EnormousSync", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && ((Boolean)this.syncedFeetPlace.getValue()).booleanValue())));
/*  178 */   public Setting<Boolean> holySync = register(new Setting("UnbelievableSync", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && ((Boolean)this.syncedFeetPlace.getValue()).booleanValue())));
/*  179 */   public Setting<Boolean> rotateFirst = register(new Setting("FirstRotation", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV && this.rotate.getValue() != Rotate.OFF && ((Integer)this.eventMode.getValue()).intValue() == 2)));
/*  180 */   public Setting<ThreadMode> threadMode = register(new Setting("Thread", ThreadMode.NONE, v -> (this.setting.getValue() == Settings.DEV)));
/*  181 */   public Setting<Integer> threadDelay = register(new Setting("ThreadDelay", Integer.valueOf(50), Integer.valueOf(1), Integer.valueOf(1000), v -> (this.setting.getValue() == Settings.DEV && this.threadMode.getValue() != ThreadMode.NONE)));
/*  182 */   public Setting<Boolean> syncThreadBool = register(new Setting("ThreadSync", Boolean.valueOf(true), v -> (this.setting.getValue() == Settings.DEV && this.threadMode.getValue() != ThreadMode.NONE)));
/*  183 */   public Setting<Integer> syncThreads = register(new Setting("SyncThreads", Integer.valueOf(1000), Integer.valueOf(1), Integer.valueOf(10000), v -> (this.setting.getValue() == Settings.DEV && this.threadMode.getValue() != ThreadMode.NONE && ((Boolean)this.syncThreadBool.getValue()).booleanValue())));
/*  184 */   public Setting<Boolean> predictPos = register(new Setting("PredictPos", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV)));
/*  185 */   public Setting<Boolean> renderExtrapolation = register(new Setting("RenderExtrapolation", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV && ((Boolean)this.predictPos.getValue()).booleanValue())));
/*  186 */   public Setting<Integer> predictTicks = register(new Setting("ExtrapolationTicks", Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(20), v -> (this.setting.getValue() == Settings.DEV && ((Boolean)this.predictPos.getValue()).booleanValue())));
/*  187 */   public Setting<Integer> rotations = register(new Setting("Spoofs", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(20), v -> (this.setting.getValue() == Settings.DEV)));
/*  188 */   public Setting<Boolean> predictRotate = register(new Setting("PredictRotate", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.DEV)));
/*  189 */   public Setting<Float> predictOffset = register(new Setting("PredictOffset", Float.valueOf(0.0F), Float.valueOf(0.0F), Float.valueOf(4.0F), v -> (this.setting.getValue() == Settings.DEV)));
/*  190 */   public Setting<Boolean> doublePopOnDamage = register(new Setting("DamagePop", Boolean.valueOf(false), v -> (this.setting.getValue() == Settings.PLACE && ((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.doublePop.getValue()).booleanValue() && this.targetMode.getValue() == Target.DAMAGE)));
/*      */   public boolean rotating = false;
/*  192 */   private Queue<Entity> attackList = new ConcurrentLinkedQueue<>();
/*  193 */   private Map<Entity, Float> crystalMap = new HashMap<>();
/*  194 */   private Entity efficientTarget = null;
/*  195 */   private double currentDamage = 0.0D;
/*  196 */   private double renderDamage = 0.0D;
/*  197 */   private double lastDamage = 0.0D;
/*      */   private boolean didRotation = false;
/*      */   private boolean switching = false;
/*  200 */   private BlockPos placePos = null;
/*  201 */   private BlockPos renderPos = null;
/*      */   private boolean mainHand = false;
/*      */   private boolean offHand = false;
/*  204 */   private int crystalCount = 0;
/*  205 */   private int minDmgCount = 0;
/*  206 */   private int lastSlot = -1;
/*  207 */   private float yaw = 0.0F;
/*  208 */   private float pitch = 0.0F;
/*  209 */   private BlockPos webPos = null;
/*  210 */   private BlockPos lastPos = null;
/*      */   private boolean posConfirmed = false;
/*      */   private boolean foundDoublePop = false;
/*  213 */   private int rotationPacketsSpoofed = 0;
/*      */   private ScheduledExecutorService executor;
/*      */   private Thread thread;
/*      */   private EntityPlayer currentSyncTarget;
/*      */   private BlockPos syncedPlayerPos;
/*      */   private BlockPos syncedCrystalPos;
/*      */   private PlaceInfo placeInfo;
/*      */   private boolean addTolowDmg;
/*      */   
/*      */   public AutoCrystal() {
/*  223 */     super("AutoCrystal", "Best CA on the market", Module.Category.COMBAT, true, false, false);
/*  224 */     instance = this;
/*      */   }
/*      */   
/*      */   public static AutoCrystal getInstance() {
/*  228 */     if (instance == null) {
/*  229 */       instance = new AutoCrystal();
/*      */     }
/*  231 */     return instance;
/*      */   }
/*      */ 
/*      */   
/*      */   public void onTick() {
/*  236 */     if (this.threadMode.getValue() == ThreadMode.NONE && ((Integer)this.eventMode.getValue()).intValue() == 3) {
/*  237 */       doAutoCrystal();
/*      */     }
/*      */   }
/*      */   
/*      */   @SubscribeEvent
/*      */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/*  243 */     if (event.getStage() == 1) {
/*  244 */       postProcessing();
/*      */     }
/*  246 */     if (event.getStage() != 0) {
/*      */       return;
/*      */     }
/*  249 */     if (this.threadMode.getValue() != ThreadMode.NONE) {
/*  250 */       processMultiThreading();
/*  251 */     } else if (((Integer)this.eventMode.getValue()).intValue() == 2) {
/*  252 */       doAutoCrystal();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void onUpdate() {
/*  258 */     if (this.threadMode.getValue() == ThreadMode.NONE && ((Integer)this.eventMode.getValue()).intValue() == 1) {
/*  259 */       doAutoCrystal();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void onToggle() {
/*  265 */     brokenPos.clear();
/*  266 */     placedPos.clear();
/*  267 */     this.totemPops.clear();
/*  268 */     this.rotating = false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void onDisable() {
/*  273 */     if (this.thread != null) {
/*  274 */       this.shouldInterrupt.set(true);
/*      */     }
/*  276 */     if (this.executor != null) {
/*  277 */       this.executor.shutdown();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void onEnable() {
/*  283 */     if (this.threadMode.getValue() != ThreadMode.NONE) {
/*  284 */       processMultiThreading();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDisplayInfo() {
/*  290 */     if (this.switching) {
/*  291 */       return "§aSwitch";
/*      */     }
/*  293 */     if (target != null) {
/*  294 */       return target.func_70005_c_();
/*      */     }
/*  296 */     return null;
/*      */   }
/*      */   
/*      */   @SubscribeEvent
/*      */   public void onPacketSend(PacketEvent.Send event) {
/*  301 */     if (event.getStage() == 0 && this.rotate.getValue() != Rotate.OFF && this.rotating && ((Integer)this.eventMode.getValue()).intValue() != 2 && event.getPacket() instanceof CPacketPlayer) {
/*  302 */       CPacketPlayer cPacketPlayer = (CPacketPlayer)event.getPacket();
/*  303 */       cPacketPlayer.field_149476_e = this.yaw;
/*  304 */       cPacketPlayer.field_149473_f = this.pitch;
/*  305 */       this.rotationPacketsSpoofed++;
/*  306 */       if (this.rotationPacketsSpoofed >= ((Integer)this.rotations.getValue()).intValue()) {
/*  307 */         this.rotating = false;
/*  308 */         this.rotationPacketsSpoofed = 0;
/*      */       } 
/*      */     } 
/*      */     
/*  312 */     CPacketUseEntity packet = (CPacketUseEntity)event.getPacket();
/*  313 */     if (event.getStage() == 0 && event.getPacket() instanceof CPacketUseEntity && (packet = (CPacketUseEntity)event.getPacket()).func_149565_c() == CPacketUseEntity.Action.ATTACK && packet.func_149564_a((World)mc.field_71441_e) instanceof net.minecraft.entity.item.EntityEnderCrystal) {
/*  314 */       if (((Boolean)this.attackOppositeHand.getValue()).booleanValue()) {
/*  315 */         boolean offhand = (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP);
/*  316 */         packet.field_186995_d = offhand ? EnumHand.MAIN_HAND : EnumHand.OFF_HAND;
/*      */       } 
/*  318 */       if (((Boolean)this.removeAfterAttack.getValue()).booleanValue()) {
/*  319 */         packet.func_149564_a((World)mc.field_71441_e).func_70106_y();
/*  320 */         mc.field_71441_e.func_73028_b(packet.field_149567_a);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @SubscribeEvent(priority = EventPriority.HIGH, receiveCanceled = true)
/*      */   public void onPacketReceive(PacketEvent.Receive event) {
/*  329 */     if (fullNullCheck()) {
/*      */       return;
/*      */     }
/*  332 */     if (!((Boolean)this.justRender.getValue()).booleanValue() && ((Boolean)this.explode.getValue()).booleanValue() && ((Boolean)this.instant.getValue()).booleanValue() && event.getPacket() instanceof SPacketSpawnObject && (this.syncedCrystalPos == null || !((Boolean)this.syncedFeetPlace.getValue()).booleanValue() || this.damageSync.getValue() == DamageSync.NONE)) {
/*      */       
/*  334 */       SPacketSpawnObject packet2 = (SPacketSpawnObject)event.getPacket(); BlockPos pos;
/*  335 */       if (packet2.func_148993_l() == 51 && mc.field_71439_g.func_174818_b(pos = new BlockPos(packet2.func_186880_c(), packet2.func_186882_d(), packet2.func_186881_e())) + ((Float)this.predictOffset.getValue()).floatValue() <= MathUtil.square(((Float)this.breakRange.getValue()).floatValue()) && (this.instantTimer.getValue() == PredictTimer.NONE || (this.instantTimer.getValue() == PredictTimer.BREAK && this.breakTimer.passedMs(((Integer)this.breakDelay.getValue()).intValue())) || (this.instantTimer.getValue() == PredictTimer.PREDICT && this.predictTimer.passedMs(((Integer)this.predictDelay.getValue()).intValue())))) {
/*  336 */         if (predictSlowBreak(pos.func_177977_b())) {
/*      */           return;
/*      */         }
/*  339 */         if (((Boolean)this.predictFriendDmg.getValue()).booleanValue() && (this.antiFriendPop.getValue() == AntiFriendPop.BREAK || this.antiFriendPop.getValue() == AntiFriendPop.ALL) && isRightThread())
/*  340 */           for (EntityPlayer friend : mc.field_71441_e.field_73010_i) {
/*  341 */             if (friend == null || mc.field_71439_g.equals(friend) || friend.func_174818_b(pos) > MathUtil.square(((Float)this.range.getValue()).floatValue() + ((Float)this.placeRange.getValue()).floatValue()) || !Phobos.friendManager.isFriend(friend) || DamageUtil.calculateDamage(pos, (Entity)friend) <= EntityUtil.getHealth((Entity)friend) + 0.5D) {
/*      */               continue;
/*      */             }
/*      */             return;
/*      */           }  
/*  346 */         if (placedPos.contains(pos.func_177977_b())) {
/*      */           float selfDamage;
/*  348 */           if (isRightThread() ? (((Boolean)this.superSafe.getValue()).booleanValue() ? (DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue()) && ((selfDamage = DamageUtil.calculateDamage(pos, (Entity)mc.field_71439_g)) - 0.5D > EntityUtil.getHealth((Entity)mc.field_71439_g) || selfDamage > ((Float)this.maxSelfBreak.getValue()).floatValue())) : ((Boolean)this.superSafe.getValue()).booleanValue()) : ((Boolean)this.superSafe.getValue()).booleanValue()) {
/*      */             return;
/*      */           }
/*  351 */           attackCrystalPredict(packet2.func_149001_c(), pos);
/*  352 */         } else if (((Boolean)this.predictCalc.getValue()).booleanValue() && isRightThread()) {
/*  353 */           float selfDamage = -1.0F;
/*  354 */           if (DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())) {
/*  355 */             selfDamage = DamageUtil.calculateDamage(pos, (Entity)mc.field_71439_g);
/*      */           }
/*  357 */           if (selfDamage + 0.5D < EntityUtil.getHealth((Entity)mc.field_71439_g) && selfDamage <= ((Float)this.maxSelfBreak.getValue()).floatValue()) {
/*  358 */             for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/*      */               float damage;
/*  360 */               if (player.func_174818_b(pos) > MathUtil.square(((Float)this.range.getValue()).floatValue()) || !EntityUtil.isValid((Entity)player, (((Float)this.range.getValue()).floatValue() + ((Float)this.breakRange.getValue()).floatValue())) || (((Boolean)this.antiNaked.getValue()).booleanValue() && DamageUtil.isNaked(player)) || ((damage = DamageUtil.calculateDamage(pos, (Entity)player)) <= selfDamage && (damage <= ((Float)this.minDamage.getValue()).floatValue() || DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())) && damage <= EntityUtil.getHealth((Entity)player)))
/*      */                 continue; 
/*  362 */               if (((Boolean)this.predictRotate.getValue()).booleanValue() && ((Integer)this.eventMode.getValue()).intValue() != 2 && (this.rotate.getValue() == Rotate.BREAK || this.rotate.getValue() == Rotate.ALL)) {
/*  363 */                 rotateToPos(pos);
/*      */               }
/*  365 */               attackCrystalPredict(packet2.func_149001_c(), pos);
/*      */             }
/*      */           
/*      */           }
/*      */         } 
/*      */       } 
/*  371 */     } else if (!((Boolean)this.soundConfirm.getValue()).booleanValue() && event.getPacket() instanceof SPacketExplosion) {
/*  372 */       SPacketExplosion packet3 = (SPacketExplosion)event.getPacket();
/*  373 */       BlockPos pos = (new BlockPos(packet3.func_149148_f(), packet3.func_149143_g(), packet3.func_149145_h())).func_177977_b();
/*  374 */       removePos(pos);
/*  375 */     } else if (event.getPacket() instanceof SPacketDestroyEntities) {
/*  376 */       SPacketDestroyEntities packet4 = (SPacketDestroyEntities)event.getPacket();
/*  377 */       for (int id : packet4.func_149098_c()) {
/*  378 */         Entity entity = mc.field_71441_e.func_73045_a(id);
/*  379 */         if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal)
/*  380 */         { brokenPos.remove((new BlockPos(entity.func_174791_d())).func_177977_b());
/*  381 */           placedPos.remove((new BlockPos(entity.func_174791_d())).func_177977_b()); } 
/*      */       } 
/*  383 */     } else if (event.getPacket() instanceof SPacketEntityStatus) {
/*  384 */       SPacketEntityStatus packet5 = (SPacketEntityStatus)event.getPacket();
/*  385 */       if (packet5.func_149160_c() == 35 && packet5.func_149161_a((World)mc.field_71441_e) instanceof EntityPlayer)
/*  386 */         this.totemPops.put((EntityPlayer)packet5.func_149161_a((World)mc.field_71441_e), (new Timer()).reset()); 
/*      */     } else {
/*  388 */       SPacketSoundEffect packet; if (event.getPacket() instanceof SPacketSoundEffect && (packet = (SPacketSoundEffect)event.getPacket()).func_186977_b() == SoundCategory.BLOCKS && packet.func_186978_a() == SoundEvents.field_187539_bB) {
/*  389 */         BlockPos pos = new BlockPos(packet.func_149207_d(), packet.func_149211_e(), packet.func_149210_f());
/*  390 */         if (((Boolean)this.sound.getValue()).booleanValue() || this.threadMode.getValue() == ThreadMode.SOUND) {
/*  391 */           NoSoundLag.removeEntities(packet, ((Float)this.soundRange.getValue()).floatValue());
/*      */         }
/*  393 */         if (((Boolean)this.soundConfirm.getValue()).booleanValue()) {
/*  394 */           removePos(pos);
/*      */         }
/*  396 */         if (this.threadMode.getValue() == ThreadMode.SOUND && isRightThread() && mc.field_71439_g != null && mc.field_71439_g.func_174818_b(pos) < MathUtil.square(((Float)this.soundPlayer.getValue()).floatValue()))
/*  397 */           handlePool(true); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean predictSlowBreak(BlockPos pos) {
/*  403 */     if (((Boolean)this.antiCommit.getValue()).booleanValue() && lowDmgPos.remove(pos)) {
/*  404 */       return shouldSlowBreak(false);
/*      */     }
/*  406 */     return false;
/*      */   }
/*      */   
/*      */   private boolean isRightThread() {
/*  410 */     return (mc.func_152345_ab() || (!Phobos.eventManager.ticksOngoing() && !this.threadOngoing.get()));
/*      */   }
/*      */   
/*      */   private void attackCrystalPredict(int entityID, BlockPos pos) {
/*  414 */     if (((Boolean)this.predictRotate.getValue()).booleanValue() && (((Integer)this.eventMode.getValue()).intValue() != 2 || this.threadMode.getValue() != ThreadMode.NONE) && (this.rotate.getValue() == Rotate.BREAK || this.rotate.getValue() == Rotate.ALL)) {
/*  415 */       rotateToPos(pos);
/*      */     }
/*  417 */     CPacketUseEntity attackPacket = new CPacketUseEntity();
/*  418 */     attackPacket.field_149567_a = entityID;
/*  419 */     attackPacket.field_149566_b = CPacketUseEntity.Action.ATTACK;
/*  420 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)attackPacket);
/*  421 */     if (((Boolean)this.breakSwing.getValue()).booleanValue()) {
/*  422 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
/*      */     }
/*  424 */     if (((Boolean)this.resetBreakTimer.getValue()).booleanValue()) {
/*  425 */       this.breakTimer.reset();
/*      */     }
/*  427 */     this.predictTimer.reset();
/*      */   }
/*      */   
/*      */   private void removePos(BlockPos pos) {
/*  431 */     if (this.damageSync.getValue() == DamageSync.PLACE) {
/*  432 */       if (placedPos.remove(pos)) {
/*  433 */         this.posConfirmed = true;
/*      */       }
/*  435 */     } else if (this.damageSync.getValue() == DamageSync.BREAK && brokenPos.remove(pos)) {
/*  436 */       this.posConfirmed = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void onRender3D(Render3DEvent event) {
/*  442 */     if ((this.offHand || this.mainHand || this.switchMode.getValue() == Switch.CALC) && this.renderPos != null && ((Boolean)this.render.getValue()).booleanValue() && (((Boolean)this.box.getValue()).booleanValue() || ((Boolean)this.text.getValue()).booleanValue() || ((Boolean)this.outline.getValue()).booleanValue())) {
/*  443 */       RenderUtil.drawBoxESP(this.renderPos, ((Boolean)this.colorSync.getValue()).booleanValue() ? Colors.INSTANCE.getCurrentColor() : new Color(((Integer)this.red.getValue()).intValue(), ((Integer)this.green.getValue()).intValue(), ((Integer)this.blue.getValue()).intValue(), ((Integer)this.alpha.getValue()).intValue()), ((Boolean)this.customOutline.getValue()).booleanValue(), ((Boolean)this.colorSync.getValue()).booleanValue() ? Colors.INSTANCE.getCurrentColor() : new Color(((Integer)this.cRed.getValue()).intValue(), ((Integer)this.cGreen.getValue()).intValue(), ((Integer)this.cBlue.getValue()).intValue(), ((Integer)this.cAlpha.getValue()).intValue()), ((Float)this.lineWidth.getValue()).floatValue(), ((Boolean)this.outline.getValue()).booleanValue(), ((Boolean)this.box.getValue()).booleanValue(), ((Integer)this.boxAlpha.getValue()).intValue(), false);
/*  444 */       if (((Boolean)this.text.getValue()).booleanValue()) {
/*  445 */         RenderUtil.drawText(this.renderPos, ((Math.floor(this.renderDamage) == this.renderDamage) ? (String)Integer.valueOf((int)this.renderDamage) : String.format("%.1f", new Object[] { Double.valueOf(this.renderDamage) })) + "");
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   @SubscribeEvent
/*      */   public void onKeyInput(InputEvent.KeyInputEvent event) {
/*  452 */     if (Keyboard.getEventKeyState() && !(mc.field_71462_r instanceof me.earth.phobos.features.gui.PhobosGui) && ((Bind)this.switchBind.getValue()).getKey() == Keyboard.getEventKey()) {
/*  453 */       if (((Boolean)this.switchBack.getValue()).booleanValue() && ((Boolean)this.offhandSwitch.getValue()).booleanValue() && this.offHand) {
/*  454 */         Offhand module = (Offhand)Phobos.moduleManager.getModuleByClass(Offhand.class);
/*  455 */         if (module.isOff()) {
/*  456 */           Command.sendMessage("<" + getDisplayName() + "> §cSwitch failed. Enable the Offhand module.");
/*  457 */         } else if (module.type.getValue() == Offhand.Type.NEW) {
/*  458 */           module.setSwapToTotem(true);
/*  459 */           module.doOffhand();
/*      */         } else {
/*  461 */           module.setMode(Offhand.Mode2.TOTEMS);
/*  462 */           module.doSwitch();
/*      */         } 
/*      */         return;
/*      */       } 
/*  466 */       this.switching = !this.switching;
/*      */     } 
/*      */   }
/*      */   
/*      */   @SubscribeEvent
/*      */   public void onSettingChange(ClientEvent event) {
/*  472 */     if (event.getStage() == 2 && event.getSetting() != null && event.getSetting().getFeature() != null && event.getSetting().getFeature().equals(this) && isEnabled() && (event.getSetting().equals(this.threadDelay) || event.getSetting().equals(this.threadMode))) {
/*  473 */       if (this.executor != null) {
/*  474 */         this.executor.shutdown();
/*      */       }
/*  476 */       if (this.thread != null) {
/*  477 */         this.shouldInterrupt.set(true);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void postProcessing() {
/*  483 */     if (this.threadMode.getValue() != ThreadMode.NONE || ((Integer)this.eventMode.getValue()).intValue() != 2 || this.rotate.getValue() == Rotate.OFF || !((Boolean)this.rotateFirst.getValue()).booleanValue()) {
/*      */       return;
/*      */     }
/*  486 */     switch ((Logic)this.logic.getValue()) {
/*      */       case OFF:
/*  488 */         postProcessBreak();
/*  489 */         postProcessPlace();
/*      */         break;
/*      */       
/*      */       case PLACE:
/*  493 */         postProcessPlace();
/*  494 */         postProcessBreak();
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void postProcessBreak() {
/*  500 */     while (!this.packetUseEntities.isEmpty()) {
/*  501 */       CPacketUseEntity packet = this.packetUseEntities.poll();
/*  502 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)packet);
/*  503 */       if (((Boolean)this.breakSwing.getValue()).booleanValue()) {
/*  504 */         mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/*      */       }
/*  506 */       this.breakTimer.reset();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void postProcessPlace() {
/*  511 */     if (this.placeInfo != null) {
/*  512 */       this.placeInfo.runPlace();
/*  513 */       this.placeTimer.reset();
/*  514 */       this.placeInfo = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void processMultiThreading() {
/*  519 */     if (isOff()) {
/*      */       return;
/*      */     }
/*  522 */     if (this.threadMode.getValue() == ThreadMode.WHILE) {
/*  523 */       handleWhile();
/*  524 */     } else if (this.threadMode.getValue() != ThreadMode.NONE) {
/*  525 */       handlePool(false);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void handlePool(boolean justDoIt) {
/*  530 */     if (justDoIt || this.executor == null || this.executor.isTerminated() || this.executor.isShutdown() || (this.syncroTimer.passedMs(((Integer)this.syncThreads.getValue()).intValue()) && ((Boolean)this.syncThreadBool.getValue()).booleanValue())) {
/*  531 */       if (this.executor != null) {
/*  532 */         this.executor.shutdown();
/*      */       }
/*  534 */       this.executor = getExecutor();
/*  535 */       this.syncroTimer.reset();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void handleWhile() {
/*  540 */     if (this.thread == null || this.thread.isInterrupted() || !this.thread.isAlive() || (this.syncroTimer.passedMs(((Integer)this.syncThreads.getValue()).intValue()) && ((Boolean)this.syncThreadBool.getValue()).booleanValue())) {
/*  541 */       if (this.thread == null) {
/*  542 */         this.thread = new Thread(RAutoCrystal.getInstance(this));
/*  543 */       } else if (this.syncroTimer.passedMs(((Integer)this.syncThreads.getValue()).intValue()) && !this.shouldInterrupt.get() && ((Boolean)this.syncThreadBool.getValue()).booleanValue()) {
/*  544 */         this.shouldInterrupt.set(true);
/*  545 */         this.syncroTimer.reset();
/*      */         return;
/*      */       } 
/*  548 */       if (this.thread != null && (this.thread.isInterrupted() || !this.thread.isAlive())) {
/*  549 */         this.thread = new Thread(RAutoCrystal.getInstance(this));
/*      */       }
/*  551 */       if (this.thread != null && this.thread.getState() == Thread.State.NEW) {
/*      */         try {
/*  553 */           this.thread.start();
/*  554 */         } catch (Exception e) {
/*  555 */           e.printStackTrace();
/*      */         } 
/*  557 */         this.syncroTimer.reset();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private ScheduledExecutorService getExecutor() {
/*  563 */     ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
/*  564 */     service.scheduleAtFixedRate(RAutoCrystal.getInstance(this), 0L, ((Integer)this.threadDelay.getValue()).intValue(), TimeUnit.MILLISECONDS);
/*  565 */     return service;
/*      */   }
/*      */   
/*      */   public void doAutoCrystal() {
/*  569 */     if (check()) {
/*  570 */       switch ((Logic)this.logic.getValue()) {
/*      */         case PLACE:
/*  572 */           placeCrystal();
/*  573 */           breakCrystal();
/*      */           break;
/*      */         
/*      */         case OFF:
/*  577 */           breakCrystal();
/*  578 */           placeCrystal();
/*      */           break;
/*      */       } 
/*      */       
/*  582 */       manualBreaker();
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean check() {
/*  587 */     if (fullNullCheck()) {
/*  588 */       return false;
/*      */     }
/*  590 */     if (this.syncTimer.passedMs(((Integer)this.damageSyncTime.getValue()).intValue())) {
/*  591 */       this.currentSyncTarget = null;
/*  592 */       this.syncedCrystalPos = null;
/*  593 */       this.syncedPlayerPos = null;
/*  594 */     } else if (((Boolean)this.syncySync.getValue()).booleanValue() && this.syncedCrystalPos != null) {
/*  595 */       this.posConfirmed = true;
/*      */     } 
/*  597 */     this.foundDoublePop = false;
/*  598 */     if (this.renderTimer.passedMs(500L)) {
/*  599 */       this.renderPos = null;
/*  600 */       this.renderTimer.reset();
/*      */     } 
/*  602 */     this.mainHand = (mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP);
/*  603 */     this.offHand = (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP);
/*  604 */     this.currentDamage = 0.0D;
/*  605 */     this.placePos = null;
/*  606 */     if (this.lastSlot != mc.field_71439_g.field_71071_by.field_70461_c || AutoTrap.isPlacing || Surround.isPlacing) {
/*  607 */       this.lastSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*  608 */       this.switchTimer.reset();
/*      */     } 
/*  610 */     if (!this.offHand && !this.mainHand) {
/*  611 */       this.placeInfo = null;
/*  612 */       this.packetUseEntities.clear();
/*      */     } 
/*  614 */     if (this.offHand || this.mainHand) {
/*  615 */       this.switching = false;
/*      */     }
/*  617 */     if ((!this.offHand && !this.mainHand && this.switchMode.getValue() == Switch.BREAKSLOT && !this.switching) || !DamageUtil.canBreakWeakness((EntityPlayer)mc.field_71439_g) || !this.switchTimer.passedMs(((Integer)this.switchCooldown.getValue()).intValue())) {
/*  618 */       this.renderPos = null;
/*  619 */       target = null;
/*  620 */       this.rotating = false;
/*  621 */       return false;
/*      */     } 
/*  623 */     if (((Boolean)this.mineSwitch.getValue()).booleanValue() && Mouse.isButtonDown(0) && (this.switching || this.autoSwitch.getValue() == AutoSwitch.ALWAYS) && Mouse.isButtonDown(1) && mc.field_71439_g.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemPickaxe) {
/*  624 */       switchItem();
/*      */     }
/*  626 */     mapCrystals();
/*  627 */     if (!this.posConfirmed && this.damageSync.getValue() != DamageSync.NONE && this.syncTimer.passedMs(((Integer)this.confirm.getValue()).intValue())) {
/*  628 */       this.syncTimer.setMs((((Integer)this.damageSyncTime.getValue()).intValue() + 1));
/*      */     }
/*  630 */     return true;
/*      */   }
/*      */   
/*      */   private void mapCrystals() {
/*  634 */     this.efficientTarget = null;
/*  635 */     if (((Integer)this.packets.getValue()).intValue() != 1) {
/*  636 */       this.attackList = new ConcurrentLinkedQueue<>();
/*  637 */       this.crystalMap = new HashMap<>();
/*      */     } 
/*  639 */     this.crystalCount = 0;
/*  640 */     this.minDmgCount = 0;
/*  641 */     Entity maxCrystal = null;
/*  642 */     float maxDamage = 0.5F;
/*  643 */     for (Entity entity : mc.field_71441_e.field_72996_f) {
/*  644 */       if (entity.field_70128_L || !(entity instanceof net.minecraft.entity.item.EntityEnderCrystal) || !isValid(entity))
/*  645 */         continue;  if (((Boolean)this.syncedFeetPlace.getValue()).booleanValue() && entity.func_180425_c().func_177977_b().equals(this.syncedCrystalPos) && this.damageSync.getValue() != DamageSync.NONE) {
/*  646 */         this.minDmgCount++;
/*  647 */         this.crystalCount++;
/*  648 */         if (((Boolean)this.syncCount.getValue()).booleanValue()) {
/*  649 */           this.minDmgCount = ((Integer)this.wasteAmount.getValue()).intValue() + 1;
/*  650 */           this.crystalCount = ((Integer)this.wasteAmount.getValue()).intValue() + 1;
/*      */         } 
/*  652 */         if (!((Boolean)this.hyperSync.getValue()).booleanValue())
/*  653 */           continue;  maxCrystal = null;
/*      */         break;
/*      */       } 
/*  656 */       boolean count = false;
/*  657 */       boolean countMin = false;
/*  658 */       float selfDamage = -1.0F;
/*  659 */       if (DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())) {
/*  660 */         selfDamage = DamageUtil.calculateDamage(entity, (Entity)mc.field_71439_g);
/*      */       }
/*  662 */       if (selfDamage + 0.5D < EntityUtil.getHealth((Entity)mc.field_71439_g) && selfDamage <= ((Float)this.maxSelfBreak.getValue()).floatValue()) {
/*  663 */         Entity beforeCrystal = maxCrystal;
/*  664 */         float beforeDamage = maxDamage;
/*  665 */         for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/*      */           
/*  667 */           if (player.func_70068_e(entity) > MathUtil.square(((Float)this.range.getValue()).floatValue()))
/*      */             continue; 
/*  669 */           if (EntityUtil.isValid((Entity)player, (((Float)this.range.getValue()).floatValue() + ((Float)this.breakRange.getValue()).floatValue()))) {
/*  670 */             float f; if ((((Boolean)this.antiNaked.getValue()).booleanValue() && DamageUtil.isNaked(player)) || ((f = DamageUtil.calculateDamage(entity, (Entity)player)) <= selfDamage && (f <= ((Float)this.minDamage.getValue()).floatValue() || DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())) && f <= EntityUtil.getHealth((Entity)player)))
/*      */               continue; 
/*  672 */             if (f > maxDamage) {
/*  673 */               maxDamage = f;
/*  674 */               maxCrystal = entity;
/*      */             } 
/*  676 */             if (((Integer)this.packets.getValue()).intValue() == 1) {
/*  677 */               if (f >= ((Float)this.minDamage.getValue()).floatValue() || !((Boolean)this.wasteMinDmgCount.getValue()).booleanValue()) {
/*  678 */                 count = true;
/*      */               }
/*  680 */               countMin = true;
/*      */               continue;
/*      */             } 
/*  683 */             if (this.crystalMap.get(entity) != null && ((Float)this.crystalMap.get(entity)).floatValue() >= f)
/*      */               continue; 
/*  685 */             this.crystalMap.put(entity, Float.valueOf(f)); continue;
/*      */           } 
/*      */           float damage;
/*  688 */           if ((this.antiFriendPop.getValue() != AntiFriendPop.BREAK && this.antiFriendPop.getValue() != AntiFriendPop.ALL) || !Phobos.friendManager.isFriend(player.func_70005_c_()) || (damage = DamageUtil.calculateDamage(entity, (Entity)player)) <= EntityUtil.getHealth((Entity)player) + 0.5D)
/*      */             continue; 
/*  690 */           maxCrystal = beforeCrystal;
/*  691 */           maxDamage = beforeDamage;
/*  692 */           this.crystalMap.remove(entity);
/*  693 */           if (!((Boolean)this.noCount.getValue()).booleanValue())
/*  694 */             break;  count = false;
/*  695 */           countMin = false;
/*      */         } 
/*      */       } 
/*      */       
/*  699 */       if (!countMin)
/*  700 */         continue;  this.minDmgCount++;
/*  701 */       if (!count)
/*  702 */         continue;  this.crystalCount++;
/*      */     } 
/*  704 */     if (this.damageSync.getValue() == DamageSync.BREAK && (maxDamage > this.lastDamage || this.syncTimer.passedMs(((Integer)this.damageSyncTime.getValue()).intValue()) || this.damageSync.getValue() == DamageSync.NONE)) {
/*  705 */       this.lastDamage = maxDamage;
/*      */     }
/*  707 */     if (((Boolean)this.enormousSync.getValue()).booleanValue() && ((Boolean)this.syncedFeetPlace.getValue()).booleanValue() && this.damageSync.getValue() != DamageSync.NONE && this.syncedCrystalPos != null) {
/*  708 */       if (((Boolean)this.syncCount.getValue()).booleanValue()) {
/*  709 */         this.minDmgCount = ((Integer)this.wasteAmount.getValue()).intValue() + 1;
/*  710 */         this.crystalCount = ((Integer)this.wasteAmount.getValue()).intValue() + 1;
/*      */       } 
/*      */       return;
/*      */     } 
/*  714 */     if (((Boolean)this.webAttack.getValue()).booleanValue() && this.webPos != null) {
/*  715 */       if (mc.field_71439_g.func_174818_b(this.webPos.func_177984_a()) > MathUtil.square(((Float)this.breakRange.getValue()).floatValue())) {
/*  716 */         this.webPos = null;
/*      */       } else {
/*  718 */         for (Entity entity : mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(this.webPos.func_177984_a()))) {
/*  719 */           if (!(entity instanceof net.minecraft.entity.item.EntityEnderCrystal))
/*  720 */             continue;  this.attackList.add(entity);
/*  721 */           this.efficientTarget = entity;
/*  722 */           this.webPos = null;
/*  723 */           this.lastDamage = 0.5D;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     }
/*  728 */     if (shouldSlowBreak(true) && maxDamage < ((Float)this.minDamage.getValue()).floatValue() && (target == null || EntityUtil.getHealth((Entity)target) > ((Float)this.facePlace.getValue()).floatValue() || (!this.breakTimer.passedMs(((Integer)this.facePlaceSpeed.getValue()).intValue()) && ((Boolean)this.slowFaceBreak.getValue()).booleanValue() && Mouse.isButtonDown(0) && ((Boolean)this.holdFacePlace.getValue()).booleanValue() && ((Boolean)this.holdFaceBreak.getValue()).booleanValue()))) {
/*  729 */       this.efficientTarget = null;
/*      */       return;
/*      */     } 
/*  732 */     if (((Integer)this.packets.getValue()).intValue() == 1) {
/*  733 */       this.efficientTarget = maxCrystal;
/*      */     } else {
/*  735 */       this.crystalMap = MathUtil.sortByValue(this.crystalMap, true);
/*  736 */       for (Map.Entry<Entity, Float> entry : this.crystalMap.entrySet()) {
/*  737 */         Entity crystal = (Entity)entry.getKey();
/*  738 */         float damage = ((Float)entry.getValue()).floatValue();
/*  739 */         if (damage >= ((Float)this.minDamage.getValue()).floatValue() || !((Boolean)this.wasteMinDmgCount.getValue()).booleanValue()) {
/*  740 */           this.crystalCount++;
/*      */         }
/*  742 */         this.attackList.add(crystal);
/*  743 */         this.minDmgCount++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean shouldSlowBreak(boolean withManual) {
/*  749 */     return ((withManual && ((Boolean)this.manual.getValue()).booleanValue() && ((Boolean)this.manualMinDmg.getValue()).booleanValue() && Mouse.isButtonDown(1) && (!Mouse.isButtonDown(0) || !((Boolean)this.holdFacePlace.getValue()).booleanValue())) || (((Boolean)this.holdFacePlace.getValue()).booleanValue() && ((Boolean)this.holdFaceBreak.getValue()).booleanValue() && Mouse.isButtonDown(0) && !this.breakTimer.passedMs(((Integer)this.facePlaceSpeed.getValue()).intValue())) || (((Boolean)this.slowFaceBreak.getValue()).booleanValue() && !this.breakTimer.passedMs(((Integer)this.facePlaceSpeed.getValue()).intValue())));
/*      */   }
/*      */   
/*      */   private void placeCrystal() {
/*  753 */     int crystalLimit = ((Integer)this.wasteAmount.getValue()).intValue();
/*  754 */     if (this.placeTimer.passedMs(((Integer)this.placeDelay.getValue()).intValue()) && ((Boolean)this.place.getValue()).booleanValue() && (this.offHand || this.mainHand || this.switchMode.getValue() == Switch.CALC || (this.switchMode.getValue() == Switch.BREAKSLOT && this.switching))) {
/*  755 */       if ((this.offHand || this.mainHand || (this.switchMode.getValue() != Switch.ALWAYS && !this.switching)) && this.crystalCount >= crystalLimit && (!((Boolean)this.antiSurround.getValue()).booleanValue() || this.lastPos == null || !this.lastPos.equals(this.placePos))) {
/*      */         return;
/*      */       }
/*  758 */       calculateDamage(getTarget((this.targetMode.getValue() == Target.UNSAFE)));
/*  759 */       if (target != null && this.placePos != null) {
/*  760 */         if (!this.offHand && !this.mainHand && this.autoSwitch.getValue() != AutoSwitch.NONE && (this.currentDamage > ((Float)this.minDamage.getValue()).floatValue() || (((Boolean)this.lethalSwitch.getValue()).booleanValue() && EntityUtil.getHealth((Entity)target) <= ((Float)this.facePlace.getValue()).floatValue())) && !switchItem()) {
/*      */           return;
/*      */         }
/*  763 */         if (this.currentDamage < ((Float)this.minDamage.getValue()).floatValue() && ((Boolean)this.limitFacePlace.getValue()).booleanValue()) {
/*  764 */           crystalLimit = 1;
/*      */         }
/*  766 */         if (this.currentDamage >= ((Float)this.minMinDmg.getValue()).floatValue() && (this.offHand || this.mainHand || this.autoSwitch.getValue() != AutoSwitch.NONE) && (this.crystalCount < crystalLimit || (((Boolean)this.antiSurround.getValue()).booleanValue() && this.lastPos != null && this.lastPos.equals(this.placePos))) && (this.currentDamage > ((Float)this.minDamage.getValue()).floatValue() || this.minDmgCount < crystalLimit) && this.currentDamage >= 1.0D && (DamageUtil.isArmorLow(target, ((Integer)this.minArmor.getValue()).intValue()) || EntityUtil.getHealth((Entity)target) <= ((Float)this.facePlace.getValue()).floatValue() || this.currentDamage > ((Float)this.minDamage.getValue()).floatValue() || shouldHoldFacePlace())) {
/*  767 */           float damageOffset = (this.damageSync.getValue() == DamageSync.BREAK) ? (((Float)this.dropOff.getValue()).floatValue() - 5.0F) : 0.0F;
/*  768 */           boolean syncflag = false;
/*  769 */           if (((Boolean)this.syncedFeetPlace.getValue()).booleanValue() && this.placePos.equals(this.lastPos) && isEligableForFeetSync(target, this.placePos) && !this.syncTimer.passedMs(((Integer)this.damageSyncTime.getValue()).intValue()) && target.equals(this.currentSyncTarget) && target.func_180425_c().equals(this.syncedPlayerPos) && this.damageSync.getValue() != DamageSync.NONE) {
/*  770 */             this.syncedCrystalPos = this.placePos;
/*  771 */             this.lastDamage = this.currentDamage;
/*  772 */             if (((Boolean)this.fullSync.getValue()).booleanValue()) {
/*  773 */               this.lastDamage = 100.0D;
/*      */             }
/*  775 */             syncflag = true;
/*      */           } 
/*  777 */           if (syncflag || this.currentDamage - damageOffset > this.lastDamage || this.syncTimer.passedMs(((Integer)this.damageSyncTime.getValue()).intValue()) || this.damageSync.getValue() == DamageSync.NONE) {
/*  778 */             if (!syncflag && this.damageSync.getValue() != DamageSync.BREAK) {
/*  779 */               this.lastDamage = this.currentDamage;
/*      */             }
/*  781 */             this.renderPos = this.placePos;
/*  782 */             this.renderDamage = this.currentDamage;
/*  783 */             if (switchItem()) {
/*  784 */               this.currentSyncTarget = target;
/*  785 */               this.syncedPlayerPos = target.func_180425_c();
/*  786 */               if (this.foundDoublePop) {
/*  787 */                 this.totemPops.put(target, (new Timer()).reset());
/*      */               }
/*  789 */               rotateToPos(this.placePos);
/*  790 */               if (this.addTolowDmg || (((Boolean)this.actualSlowBreak.getValue()).booleanValue() && this.currentDamage < ((Float)this.minDamage.getValue()).floatValue())) {
/*  791 */                 lowDmgPos.add(this.placePos);
/*      */               }
/*  793 */               placedPos.add(this.placePos);
/*  794 */               if (!((Boolean)this.justRender.getValue()).booleanValue()) {
/*  795 */                 if (((Integer)this.eventMode.getValue()).intValue() == 2 && this.threadMode.getValue() == ThreadMode.NONE && ((Boolean)this.rotateFirst.getValue()).booleanValue() && this.rotate.getValue() != Rotate.OFF) {
/*  796 */                   this.placeInfo = new PlaceInfo(this.placePos, this.offHand, ((Boolean)this.placeSwing.getValue()).booleanValue(), ((Boolean)this.exactHand.getValue()).booleanValue());
/*      */                 } else {
/*  798 */                   BlockUtil.placeCrystalOnBlock(this.placePos, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, ((Boolean)this.placeSwing.getValue()).booleanValue(), ((Boolean)this.exactHand.getValue()).booleanValue());
/*      */                 } 
/*      */               }
/*  801 */               this.lastPos = this.placePos;
/*  802 */               this.placeTimer.reset();
/*  803 */               this.posConfirmed = false;
/*  804 */               if (this.syncTimer.passedMs(((Integer)this.damageSyncTime.getValue()).intValue())) {
/*  805 */                 this.syncedCrystalPos = null;
/*  806 */                 this.syncTimer.reset();
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } else {
/*  812 */         this.renderPos = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean shouldHoldFacePlace() {
/*  818 */     this.addTolowDmg = false;
/*  819 */     if (((Boolean)this.holdFacePlace.getValue()).booleanValue() && Mouse.isButtonDown(0)) {
/*  820 */       this.addTolowDmg = true;
/*  821 */       return true;
/*      */     } 
/*  823 */     return false;
/*      */   }
/*      */   
/*      */   private boolean switchItem() {
/*  827 */     if (this.offHand || this.mainHand) {
/*  828 */       return true;
/*      */     }
/*  830 */     switch ((AutoSwitch)this.autoSwitch.getValue()) {
/*      */       case OFF:
/*  832 */         return false;
/*      */       
/*      */       case PLACE:
/*  835 */         if (!this.switching) {
/*  836 */           return false;
/*      */         }
/*      */       
/*      */       case BREAK:
/*  840 */         if (!doSwitch())
/*  841 */           break;  return true;
/*      */     } 
/*      */     
/*  844 */     return false;
/*      */   }
/*      */   
/*      */   private boolean doSwitch() {
/*  848 */     if (((Boolean)this.offhandSwitch.getValue()).booleanValue()) {
/*  849 */       Offhand module = (Offhand)Phobos.moduleManager.getModuleByClass(Offhand.class);
/*  850 */       if (module.isOff()) {
/*  851 */         Command.sendMessage("<" + getDisplayName() + "> §cSwitch failed. Enable the Offhand module.");
/*  852 */         this.switching = false;
/*  853 */         return false;
/*      */       } 
/*  855 */       if (module.type.getValue() == Offhand.Type.NEW) {
/*  856 */         module.setSwapToTotem(false);
/*  857 */         module.setMode(Offhand.Mode.CRYSTALS);
/*  858 */         module.doOffhand();
/*      */       } else {
/*  860 */         module.setMode(Offhand.Mode2.CRYSTALS);
/*  861 */         module.doSwitch();
/*      */       } 
/*  863 */       this.switching = false;
/*  864 */       return true;
/*      */     } 
/*  866 */     if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
/*  867 */       this.mainHand = false;
/*      */     } else {
/*  869 */       InventoryUtil.switchToHotbarSlot(ItemEndCrystal.class, false);
/*  870 */       this.mainHand = true;
/*      */     } 
/*  872 */     this.switching = false;
/*  873 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void calculateDamage(EntityPlayer targettedPlayer) {
/*  879 */     if (targettedPlayer == null && this.targetMode.getValue() != Target.DAMAGE && !((Boolean)this.fullCalc.getValue()).booleanValue()) {
/*      */       return;
/*      */     }
/*  882 */     float maxDamage = 0.5F;
/*  883 */     EntityPlayer currentTarget = null;
/*  884 */     BlockPos currentPos = null;
/*  885 */     float maxSelfDamage = 0.0F;
/*  886 */     this.foundDoublePop = false;
/*  887 */     BlockPos setToAir = null;
/*  888 */     IBlockState state = null; BlockPos playerPos; Block web;
/*  889 */     if (((Boolean)this.webAttack.getValue()).booleanValue() && targettedPlayer != null && (web = mc.field_71441_e.func_180495_p(playerPos = new BlockPos(targettedPlayer.func_174791_d())).func_177230_c()) == Blocks.field_150321_G) {
/*  890 */       setToAir = playerPos;
/*  891 */       state = mc.field_71441_e.func_180495_p(playerPos);
/*  892 */       mc.field_71441_e.func_175698_g(playerPos);
/*      */     } 
/*      */     
/*  895 */     for (BlockPos pos : BlockUtil.possiblePlacePositions(((Float)this.placeRange.getValue()).floatValue(), ((Boolean)this.antiSurround.getValue()).booleanValue(), ((Boolean)this.oneDot15.getValue()).booleanValue())) {
/*  896 */       if (!BlockUtil.rayTracePlaceCheck(pos, ((this.raytrace.getValue() == Raytrace.PLACE || this.raytrace.getValue() == Raytrace.FULL) && mc.field_71439_g.func_174818_b(pos) > MathUtil.square(((Float)this.placetrace.getValue()).floatValue())), 1.0F))
/*      */         continue; 
/*  898 */       float selfDamage = -1.0F;
/*  899 */       if (DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())) {
/*  900 */         selfDamage = DamageUtil.calculateDamage(pos, (Entity)mc.field_71439_g);
/*      */       }
/*  902 */       if (selfDamage + 0.5D >= EntityUtil.getHealth((Entity)mc.field_71439_g) || selfDamage > ((Float)this.maxSelfPlace.getValue()).floatValue())
/*      */         continue; 
/*  904 */       if (targettedPlayer != null) {
/*  905 */         float playerDamage = DamageUtil.calculateDamage(pos, (Entity)targettedPlayer);
/*  906 */         if (((Boolean)this.calcEvenIfNoDamage.getValue()).booleanValue() && (this.antiFriendPop.getValue() == AntiFriendPop.ALL || this.antiFriendPop.getValue() == AntiFriendPop.PLACE)) {
/*  907 */           boolean friendPop = false;
/*  908 */           for (EntityPlayer friend : mc.field_71441_e.field_73010_i) {
/*      */             float friendDamage;
/*  910 */             if (friend == null || mc.field_71439_g.equals(friend) || friend.func_174818_b(pos) > MathUtil.square(((Float)this.range.getValue()).floatValue() + ((Float)this.placeRange.getValue()).floatValue()) || !Phobos.friendManager.isFriend(friend) || (friendDamage = DamageUtil.calculateDamage(pos, (Entity)friend)) <= EntityUtil.getHealth((Entity)friend) + 0.5D)
/*      */               continue; 
/*  912 */             friendPop = true;
/*      */           } 
/*      */           
/*  915 */           if (friendPop)
/*      */             continue; 
/*  917 */         }  if (isDoublePoppable(targettedPlayer, playerDamage) && (currentPos == null || targettedPlayer.func_174818_b(pos) < targettedPlayer.func_174818_b(currentPos))) {
/*  918 */           currentTarget = targettedPlayer;
/*  919 */           maxDamage = playerDamage;
/*  920 */           currentPos = pos;
/*  921 */           this.foundDoublePop = true;
/*      */           continue;
/*      */         } 
/*  924 */         if (this.foundDoublePop || (playerDamage <= maxDamage && (!((Boolean)this.extraSelfCalc.getValue()).booleanValue() || playerDamage < maxDamage || selfDamage >= maxSelfDamage)) || (playerDamage <= selfDamage && (playerDamage <= ((Float)this.minDamage.getValue()).floatValue() || DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())) && playerDamage <= EntityUtil.getHealth((Entity)targettedPlayer)))
/*      */           continue; 
/*  926 */         maxDamage = playerDamage;
/*  927 */         currentTarget = targettedPlayer;
/*  928 */         currentPos = pos;
/*  929 */         maxSelfDamage = selfDamage;
/*      */         continue;
/*      */       } 
/*  932 */       float maxDamageBefore = maxDamage;
/*  933 */       EntityPlayer currentTargetBefore = currentTarget;
/*  934 */       BlockPos currentPosBefore = currentPos;
/*  935 */       float maxSelfDamageBefore = maxSelfDamage;
/*  936 */       for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/*      */         
/*  938 */         if (EntityUtil.isValid((Entity)player, (((Float)this.placeRange.getValue()).floatValue() + ((Float)this.range.getValue()).floatValue()))) {
/*  939 */           if (((Boolean)this.antiNaked.getValue()).booleanValue() && DamageUtil.isNaked(player))
/*  940 */             continue;  float playerDamage = DamageUtil.calculateDamage(pos, (Entity)player);
/*  941 */           if (((Boolean)this.doublePopOnDamage.getValue()).booleanValue() && isDoublePoppable(player, playerDamage) && (currentPos == null || player.func_174818_b(pos) < player.func_174818_b(currentPos))) {
/*  942 */             currentTarget = player;
/*  943 */             maxDamage = playerDamage;
/*  944 */             currentPos = pos;
/*  945 */             maxSelfDamage = selfDamage;
/*  946 */             this.foundDoublePop = true;
/*  947 */             if (this.antiFriendPop.getValue() != AntiFriendPop.BREAK && this.antiFriendPop.getValue() != AntiFriendPop.PLACE)
/*      */               continue; 
/*      */             break;
/*      */           } 
/*  951 */           if (this.foundDoublePop || (playerDamage <= maxDamage && (!((Boolean)this.extraSelfCalc.getValue()).booleanValue() || playerDamage < maxDamage || selfDamage >= maxSelfDamage)) || (playerDamage <= selfDamage && (playerDamage <= ((Float)this.minDamage.getValue()).floatValue() || DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())) && playerDamage <= EntityUtil.getHealth((Entity)player)))
/*      */             continue; 
/*  953 */           maxDamage = playerDamage;
/*  954 */           currentTarget = player;
/*  955 */           currentPos = pos;
/*  956 */           maxSelfDamage = selfDamage; continue;
/*      */         } 
/*      */         float friendDamage;
/*  959 */         if ((this.antiFriendPop.getValue() != AntiFriendPop.ALL && this.antiFriendPop.getValue() != AntiFriendPop.PLACE) || player == null || player.func_174818_b(pos) > MathUtil.square(((Float)this.range.getValue()).floatValue() + ((Float)this.placeRange.getValue()).floatValue()) || !Phobos.friendManager.isFriend(player) || (friendDamage = DamageUtil.calculateDamage(pos, (Entity)player)) <= EntityUtil.getHealth((Entity)player) + 0.5D)
/*      */           continue; 
/*  961 */         maxDamage = maxDamageBefore;
/*  962 */         currentTarget = currentTargetBefore;
/*  963 */         currentPos = currentPosBefore;
/*  964 */         maxSelfDamage = maxSelfDamageBefore;
/*      */       } 
/*      */     } 
/*      */     
/*  968 */     if (setToAir != null) {
/*  969 */       mc.field_71441_e.func_175656_a(setToAir, state);
/*  970 */       this.webPos = currentPos;
/*      */     } 
/*  972 */     target = currentTarget;
/*  973 */     this.currentDamage = maxDamage;
/*  974 */     this.placePos = currentPos;
/*      */   }
/*      */   private EntityPlayer getTarget(boolean unsafe) {
/*      */     EntityOtherPlayerMP entityOtherPlayerMP;
/*  978 */     if (this.targetMode.getValue() == Target.DAMAGE) {
/*  979 */       return null;
/*      */     }
/*  981 */     EntityPlayer currentTarget = null;
/*  982 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/*  983 */       if (EntityUtil.isntValid((Entity)player, (((Float)this.placeRange.getValue()).floatValue() + ((Float)this.range.getValue()).floatValue())) || (((Boolean)this.antiNaked.getValue()).booleanValue() && DamageUtil.isNaked(player)) || (unsafe && EntityUtil.isSafe((Entity)player)))
/*      */         continue; 
/*  985 */       if (((Integer)this.minArmor.getValue()).intValue() > 0 && DamageUtil.isArmorLow(player, ((Integer)this.minArmor.getValue()).intValue())) {
/*  986 */         currentTarget = player;
/*      */         break;
/*      */       } 
/*  989 */       if (currentTarget == null) {
/*  990 */         currentTarget = player;
/*      */         continue;
/*      */       } 
/*  993 */       if (mc.field_71439_g.func_70068_e((Entity)player) >= mc.field_71439_g.func_70068_e((Entity)currentTarget))
/*      */         continue; 
/*  995 */       currentTarget = player;
/*      */     } 
/*  997 */     if (unsafe && currentTarget == null) {
/*  998 */       return getTarget(false);
/*      */     }
/* 1000 */     if (((Boolean)this.predictPos.getValue()).booleanValue() && currentTarget != null) {
/* 1001 */       GameProfile profile = new GameProfile((currentTarget.func_110124_au() == null) ? UUID.fromString("8af022c8-b926-41a0-8b79-2b544ff00fcf") : currentTarget.func_110124_au(), currentTarget.func_70005_c_());
/* 1002 */       EntityOtherPlayerMP newTarget = new EntityOtherPlayerMP((World)mc.field_71441_e, profile);
/* 1003 */       Vec3d extrapolatePosition = MathUtil.extrapolatePlayerPosition(currentTarget, ((Integer)this.predictTicks.getValue()).intValue());
/* 1004 */       newTarget.func_82149_j((Entity)currentTarget);
/* 1005 */       newTarget.field_70165_t = extrapolatePosition.field_72450_a;
/* 1006 */       newTarget.field_70163_u = extrapolatePosition.field_72448_b;
/* 1007 */       newTarget.field_70161_v = extrapolatePosition.field_72449_c;
/* 1008 */       newTarget.func_70606_j(EntityUtil.getHealth((Entity)currentTarget));
/* 1009 */       newTarget.field_71071_by.func_70455_b(currentTarget.field_71071_by);
/* 1010 */       entityOtherPlayerMP = newTarget;
/*      */     } 
/* 1012 */     return (EntityPlayer)entityOtherPlayerMP;
/*      */   }
/*      */   
/*      */   private void breakCrystal() {
/* 1016 */     if (((Boolean)this.explode.getValue()).booleanValue() && this.breakTimer.passedMs(((Integer)this.breakDelay.getValue()).intValue()) && (this.switchMode.getValue() == Switch.ALWAYS || this.mainHand || this.offHand)) {
/* 1017 */       if (((Integer)this.packets.getValue()).intValue() == 1 && this.efficientTarget != null) {
/* 1018 */         if (((Boolean)this.justRender.getValue()).booleanValue()) {
/* 1019 */           doFakeSwing();
/*      */           return;
/*      */         } 
/* 1022 */         if (((Boolean)this.syncedFeetPlace.getValue()).booleanValue() && ((Boolean)this.gigaSync.getValue()).booleanValue() && this.syncedCrystalPos != null && this.damageSync.getValue() != DamageSync.NONE) {
/*      */           return;
/*      */         }
/* 1025 */         rotateTo(this.efficientTarget);
/* 1026 */         attackEntity(this.efficientTarget);
/* 1027 */         this.breakTimer.reset();
/* 1028 */       } else if (!this.attackList.isEmpty()) {
/* 1029 */         if (((Boolean)this.justRender.getValue()).booleanValue()) {
/* 1030 */           doFakeSwing();
/*      */           return;
/*      */         } 
/* 1033 */         if (((Boolean)this.syncedFeetPlace.getValue()).booleanValue() && ((Boolean)this.gigaSync.getValue()).booleanValue() && this.syncedCrystalPos != null && this.damageSync.getValue() != DamageSync.NONE) {
/*      */           return;
/*      */         }
/* 1036 */         for (int i = 0; i < ((Integer)this.packets.getValue()).intValue(); i++) {
/* 1037 */           Entity entity = this.attackList.poll();
/* 1038 */           if (entity != null) {
/* 1039 */             rotateTo(entity);
/* 1040 */             attackEntity(entity);
/*      */           } 
/* 1042 */         }  this.breakTimer.reset();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private void attackEntity(Entity entity) {
/* 1048 */     if (entity != null) {
/* 1049 */       if (((Integer)this.eventMode.getValue()).intValue() == 2 && this.threadMode.getValue() == ThreadMode.NONE && ((Boolean)this.rotateFirst.getValue()).booleanValue() && this.rotate.getValue() != Rotate.OFF) {
/* 1050 */         this.packetUseEntities.add(new CPacketUseEntity(entity));
/*      */       } else {
/* 1052 */         EntityUtil.attackEntity(entity, ((Boolean)this.sync.getValue()).booleanValue(), ((Boolean)this.breakSwing.getValue()).booleanValue());
/* 1053 */         brokenPos.add((new BlockPos(entity.func_174791_d())).func_177977_b());
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private void doFakeSwing() {
/* 1059 */     if (((Boolean)this.fakeSwing.getValue()).booleanValue()) {
/* 1060 */       EntityUtil.swingArmNoPacket(EnumHand.MAIN_HAND, (EntityLivingBase)mc.field_71439_g);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void manualBreaker() {
/* 1066 */     if (this.rotate.getValue() != Rotate.OFF && ((Integer)this.eventMode.getValue()).intValue() != 2 && this.rotating)
/* 1067 */       if (this.didRotation) {
/* 1068 */         mc.field_71439_g.field_70125_A = (float)(mc.field_71439_g.field_70125_A + 4.0E-4D);
/* 1069 */         this.didRotation = false;
/*      */       } else {
/* 1071 */         mc.field_71439_g.field_70125_A = (float)(mc.field_71439_g.field_70125_A - 4.0E-4D);
/* 1072 */         this.didRotation = true;
/*      */       }  
/*      */     RayTraceResult result;
/* 1075 */     if ((this.offHand || this.mainHand) && ((Boolean)this.manual.getValue()).booleanValue() && this.manualTimer.passedMs(((Integer)this.manualBreak.getValue()).intValue()) && Mouse.isButtonDown(1) && mc.field_71439_g.func_184592_cb().func_77973_b() != Items.field_151153_ao && mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151153_ao && mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151031_f && mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151062_by && (result = mc.field_71476_x) != null) {
/* 1076 */       Entity entity; BlockPos mousePos; switch (result.field_72313_a) {
/*      */         case OFF:
/* 1078 */           entity = result.field_72308_g;
/* 1079 */           if (!(entity instanceof net.minecraft.entity.item.EntityEnderCrystal))
/* 1080 */             break;  EntityUtil.attackEntity(entity, ((Boolean)this.sync.getValue()).booleanValue(), ((Boolean)this.breakSwing.getValue()).booleanValue());
/* 1081 */           this.manualTimer.reset();
/*      */           break;
/*      */         
/*      */         case PLACE:
/* 1085 */           mousePos = mc.field_71476_x.func_178782_a().func_177984_a();
/* 1086 */           for (Entity target : mc.field_71441_e.func_72839_b(null, new AxisAlignedBB(mousePos))) {
/* 1087 */             if (!(target instanceof net.minecraft.entity.item.EntityEnderCrystal))
/* 1088 */               continue;  EntityUtil.attackEntity(target, ((Boolean)this.sync.getValue()).booleanValue(), ((Boolean)this.breakSwing.getValue()).booleanValue());
/* 1089 */             this.manualTimer.reset();
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void rotateTo(Entity entity) {
/*      */     float[] angle;
/* 1098 */     switch ((Rotate)this.rotate.getValue()) {
/*      */       case OFF:
/* 1100 */         this.rotating = false;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case BREAK:
/*      */       case ALL:
/* 1107 */         angle = MathUtil.calcAngle(mc.field_71439_g.func_174824_e(mc.func_184121_ak()), entity.func_174791_d());
/* 1108 */         if (((Integer)this.eventMode.getValue()).intValue() == 2 && this.threadMode.getValue() == ThreadMode.NONE) {
/* 1109 */           Phobos.rotationManager.setPlayerRotations(angle[0], angle[1]);
/*      */           break;
/*      */         } 
/* 1112 */         this.yaw = angle[0];
/* 1113 */         this.pitch = angle[1];
/* 1114 */         this.rotating = true;
/*      */         break;
/*      */     } 
/*      */   }
/*      */   private void rotateToPos(BlockPos pos) {
/*      */     float[] angle;
/* 1120 */     switch ((Rotate)this.rotate.getValue()) {
/*      */       case OFF:
/* 1122 */         this.rotating = false;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case PLACE:
/*      */       case ALL:
/* 1129 */         angle = MathUtil.calcAngle(mc.field_71439_g.func_174824_e(mc.func_184121_ak()), new Vec3d((pos.func_177958_n() + 0.5F), (pos.func_177956_o() - 0.5F), (pos.func_177952_p() + 0.5F)));
/* 1130 */         if (((Integer)this.eventMode.getValue()).intValue() == 2 && this.threadMode.getValue() == ThreadMode.NONE) {
/* 1131 */           Phobos.rotationManager.setPlayerRotations(angle[0], angle[1]);
/*      */           break;
/*      */         } 
/* 1134 */         this.yaw = angle[0];
/* 1135 */         this.pitch = angle[1];
/* 1136 */         this.rotating = true;
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isDoublePoppable(EntityPlayer player, float damage) {
/*      */     float health;
/* 1143 */     if (((Boolean)this.doublePop.getValue()).booleanValue() && (health = EntityUtil.getHealth((Entity)player)) <= ((Double)this.popHealth.getValue()).doubleValue() && damage > health + 0.5D && damage <= ((Float)this.popDamage.getValue()).floatValue()) {
/* 1144 */       Timer timer = this.totemPops.get(player);
/* 1145 */       return (timer == null || timer.passedMs(((Integer)this.popTime.getValue()).intValue()));
/*      */     } 
/* 1147 */     return false;
/*      */   }
/*      */   
/*      */   private boolean isValid(Entity entity) {
/* 1151 */     return (entity != null && mc.field_71439_g.func_70068_e(entity) <= MathUtil.square(((Float)this.breakRange.getValue()).floatValue()) && (this.raytrace.getValue() == Raytrace.NONE || this.raytrace.getValue() == Raytrace.PLACE || mc.field_71439_g.func_70685_l(entity) || (!mc.field_71439_g.func_70685_l(entity) && mc.field_71439_g.func_70068_e(entity) <= MathUtil.square(((Float)this.breaktrace.getValue()).floatValue()))));
/*      */   }
/*      */   
/*      */   private boolean isEligableForFeetSync(EntityPlayer player, BlockPos pos) {
/* 1155 */     if (((Boolean)this.holySync.getValue()).booleanValue()) {
/* 1156 */       BlockPos playerPos = new BlockPos(player.func_174791_d()); EnumFacing[] arrayOfEnumFacing; int i; byte b;
/* 1157 */       for (arrayOfEnumFacing = EnumFacing.values(), i = arrayOfEnumFacing.length, b = 0; b < i; ) { EnumFacing facing = arrayOfEnumFacing[b];
/*      */         BlockPos holyPos;
/* 1159 */         if (facing == EnumFacing.DOWN || facing == EnumFacing.UP || !pos.equals(holyPos = playerPos.func_177977_b().func_177972_a(facing))) {
/*      */           b++; continue;
/* 1161 */         }  return true; }
/*      */       
/* 1163 */       return false;
/*      */     } 
/* 1165 */     return true;
/*      */   }
/*      */   
/*      */   public enum PredictTimer {
/* 1169 */     NONE,
/* 1170 */     BREAK,
/* 1171 */     PREDICT;
/*      */   }
/*      */   
/*      */   public enum AntiFriendPop
/*      */   {
/* 1176 */     NONE,
/* 1177 */     PLACE,
/* 1178 */     BREAK,
/* 1179 */     ALL;
/*      */   }
/*      */   
/*      */   public enum ThreadMode
/*      */   {
/* 1184 */     NONE,
/* 1185 */     POOL,
/* 1186 */     SOUND,
/* 1187 */     WHILE;
/*      */   }
/*      */   
/*      */   public enum AutoSwitch
/*      */   {
/* 1192 */     NONE,
/* 1193 */     TOGGLE,
/* 1194 */     ALWAYS;
/*      */   }
/*      */   
/*      */   public enum Raytrace
/*      */   {
/* 1199 */     NONE,
/* 1200 */     PLACE,
/* 1201 */     BREAK,
/* 1202 */     FULL;
/*      */   }
/*      */   
/*      */   public enum Switch
/*      */   {
/* 1207 */     ALWAYS,
/* 1208 */     BREAKSLOT,
/* 1209 */     CALC;
/*      */   }
/*      */   
/*      */   public enum Logic
/*      */   {
/* 1214 */     BREAKPLACE,
/* 1215 */     PLACEBREAK;
/*      */   }
/*      */   
/*      */   public enum Target
/*      */   {
/* 1220 */     CLOSEST,
/* 1221 */     UNSAFE,
/* 1222 */     DAMAGE;
/*      */   }
/*      */   
/*      */   public enum Rotate
/*      */   {
/* 1227 */     OFF,
/* 1228 */     PLACE,
/* 1229 */     BREAK,
/* 1230 */     ALL;
/*      */   }
/*      */   
/*      */   public enum DamageSync
/*      */   {
/* 1235 */     NONE,
/* 1236 */     PLACE,
/* 1237 */     BREAK;
/*      */   }
/*      */   
/*      */   public enum Settings
/*      */   {
/* 1242 */     PLACE,
/* 1243 */     BREAK,
/* 1244 */     RENDER,
/* 1245 */     MISC,
/* 1246 */     DEV;
/*      */   }
/*      */   
/*      */   public static class PlaceInfo
/*      */   {
/*      */     private final BlockPos pos;
/*      */     private final boolean offhand;
/*      */     private final boolean placeSwing;
/*      */     private final boolean exactHand;
/*      */     
/*      */     public PlaceInfo(BlockPos pos, boolean offhand, boolean placeSwing, boolean exactHand) {
/* 1257 */       this.pos = pos;
/* 1258 */       this.offhand = offhand;
/* 1259 */       this.placeSwing = placeSwing;
/* 1260 */       this.exactHand = exactHand;
/*      */     }
/*      */     
/*      */     public void runPlace() {
/* 1264 */       BlockUtil.placeCrystalOnBlock(this.pos, this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.placeSwing, this.exactHand);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class RAutoCrystal
/*      */     implements Runnable
/*      */   {
/*      */     private static RAutoCrystal instance;
/*      */     
/*      */     private AutoCrystal autoCrystal;
/*      */     
/*      */     public static RAutoCrystal getInstance(AutoCrystal autoCrystal) {
/* 1277 */       if (instance == null) {
/* 1278 */         instance = new RAutoCrystal();
/* 1279 */         instance.autoCrystal = autoCrystal;
/*      */       } 
/* 1281 */       return instance;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/* 1286 */       if (this.autoCrystal.threadMode.getValue() == AutoCrystal.ThreadMode.WHILE) {
/* 1287 */         while (this.autoCrystal.isOn() && this.autoCrystal.threadMode.getValue() == AutoCrystal.ThreadMode.WHILE) {
/* 1288 */           while (Phobos.eventManager.ticksOngoing());
/*      */           
/* 1290 */           if (this.autoCrystal.shouldInterrupt.get()) {
/* 1291 */             this.autoCrystal.shouldInterrupt.set(false);
/* 1292 */             this.autoCrystal.syncroTimer.reset();
/* 1293 */             this.autoCrystal.thread.interrupt();
/*      */             break;
/*      */           } 
/* 1296 */           this.autoCrystal.threadOngoing.set(true);
/* 1297 */           Phobos.safetyManager.doSafetyCheck();
/* 1298 */           this.autoCrystal.doAutoCrystal();
/* 1299 */           this.autoCrystal.threadOngoing.set(false);
/*      */           try {
/* 1301 */             Thread.sleep(((Integer)this.autoCrystal.threadDelay.getValue()).intValue());
/* 1302 */           } catch (InterruptedException e) {
/* 1303 */             this.autoCrystal.thread.interrupt();
/* 1304 */             e.printStackTrace();
/*      */           } 
/*      */         } 
/* 1307 */       } else if (this.autoCrystal.threadMode.getValue() != AutoCrystal.ThreadMode.NONE && this.autoCrystal.isOn()) {
/* 1308 */         while (Phobos.eventManager.ticksOngoing());
/*      */         
/* 1310 */         this.autoCrystal.threadOngoing.set(true);
/* 1311 */         Phobos.safetyManager.doSafetyCheck();
/* 1312 */         this.autoCrystal.doAutoCrystal();
/* 1313 */         this.autoCrystal.threadOngoing.set(false);
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\combat\AutoCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */