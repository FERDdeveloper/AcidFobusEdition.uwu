/*     */ package me.earth.phobos.features.modules.combat;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
/*     */ import me.earth.phobos.features.command.Command;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.modules.client.Colors;
/*     */ import me.earth.phobos.features.modules.player.BlockTweaks;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.BlockUtil;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.InventoryUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.block.BlockEnderChest;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class Surround extends Module {
/*  30 */   private final Setting<Integer> delay = register(new Setting("Delay/Place", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(250))); public static boolean isPlacing = false;
/*  31 */   private final Setting<Integer> blocksPerTick = register(new Setting("Block/Place", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(20)));
/*  32 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  33 */   private final Setting<Boolean> raytrace = register(new Setting("Raytrace", Boolean.valueOf(false)));
/*  34 */   private final Setting<InventoryUtil.Switch> switchMode = register(new Setting("Switch", InventoryUtil.Switch.NORMAL));
/*  35 */   private final Setting<Boolean> center = register(new Setting("Center", Boolean.valueOf(false)));
/*  36 */   private final Setting<Boolean> helpingBlocks = register(new Setting("HelpingBlocks", Boolean.valueOf(true)));
/*  37 */   private final Setting<Boolean> intelligent = register(new Setting("Intelligent", Boolean.valueOf(false), v -> ((Boolean)this.helpingBlocks.getValue()).booleanValue()));
/*  38 */   private final Setting<Boolean> antiPedo = register(new Setting("NoPedo", Boolean.valueOf(false)));
/*  39 */   private final Setting<Integer> extender = register(new Setting("Extend", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(4)));
/*  40 */   private final Setting<Boolean> extendMove = register(new Setting("MoveExtend", Boolean.valueOf(false), v -> (((Integer)this.extender.getValue()).intValue() > 1)));
/*  41 */   private final Setting<MovementMode> movementMode = register(new Setting("Movement", MovementMode.STATIC));
/*  42 */   private final Setting<Double> speed = register(new Setting("Speed", Double.valueOf(10.0D), Double.valueOf(0.0D), Double.valueOf(30.0D), v -> (this.movementMode.getValue() == MovementMode.LIMIT || this.movementMode.getValue() == MovementMode.OFF), "Maximum Movement Speed"));
/*  43 */   private final Setting<Integer> eventMode = register(new Setting("Updates", Integer.valueOf(3), Integer.valueOf(1), Integer.valueOf(3)));
/*  44 */   private final Setting<Boolean> floor = register(new Setting("Floor", Boolean.valueOf(false)));
/*  45 */   private final Setting<Boolean> echests = register(new Setting("Echests", Boolean.valueOf(false)));
/*  46 */   private final Setting<Boolean> noGhost = register(new Setting("Packet", Boolean.valueOf(false)));
/*  47 */   private final Setting<Boolean> info = register(new Setting("Info", Boolean.valueOf(false)));
/*  48 */   private final Setting<Integer> retryer = register(new Setting("Retries", Integer.valueOf(4), Integer.valueOf(1), Integer.valueOf(15)));
/*  49 */   private final Setting<Boolean> render = register(new Setting("Render", Boolean.valueOf(true)));
/*  50 */   public final Setting<Boolean> colorSync = register(new Setting("Sync", Boolean.valueOf(false), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  51 */   public final Setting<Boolean> box = register(new Setting("Box", Boolean.valueOf(false), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  52 */   public final Setting<Boolean> outline = register(new Setting("Outline", Boolean.valueOf(true), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  53 */   public final Setting<Boolean> customOutline = register(new Setting("CustomLine", Boolean.valueOf(false), v -> (((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  54 */   private final Setting<Integer> red = register(new Setting("Red", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  55 */   private final Setting<Integer> green = register(new Setting("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  56 */   private final Setting<Integer> blue = register(new Setting("Blue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  57 */   private final Setting<Integer> alpha = register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  58 */   private final Setting<Integer> boxAlpha = register(new Setting("BoxAlpha", Integer.valueOf(125), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.box.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  59 */   private final Setting<Float> lineWidth = register(new Setting("LineWidth", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(5.0F), v -> (((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  60 */   private final Setting<Integer> cRed = register(new Setting("OL-Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  61 */   private final Setting<Integer> cGreen = register(new Setting("OL-Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  62 */   private final Setting<Integer> cBlue = register(new Setting("OL-Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  63 */   private final Setting<Integer> cAlpha = register(new Setting("OL-Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  64 */   private final Timer timer = new Timer();
/*  65 */   private final Timer retryTimer = new Timer();
/*  66 */   private final Set<Vec3d> extendingBlocks = new HashSet<>();
/*  67 */   private final Map<BlockPos, Integer> retries = new HashMap<>();
/*     */   private int isSafe;
/*     */   private BlockPos startPos;
/*     */   private boolean didPlace = false;
/*     */   private boolean switchedItem;
/*     */   private int lastHotbarSlot;
/*     */   private boolean isSneaking;
/*  74 */   private int placements = 0;
/*  75 */   private int extenders = 1;
/*  76 */   private int obbySlot = -1;
/*     */   private boolean offHand = false;
/*  78 */   private List<BlockPos> placeVectors = new ArrayList<>();
/*     */   
/*     */   public Surround() {
/*  81 */     super("Surround", "Surrounds you with Obsidian", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  86 */     if (fullNullCheck()) {
/*  87 */       disable();
/*     */     }
/*  89 */     this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*  90 */     this.startPos = EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g);
/*  91 */     if (((Boolean)this.center.getValue()).booleanValue() && !Phobos.moduleManager.isModuleEnabled("Freecam")) {
/*  92 */       if (mc.field_71441_e.func_180495_p(new BlockPos(mc.field_71439_g.func_174791_d())).func_177230_c() == Blocks.field_150321_G) {
/*  93 */         Phobos.positionManager.setPositionPacket(mc.field_71439_g.field_70165_t, this.startPos.func_177956_o(), mc.field_71439_g.field_70161_v, true, true, true);
/*     */       } else {
/*  95 */         Phobos.positionManager.setPositionPacket(this.startPos.func_177958_n() + 0.5D, this.startPos.func_177956_o(), this.startPos.func_177952_p() + 0.5D, true, true, true);
/*     */       } 
/*     */     }
/*  98 */     this.retries.clear();
/*  99 */     this.retryTimer.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/* 104 */     if (((Integer)this.eventMode.getValue()).intValue() == 3) {
/* 105 */       doFeetPlace();
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/* 111 */     if (event.getStage() == 0 && ((Integer)this.eventMode.getValue()).intValue() == 2) {
/* 112 */       doFeetPlace();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 118 */     if (((Integer)this.eventMode.getValue()).intValue() == 1) {
/* 119 */       doFeetPlace();
/*     */     }
/* 121 */     if (this.isSafe == 2) {
/* 122 */       this.placeVectors = new ArrayList<>();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 128 */     if (nullCheck()) {
/*     */       return;
/*     */     }
/* 131 */     isPlacing = false;
/* 132 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 133 */     switchItem(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/* 138 */     if (((Boolean)this.render.getValue()).booleanValue() && (this.isSafe == 0 || this.isSafe == 1)) {
/* 139 */       this.placeVectors = fuckYou3arthqu4keYourCodeIsGarbage();
/* 140 */       for (BlockPos pos : this.placeVectors) {
/* 141 */         if (!(mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockAir))
/* 142 */           continue;  RenderUtil.drawBoxESP(pos, ((Boolean)this.colorSync.getValue()).booleanValue() ? Colors.INSTANCE.getCurrentColor() : new Color(((Integer)this.red.getValue()).intValue(), ((Integer)this.green.getValue()).intValue(), ((Integer)this.blue.getValue()).intValue(), ((Integer)this.alpha.getValue()).intValue()), ((Boolean)this.customOutline.getValue()).booleanValue(), new Color(((Integer)this.cRed.getValue()).intValue(), ((Integer)this.cGreen.getValue()).intValue(), ((Integer)this.cBlue.getValue()).intValue(), ((Integer)this.cAlpha.getValue()).intValue()), ((Float)this.lineWidth.getValue()).floatValue(), ((Boolean)this.outline.getValue()).booleanValue(), ((Boolean)this.box.getValue()).booleanValue(), ((Integer)this.boxAlpha.getValue()).intValue(), false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/* 149 */     if (!((Boolean)this.info.getValue()).booleanValue()) {
/* 150 */       return null;
/*     */     }
/* 152 */     switch (this.isSafe) {
/*     */       case 0:
/* 154 */         return "§cUnsafe";
/*     */       
/*     */       case 1:
/* 157 */         return "§eSecure";
/*     */     } 
/*     */     
/* 160 */     return "§aSecure";
/*     */   }
/*     */   
/*     */   private void doFeetPlace() {
/* 164 */     if (check()) {
/*     */       return;
/*     */     }
/* 167 */     if (!EntityUtil.isSafe((Entity)mc.field_71439_g, 0, ((Boolean)this.floor.getValue()).booleanValue())) {
/* 168 */       this.isSafe = 0;
/* 169 */       placeBlocks(mc.field_71439_g.func_174791_d(), EntityUtil.getUnsafeBlockArray((Entity)mc.field_71439_g, 0, ((Boolean)this.floor.getValue()).booleanValue()), ((Boolean)this.helpingBlocks.getValue()).booleanValue(), false, false);
/* 170 */     } else if (!EntityUtil.isSafe((Entity)mc.field_71439_g, -1, false)) {
/* 171 */       this.isSafe = 1;
/* 172 */       if (((Boolean)this.antiPedo.getValue()).booleanValue()) {
/* 173 */         placeBlocks(mc.field_71439_g.func_174791_d(), EntityUtil.getUnsafeBlockArray((Entity)mc.field_71439_g, -1, false), false, false, true);
/*     */       }
/*     */     } else {
/* 176 */       this.isSafe = 2;
/*     */     } 
/* 178 */     processExtendingBlocks();
/* 179 */     if (this.didPlace) {
/* 180 */       this.timer.reset();
/*     */     }
/*     */   }
/*     */   
/*     */   private void processExtendingBlocks() {
/* 185 */     if (this.extendingBlocks.size() == 2 && this.extenders < ((Integer)this.extender.getValue()).intValue()) {
/* 186 */       Vec3d[] array = new Vec3d[2];
/* 187 */       int i = 0;
/* 188 */       Iterator<Vec3d> iterator = this.extendingBlocks.iterator();
/* 189 */       while (iterator.hasNext()) {
/*     */         
/* 191 */         Vec3d vec3d = iterator.next();
/* 192 */         i++;
/*     */       } 
/* 194 */       int placementsBefore = this.placements;
/* 195 */       if (areClose(array) != null) {
/* 196 */         placeBlocks(areClose(array), EntityUtil.getUnsafeBlockArrayFromVec3d(areClose(array), 0, ((Boolean)this.floor.getValue()).booleanValue()), ((Boolean)this.helpingBlocks.getValue()).booleanValue(), false, true);
/*     */       }
/* 198 */       if (placementsBefore < this.placements) {
/* 199 */         this.extendingBlocks.clear();
/*     */       }
/* 201 */     } else if (this.extendingBlocks.size() > 2 || this.extenders >= ((Integer)this.extender.getValue()).intValue()) {
/* 202 */       this.extendingBlocks.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Vec3d areClose(Vec3d[] vec3ds) {
/* 207 */     int matches = 0;
/* 208 */     for (Vec3d vec3d : vec3ds) {
/* 209 */       for (Vec3d pos : EntityUtil.getUnsafeBlockArray((Entity)mc.field_71439_g, 0, ((Boolean)this.floor.getValue()).booleanValue())) {
/* 210 */         if (vec3d.equals(pos))
/* 211 */           matches++; 
/*     */       } 
/*     */     } 
/* 214 */     if (matches == 2) {
/* 215 */       return mc.field_71439_g.func_174791_d().func_178787_e(vec3ds[0].func_178787_e(vec3ds[1]));
/*     */     }
/* 217 */     return null;
/*     */   }
/*     */   
/*     */   private boolean placeBlocks(Vec3d pos, Vec3d[] vec3ds, boolean hasHelpingBlocks, boolean isHelping, boolean isExtending) {
/* 221 */     int helpings = 0;
/* 222 */     boolean gotHelp = true;
/*     */     
/* 224 */     for (Vec3d vec3d : vec3ds) {
/* 225 */       gotHelp = true;
/* 226 */       if (isHelping && !((Boolean)this.intelligent.getValue()).booleanValue() && ++helpings > 1) {
/* 227 */         return false;
/*     */       }
/* 229 */       BlockPos position = (new BlockPos(pos)).func_177963_a(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c);
/* 230 */       switch (BlockUtil.isPositionPlaceable(position, ((Boolean)this.raytrace.getValue()).booleanValue())) {
/*     */ 
/*     */ 
/*     */         
/*     */         case 1:
/* 235 */           if ((this.switchMode.getValue() == InventoryUtil.Switch.SILENT || (BlockTweaks.getINSTANCE().isOn() && ((Boolean)(BlockTweaks.getINSTANCE()).noBlock.getValue()).booleanValue())) && (this.retries.get(position) == null || ((Integer)this.retries.get(position)).intValue() < ((Integer)this.retryer.getValue()).intValue())) {
/* 236 */             placeBlock(position);
/* 237 */             this.retries.put(position, Integer.valueOf((this.retries.get(position) == null) ? 1 : (((Integer)this.retries.get(position)).intValue() + 1)));
/* 238 */             this.retryTimer.reset();
/*     */             break;
/*     */           } 
/* 241 */           if ((!((Boolean)this.extendMove.getValue()).booleanValue() && Phobos.speedManager.getSpeedKpH() != 0.0D) || isExtending || this.extenders >= ((Integer)this.extender.getValue()).intValue())
/*     */             break; 
/* 243 */           placeBlocks(mc.field_71439_g.func_174791_d().func_178787_e(vec3d), EntityUtil.getUnsafeBlockArrayFromVec3d(mc.field_71439_g.func_174791_d().func_178787_e(vec3d), 0, ((Boolean)this.floor.getValue()).booleanValue()), hasHelpingBlocks, false, true);
/* 244 */           this.extendingBlocks.add(vec3d);
/* 245 */           this.extenders++;
/*     */           break;
/*     */         
/*     */         case 2:
/* 249 */           if (!hasHelpingBlocks)
/* 250 */             break;  gotHelp = placeBlocks(pos, BlockUtil.getHelpingBlocks(vec3d), false, true, true);
/*     */         
/*     */         case 3:
/* 253 */           if (gotHelp) {
/* 254 */             placeBlock(position);
/*     */           }
/* 256 */           if (!isHelping)
/* 257 */             break;  return true;
/*     */       } 
/*     */     
/*     */     } 
/* 261 */     return false;
/*     */   }
/*     */   
/*     */   private boolean check() {
/* 265 */     if (fullNullCheck()) {
/* 266 */       return true;
/*     */     }
/* 268 */     this.offHand = InventoryUtil.isBlock(mc.field_71439_g.func_184592_cb().func_77973_b(), BlockObsidian.class);
/* 269 */     isPlacing = false;
/* 270 */     this.didPlace = false;
/* 271 */     this.extenders = 1;
/* 272 */     this.placements = 0;
/* 273 */     this.obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 274 */     int echestSlot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
/* 275 */     if (isOff()) {
/* 276 */       return true;
/*     */     }
/* 278 */     if (this.retryTimer.passedMs(2500L)) {
/* 279 */       this.retries.clear();
/* 280 */       this.retryTimer.reset();
/*     */     } 
/* 282 */     switchItem(true);
/* 283 */     if (this.obbySlot == -1 && !this.offHand && (!((Boolean)this.echests.getValue()).booleanValue() || echestSlot == -1)) {
/* 284 */       if (((Boolean)this.info.getValue()).booleanValue()) {
/* 285 */         Command.sendMessage("<" + getDisplayName() + "> §cYou are out of Obsidian.");
/*     */       }
/* 287 */       disable();
/* 288 */       return true;
/*     */     } 
/* 290 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 291 */     if (mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && mc.field_71439_g.field_71071_by.field_70461_c != this.obbySlot && mc.field_71439_g.field_71071_by.field_70461_c != echestSlot) {
/* 292 */       this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */     }
/* 294 */     switch ((MovementMode)this.movementMode.getValue()) {
/*     */ 
/*     */ 
/*     */       
/*     */       case STATIC:
/* 299 */         if (!this.startPos.equals(EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g))) {
/* 300 */           disable();
/* 301 */           return true;
/*     */         } 
/*     */       
/*     */       case LIMIT:
/* 305 */         if (Phobos.speedManager.getSpeedKpH() <= ((Double)this.speed.getValue()).doubleValue())
/* 306 */           break;  return true;
/*     */       
/*     */       case OFF:
/* 309 */         if (Phobos.speedManager.getSpeedKpH() <= ((Double)this.speed.getValue()).doubleValue())
/* 310 */           break;  disable();
/* 311 */         return true;
/*     */     } 
/*     */     
/* 314 */     return (Phobos.moduleManager.isModuleEnabled("Freecam") || !this.timer.passedMs(((Integer)this.delay.getValue()).intValue()) || (this.switchMode.getValue() == InventoryUtil.Switch.NONE && mc.field_71439_g.field_71071_by.field_70461_c != InventoryUtil.findHotbarBlock(BlockObsidian.class)));
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 318 */     if (this.placements < ((Integer)this.blocksPerTick.getValue()).intValue() && switchItem(false)) {
/* 319 */       isPlacing = true;
/* 320 */       this.isSneaking = BlockUtil.placeBlock(pos, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.noGhost.getValue()).booleanValue(), this.isSneaking);
/* 321 */       this.didPlace = true;
/* 322 */       this.placements++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean switchItem(boolean back) {
/* 327 */     if (this.offHand) {
/* 328 */       return true;
/*     */     }
/* 330 */     boolean[] value = InventoryUtil.switchItem(back, this.lastHotbarSlot, this.switchedItem, (InventoryUtil.Switch)this.switchMode.getValue(), (this.obbySlot == -1) ? BlockEnderChest.class : BlockObsidian.class);
/* 331 */     this.switchedItem = value[0];
/* 332 */     return value[1];
/*     */   }
/*     */   
/*     */   private List<BlockPos> fuckYou3arthqu4keYourCodeIsGarbage() {
/* 336 */     if (((Boolean)this.floor.getValue()).booleanValue()) {
/* 337 */       return Arrays.asList(new BlockPos[] { (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(0, -1, 0), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(1, 0, 0), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(-1, 0, 0), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(0, 0, -1), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(0, 0, 1) });
/*     */     }
/* 339 */     return Arrays.asList(new BlockPos[] { (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(1, 0, 0), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(-1, 0, 0), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(0, 0, -1), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(0, 0, 1) });
/*     */   }
/*     */   
/*     */   public enum MovementMode {
/* 343 */     NONE,
/* 344 */     STATIC,
/* 345 */     LIMIT,
/* 346 */     OFF;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\combat\Surround.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */