/*     */ package me.earth.phobos.features.modules.combat;
/*     */ import java.awt.Color;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.Render3DEvent;
/*     */ import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
/*     */ import me.earth.phobos.features.command.Command;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.modules.client.Colors;
/*     */ import me.earth.phobos.features.modules.player.BlockTweaks;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.BlockUtil;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.InventoryUtil;
/*     */ import me.earth.phobos.util.MathUtil;
/*     */ import me.earth.phobos.util.RenderUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class AutoTrap extends Module {
/*  31 */   private final Setting<Integer> delay = register(new Setting("Delay/Place", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(250))); public static boolean isPlacing = false;
/*  32 */   private final Setting<Integer> blocksPerPlace = register(new Setting("Block/Place", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  33 */   private final Setting<Double> targetRange = register(new Setting("TargetRange", Double.valueOf(10.0D), Double.valueOf(0.0D), Double.valueOf(20.0D)));
/*  34 */   private final Setting<Double> range = register(new Setting("PlaceRange", Double.valueOf(6.0D), Double.valueOf(0.0D), Double.valueOf(10.0D)));
/*  35 */   private final Setting<TargetMode> targetMode = register(new Setting("Target", TargetMode.CLOSEST));
/*  36 */   private final Setting<InventoryUtil.Switch> switchMode = register(new Setting("Switch", InventoryUtil.Switch.NORMAL));
/*  37 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  38 */   private final Setting<Boolean> raytrace = register(new Setting("Raytrace", Boolean.valueOf(false)));
/*  39 */   private final Setting<Pattern> pattern = register(new Setting("Pattern", Pattern.STATIC));
/*  40 */   private final Setting<Integer> extend = register(new Setting("Extend", Integer.valueOf(4), Integer.valueOf(1), Integer.valueOf(4), v -> (this.pattern.getValue() != Pattern.STATIC), "Extending the Trap."));
/*  41 */   private final Setting<Boolean> antiScaffold = register(new Setting("AntiScaffold", Boolean.valueOf(false)));
/*  42 */   private final Setting<Boolean> antiStep = register(new Setting("AntiStep", Boolean.valueOf(false)));
/*  43 */   private final Setting<Boolean> legs = register(new Setting("Legs", Boolean.valueOf(false), v -> (this.pattern.getValue() != Pattern.OPEN)));
/*  44 */   private final Setting<Boolean> platform = register(new Setting("Platform", Boolean.valueOf(false), v -> (this.pattern.getValue() != Pattern.OPEN)));
/*  45 */   private final Setting<Boolean> antiDrop = register(new Setting("AntiDrop", Boolean.valueOf(false)));
/*  46 */   private final Setting<Double> speed = register(new Setting("Speed", Double.valueOf(10.0D), Double.valueOf(0.0D), Double.valueOf(30.0D)));
/*  47 */   private final Setting<Boolean> antiSelf = register(new Setting("AntiSelf", Boolean.valueOf(false)));
/*  48 */   private final Setting<Integer> eventMode = register(new Setting("Updates", Integer.valueOf(3), Integer.valueOf(1), Integer.valueOf(3)));
/*  49 */   private final Setting<Boolean> freecam = register(new Setting("Freecam", Boolean.valueOf(false)));
/*  50 */   private final Setting<Boolean> info = register(new Setting("Info", Boolean.valueOf(false)));
/*  51 */   private final Setting<Boolean> entityCheck = register(new Setting("NoBlock", Boolean.valueOf(true)));
/*  52 */   private final Setting<Boolean> noScaffoldExtend = register(new Setting("NoScaffoldExtend", Boolean.valueOf(false)));
/*  53 */   private final Setting<Boolean> disable = register(new Setting("TSelfMove", Boolean.valueOf(false)));
/*  54 */   private final Setting<Boolean> packet = register(new Setting("Packet", Boolean.valueOf(false)));
/*  55 */   private final Setting<Boolean> airPacket = register(new Setting("AirPacket", Boolean.valueOf(false), v -> ((Boolean)this.packet.getValue()).booleanValue()));
/*  56 */   private final Setting<Integer> retryer = register(new Setting("Retries", Integer.valueOf(4), Integer.valueOf(1), Integer.valueOf(15)));
/*  57 */   private final Setting<Boolean> render = register(new Setting("Render", Boolean.valueOf(true)));
/*  58 */   public final Setting<Boolean> colorSync = register(new Setting("Sync", Boolean.valueOf(false), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  59 */   public final Setting<Boolean> box = register(new Setting("Box", Boolean.valueOf(false), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  60 */   public final Setting<Boolean> outline = register(new Setting("Outline", Boolean.valueOf(true), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  61 */   public final Setting<Boolean> customOutline = register(new Setting("CustomLine", Boolean.valueOf(false), v -> (((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  62 */   private final Setting<Integer> red = register(new Setting("Red", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  63 */   private final Setting<Integer> green = register(new Setting("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  64 */   private final Setting<Integer> blue = register(new Setting("Blue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  65 */   private final Setting<Integer> alpha = register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  66 */   private final Setting<Integer> boxAlpha = register(new Setting("BoxAlpha", Integer.valueOf(125), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.box.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  67 */   private final Setting<Float> lineWidth = register(new Setting("LineWidth", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(5.0F), v -> (((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  68 */   private final Setting<Integer> cRed = register(new Setting("OL-Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  69 */   private final Setting<Integer> cGreen = register(new Setting("OL-Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  70 */   private final Setting<Integer> cBlue = register(new Setting("OL-Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  71 */   private final Setting<Integer> cAlpha = register(new Setting("OL-Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.customOutline.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  72 */   private final Timer timer = new Timer();
/*  73 */   private final Map<BlockPos, Integer> retries = new HashMap<>();
/*  74 */   private final Timer retryTimer = new Timer();
/*  75 */   private final Map<BlockPos, IBlockState> toAir = new HashMap<>();
/*     */   public EntityPlayer target;
/*     */   private boolean didPlace = false;
/*     */   private boolean switchedItem;
/*     */   private boolean isSneaking;
/*     */   private int lastHotbarSlot;
/*  81 */   private int placements = 0;
/*     */   private boolean smartRotate = false;
/*  83 */   private BlockPos startPos = null;
/*     */   private List<Vec3d> currentPlaceList;
/*     */   
/*     */   public AutoTrap() {
/*  87 */     super("AutoTrap", "Traps other players", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  92 */     if (fullNullCheck()) {
/*  93 */       disable();
/*     */       return;
/*     */     } 
/*  96 */     this.toAir.clear();
/*  97 */     this.startPos = EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g);
/*  98 */     this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*  99 */     this.retries.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLogout() {
/* 104 */     disable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/* 109 */     if (((Integer)this.eventMode.getValue()).intValue() == 3) {
/* 110 */       this.smartRotate = false;
/* 111 */       doTrap();
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/* 117 */     if (event.getStage() == 0 && ((Integer)this.eventMode.getValue()).intValue() == 2) {
/* 118 */       this.smartRotate = (((Boolean)this.rotate.getValue()).booleanValue() && ((Integer)this.blocksPerPlace.getValue()).intValue() == 1);
/* 119 */       doTrap();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 125 */     if (((Integer)this.eventMode.getValue()).intValue() == 1) {
/* 126 */       this.smartRotate = false;
/* 127 */       doTrap();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/* 133 */     if (((Boolean)this.info.getValue()).booleanValue() && this.target != null) {
/* 134 */       return this.target.func_70005_c_();
/*     */     }
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 141 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/* 144 */     isPlacing = false;
/* 145 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 146 */     switchItem(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/* 151 */     if (((Boolean)this.render.getValue()).booleanValue()) {
/* 152 */       for (Vec3d vec : this.currentPlaceList) {
/* 153 */         BlockPos pos = new BlockPos(vec);
/* 154 */         if (!(mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockAir))
/* 155 */           continue;  RenderUtil.drawBoxESP(pos, ((Boolean)this.colorSync.getValue()).booleanValue() ? Colors.INSTANCE.getCurrentColor() : new Color(((Integer)this.red.getValue()).intValue(), ((Integer)this.green.getValue()).intValue(), ((Integer)this.blue.getValue()).intValue(), ((Integer)this.alpha.getValue()).intValue()), ((Boolean)this.customOutline.getValue()).booleanValue(), new Color(((Integer)this.cRed.getValue()).intValue(), ((Integer)this.cGreen.getValue()).intValue(), ((Integer)this.cBlue.getValue()).intValue(), ((Integer)this.cAlpha.getValue()).intValue()), ((Float)this.lineWidth.getValue()).floatValue(), ((Boolean)this.outline.getValue()).booleanValue(), ((Boolean)this.box.getValue()).booleanValue(), ((Integer)this.boxAlpha.getValue()).intValue(), false);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void doTrap() {
/* 161 */     if (check()) {
/*     */       return;
/*     */     }
/* 164 */     switch ((Pattern)this.pattern.getValue()) {
/*     */       case STATIC:
/* 166 */         doStaticTrap();
/*     */         break;
/*     */       
/*     */       case SMART:
/*     */       case OPEN:
/* 171 */         doSmartTrap();
/*     */         break;
/*     */     } 
/*     */     
/* 175 */     if (((Boolean)this.packet.getValue()).booleanValue() && ((Boolean)this.airPacket.getValue()).booleanValue()) {
/* 176 */       for (Map.Entry<BlockPos, IBlockState> entry : this.toAir.entrySet()) {
/* 177 */         mc.field_71441_e.func_175656_a(entry.getKey(), entry.getValue());
/*     */       }
/* 179 */       this.toAir.clear();
/*     */     } 
/* 181 */     if (this.didPlace) {
/* 182 */       this.timer.reset();
/*     */     }
/*     */   }
/*     */   
/*     */   private void doSmartTrap() {
/* 187 */     List<Vec3d> placeTargets = EntityUtil.getUntrappedBlocksExtended(((Integer)this.extend.getValue()).intValue(), this.target, ((Boolean)this.antiScaffold.getValue()).booleanValue(), ((Boolean)this.antiStep.getValue()).booleanValue(), ((Boolean)this.legs.getValue()).booleanValue(), ((Boolean)this.platform.getValue()).booleanValue(), ((Boolean)this.antiDrop.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), ((Boolean)this.noScaffoldExtend.getValue()).booleanValue());
/* 188 */     placeList(placeTargets);
/* 189 */     this.currentPlaceList = placeTargets;
/*     */   }
/*     */   
/*     */   private void doStaticTrap() {
/* 193 */     List<Vec3d> placeTargets = EntityUtil.targets(this.target.func_174791_d(), ((Boolean)this.antiScaffold.getValue()).booleanValue(), ((Boolean)this.antiStep.getValue()).booleanValue(), ((Boolean)this.legs.getValue()).booleanValue(), ((Boolean)this.platform.getValue()).booleanValue(), ((Boolean)this.antiDrop.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue());
/* 194 */     placeList(placeTargets);
/* 195 */     this.currentPlaceList = placeTargets;
/*     */   }
/*     */   
/*     */   private void placeList(List<Vec3d> list) {
/* 199 */     list.sort((vec3d, vec3d2) -> Double.compare(mc.field_71439_g.func_70092_e(vec3d2.field_72450_a, vec3d2.field_72448_b, vec3d2.field_72449_c), mc.field_71439_g.func_70092_e(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c)));
/* 200 */     list.sort(Comparator.comparingDouble(vec3d -> vec3d.field_72448_b));
/* 201 */     for (Vec3d vec3d3 : list) {
/* 202 */       BlockPos position = new BlockPos(vec3d3);
/* 203 */       int placeability = BlockUtil.isPositionPlaceable(position, ((Boolean)this.raytrace.getValue()).booleanValue());
/* 204 */       if (((Boolean)this.entityCheck.getValue()).booleanValue() && placeability == 1 && (this.switchMode.getValue() == InventoryUtil.Switch.SILENT || (BlockTweaks.getINSTANCE().isOn() && ((Boolean)(BlockTweaks.getINSTANCE()).noBlock.getValue()).booleanValue())) && (this.retries.get(position) == null || ((Integer)this.retries.get(position)).intValue() < ((Integer)this.retryer.getValue()).intValue())) {
/* 205 */         placeBlock(position);
/* 206 */         this.retries.put(position, Integer.valueOf((this.retries.get(position) == null) ? 1 : (((Integer)this.retries.get(position)).intValue() + 1)));
/* 207 */         this.retryTimer.reset();
/*     */         continue;
/*     */       } 
/* 210 */       if (placeability != 3 || (((Boolean)this.antiSelf.getValue()).booleanValue() && MathUtil.areVec3dsAligned(mc.field_71439_g.func_174791_d(), vec3d3)))
/*     */         continue; 
/* 212 */       placeBlock(position);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean check() {
/* 217 */     isPlacing = false;
/* 218 */     this.didPlace = false;
/* 219 */     this.placements = 0;
/* 220 */     int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 221 */     if (isOff()) {
/* 222 */       return true;
/*     */     }
/* 224 */     if (((Boolean)this.disable.getValue()).booleanValue() && !this.startPos.equals(EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g))) {
/* 225 */       disable();
/* 226 */       return true;
/*     */     } 
/* 228 */     if (this.retryTimer.passedMs(2000L)) {
/* 229 */       this.retries.clear();
/* 230 */       this.retryTimer.reset();
/*     */     } 
/* 232 */     if (obbySlot == -1) {
/* 233 */       if (this.switchMode.getValue() != InventoryUtil.Switch.NONE) {
/* 234 */         if (((Boolean)this.info.getValue()).booleanValue()) {
/* 235 */           Command.sendMessage("<" + getDisplayName() + "> §cYou are out of Obsidian.");
/*     */         }
/* 237 */         disable();
/*     */       } 
/* 239 */       return true;
/*     */     } 
/* 241 */     if (mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && mc.field_71439_g.field_71071_by.field_70461_c != obbySlot) {
/* 242 */       this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */     }
/* 244 */     switchItem(true);
/* 245 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 246 */     this.target = getTarget(((Double)this.targetRange.getValue()).doubleValue(), (this.targetMode.getValue() == TargetMode.UNTRAPPED));
/* 247 */     return (this.target == null || (Phobos.moduleManager.isModuleEnabled("Freecam") && !((Boolean)this.freecam.getValue()).booleanValue()) || !this.timer.passedMs(((Integer)this.delay.getValue()).intValue()) || (this.switchMode.getValue() == InventoryUtil.Switch.NONE && mc.field_71439_g.field_71071_by.field_70461_c != InventoryUtil.findHotbarBlock(BlockObsidian.class)));
/*     */   }
/*     */   
/*     */   private EntityPlayer getTarget(double range, boolean trapped) {
/* 251 */     EntityPlayer target = null;
/* 252 */     double distance = Math.pow(range, 2.0D) + 1.0D;
/* 253 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 254 */       if (EntityUtil.isntValid((Entity)player, range) || (this.pattern.getValue() == Pattern.STATIC && trapped && EntityUtil.isTrapped(player, ((Boolean)this.antiScaffold.getValue()).booleanValue(), ((Boolean)this.antiStep.getValue()).booleanValue(), ((Boolean)this.legs.getValue()).booleanValue(), ((Boolean)this.platform.getValue()).booleanValue(), ((Boolean)this.antiDrop.getValue()).booleanValue())) || (this.pattern.getValue() != Pattern.STATIC && trapped && EntityUtil.isTrappedExtended(((Integer)this.extend.getValue()).intValue(), player, ((Boolean)this.antiScaffold.getValue()).booleanValue(), ((Boolean)this.antiStep.getValue()).booleanValue(), ((Boolean)this.legs.getValue()).booleanValue(), ((Boolean)this.platform.getValue()).booleanValue(), ((Boolean)this.antiDrop.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), ((Boolean)this.noScaffoldExtend.getValue()).booleanValue())) || (EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g).equals(EntityUtil.getRoundedBlockPos((Entity)player)) && ((Boolean)this.antiSelf.getValue()).booleanValue()) || Phobos.speedManager.getPlayerSpeed(player) > ((Double)this.speed.getValue()).doubleValue())
/*     */         continue; 
/* 256 */       if (target == null) {
/* 257 */         target = player;
/* 258 */         distance = mc.field_71439_g.func_70068_e((Entity)player);
/*     */         continue;
/*     */       } 
/* 261 */       if (mc.field_71439_g.func_70068_e((Entity)player) >= distance)
/* 262 */         continue;  target = player;
/* 263 */       distance = mc.field_71439_g.func_70068_e((Entity)player);
/*     */     } 
/* 265 */     return target;
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 269 */     if (this.placements < ((Integer)this.blocksPerPlace.getValue()).intValue() && mc.field_71439_g.func_174818_b(pos) <= MathUtil.square(((Double)this.range.getValue()).doubleValue()) && switchItem(false)) {
/* 270 */       isPlacing = true;
/* 271 */       if (((Boolean)this.airPacket.getValue()).booleanValue() && ((Boolean)this.packet.getValue()).booleanValue()) {
/* 272 */         this.toAir.put(pos, mc.field_71441_e.func_180495_p(pos));
/*     */       }
/* 274 */       this.isSneaking = this.smartRotate ? BlockUtil.placeBlockSmartRotate(pos, EnumHand.MAIN_HAND, true, (!((Boolean)this.airPacket.getValue()).booleanValue() && ((Boolean)this.packet.getValue()).booleanValue()), this.isSneaking) : BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), (!((Boolean)this.airPacket.getValue()).booleanValue() && ((Boolean)this.packet.getValue()).booleanValue()), this.isSneaking);
/* 275 */       this.didPlace = true;
/* 276 */       this.placements++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean switchItem(boolean back) {
/* 281 */     boolean[] value = InventoryUtil.switchItem(back, this.lastHotbarSlot, this.switchedItem, (InventoryUtil.Switch)this.switchMode.getValue(), BlockObsidian.class);
/* 282 */     this.switchedItem = value[0];
/* 283 */     return value[1];
/*     */   }
/*     */   
/*     */   public enum TargetMode {
/* 287 */     CLOSEST,
/* 288 */     UNTRAPPED;
/*     */   }
/*     */   
/*     */   public enum Pattern
/*     */   {
/* 293 */     STATIC,
/* 294 */     SMART,
/* 295 */     OPEN;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\combat\AutoTrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */