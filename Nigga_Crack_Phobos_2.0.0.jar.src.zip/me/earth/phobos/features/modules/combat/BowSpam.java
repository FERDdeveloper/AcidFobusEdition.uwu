/*     */ package me.earth.phobos.features.modules.combat;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.PacketEvent;
/*     */ import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.InventoryUtil;
/*     */ import me.earth.phobos.util.MathUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemBow;
/*     */ import net.minecraft.item.ItemEndCrystal;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ public class BowSpam extends Module {
/*  27 */   private final Timer timer = new Timer();
/*  28 */   public Setting<Mode> mode = register(new Setting("Mode", Mode.FAST));
/*  29 */   public Setting<Boolean> bowbomb = register(new Setting("BowBomb", Boolean.valueOf(false), v -> (this.mode.getValue() != Mode.BOWBOMB)));
/*  30 */   public Setting<Boolean> allowOffhand = register(new Setting("Offhand", Boolean.valueOf(true), v -> (this.mode.getValue() != Mode.AUTORELEASE)));
/*  31 */   public Setting<Integer> ticks = register(new Setting("Ticks", Integer.valueOf(3), Integer.valueOf(0), Integer.valueOf(20), v -> (this.mode.getValue() == Mode.BOWBOMB || this.mode.getValue() == Mode.FAST), "Speed"));
/*  32 */   public Setting<Integer> delay = register(new Setting("Delay", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(500), v -> (this.mode.getValue() == Mode.AUTORELEASE), "Speed"));
/*  33 */   public Setting<Boolean> tpsSync = register(new Setting("TpsSync", Boolean.valueOf(true)));
/*  34 */   public Setting<Boolean> autoSwitch = register(new Setting("AutoSwitch", Boolean.valueOf(false)));
/*  35 */   public Setting<Boolean> onlyWhenSave = register(new Setting("OnlyWhenSave", Boolean.valueOf(true), v -> ((Boolean)this.autoSwitch.getValue()).booleanValue()));
/*  36 */   public Setting<Target> targetMode = register(new Setting("Target", Target.LOWEST, v -> ((Boolean)this.autoSwitch.getValue()).booleanValue()));
/*  37 */   public Setting<Float> range = register(new Setting("Range", Float.valueOf(3.0F), Float.valueOf(0.0F), Float.valueOf(6.0F), v -> ((Boolean)this.autoSwitch.getValue()).booleanValue(), "Range of the target"));
/*  38 */   public Setting<Float> health = register(new Setting("Lethal", Float.valueOf(6.0F), Float.valueOf(0.1F), Float.valueOf(36.0F), v -> ((Boolean)this.autoSwitch.getValue()).booleanValue(), "When should it switch?"));
/*  39 */   public Setting<Float> ownHealth = register(new Setting("OwnHealth", Float.valueOf(20.0F), Float.valueOf(0.1F), Float.valueOf(36.0F), v -> ((Boolean)this.autoSwitch.getValue()).booleanValue(), "Own Health."));
/*     */   private boolean offhand = false;
/*     */   private boolean switched = false;
/*  42 */   private int lastHotbarSlot = -1;
/*     */   
/*     */   public BowSpam() {
/*  45 */     super("BowSpam", "Spams your bow", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  50 */     this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/*  55 */     if (event.getStage() != 0) {
/*     */       return;
/*     */     }
/*     */     
/*  59 */     if (((Boolean)this.autoSwitch.getValue()).booleanValue() && InventoryUtil.findHotbarBlock(ItemBow.class) != -1 && ((Float)this.ownHealth.getValue()).floatValue() <= EntityUtil.getHealth((Entity)mc.field_71439_g) && (!((Boolean)this.onlyWhenSave.getValue()).booleanValue() || EntityUtil.isSafe((Entity)mc.field_71439_g))) {
/*  60 */       EntityPlayer target = getTarget();
/*  61 */       if (target != null) {
/*  62 */         AutoCrystal crystal = (AutoCrystal)Phobos.moduleManager.getModuleByClass(AutoCrystal.class);
/*  63 */         if (!crystal.isOn() || !InventoryUtil.holdingItem(ItemEndCrystal.class)) {
/*  64 */           Vec3d pos = target.func_174791_d();
/*  65 */           double xPos = pos.field_72450_a;
/*  66 */           double yPos = pos.field_72448_b;
/*  67 */           double zPos = pos.field_72449_c;
/*  68 */           if (mc.field_71439_g.func_70685_l((Entity)target)) {
/*     */             
/*  70 */             yPos += target.eyeHeight;
/*  71 */           } else if (EntityUtil.canEntityFeetBeSeen((Entity)target)) {
/*  72 */             yPos += 0.1D;
/*     */           } else {
/*     */             return;
/*     */           } 
/*     */           
/*  77 */           if (!(mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemBow)) {
/*  78 */             this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*  79 */             InventoryUtil.switchToHotbarSlot(ItemBow.class, false);
/*  80 */             mc.field_71474_y.field_74313_G.field_74513_e = true;
/*  81 */             this.switched = true;
/*     */           } 
/*     */           
/*  84 */           Phobos.rotationManager.lookAtVec3d(xPos, yPos, zPos);
/*  85 */           if (mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemBow) {
/*  86 */             this.switched = true;
/*     */           }
/*     */         } 
/*     */       } 
/*  90 */     } else if (event.getStage() == 0 && this.switched && this.lastHotbarSlot != -1) {
/*  91 */       InventoryUtil.switchToHotbarSlot(this.lastHotbarSlot, false);
/*  92 */       mc.field_71474_y.field_74313_G.field_74513_e = Mouse.isButtonDown(1);
/*  93 */       this.switched = false;
/*     */     } else {
/*  95 */       mc.field_71474_y.field_74313_G.field_74513_e = Mouse.isButtonDown(1);
/*     */     } 
/*     */     
/*  98 */     if (this.mode.getValue() == Mode.FAST && (
/*  99 */       this.offhand || mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemBow) && 
/* 100 */       mc.field_71439_g.func_184587_cr() && mc.field_71439_g.func_184612_cw() >= ((Integer)this.ticks.getValue()).intValue() * (((Boolean)this.tpsSync.getValue()).booleanValue() ? Phobos.serverManager.getTpsFactor() : 1.0F)) {
/* 101 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, mc.field_71439_g.func_174811_aO()));
/* 102 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItem(this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND));
/* 103 */       mc.field_71439_g.func_184597_cx();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 111 */     this.offhand = (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151031_f && ((Boolean)this.allowOffhand.getValue()).booleanValue());
/* 112 */     switch ((Mode)this.mode.getValue()) {
/*     */       case AUTORELEASE:
/* 114 */         if ((this.offhand || mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemBow) && 
/* 115 */           this.timer.passedMs((int)(((Integer)this.delay.getValue()).intValue() * (((Boolean)this.tpsSync.getValue()).booleanValue() ? Phobos.serverManager.getTpsFactor() : 1.0F)))) {
/* 116 */           mc.field_71442_b.func_78766_c((EntityPlayer)mc.field_71439_g);
/* 117 */           this.timer.reset();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case BOWBOMB:
/* 122 */         if ((this.offhand || mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemBow) && 
/* 123 */           mc.field_71439_g.func_184587_cr() && mc.field_71439_g.func_184612_cw() >= ((Integer)this.ticks.getValue()).intValue() * (((Boolean)this.tpsSync.getValue()).booleanValue() ? Phobos.serverManager.getTpsFactor() : 1.0F)) {
/* 124 */           mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, mc.field_71439_g.func_174811_aO()));
/* 125 */           mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.PositionRotation(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - 0.0624D, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70177_z, mc.field_71439_g.field_70125_A, false));
/* 126 */           mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.PositionRotation(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - 999.0D, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70177_z, mc.field_71439_g.field_70125_A, true));
/* 127 */           mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItem(this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND));
/* 128 */           mc.field_71439_g.func_184597_cx();
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.Send event) {
/* 137 */     if (event.getStage() == 0 && ((Boolean)this.bowbomb.getValue()).booleanValue() && this.mode.getValue() != Mode.BOWBOMB && event.getPacket() instanceof CPacketPlayerDigging) {
/* 138 */       CPacketPlayerDigging packet = (CPacketPlayerDigging)event.getPacket();
/* 139 */       if (packet.func_180762_c() == CPacketPlayerDigging.Action.RELEASE_USE_ITEM && (
/* 140 */         this.offhand || mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemBow) && mc.field_71439_g.func_184612_cw() >= 20 && !mc.field_71439_g.field_70122_E) {
/* 141 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - 0.10000000149011612D, mc.field_71439_g.field_70161_v, false));
/* 142 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - 10000.0D, mc.field_71439_g.field_70161_v, true));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private EntityPlayer getTarget() {
/* 149 */     double maxHealth = 36.0D;
/* 150 */     EntityPlayer target = null;
/* 151 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 152 */       if (player == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 156 */       if (EntityUtil.isDead((Entity)player)) {
/*     */         continue;
/*     */       }
/*     */       
/* 160 */       if (EntityUtil.getHealth((Entity)player) > ((Float)this.health.getValue()).floatValue()) {
/*     */         continue;
/*     */       }
/*     */       
/* 164 */       if (player.equals(mc.field_71439_g)) {
/*     */         continue;
/*     */       }
/*     */       
/* 168 */       if (Phobos.friendManager.isFriend(player)) {
/*     */         continue;
/*     */       }
/*     */       
/* 172 */       if (mc.field_71439_g.func_70068_e((Entity)player) > MathUtil.square(((Float)this.range.getValue()).floatValue())) {
/*     */         continue;
/*     */       }
/*     */       
/* 176 */       if (!mc.field_71439_g.func_70685_l((Entity)player) && !EntityUtil.canEntityFeetBeSeen((Entity)player)) {
/*     */         continue;
/*     */       }
/*     */       
/* 180 */       if (target == null) {
/* 181 */         target = player;
/* 182 */         maxHealth = EntityUtil.getHealth((Entity)player);
/*     */       } 
/*     */       
/* 185 */       if (this.targetMode.getValue() == Target.CLOSEST && mc.field_71439_g.func_70068_e((Entity)player) < mc.field_71439_g.func_70068_e((Entity)target)) {
/* 186 */         target = player;
/* 187 */         maxHealth = EntityUtil.getHealth((Entity)player);
/*     */       } 
/*     */       
/* 190 */       if (this.targetMode.getValue() == Target.LOWEST && EntityUtil.getHealth((Entity)player) < maxHealth) {
/* 191 */         target = player;
/* 192 */         maxHealth = EntityUtil.getHealth((Entity)player);
/*     */       } 
/*     */     } 
/* 195 */     return target;
/*     */   }
/*     */   
/*     */   public enum Target {
/* 199 */     CLOSEST,
/* 200 */     LOWEST;
/*     */   }
/*     */   
/*     */   public enum Mode {
/* 204 */     FAST,
/* 205 */     AUTORELEASE,
/* 206 */     BOWBOMB;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\combat\BowSpam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */