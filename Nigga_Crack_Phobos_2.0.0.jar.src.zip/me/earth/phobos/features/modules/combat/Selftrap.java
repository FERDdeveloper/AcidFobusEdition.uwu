/*     */ package me.earth.phobos.features.modules.combat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.modules.player.BlockTweaks;
/*     */ import me.earth.phobos.features.modules.player.Freecam;
/*     */ import me.earth.phobos.features.setting.Bind;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.BlockUtil;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.InventoryUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.block.BlockWeb;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.InputEvent;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ public class Selftrap extends Module {
/*  30 */   private final Setting<Boolean> smart = register(new Setting("Smart", Boolean.valueOf(false)));
/*  31 */   private final Setting<Double> smartRange = register(new Setting("SmartRange", Double.valueOf(6.0D), Double.valueOf(0.0D), Double.valueOf(10.0D)));
/*  32 */   private final Setting<Integer> delay = register(new Setting("Delay/Place", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(250)));
/*  33 */   private final Setting<Integer> blocksPerTick = register(new Setting("Block/Place", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(20)));
/*  34 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  35 */   private final Setting<Boolean> disable = register(new Setting("Disable", Boolean.valueOf(true)));
/*  36 */   private final Setting<Integer> disableTime = register(new Setting("Ms/Disable", Integer.valueOf(200), Integer.valueOf(1), Integer.valueOf(250)));
/*  37 */   private final Setting<Boolean> offhand = register(new Setting("OffHand", Boolean.valueOf(true)));
/*  38 */   private final Setting<InventoryUtil.Switch> switchMode = register(new Setting("Switch", InventoryUtil.Switch.NORMAL));
/*  39 */   private final Setting<Boolean> onlySafe = register(new Setting("OnlySafe", Boolean.valueOf(true), v -> ((Boolean)this.offhand.getValue()).booleanValue()));
/*  40 */   private final Setting<Boolean> highWeb = register(new Setting("HighWeb", Boolean.valueOf(false)));
/*  41 */   private final Setting<Boolean> freecam = register(new Setting("Freecam", Boolean.valueOf(false)));
/*  42 */   private final Setting<Boolean> packet = register(new Setting("Packet", Boolean.valueOf(false)));
/*  43 */   private final Timer offTimer = new Timer();
/*  44 */   private final Timer timer = new Timer();
/*  45 */   private final Map<BlockPos, Integer> retries = new HashMap<>();
/*  46 */   private final Timer retryTimer = new Timer();
/*  47 */   public Setting<Mode> mode = register(new Setting("Mode", Mode.OBSIDIAN));
/*  48 */   public Setting<Bind> obbyBind = register(new Setting("Obsidian", new Bind(-1)));
/*  49 */   public Setting<Bind> webBind = register(new Setting("Webs", new Bind(-1)));
/*  50 */   public Mode currentMode = Mode.OBSIDIAN;
/*     */   private boolean accessedViaBind = false;
/*  52 */   private int blocksThisTick = 0;
/*  53 */   private Offhand.Mode offhandMode = Offhand.Mode.CRYSTALS;
/*  54 */   private Offhand.Mode2 offhandMode2 = Offhand.Mode2.CRYSTALS;
/*     */   private boolean isSneaking;
/*     */   private boolean hasOffhand = false;
/*     */   private boolean placeHighWeb = false;
/*  58 */   private int lastHotbarSlot = -1;
/*     */   private boolean switchedItem = false;
/*     */   
/*     */   public Selftrap() {
/*  62 */     super("Selftrap", "Lure your enemies in!", Module.Category.COMBAT, true, false, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  67 */     if (fullNullCheck()) {
/*  68 */       disable();
/*     */     }
/*  70 */     this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*  71 */     if (!this.accessedViaBind) {
/*  72 */       this.currentMode = (Mode)this.mode.getValue();
/*     */     }
/*  74 */     Offhand module = (Offhand)Phobos.moduleManager.getModuleByClass(Offhand.class);
/*  75 */     this.offhandMode = module.mode;
/*  76 */     this.offhandMode2 = module.currentMode;
/*  77 */     if (((Boolean)this.offhand.getValue()).booleanValue() && (EntityUtil.isSafe((Entity)mc.field_71439_g) || !((Boolean)this.onlySafe.getValue()).booleanValue())) {
/*  78 */       if (module.type.getValue() == Offhand.Type.OLD) {
/*  79 */         if (this.currentMode == Mode.WEBS) {
/*  80 */           module.setMode(Offhand.Mode2.WEBS);
/*     */         } else {
/*  82 */           module.setMode(Offhand.Mode2.OBSIDIAN);
/*     */         } 
/*  84 */       } else if (this.currentMode == Mode.WEBS) {
/*  85 */         module.setSwapToTotem(false);
/*  86 */         module.setMode(Offhand.Mode.WEBS);
/*     */       } else {
/*  88 */         module.setSwapToTotem(false);
/*  89 */         module.setMode(Offhand.Mode.OBSIDIAN);
/*     */       } 
/*     */     }
/*  92 */     Phobos.holeManager.update();
/*  93 */     this.offTimer.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  98 */     if (isOn() && (((Integer)this.blocksPerTick.getValue()).intValue() != 1 || !((Boolean)this.rotate.getValue()).booleanValue())) {
/*  99 */       doHoleFill();
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/* 105 */     if (isOn() && event.getStage() == 0 && ((Integer)this.blocksPerTick.getValue()).intValue() == 1 && ((Boolean)this.rotate.getValue()).booleanValue()) {
/* 106 */       doHoleFill();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 112 */     if (((Boolean)this.offhand.getValue()).booleanValue()) {
/* 113 */       ((Offhand)Phobos.moduleManager.getModuleByClass(Offhand.class)).setMode(this.offhandMode);
/* 114 */       ((Offhand)Phobos.moduleManager.getModuleByClass(Offhand.class)).setMode(this.offhandMode2);
/*     */     } 
/* 116 */     switchItem(true);
/* 117 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 118 */     this.retries.clear();
/* 119 */     this.accessedViaBind = false;
/* 120 */     this.hasOffhand = false;
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.NORMAL, receiveCanceled = true)
/*     */   public void onKeyInput(InputEvent.KeyInputEvent event) {
/* 125 */     if (Keyboard.getEventKeyState()) {
/* 126 */       if (((Bind)this.obbyBind.getValue()).getKey() == Keyboard.getEventKey()) {
/* 127 */         this.accessedViaBind = true;
/* 128 */         this.currentMode = Mode.OBSIDIAN;
/* 129 */         toggle();
/*     */       } 
/* 131 */       if (((Bind)this.webBind.getValue()).getKey() == Keyboard.getEventKey()) {
/* 132 */         this.accessedViaBind = true;
/* 133 */         this.currentMode = Mode.WEBS;
/* 134 */         toggle();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void doHoleFill() {
/* 140 */     if (check()) {
/*     */       return;
/*     */     }
/* 143 */     if (this.placeHighWeb) {
/* 144 */       BlockPos pos = new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.0D, mc.field_71439_g.field_70161_v);
/* 145 */       placeBlock(pos);
/* 146 */       this.placeHighWeb = false;
/*     */     } 
/* 148 */     for (BlockPos position : getPositions()) {
/* 149 */       if (((Boolean)this.smart.getValue()).booleanValue() && !isPlayerInRange())
/* 150 */         continue;  int placeability = BlockUtil.isPositionPlaceable(position, false);
/* 151 */       if (placeability == 1) {
/* 152 */         switch (this.currentMode) {
/*     */           case WEBS:
/* 154 */             placeBlock(position);
/*     */             break;
/*     */           
/*     */           case OBSIDIAN:
/* 158 */             if ((this.switchMode.getValue() != InventoryUtil.Switch.SILENT && (!BlockTweaks.getINSTANCE().isOn() || !((Boolean)(BlockTweaks.getINSTANCE()).noBlock.getValue()).booleanValue())) || (this.retries.get(position) != null && ((Integer)this.retries.get(position)).intValue() >= 4))
/*     */               break; 
/* 160 */             placeBlock(position);
/* 161 */             this.retries.put(position, Integer.valueOf((this.retries.get(position) == null) ? 1 : (((Integer)this.retries.get(position)).intValue() + 1)));
/*     */             break;
/*     */         } 
/*     */       }
/* 165 */       if (placeability != 3)
/* 166 */         continue;  placeBlock(position);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPlayerInRange() {
/* 171 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 172 */       if (EntityUtil.isntValid((Entity)player, ((Double)this.smartRange.getValue()).doubleValue()))
/* 173 */         continue;  return true;
/*     */     } 
/* 175 */     return false;
/*     */   }
/*     */   private List<BlockPos> getPositions() {
/*     */     int placeability;
/* 179 */     ArrayList<BlockPos> positions = new ArrayList<>();
/*     */     
/* 181 */     switch (this.currentMode) {
/*     */       case WEBS:
/* 183 */         positions.add(new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v));
/* 184 */         if (!((Boolean)this.highWeb.getValue()).booleanValue())
/* 185 */           break;  positions.add(new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.0D, mc.field_71439_g.field_70161_v));
/*     */         break;
/*     */       
/*     */       case OBSIDIAN:
/* 189 */         positions.add(new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 2.0D, mc.field_71439_g.field_70161_v));
/* 190 */         placeability = BlockUtil.isPositionPlaceable(positions.get(0), false);
/* 191 */         switch (placeability) {
/*     */           case 0:
/* 193 */             return new ArrayList<>();
/*     */           
/*     */           case 3:
/* 196 */             return positions;
/*     */           
/*     */           case 1:
/* 199 */             if (BlockUtil.isPositionPlaceable(positions.get(0), false, false) == 3) {
/* 200 */               return positions;
/*     */             }
/*     */           
/*     */           case 2:
/* 204 */             positions.add(new BlockPos(mc.field_71439_g.field_70165_t + 1.0D, mc.field_71439_g.field_70163_u + 1.0D, mc.field_71439_g.field_70161_v));
/* 205 */             positions.add(new BlockPos(mc.field_71439_g.field_70165_t + 1.0D, mc.field_71439_g.field_70163_u + 2.0D, mc.field_71439_g.field_70161_v));
/*     */             break;
/*     */         } 
/*     */         
/*     */         break;
/*     */     } 
/* 211 */     positions.sort(Comparator.comparingDouble(Vec3i::func_177956_o));
/* 212 */     return positions;
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 216 */     if (this.blocksThisTick < ((Integer)this.blocksPerTick.getValue()).intValue() && switchItem(false)) {
/*     */       
/* 218 */       boolean smartRotate = (((Integer)this.blocksPerTick.getValue()).intValue() == 1 && ((Boolean)this.rotate.getValue()).booleanValue()), bl = smartRotate;
/* 219 */       this.isSneaking = smartRotate ? BlockUtil.placeBlockSmartRotate(pos, this.hasOffhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, true, ((Boolean)this.packet.getValue()).booleanValue(), this.isSneaking) : BlockUtil.placeBlock(pos, this.hasOffhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), this.isSneaking);
/* 220 */       this.timer.reset();
/* 221 */       this.blocksThisTick++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean check() {
/* 226 */     if (fullNullCheck() || (((Boolean)this.disable.getValue()).booleanValue() && this.offTimer.passedMs(((Integer)this.disableTime.getValue()).intValue()))) {
/* 227 */       disable();
/* 228 */       return true;
/*     */     } 
/* 230 */     if (mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && mc.field_71439_g.field_71071_by.field_70461_c != InventoryUtil.findHotbarBlock((this.currentMode == Mode.WEBS) ? BlockWeb.class : BlockObsidian.class)) {
/* 231 */       this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */     }
/* 233 */     switchItem(true);
/* 234 */     if (!((Boolean)this.freecam.getValue()).booleanValue() && Phobos.moduleManager.isModuleEnabled(Freecam.class)) {
/* 235 */       return true;
/*     */     }
/* 237 */     this.blocksThisTick = 0;
/* 238 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 239 */     if (this.retryTimer.passedMs(2000L)) {
/* 240 */       this.retries.clear();
/* 241 */       this.retryTimer.reset();
/*     */     } 
/* 243 */     int targetSlot = -1;
/* 244 */     switch (this.currentMode) {
/*     */       case WEBS:
/* 246 */         this.hasOffhand = InventoryUtil.isBlock(mc.field_71439_g.func_184592_cb().func_77973_b(), BlockWeb.class);
/* 247 */         targetSlot = InventoryUtil.findHotbarBlock(BlockWeb.class);
/*     */         break;
/*     */       
/*     */       case OBSIDIAN:
/* 251 */         this.hasOffhand = InventoryUtil.isBlock(mc.field_71439_g.func_184592_cb().func_77973_b(), BlockObsidian.class);
/* 252 */         targetSlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/*     */         break;
/*     */     } 
/*     */     
/* 256 */     if (((Boolean)this.onlySafe.getValue()).booleanValue() && !EntityUtil.isSafe((Entity)mc.field_71439_g)) {
/* 257 */       disable();
/* 258 */       return true;
/*     */     } 
/* 260 */     if (!this.hasOffhand && targetSlot == -1 && (!((Boolean)this.offhand.getValue()).booleanValue() || (!EntityUtil.isSafe((Entity)mc.field_71439_g) && ((Boolean)this.onlySafe.getValue()).booleanValue()))) {
/* 261 */       return true;
/*     */     }
/* 263 */     if (((Boolean)this.offhand.getValue()).booleanValue() && !this.hasOffhand) {
/* 264 */       return true;
/*     */     }
/* 266 */     return !this.timer.passedMs(((Integer)this.delay.getValue()).intValue());
/*     */   }
/*     */   
/*     */   private boolean switchItem(boolean back) {
/* 270 */     if (((Boolean)this.offhand.getValue()).booleanValue()) {
/* 271 */       return true;
/*     */     }
/* 273 */     boolean[] value = InventoryUtil.switchItem(back, this.lastHotbarSlot, this.switchedItem, (InventoryUtil.Switch)this.switchMode.getValue(), (this.currentMode == Mode.WEBS) ? BlockWeb.class : BlockObsidian.class);
/* 274 */     this.switchedItem = value[0];
/* 275 */     return value[1];
/*     */   }
/*     */   
/*     */   public enum Mode {
/* 279 */     WEBS,
/* 280 */     OBSIDIAN;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\combat\Selftrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */