/*     */ package me.earth.phobos.features.modules.combat;
/*     */ import com.google.common.util.concurrent.AtomicDouble;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import me.earth.phobos.event.events.PacketEvent;
/*     */ import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.BlockUtil;
/*     */ import me.earth.phobos.util.DamageUtil;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.MathUtil;
/*     */ import me.earth.phobos.util.RotationUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.tileentity.TileEntityBed;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class BedBomb extends Module {
/*  34 */   private final Setting<Boolean> place = register(new Setting("Place", Boolean.valueOf(false)));
/*  35 */   private final Setting<Integer> placeDelay = register(new Setting("Placedelay", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(500), v -> ((Boolean)this.place.getValue()).booleanValue()));
/*  36 */   private final Setting<Float> placeRange = register(new Setting("PlaceRange", Float.valueOf(6.0F), Float.valueOf(1.0F), Float.valueOf(10.0F), v -> ((Boolean)this.place.getValue()).booleanValue()));
/*  37 */   private final Setting<Boolean> extraPacket = register(new Setting("InsanePacket", Boolean.valueOf(false), v -> ((Boolean)this.place.getValue()).booleanValue()));
/*  38 */   private final Setting<Boolean> packet = register(new Setting("Packet", Boolean.valueOf(false), v -> ((Boolean)this.place.getValue()).booleanValue()));
/*  39 */   private final Setting<Boolean> explode = register(new Setting("Break", Boolean.valueOf(true)));
/*  40 */   private final Setting<Integer> breakDelay = register(new Setting("Breakdelay", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(500), v -> ((Boolean)this.explode.getValue()).booleanValue()));
/*  41 */   private final Setting<Float> breakRange = register(new Setting("BreakRange", Float.valueOf(6.0F), Float.valueOf(1.0F), Float.valueOf(10.0F), v -> ((Boolean)this.explode.getValue()).booleanValue()));
/*  42 */   private final Setting<Float> minDamage = register(new Setting("MinDamage", Float.valueOf(5.0F), Float.valueOf(1.0F), Float.valueOf(36.0F), v -> ((Boolean)this.explode.getValue()).booleanValue()));
/*  43 */   private final Setting<Float> range = register(new Setting("Range", Float.valueOf(10.0F), Float.valueOf(1.0F), Float.valueOf(12.0F), v -> ((Boolean)this.explode.getValue()).booleanValue()));
/*  44 */   private final Setting<Boolean> suicide = register(new Setting("Suicide", Boolean.valueOf(false), v -> ((Boolean)this.explode.getValue()).booleanValue()));
/*  45 */   private final Setting<Boolean> removeTiles = register(new Setting("RemoveTiles", Boolean.valueOf(false)));
/*  46 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(false)));
/*  47 */   private final Setting<Logic> logic = register(new Setting("Logic", Logic.BREAKPLACE, v -> (((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.explode.getValue()).booleanValue())));
/*  48 */   private final Timer breakTimer = new Timer();
/*  49 */   private final Timer placeTimer = new Timer();
/*  50 */   private final AtomicDouble yaw = new AtomicDouble(-1.0D);
/*  51 */   private final AtomicDouble pitch = new AtomicDouble(-1.0D);
/*  52 */   private final AtomicBoolean shouldRotate = new AtomicBoolean(false);
/*  53 */   private EntityPlayer target = null;
/*     */   private boolean sendRotationPacket = false;
/*  55 */   private BlockPos maxPos = null;
/*  56 */   private int lastHotbarSlot = -1;
/*  57 */   private int bedSlot = -1;
/*     */   
/*     */   public BedBomb() {
/*  60 */     super("BedBomb", "AutoPlace and Break for beds", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacket(PacketEvent.Send event) {
/*  65 */     if (this.shouldRotate.get() && event.getPacket() instanceof CPacketPlayer) {
/*  66 */       CPacketPlayer packet = (CPacketPlayer)event.getPacket();
/*  67 */       packet.field_149476_e = (float)this.yaw.get();
/*  68 */       packet.field_149473_f = (float)this.pitch.get();
/*  69 */       this.shouldRotate.set(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/*  75 */     if (event.getStage() != 0 || fullNullCheck() || (mc.field_71439_g.field_71093_bK != -1 && mc.field_71439_g.field_71093_bK != 1)) {
/*     */       return;
/*     */     }
/*  78 */     doBedBomb();
/*     */   }
/*     */   
/*     */   private void doBedBomb() {
/*  82 */     switch ((Logic)this.logic.getValue()) {
/*     */       case BREAKPLACE:
/*  84 */         mapBeds();
/*  85 */         breakBeds();
/*  86 */         placeBeds();
/*     */         break;
/*     */       
/*     */       case PLACEBREAK:
/*  90 */         mapBeds();
/*  91 */         placeBeds();
/*  92 */         breakBeds();
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void breakBeds() {
/*  98 */     if (((Boolean)this.explode.getValue()).booleanValue() && this.breakTimer.passedMs(((Integer)this.breakDelay.getValue()).intValue()) && this.maxPos != null) {
/*  99 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/* 100 */       BlockUtil.rightClickBlockLegit(this.maxPos, ((Float)this.range.getValue()).floatValue(), (((Boolean)this.rotate.getValue()).booleanValue() && !((Boolean)this.place.getValue()).booleanValue()), EnumHand.MAIN_HAND, this.yaw, this.pitch, this.shouldRotate, true);
/* 101 */       if (mc.field_71439_g.func_70093_af()) {
/* 102 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
/*     */       }
/* 104 */       this.breakTimer.reset();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void mapBeds() {
/* 109 */     this.maxPos = null;
/* 110 */     float maxDamage = 0.5F;
/* 111 */     if (((Boolean)this.removeTiles.getValue()).booleanValue()) {
/* 112 */       ArrayList<BedData> removedBlocks = new ArrayList<>();
/* 113 */       for (TileEntity tile : mc.field_71441_e.field_147482_g) {
/* 114 */         if (!(tile instanceof TileEntityBed))
/* 115 */           continue;  TileEntityBed bed = (TileEntityBed)tile;
/* 116 */         BedData data = new BedData(tile.func_174877_v(), mc.field_71441_e.func_180495_p(tile.func_174877_v()), bed, bed.func_193050_e());
/* 117 */         removedBlocks.add(data);
/*     */       } 
/* 119 */       for (BedData data : removedBlocks) {
/* 120 */         mc.field_71441_e.func_175698_g(data.getPos());
/*     */       }
/* 122 */       for (BedData data : removedBlocks) {
/*     */         float selfDamage;
/*     */         BlockPos pos;
/* 125 */         if (!data.isHeadPiece() || mc.field_71439_g.func_174818_b(pos = data.getPos()) > MathUtil.square(((Float)this.breakRange.getValue()).floatValue()) || ((selfDamage = DamageUtil.calculateDamage(pos, (Entity)mc.field_71439_g)) + 1.0D >= EntityUtil.getHealth((Entity)mc.field_71439_g) && DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())))
/*     */           continue; 
/* 127 */         for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/*     */           float damage;
/* 129 */           if (player.func_174818_b(pos) >= MathUtil.square(((Float)this.range.getValue()).floatValue()) || !EntityUtil.isValid((Entity)player, (((Float)this.range.getValue()).floatValue() + ((Float)this.breakRange.getValue()).floatValue())) || ((damage = DamageUtil.calculateDamage(pos, (Entity)player)) <= selfDamage && (damage <= ((Float)this.minDamage.getValue()).floatValue() || DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())) && damage <= EntityUtil.getHealth((Entity)player)) || damage <= maxDamage)
/*     */             continue; 
/* 131 */           maxDamage = damage;
/* 132 */           this.maxPos = pos;
/*     */         } 
/*     */       } 
/* 135 */       for (BedData data : removedBlocks) {
/* 136 */         mc.field_71441_e.func_175656_a(data.getPos(), data.getState());
/*     */       }
/*     */     } else {
/* 139 */       for (TileEntity tile : mc.field_71441_e.field_147482_g) {
/*     */         float selfDamage;
/*     */         BlockPos pos;
/*     */         TileEntityBed bed;
/* 143 */         if (!(tile instanceof TileEntityBed) || !(bed = (TileEntityBed)tile).func_193050_e() || mc.field_71439_g.func_174818_b(pos = bed.func_174877_v()) > MathUtil.square(((Float)this.breakRange.getValue()).floatValue()) || ((selfDamage = DamageUtil.calculateDamage(pos, (Entity)mc.field_71439_g)) + 1.0D >= EntityUtil.getHealth((Entity)mc.field_71439_g) && DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())))
/*     */           continue; 
/* 145 */         for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/*     */           float damage;
/* 147 */           if (player.func_174818_b(pos) >= MathUtil.square(((Float)this.range.getValue()).floatValue()) || !EntityUtil.isValid((Entity)player, (((Float)this.range.getValue()).floatValue() + ((Float)this.breakRange.getValue()).floatValue())) || ((damage = DamageUtil.calculateDamage(pos, (Entity)player)) <= selfDamage && (damage <= ((Float)this.minDamage.getValue()).floatValue() || DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())) && damage <= EntityUtil.getHealth((Entity)player)) || damage <= maxDamage)
/*     */             continue; 
/* 149 */           maxDamage = damage;
/* 150 */           this.maxPos = pos;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void placeBeds() {
/* 157 */     if (((Boolean)this.place.getValue()).booleanValue() && this.placeTimer.passedMs(((Integer)this.placeDelay.getValue()).intValue()) && this.maxPos == null) {
/* 158 */       this.bedSlot = findBedSlot();
/* 159 */       if (this.bedSlot == -1) {
/* 160 */         if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151104_aV) {
/* 161 */           this.bedSlot = -2;
/*     */         } else {
/*     */           return;
/*     */         } 
/*     */       }
/* 166 */       this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/* 167 */       this.target = EntityUtil.getClosestEnemy(((Float)this.placeRange.getValue()).floatValue());
/* 168 */       if (this.target != null) {
/* 169 */         BlockPos targetPos = new BlockPos(this.target.func_174791_d());
/* 170 */         placeBed(targetPos, true);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void placeBed(BlockPos pos, boolean firstCheck) {
/* 176 */     if (mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150324_C) {
/*     */       return;
/*     */     }
/* 179 */     float damage = DamageUtil.calculateDamage(pos, (Entity)mc.field_71439_g);
/* 180 */     if (damage > EntityUtil.getHealth((Entity)mc.field_71439_g) + 0.5D) {
/* 181 */       if (firstCheck) {
/* 182 */         placeBed(pos.func_177984_a(), false);
/*     */       }
/*     */       return;
/*     */     } 
/* 186 */     if (!mc.field_71441_e.func_180495_p(pos).func_185904_a().func_76222_j()) {
/* 187 */       if (firstCheck) {
/* 188 */         placeBed(pos.func_177984_a(), false);
/*     */       }
/*     */       return;
/*     */     } 
/* 192 */     ArrayList<BlockPos> positions = new ArrayList<>();
/* 193 */     HashMap<BlockPos, EnumFacing> facings = new HashMap<>();
/* 194 */     for (EnumFacing facing : EnumFacing.values()) {
/*     */       BlockPos position;
/* 196 */       if (facing != EnumFacing.DOWN && facing != EnumFacing.UP && mc.field_71439_g.func_174818_b(position = pos.func_177972_a(facing)) <= MathUtil.square(((Float)this.placeRange.getValue()).floatValue()) && mc.field_71441_e.func_180495_p(position).func_185904_a().func_76222_j() && !mc.field_71441_e.func_180495_p(position.func_177977_b()).func_185904_a().func_76222_j()) {
/*     */         
/* 198 */         positions.add(position);
/* 199 */         facings.put(position, facing.func_176734_d());
/*     */       } 
/* 201 */     }  if (positions.isEmpty()) {
/* 202 */       if (firstCheck) {
/* 203 */         placeBed(pos.func_177984_a(), false);
/*     */       }
/*     */       return;
/*     */     } 
/* 207 */     positions.sort(Comparator.comparingDouble(pos2 -> mc.field_71439_g.func_174818_b(pos2)));
/* 208 */     BlockPos finalPos = positions.get(0);
/* 209 */     EnumFacing finalFacing = facings.get(finalPos);
/* 210 */     float[] rotation = RotationUtil.simpleFacing(finalFacing);
/* 211 */     if (!this.sendRotationPacket && ((Boolean)this.extraPacket.getValue()).booleanValue()) {
/* 212 */       RotationUtil.faceYawAndPitch(rotation[0], rotation[1]);
/* 213 */       this.sendRotationPacket = true;
/*     */     } 
/* 215 */     this.yaw.set(rotation[0]);
/* 216 */     this.pitch.set(rotation[1]);
/* 217 */     this.shouldRotate.set(true);
/* 218 */     Vec3d hitVec = (new Vec3d((Vec3i)finalPos.func_177977_b())).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(finalFacing.func_176734_d().func_176730_m())).func_186678_a(0.5D));
/* 219 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
/* 220 */     InventoryUtil.switchToHotbarSlot(this.bedSlot, false);
/* 221 */     BlockUtil.rightClickBlock(finalPos.func_177977_b(), hitVec, (this.bedSlot == -2) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, EnumFacing.UP, ((Boolean)this.packet.getValue()).booleanValue());
/* 222 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/* 223 */     this.placeTimer.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/* 228 */     if (this.target != null) {
/* 229 */       return this.target.func_70005_c_();
/*     */     }
/* 231 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onToggle() {
/* 236 */     this.lastHotbarSlot = -1;
/* 237 */     this.bedSlot = -1;
/* 238 */     this.sendRotationPacket = false;
/* 239 */     this.target = null;
/* 240 */     this.yaw.set(-1.0D);
/* 241 */     this.pitch.set(-1.0D);
/* 242 */     this.shouldRotate.set(false);
/*     */   }
/*     */   
/*     */   private int findBedSlot() {
/* 246 */     for (int i = 0; i < 9; ) {
/* 247 */       ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
/* 248 */       if (stack == ItemStack.field_190927_a || stack.func_77973_b() != Items.field_151104_aV) { i++; continue; }
/* 249 */        return i;
/*     */     } 
/* 251 */     return -1;
/*     */   }
/*     */   
/*     */   public enum Logic {
/* 255 */     BREAKPLACE,
/* 256 */     PLACEBREAK;
/*     */   }
/*     */   
/*     */   public static class BedData
/*     */   {
/*     */     private final BlockPos pos;
/*     */     private final IBlockState state;
/*     */     private final boolean isHeadPiece;
/*     */     private final TileEntityBed entity;
/*     */     
/*     */     public BedData(BlockPos pos, IBlockState state, TileEntityBed bed, boolean isHeadPiece) {
/* 267 */       this.pos = pos;
/* 268 */       this.state = state;
/* 269 */       this.entity = bed;
/* 270 */       this.isHeadPiece = isHeadPiece;
/*     */     }
/*     */     
/*     */     public BlockPos getPos() {
/* 274 */       return this.pos;
/*     */     }
/*     */     
/*     */     public IBlockState getState() {
/* 278 */       return this.state;
/*     */     }
/*     */     
/*     */     public boolean isHeadPiece() {
/* 282 */       return this.isHeadPiece;
/*     */     }
/*     */     
/*     */     public TileEntityBed getEntity() {
/* 286 */       return this.entity;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\combat\BedBomb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */