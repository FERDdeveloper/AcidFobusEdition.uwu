/*     */ package me.earth.phobos.features.modules.combat;
/*     */ import java.util.ArrayList;
/*     */ import me.earth.phobos.event.events.PacketEvent;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.BlockUtil;
/*     */ import me.earth.phobos.util.DamageUtil;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.MathUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class AntiCrystal extends Module {
/*  21 */   private final List<BlockPos> targets = new ArrayList<>();
/*  22 */   private final Timer timer = new Timer();
/*  23 */   private final Timer breakTimer = new Timer();
/*  24 */   private final Timer checkTimer = new Timer();
/*  25 */   public Setting<Float> range = register(new Setting("Range", Float.valueOf(6.0F), Float.valueOf(0.0F), Float.valueOf(10.0F)));
/*  26 */   public Setting<Float> wallsRange = register(new Setting("WallsRange", Float.valueOf(3.5F), Float.valueOf(0.0F), Float.valueOf(10.0F)));
/*  27 */   public Setting<Float> minDmg = register(new Setting("MinDmg", Float.valueOf(6.0F), Float.valueOf(0.0F), Float.valueOf(100.0F)));
/*  28 */   public Setting<Float> selfDmg = register(new Setting("SelfDmg", Float.valueOf(2.0F), Float.valueOf(0.0F), Float.valueOf(10.0F)));
/*  29 */   public Setting<Integer> placeDelay = register(new Setting("PlaceDelay", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(500)));
/*  30 */   public Setting<Integer> breakDelay = register(new Setting("BreakDelay", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(500)));
/*  31 */   public Setting<Integer> checkDelay = register(new Setting("CheckDelay", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(500)));
/*  32 */   public Setting<Integer> wasteAmount = register(new Setting("WasteAmount", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(5)));
/*  33 */   public Setting<Boolean> switcher = register(new Setting("Switch", Boolean.valueOf(true)));
/*  34 */   public Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  35 */   public Setting<Boolean> packet = register(new Setting("Packet", Boolean.valueOf(true)));
/*  36 */   public Setting<Integer> rotations = register(new Setting("Spoofs", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(20)));
/*  37 */   private float yaw = 0.0F;
/*  38 */   private float pitch = 0.0F;
/*     */   private boolean rotating = false;
/*  40 */   private int rotationPacketsSpoofed = 0;
/*     */   private Entity breakTarget;
/*     */   
/*     */   public AntiCrystal() {
/*  44 */     super("AntiCrystal", "Hacker shit", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onToggle() {
/*  49 */     this.rotating = false;
/*     */   }
/*     */   
/*     */   private Entity getDeadlyCrystal() {
/*  53 */     Entity bestcrystal = null;
/*  54 */     float highestDamage = 0.0F;
/*  55 */     for (Entity crystal : mc.field_71441_e.field_72996_f) {
/*     */       float damage;
/*  57 */       if (!(crystal instanceof net.minecraft.entity.item.EntityEnderCrystal) || mc.field_71439_g.func_70068_e(crystal) > 169.0D || (damage = DamageUtil.calculateDamage(crystal, (Entity)mc.field_71439_g)) < ((Float)this.minDmg.getValue()).floatValue())
/*     */         continue; 
/*  59 */       if (bestcrystal == null) {
/*  60 */         bestcrystal = crystal;
/*  61 */         highestDamage = damage;
/*     */         continue;
/*     */       } 
/*  64 */       if (damage <= highestDamage)
/*  65 */         continue;  bestcrystal = crystal;
/*  66 */       highestDamage = damage;
/*     */     } 
/*  68 */     return bestcrystal;
/*     */   }
/*     */   
/*     */   private int getSafetyCrystals(Entity deadlyCrystal) {
/*  72 */     int count = 0;
/*  73 */     for (Entity entity : mc.field_71441_e.field_72996_f) {
/*     */       float damage;
/*  75 */       if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal || (damage = DamageUtil.calculateDamage(entity, (Entity)mc.field_71439_g)) > 2.0F || deadlyCrystal.func_70068_e(entity) > 144.0D)
/*     */         continue; 
/*  77 */       count++;
/*     */     } 
/*  79 */     return count;
/*     */   }
/*     */   
/*     */   private BlockPos getPlaceTarget(Entity deadlyCrystal) {
/*  83 */     BlockPos closestPos = null;
/*  84 */     float smallestDamage = 10.0F;
/*  85 */     for (BlockPos pos : BlockUtil.possiblePlacePositions(((Float)this.range.getValue()).floatValue())) {
/*  86 */       float damage = DamageUtil.calculateDamage(pos, (Entity)mc.field_71439_g);
/*  87 */       if (damage > 2.0F || deadlyCrystal.func_174818_b(pos) > 144.0D || (mc.field_71439_g.func_174818_b(pos) >= MathUtil.square(((Float)this.wallsRange.getValue()).floatValue()) && BlockUtil.rayTracePlaceCheck(pos, true, 1.0F)))
/*     */         continue; 
/*  89 */       if (closestPos == null) {
/*  90 */         smallestDamage = damage;
/*  91 */         closestPos = pos;
/*     */         continue;
/*     */       } 
/*  94 */       if (damage >= smallestDamage && (damage != smallestDamage || mc.field_71439_g.func_174818_b(pos) >= mc.field_71439_g.func_174818_b(closestPos)))
/*     */         continue; 
/*  96 */       smallestDamage = damage;
/*  97 */       closestPos = pos;
/*     */     } 
/*  99 */     return closestPos;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.Send event) {
/* 104 */     if (event.getStage() == 0 && ((Boolean)this.rotate.getValue()).booleanValue() && this.rotating) {
/* 105 */       if (event.getPacket() instanceof CPacketPlayer) {
/* 106 */         CPacketPlayer packet = (CPacketPlayer)event.getPacket();
/* 107 */         packet.field_149476_e = this.yaw;
/* 108 */         packet.field_149473_f = this.pitch;
/*     */       } 
/* 110 */       this.rotationPacketsSpoofed++;
/* 111 */       if (this.rotationPacketsSpoofed >= ((Integer)this.rotations.getValue()).intValue()) {
/* 112 */         this.rotating = false;
/* 113 */         this.rotationPacketsSpoofed = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/* 120 */     if (!fullNullCheck() && this.checkTimer.passedMs(((Integer)this.checkDelay.getValue()).intValue())) {
/* 121 */       Entity deadlyCrystal = getDeadlyCrystal();
/* 122 */       if (deadlyCrystal != null) {
/* 123 */         BlockPos placeTarget = getPlaceTarget(deadlyCrystal);
/* 124 */         if (placeTarget != null) {
/* 125 */           this.targets.add(placeTarget);
/*     */         }
/* 127 */         placeCrystal(deadlyCrystal);
/* 128 */         this.breakTarget = getBreakTarget(deadlyCrystal);
/* 129 */         breakCrystal();
/*     */       } 
/* 131 */       this.checkTimer.reset();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Entity getBreakTarget(Entity deadlyCrystal) {
/* 136 */     Entity smallestCrystal = null;
/* 137 */     float smallestDamage = 10.0F;
/* 138 */     for (Entity entity : mc.field_71441_e.field_72996_f) {
/*     */       float damage;
/* 140 */       if (!(entity instanceof net.minecraft.entity.item.EntityEnderCrystal) || (damage = DamageUtil.calculateDamage(entity, (Entity)mc.field_71439_g)) > ((Float)this.selfDmg.getValue()).floatValue() || entity.func_70068_e(deadlyCrystal) > 144.0D || (mc.field_71439_g.func_70068_e(entity) > MathUtil.square(((Float)this.wallsRange.getValue()).floatValue()) && EntityUtil.rayTraceHitCheck(entity, true)))
/*     */         continue; 
/* 142 */       if (smallestCrystal == null) {
/* 143 */         smallestCrystal = entity;
/* 144 */         smallestDamage = damage;
/*     */         continue;
/*     */       } 
/* 147 */       if (damage >= smallestDamage && (smallestDamage != damage || mc.field_71439_g.func_70068_e(entity) >= mc.field_71439_g.func_70068_e(smallestCrystal)))
/*     */         continue; 
/* 149 */       smallestCrystal = entity;
/* 150 */       smallestDamage = damage;
/*     */     } 
/* 152 */     return smallestCrystal;
/*     */   }
/*     */ 
/*     */   
/*     */   private void placeCrystal(Entity deadlyCrystal) {
/* 157 */     boolean offhand = (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP), bl = offhand;
/* 158 */     if (this.timer.passedMs(((Integer)this.placeDelay.getValue()).intValue()) && (((Boolean)this.switcher.getValue()).booleanValue() || mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP || offhand) && !this.targets.isEmpty() && getSafetyCrystals(deadlyCrystal) <= ((Integer)this.wasteAmount.getValue()).intValue()) {
/* 159 */       if (((Boolean)this.switcher.getValue()).booleanValue() && mc.field_71439_g.func_184614_ca().func_77973_b() != Items.field_185158_cP && !offhand) {
/* 160 */         doSwitch();
/*     */       }
/* 162 */       rotateToPos(this.targets.get(this.targets.size() - 1));
/* 163 */       BlockUtil.placeCrystalOnBlock(this.targets.get(this.targets.size() - 1), offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, true, true);
/* 164 */       this.timer.reset();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void doSwitch() {
/* 170 */     int crystalSlot = (mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP) ? mc.field_71439_g.field_71071_by.field_70461_c : -1, n = crystalSlot;
/* 171 */     if (crystalSlot == -1) {
/* 172 */       for (int l = 0; l < 9; ) {
/* 173 */         if (mc.field_71439_g.field_71071_by.func_70301_a(l).func_77973_b() != Items.field_185158_cP) { l++; continue; }
/* 174 */          crystalSlot = l;
/*     */       } 
/*     */     }
/*     */     
/* 178 */     if (crystalSlot != -1) {
/* 179 */       mc.field_71439_g.field_71071_by.field_70461_c = crystalSlot;
/*     */     }
/*     */   }
/*     */   
/*     */   private void breakCrystal() {
/* 184 */     if (this.breakTimer.passedMs(((Integer)this.breakDelay.getValue()).intValue()) && this.breakTarget != null && DamageUtil.canBreakWeakness((EntityPlayer)mc.field_71439_g)) {
/* 185 */       rotateTo(this.breakTarget);
/* 186 */       EntityUtil.attackEntity(this.breakTarget, ((Boolean)this.packet.getValue()).booleanValue(), true);
/* 187 */       this.breakTimer.reset();
/* 188 */       this.targets.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void rotateTo(Entity entity) {
/* 193 */     if (((Boolean)this.rotate.getValue()).booleanValue()) {
/* 194 */       float[] angle = MathUtil.calcAngle(mc.field_71439_g.func_174824_e(mc.func_184121_ak()), entity.func_174791_d());
/* 195 */       this.yaw = angle[0];
/* 196 */       this.pitch = angle[1];
/* 197 */       this.rotating = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void rotateToPos(BlockPos pos) {
/* 202 */     if (((Boolean)this.rotate.getValue()).booleanValue()) {
/* 203 */       float[] angle = MathUtil.calcAngle(mc.field_71439_g.func_174824_e(mc.func_184121_ak()), new Vec3d((pos.func_177958_n() + 0.5F), (pos.func_177956_o() - 0.5F), (pos.func_177952_p() + 0.5F)));
/* 204 */       this.yaw = angle[0];
/* 205 */       this.pitch = angle[1];
/* 206 */       this.rotating = true;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\combat\AntiCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */