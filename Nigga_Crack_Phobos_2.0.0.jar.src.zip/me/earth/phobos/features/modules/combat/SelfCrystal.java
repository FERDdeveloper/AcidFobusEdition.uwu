/*    */ package me.earth.phobos.features.modules.combat;
/*    */ 
/*    */ import me.earth.phobos.features.modules.Module;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class SelfCrystal extends Module {
/*    */   public SelfCrystal() {
/*  8 */     super("SelfCrystal", "Best module", Module.Category.COMBAT, true, false, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onTick() {
/* 13 */     if (AutoCrystal.getInstance().isEnabled())
/* 14 */       AutoCrystal.target = (EntityPlayer)mc.field_71439_g; 
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\combat\SelfCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */