/*    */ package me.earth.phobos.features.modules.client;
/*    */ 
/*    */ import me.earth.phobos.Phobos;
/*    */ import me.earth.phobos.event.events.ClientEvent;
/*    */ import me.earth.phobos.features.modules.Module;
/*    */ import me.earth.phobos.features.setting.Setting;
/*    */ import me.earth.phobos.util.TextUtil;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class Managers
/*    */   extends Module {
/* 12 */   private static Managers INSTANCE = new Managers();
/* 13 */   public Setting<Boolean> betterFrames = register(new Setting("BetterMaxFPS", Boolean.valueOf(false)));
/* 14 */   public Setting<String> commandBracket = register(new Setting("Bracket", "["));
/* 15 */   public Setting<String> commandBracket2 = register(new Setting("Bracket2", "]"));
/* 16 */   public Setting<String> command = register(new Setting("Command", "RenoSense"));
/* 17 */   public Setting<TextUtil.Color> bracketColor = register(new Setting("BColor", TextUtil.Color.YELLOW));
/* 18 */   public Setting<TextUtil.Color> commandColor = register(new Setting("CColor", TextUtil.Color.BLACK));
/* 19 */   public Setting<Integer> betterFPS = register(new Setting("MaxFPS", Integer.valueOf(300), Integer.valueOf(30), Integer.valueOf(1000), v -> ((Boolean)this.betterFrames.getValue()).booleanValue()));
/* 20 */   public Setting<Boolean> potions = register(new Setting("Potions", Boolean.valueOf(true)));
/* 21 */   public Setting<Integer> textRadarUpdates = register(new Setting("TRUpdates", Integer.valueOf(500), Integer.valueOf(0), Integer.valueOf(1000)));
/* 22 */   public Setting<Integer> respondTime = register(new Setting("SeverTime", Integer.valueOf(500), Integer.valueOf(0), Integer.valueOf(1000)));
/* 23 */   public Setting<Integer> moduleListUpdates = register(new Setting("ALUpdates", Integer.valueOf(1000), Integer.valueOf(0), Integer.valueOf(1000)));
/* 24 */   public Setting<Float> holeRange = register(new Setting("HoleRange", Float.valueOf(6.0F), Float.valueOf(1.0F), Float.valueOf(256.0F)));
/* 25 */   public Setting<Integer> holeUpdates = register(new Setting("HoleUpdates", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(1000)));
/* 26 */   public Setting<Integer> holeSync = register(new Setting("HoleSync", Integer.valueOf(10000), Integer.valueOf(1), Integer.valueOf(10000)));
/* 27 */   public Setting<Boolean> safety = register(new Setting("SafetyPlayer", Boolean.valueOf(false)));
/* 28 */   public Setting<Integer> safetyCheck = register(new Setting("SafetyCheck", Integer.valueOf(50), Integer.valueOf(1), Integer.valueOf(150)));
/* 29 */   public Setting<Integer> safetySync = register(new Setting("SafetySync", Integer.valueOf(250), Integer.valueOf(1), Integer.valueOf(10000)));
/* 30 */   public Setting<ThreadMode> holeThread = register(new Setting("HoleThread", ThreadMode.WHILE));
/* 31 */   public Setting<Boolean> speed = register(new Setting("Speed", Boolean.valueOf(true)));
/* 32 */   public Setting<Boolean> oneDot15 = register(new Setting("1.15", Boolean.valueOf(false)));
/* 33 */   public Setting<Boolean> tRadarInv = register(new Setting("TRadarInv", Boolean.valueOf(true)));
/* 34 */   public Setting<Boolean> unfocusedCpu = register(new Setting("UnfocusedCPU", Boolean.valueOf(false)));
/* 35 */   public Setting<Integer> cpuFPS = register(new Setting("UnfocusedFPS", Integer.valueOf(60), Integer.valueOf(1), Integer.valueOf(60), v -> ((Boolean)this.unfocusedCpu.getValue()).booleanValue()));
/* 36 */   public Setting<Integer> baritoneTimeOut = register(new Setting("Baritone", Integer.valueOf(5), Integer.valueOf(1), Integer.valueOf(20)));
/* 37 */   public Setting<Boolean> oneChunk = register(new Setting("OneChunk", Boolean.valueOf(false)));
/*    */   
/*    */   public Managers() {
/* 40 */     super("Management", "ClientManagement", Module.Category.CLIENT, false, false, true);
/* 41 */     setInstance();
/*    */   }
/*    */   
/*    */   public static Managers getInstance() {
/* 45 */     if (INSTANCE == null) {
/* 46 */       INSTANCE = new Managers();
/*    */     }
/* 48 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 52 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onLoad() {
/* 57 */     Phobos.commandManager.setClientMessage(getCommandMessage());
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onSettingChange(ClientEvent event) {
/* 62 */     if (event.getStage() == 2) {
/* 63 */       if (((Boolean)this.oneChunk.getPlannedValue()).booleanValue()) {
/* 64 */         mc.field_71474_y.field_151451_c = 1;
/*    */       }
/* 66 */       if (event.getSetting() != null && equals(event.getSetting().getFeature())) {
/* 67 */         if (event.getSetting().equals(this.holeThread)) {
/* 68 */           Phobos.holeManager.settingChanged();
/*    */         }
/* 70 */         Phobos.commandManager.setClientMessage(getCommandMessage());
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getCommandMessage() {
/* 76 */     return TextUtil.coloredString((String)this.commandBracket.getPlannedValue(), (TextUtil.Color)this.bracketColor.getPlannedValue()) + TextUtil.coloredString((String)this.command.getPlannedValue(), (TextUtil.Color)this.commandColor.getPlannedValue()) + TextUtil.coloredString((String)this.commandBracket2.getPlannedValue(), (TextUtil.Color)this.bracketColor.getPlannedValue());
/*    */   }
/*    */   
/*    */   public String getRawCommandMessage() {
/* 80 */     return (String)this.commandBracket.getValue() + (String)this.command.getValue() + (String)this.commandBracket2.getValue();
/*    */   }
/*    */   
/*    */   public enum ThreadMode {
/* 84 */     POOL,
/* 85 */     WHILE,
/* 86 */     NONE;
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\client\Managers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */