/*     */ package me.earth.phobos.features.modules.client;
/*     */ import java.awt.Color;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.ClientEvent;
/*     */ import me.earth.phobos.event.events.Render2DEvent;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.modules.misc.ToolTips;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.util.ColorUtil;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.MathUtil;
/*     */ import me.earth.phobos.util.RenderUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.SoundEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class HUD extends Module {
/*  31 */   private static final ResourceLocation box = new ResourceLocation("textures/gui/container/shulker_box.png");
/*  32 */   private static final ItemStack totem = new ItemStack(Items.field_190929_cY);
/*  33 */   private static final ResourceLocation codHitmarker = new ResourceLocation("earthhack", "cod_hitmarker");
/*  34 */   public static final SoundEvent COD_EVENT = new SoundEvent(codHitmarker);
/*  35 */   private static final ResourceLocation csgoHitmarker = new ResourceLocation("earthhack", "csgo_hitmarker");
/*  36 */   public static final SoundEvent CSGO_EVENT = new SoundEvent(csgoHitmarker);
/*  37 */   private static HUD INSTANCE = new HUD();
/*  38 */   private final Setting<Boolean> renderingUp = register(new Setting("RenderingUp", Boolean.valueOf(false), "Orientation of the HUD-Elements."));
/*  39 */   private final Setting<WaterMark> watermark = register(new Setting("Logo", WaterMark.NONE, "WaterMark"));
/*  40 */   private final Setting<String> customWatermark = register(new Setting("WatermarkName", "RenoSense"));
/*  41 */   private final Setting<Boolean> modeVer = register(new Setting("Version", Boolean.valueOf(false), v -> (this.watermark.getValue() != WaterMark.NONE)));
/*  42 */   private final Setting<Boolean> arrayList = register(new Setting("ActiveModules", Boolean.valueOf(false), "Lists the active modules."));
/*  43 */   private final Setting<Boolean> moduleColors = register(new Setting("ModuleColors", Boolean.valueOf(false), v -> ((Boolean)this.arrayList.getValue()).booleanValue()));
/*  44 */   private final Setting<Boolean> alphabeticalSorting = register(new Setting("AlphabeticalSorting", Boolean.valueOf(false), v -> ((Boolean)this.arrayList.getValue()).booleanValue()));
/*  45 */   private final Setting<Boolean> serverBrand = register(new Setting("ServerBrand", Boolean.valueOf(false), "Brand of the server you are on."));
/*  46 */   private final Setting<Boolean> ping = register(new Setting("Ping", Boolean.valueOf(false), "Your response time to the server."));
/*  47 */   private final Setting<Boolean> tps = register(new Setting("TPS", Boolean.valueOf(false), "Ticks per second of the server."));
/*  48 */   private final Setting<Boolean> fps = register(new Setting("FPS", Boolean.valueOf(false), "Your frames per second."));
/*  49 */   private final Setting<Boolean> coords = register(new Setting("Coords", Boolean.valueOf(false), "Your current coordinates"));
/*  50 */   private final Setting<Boolean> direction = register(new Setting("Direction", Boolean.valueOf(false), "The Direction you are facing."));
/*  51 */   private final Setting<Boolean> speed = register(new Setting("Speed", Boolean.valueOf(false), "Your Speed"));
/*  52 */   private final Setting<Boolean> potions = register(new Setting("Potions", Boolean.valueOf(false), "Active potion effects"));
/*  53 */   private final Setting<Boolean> altPotionsColors = register(new Setting("AltPotionColors", Boolean.valueOf(false), v -> ((Boolean)this.potions.getValue()).booleanValue()));
/*  54 */   private final Setting<Boolean> armor = register(new Setting("Armor", Boolean.valueOf(false), "ArmorHUD"));
/*  55 */   private final Setting<Boolean> durability = register(new Setting("Durability", Boolean.valueOf(false), "Durability"));
/*  56 */   private final Setting<Boolean> percent = register(new Setting("Percent", Boolean.valueOf(true), v -> ((Boolean)this.armor.getValue()).booleanValue()));
/*  57 */   private final Setting<Boolean> totems = register(new Setting("Totems", Boolean.valueOf(false), "TotemHUD"));
/*  58 */   private final Setting<Boolean> queue = register(new Setting("2b2tQueue", Boolean.valueOf(false), "Shows the 2b2t queue."));
/*  59 */   private final Setting<Greeter> greeter = register(new Setting("Greeter", Greeter.NONE, "Greets you."));
/*  60 */   private final Setting<String> spoofGreeter = register(new Setting("GreeterName", "3arthqu4ke", v -> (this.greeter.getValue() == Greeter.CUSTOM)));
/*  61 */   private final Setting<LagNotify> lag = register(new Setting("Lag", LagNotify.GRAY, "Lag Notifier"));
/*  62 */   private final Setting<Boolean> hitMarkers = register(new Setting("HitMarkers", Boolean.valueOf(true)));
/*  63 */   private final Setting<Sound> sound = register(new Setting("Sound", Sound.NONE, v -> ((Boolean)this.hitMarkers.getValue()).booleanValue()));
/*  64 */   private final Setting<Boolean> grayNess = register(new Setting("FutureColour", Boolean.valueOf(true)));
/*  65 */   private final Timer timer = new Timer();
/*  66 */   private final Timer moduleTimer = new Timer();
/*  67 */   public Setting<Boolean> colorSync = register(new Setting("Sync", Boolean.valueOf(false), "Universal colors for hud."));
/*  68 */   public Setting<Boolean> rainbow = register(new Setting("Rainbow", Boolean.valueOf(false), "Rainbow hud."));
/*  69 */   public Setting<Integer> factor = register(new Setting("Factor", Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(20), v -> ((Boolean)this.rainbow.getValue()).booleanValue()));
/*  70 */   public Setting<Boolean> rolling = register(new Setting("Rolling", Boolean.valueOf(false), v -> ((Boolean)this.rainbow.getValue()).booleanValue()));
/*  71 */   public Setting<Boolean> staticRainbow = register(new Setting("Static", Boolean.valueOf(false), v -> ((Boolean)this.rainbow.getValue()).booleanValue()));
/*  72 */   public Setting<Integer> rainbowSpeed = register(new Setting("RSpeed", Integer.valueOf(20), Integer.valueOf(0), Integer.valueOf(100), v -> ((Boolean)this.rainbow.getValue()).booleanValue()));
/*  73 */   public Setting<Integer> rainbowSaturation = register(new Setting("Saturation", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.rainbow.getValue()).booleanValue()));
/*  74 */   public Setting<Integer> rainbowBrightness = register(new Setting("Brightness", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.rainbow.getValue()).booleanValue()));
/*  75 */   public Setting<Boolean> potionIcons = register(new Setting("PotionIcons", Boolean.valueOf(true), "Draws Potion Icons."));
/*  76 */   public Setting<Boolean> shadow = register(new Setting("Shadow", Boolean.valueOf(false), "Draws the text with a shadow."));
/*  77 */   public Setting<Integer> animationHorizontalTime = register(new Setting("AnimationHTime", Integer.valueOf(500), Integer.valueOf(1), Integer.valueOf(1000), v -> ((Boolean)this.arrayList.getValue()).booleanValue()));
/*  78 */   public Setting<Integer> animationVerticalTime = register(new Setting("AnimationVTime", Integer.valueOf(50), Integer.valueOf(1), Integer.valueOf(500), v -> ((Boolean)this.arrayList.getValue()).booleanValue()));
/*  79 */   public Setting<Boolean> textRadar = register(new Setting("TextRadar", Boolean.valueOf(false), "A TextRadar"));
/*  80 */   public Setting<Boolean> time = register(new Setting("Time", Boolean.valueOf(false), "The time"));
/*  81 */   public Setting<Integer> hudRed = register(new Setting("Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> !((Boolean)this.rainbow.getValue()).booleanValue()));
/*  82 */   public Setting<Integer> hudGreen = register(new Setting("Green", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> !((Boolean)this.rainbow.getValue()).booleanValue()));
/*  83 */   public Setting<Integer> hudBlue = register(new Setting("Blue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> !((Boolean)this.rainbow.getValue()).booleanValue()));
/*  84 */   public Setting<Boolean> potions1 = register(new Setting("LevelPotions", Boolean.valueOf(false), v -> ((Boolean)this.potions.getValue()).booleanValue()));
/*  85 */   public Setting<Boolean> MS = register(new Setting("ms", Boolean.valueOf(false), v -> ((Boolean)this.ping.getValue()).booleanValue()));
/*  86 */   public Map<Module, Float> moduleProgressMap = new HashMap<>();
/*  87 */   public Map<Integer, Integer> colorMap = new HashMap<>();
/*  88 */   private Map<String, Integer> players = new HashMap<>();
/*  89 */   private final Map<Potion, Color> potionColorMap = new HashMap<>();
/*     */   private int color;
/*     */   private boolean shouldIncrement;
/*     */   private int hitMarkerTimer;
/*     */   
/*     */   public HUD() {
/*  95 */     super("HUD", "HUD Elements rendered on your screen", Module.Category.CLIENT, true, false, false);
/*  96 */     setInstance();
/*  97 */     this.potionColorMap.put(MobEffects.field_76424_c, new Color(124, 175, 198));
/*  98 */     this.potionColorMap.put(MobEffects.field_76421_d, new Color(90, 108, 129));
/*  99 */     this.potionColorMap.put(MobEffects.field_76422_e, new Color(217, 192, 67));
/* 100 */     this.potionColorMap.put(MobEffects.field_76419_f, new Color(74, 66, 23));
/* 101 */     this.potionColorMap.put(MobEffects.field_76420_g, new Color(147, 36, 35));
/* 102 */     this.potionColorMap.put(MobEffects.field_76432_h, new Color(67, 10, 9));
/* 103 */     this.potionColorMap.put(MobEffects.field_76433_i, new Color(67, 10, 9));
/* 104 */     this.potionColorMap.put(MobEffects.field_76430_j, new Color(34, 255, 76));
/* 105 */     this.potionColorMap.put(MobEffects.field_76431_k, new Color(85, 29, 74));
/* 106 */     this.potionColorMap.put(MobEffects.field_76428_l, new Color(205, 92, 171));
/* 107 */     this.potionColorMap.put(MobEffects.field_76429_m, new Color(153, 69, 58));
/* 108 */     this.potionColorMap.put(MobEffects.field_76426_n, new Color(228, 154, 58));
/* 109 */     this.potionColorMap.put(MobEffects.field_76427_o, new Color(46, 82, 153));
/* 110 */     this.potionColorMap.put(MobEffects.field_76441_p, new Color(127, 131, 146));
/* 111 */     this.potionColorMap.put(MobEffects.field_76440_q, new Color(31, 31, 35));
/* 112 */     this.potionColorMap.put(MobEffects.field_76439_r, new Color(31, 31, 161));
/* 113 */     this.potionColorMap.put(MobEffects.field_76438_s, new Color(88, 118, 83));
/* 114 */     this.potionColorMap.put(MobEffects.field_76437_t, new Color(72, 77, 72));
/* 115 */     this.potionColorMap.put(MobEffects.field_76436_u, new Color(78, 147, 49));
/* 116 */     this.potionColorMap.put(MobEffects.field_82731_v, new Color(53, 42, 39));
/* 117 */     this.potionColorMap.put(MobEffects.field_180152_w, new Color(248, 125, 35));
/* 118 */     this.potionColorMap.put(MobEffects.field_76444_x, new Color(37, 82, 165));
/* 119 */     this.potionColorMap.put(MobEffects.field_76443_y, new Color(248, 36, 35));
/* 120 */     this.potionColorMap.put(MobEffects.field_188423_x, new Color(148, 160, 97));
/* 121 */     this.potionColorMap.put(MobEffects.field_188424_y, new Color(206, 255, 255));
/* 122 */     this.potionColorMap.put(MobEffects.field_188425_z, new Color(51, 153, 0));
/* 123 */     this.potionColorMap.put(MobEffects.field_189112_A, new Color(192, 164, 77));
/*     */   }
/*     */   
/*     */   public static HUD getInstance() {
/* 127 */     if (INSTANCE == null) {
/* 128 */       INSTANCE = new HUD();
/*     */     }
/* 130 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private void setInstance() {
/* 134 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 139 */     for (Module module : Phobos.moduleManager.sortedModules) {
/* 140 */       if (!module.isDisabled() || module.arrayListOffset != 0.0F)
/* 141 */         continue;  module.sliding = true;
/*     */     } 
/* 143 */     if (this.timer.passedMs(((Integer)(Managers.getInstance()).textRadarUpdates.getValue()).intValue())) {
/* 144 */       this.players = getTextRadarPlayers();
/* 145 */       this.timer.reset();
/*     */     } 
/* 147 */     if (this.shouldIncrement) {
/* 148 */       this.hitMarkerTimer++;
/*     */     }
/* 150 */     if (this.hitMarkerTimer == 10) {
/* 151 */       this.hitMarkerTimer = 0;
/* 152 */       this.shouldIncrement = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onModuleToggle(ClientEvent event) {
/* 162 */     if (event.getFeature() instanceof Module) {
/* 163 */       if (event.getStage() != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 172 */         if (event.getStage() == 1)
/* 173 */           for (float i = 0.0F; i <= this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()); i += this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()) / 500.0F) {
/* 174 */             if (this.moduleTimer.passedMs(1L)) {
/* 175 */               this.moduleProgressMap.put((Module)event.getFeature(), Float.valueOf(this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()) - i));
/*     */             }
/* 177 */             this.timer.reset();
/*     */           }  
/*     */         return;
/*     */       } 
/*     */       for (float f = 0.0F; f <= this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()); f += this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()) / 500.0F) {
/*     */         if (this.moduleTimer.passedMs(1L))
/*     */           this.moduleProgressMap.put((Module)event.getFeature(), Float.valueOf(this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()) - f)); 
/*     */         this.timer.reset();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onRender2D(Render2DEvent event) {
/* 190 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/* 193 */     int colorSpeed = 101 - ((Integer)this.rainbowSpeed.getValue()).intValue();
/* 194 */     float hue = ((Boolean)this.colorSync.getValue()).booleanValue() ? Colors.INSTANCE.hue : ((float)(System.currentTimeMillis() % (360 * colorSpeed)) / 360.0F * colorSpeed);
/* 195 */     int width = this.renderer.scaledWidth;
/* 196 */     int height = this.renderer.scaledHeight;
/* 197 */     float tempHue = hue;
/* 198 */     for (int i2 = 0; i2 <= height; i2++) {
/* 199 */       if (((Boolean)this.colorSync.getValue()).booleanValue()) {
/* 200 */         this.colorMap.put(Integer.valueOf(i2), Integer.valueOf(Color.HSBtoRGB(tempHue, ((Integer)Colors.INSTANCE.rainbowSaturation.getValue()).intValue() / 255.0F, ((Integer)Colors.INSTANCE.rainbowBrightness.getValue()).intValue() / 255.0F)));
/*     */       } else {
/* 202 */         this.colorMap.put(Integer.valueOf(i2), Integer.valueOf(Color.HSBtoRGB(tempHue, ((Integer)this.rainbowSaturation.getValue()).intValue() / 255.0F, ((Integer)this.rainbowBrightness.getValue()).intValue() / 255.0F)));
/*     */       } 
/* 204 */       tempHue += 1.0F / height * ((Integer)this.factor.getValue()).intValue();
/*     */     } 
/* 206 */     if (((Boolean)this.rainbow.getValue()).booleanValue() && !((Boolean)this.rolling.getValue()).booleanValue()) {
/* 207 */       this.color = ((Boolean)this.colorSync.getValue()).booleanValue() ? Colors.INSTANCE.getCurrentColorHex() : Color.HSBtoRGB(hue, ((Integer)this.rainbowSaturation.getValue()).intValue() / 255.0F, ((Integer)this.rainbowBrightness.getValue()).intValue() / 255.0F);
/* 208 */     } else if (!((Boolean)this.rainbow.getValue()).booleanValue()) {
/* 209 */       this.color = ((Boolean)this.colorSync.getValue()).booleanValue() ? Colors.INSTANCE.getCurrentColorHex() : ColorUtil.toRGBA(((Integer)this.hudRed.getValue()).intValue(), ((Integer)this.hudGreen.getValue()).intValue(), ((Integer)this.hudBlue.getValue()).intValue());
/*     */     } 
/* 211 */     String grayString = ((Boolean)this.grayNess.getValue()).booleanValue() ? "§7" : "";
/* 212 */     switch ((WaterMark)this.watermark.getValue()) {
/*     */       case TIME:
/* 214 */         this.renderer.drawString("RenoSense" + (((Boolean)this.modeVer.getValue()).booleanValue() ? " v1.6" : ""), 2.0F, 2.0F, (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2))).intValue() : this.color, true);
/*     */         break;
/*     */       
/*     */       case LONG:
/* 218 */         this.renderer.drawString("SkittyHack" + (((Boolean)this.modeVer.getValue()).booleanValue() ? " b1.0" : ""), 2.0F, 2.0F, (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2))).intValue() : this.color, true);
/*     */         break;
/*     */       
/*     */       case CUSTOM:
/* 222 */         this.renderer.drawString((String)this.customWatermark.getValue() + (((Boolean)this.modeVer.getValue()).booleanValue() ? " v1.6" : ""), 2.0F, 2.0F, (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2))).intValue() : this.color, true);
/*     */         break;
/*     */     } 
/* 225 */     if (((Boolean)this.textRadar.getValue()).booleanValue()) {
/* 226 */       drawTextRadar((ToolTips.getInstance().isOff() || !((Boolean)(ToolTips.getInstance()).shulkerSpy.getValue()).booleanValue() || !((Boolean)(ToolTips.getInstance()).render.getValue()).booleanValue()) ? 0 : ToolTips.getInstance().getTextRadarY());
/*     */     }
/* 228 */     int j = ((Boolean)this.renderingUp.getValue()).booleanValue() ? 0 : ((mc.field_71462_r instanceof net.minecraft.client.gui.GuiChat) ? 14 : 0);
/* 229 */     if (((Boolean)this.arrayList.getValue()).booleanValue())
/*     */     {
/*     */       
/* 232 */       if (((Boolean)this.renderingUp.getValue()).booleanValue()) {
/* 233 */         for (int k = 0; k < (((Boolean)this.alphabeticalSorting.getValue()).booleanValue() ? Phobos.moduleManager.alphabeticallySortedModules.size() : Phobos.moduleManager.sortedModules.size()); k++) {
/* 234 */           Module module = ((Boolean)this.alphabeticalSorting.getValue()).booleanValue() ? Phobos.moduleManager.alphabeticallySortedModules.get(k) : Phobos.moduleManager.sortedModules.get(k);
/* 235 */           String text3 = module.getDisplayName() + "§7" + ((module.getDisplayInfo() != null) ? (" [§f" + module.getDisplayInfo() + "§7]") : "");
/* 236 */           Color moduleColor = (Color)Phobos.moduleManager.moduleColorMap.get(module);
/* 237 */           this.renderer.drawString(text3, (width - 2 - this.renderer.getStringWidth(text3)) + ((((Integer)this.animationHorizontalTime.getValue()).intValue() == 1) ? 0.0F : module.arrayListOffset), (2 + j * 10), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(MathUtil.clamp(2 + j * 10, 0, height)))).intValue() : ((((Boolean)this.moduleColors.getValue()).booleanValue() && moduleColor != null) ? moduleColor.getRGB() : this.color), true);
/* 238 */           j++;
/*     */         } 
/*     */       } else {
/* 241 */         for (int k = 0; k < (((Boolean)this.alphabeticalSorting.getValue()).booleanValue() ? Phobos.moduleManager.alphabeticallySortedModules.size() : Phobos.moduleManager.sortedModules.size()); k++) {
/* 242 */           Module module = ((Boolean)this.alphabeticalSorting.getValue()).booleanValue() ? Phobos.moduleManager.alphabeticallySortedModules.get(Phobos.moduleManager.alphabeticallySortedModules.size() - 1 - k) : Phobos.moduleManager.sortedModules.get(k);
/* 243 */           String text3 = module.getDisplayName() + "§7" + ((module.getDisplayInfo() != null) ? (" [§f" + module.getDisplayInfo() + "§7]") : "");
/* 244 */           Color moduleColor = (Color)Phobos.moduleManager.moduleColorMap.get(module);
/* 245 */           j += 10; this.renderer.drawString(text3, (width - 2 - this.renderer.getStringWidth(text3)) + ((((Integer)this.animationHorizontalTime.getValue()).intValue() == 1) ? 0.0F : module.arrayListOffset), (height - j), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(MathUtil.clamp(height - j, 0, height)))).intValue() : ((((Boolean)this.moduleColors.getValue()).booleanValue() && moduleColor != null) ? moduleColor.getRGB() : this.color), true);
/*     */         } 
/*     */       } 
/*     */     }
/* 249 */     int i = !((Boolean)this.renderingUp.getValue()).booleanValue() ? 0 : ((mc.field_71462_r instanceof net.minecraft.client.gui.GuiChat) ? 0 : 0);
/* 250 */     if (((Boolean)this.renderingUp.getValue()).booleanValue()) {
/*     */       
/* 252 */       if (((Boolean)this.serverBrand.getValue()).booleanValue()) {
/* 253 */         Object text2 = grayString + "Server brand §f" + Phobos.serverManager.getServerBrand();
/* 254 */         i += 10; this.renderer.drawString((String)text2, (width - this.renderer.getStringWidth((String)text2) + 2), (height - 2 - i), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(height - i))).intValue() : this.color, true);
/*     */       } 
/* 256 */       if (((Boolean)this.potions.getValue()).booleanValue()) {
/* 257 */         for (PotionEffect effect : Phobos.potionManager.getOwnPotions()) {
/* 258 */           String text = ((Boolean)this.altPotionsColors.getValue()).booleanValue() ? Phobos.potionManager.getPotionString(effect) : Phobos.potionManager.getColoredPotionString(effect);
/* 259 */           i += 10; this.renderer.drawString(text, (width - this.renderer.getStringWidth(text) + 2), (height - 2 - i), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(height - i))).intValue() : (((Boolean)this.altPotionsColors.getValue()).booleanValue() ? ((Color)this.potionColorMap.get(effect.func_188419_a())).getRGB() : this.color), true);
/*     */         } 
/*     */       }
/* 262 */       if (((Boolean)this.speed.getValue()).booleanValue()) {
/* 263 */         Object text2 = grayString + "Speed §f" + Phobos.speedManager.getSpeedKpH() + " km/h";
/* 264 */         i += 10; this.renderer.drawString((String)text2, (width - this.renderer.getStringWidth((String)text2) + 2), (height - 2 - i), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(height - i))).intValue() : this.color, true);
/*     */       } 
/* 266 */       if (((Boolean)this.time.getValue()).booleanValue()) {
/* 267 */         Object text2 = grayString + "Time §f" + (new SimpleDateFormat("h:mm a")).format(new Date());
/* 268 */         i += 10; this.renderer.drawString((String)text2, (width - this.renderer.getStringWidth((String)text2) + 2), (height - 2 - i), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(height - i))).intValue() : this.color, true);
/*     */       }  int itemDamage;
/* 270 */       if (((Boolean)this.durability.getValue()).booleanValue() && (itemDamage = mc.field_71439_g.func_184614_ca().func_77958_k() - mc.field_71439_g.func_184614_ca().func_77952_i()) > 0) {
/* 271 */         String str = grayString + "Durability §a" + itemDamage;
/* 272 */         i += 10; this.renderer.drawString(str, (width - this.renderer.getStringWidth(str) + 2), (height - 2 - i), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(height - i))).intValue() : this.color, true);
/*     */       } 
/* 274 */       if (((Boolean)this.tps.getValue()).booleanValue()) {
/* 275 */         String text4 = grayString + "TPS §f" + Phobos.serverManager.getTPS();
/* 276 */         i += 10; this.renderer.drawString(text4, (width - this.renderer.getStringWidth(text4) + 2), (height - 2 - i), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(height - i))).intValue() : this.color, true);
/*     */       } 
/* 278 */       String fpsText = grayString + "FPS §f" + Minecraft.field_71470_ab;
/* 279 */       String text3 = grayString + "Ping §f" + (ServerModule.getInstance().isConnected() ? ServerModule.getInstance().getServerPing() : Phobos.serverManager.getPing()) + (((Boolean)this.MS.getValue()).booleanValue() ? "ms" : "");
/* 280 */       if (this.renderer.getStringWidth(text3) > this.renderer.getStringWidth(fpsText)) {
/* 281 */         if (((Boolean)this.ping.getValue()).booleanValue()) {
/* 282 */           i += 10; this.renderer.drawString(text3, (width - this.renderer.getStringWidth(text3) + 2), (height - 2 - i), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(height - i))).intValue() : this.color, true);
/*     */         } 
/* 284 */         if (((Boolean)this.fps.getValue()).booleanValue()) {
/* 285 */           i += 10; this.renderer.drawString(fpsText, (width - this.renderer.getStringWidth(fpsText) + 2), (height - 2 - i), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(height - i))).intValue() : this.color, true);
/*     */         } 
/*     */       } else {
/* 288 */         if (((Boolean)this.fps.getValue()).booleanValue()) {
/* 289 */           i += 10; this.renderer.drawString(fpsText, (width - this.renderer.getStringWidth(fpsText) + 2), (height - 2 - i), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(height - i))).intValue() : this.color, true);
/*     */         } 
/* 291 */         if (((Boolean)this.ping.getValue()).booleanValue()) {
/* 292 */           i += 10; this.renderer.drawString(text3, (width - this.renderer.getStringWidth(text3) + 2), (height - 2 - i), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(height - i))).intValue() : this.color, true);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 297 */       if (((Boolean)this.serverBrand.getValue()).booleanValue()) {
/* 298 */         Object text2 = grayString + "Server brand §f" + Phobos.serverManager.getServerBrand();
/* 299 */         this.renderer.drawString((String)text2, (width - this.renderer.getStringWidth((String)text2) + 2), (2 + i++ * 10), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2 + i * 10))).intValue() : this.color, true);
/*     */       } 
/* 301 */       if (((Boolean)this.potions.getValue()).booleanValue()) {
/* 302 */         for (PotionEffect effect : Phobos.potionManager.getOwnPotions()) {
/* 303 */           String text = ((Boolean)this.altPotionsColors.getValue()).booleanValue() ? Phobos.potionManager.getPotionString(effect) : Phobos.potionManager.getColoredPotionString(effect);
/* 304 */           this.renderer.drawString(text, (width - this.renderer.getStringWidth(text) + 2), (2 + i++ * 10), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2 + i * 10))).intValue() : (((Boolean)this.altPotionsColors.getValue()).booleanValue() ? ((Color)this.potionColorMap.get(effect.func_188419_a())).getRGB() : this.color), true);
/*     */         } 
/*     */       }
/* 307 */       if (((Boolean)this.speed.getValue()).booleanValue()) {
/* 308 */         Object text2 = grayString + "Speed §f" + Phobos.speedManager.getSpeedKpH() + " km/h";
/* 309 */         this.renderer.drawString((String)text2, (width - this.renderer.getStringWidth((String)text2) + 2), (2 + i++ * 10), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2 + i * 10))).intValue() : this.color, true);
/*     */       } 
/* 311 */       if (((Boolean)this.time.getValue()).booleanValue()) {
/* 312 */         Object text2 = grayString + "Time §f" + (new SimpleDateFormat("h:mm a")).format(new Date());
/* 313 */         this.renderer.drawString((String)text2, (width - this.renderer.getStringWidth((String)text2) + 2), (2 + i++ * 10), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2 + i * 10))).intValue() : this.color, true);
/*     */       }  int itemDamage;
/* 315 */       if (((Boolean)this.durability.getValue()).booleanValue() && (itemDamage = mc.field_71439_g.func_184614_ca().func_77958_k() - mc.field_71439_g.func_184614_ca().func_77952_i()) > 0) {
/* 316 */         String str = grayString + "Durability §a" + itemDamage;
/* 317 */         this.renderer.drawString(str, (width - this.renderer.getStringWidth(str) + 2), (2 + i++ * 10), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2 + i * 10))).intValue() : this.color, true);
/*     */       } 
/* 319 */       if (((Boolean)this.tps.getValue()).booleanValue()) {
/* 320 */         String text5 = grayString + "TPS §f" + Phobos.serverManager.getTPS();
/* 321 */         this.renderer.drawString(text5, (width - this.renderer.getStringWidth(text5) + 2), (2 + i++ * 10), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2 + i * 10))).intValue() : this.color, true);
/*     */       } 
/* 323 */       String fpsText = grayString + "FPS §f" + Minecraft.field_71470_ab;
/* 324 */       String text3 = grayString + "Ping §f" + Phobos.serverManager.getPing();
/* 325 */       if (this.renderer.getStringWidth(text3) > this.renderer.getStringWidth(fpsText)) {
/* 326 */         if (((Boolean)this.ping.getValue()).booleanValue()) {
/* 327 */           this.renderer.drawString(text3, (width - this.renderer.getStringWidth(text3) + 2), (2 + i++ * 10), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2 + i * 10))).intValue() : this.color, true);
/*     */         }
/* 329 */         if (((Boolean)this.fps.getValue()).booleanValue()) {
/* 330 */           this.renderer.drawString(fpsText, (width - this.renderer.getStringWidth(fpsText) + 2), (2 + i++ * 10), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2 + i * 10))).intValue() : this.color, true);
/*     */         }
/*     */       } else {
/* 333 */         if (((Boolean)this.fps.getValue()).booleanValue()) {
/* 334 */           this.renderer.drawString(fpsText, (width - this.renderer.getStringWidth(fpsText) + 2), (2 + i++ * 10), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2 + i * 10))).intValue() : this.color, true);
/*     */         }
/* 336 */         if (((Boolean)this.ping.getValue()).booleanValue()) {
/* 337 */           this.renderer.drawString(text3, (width - this.renderer.getStringWidth(text3) + 2), (2 + i++ * 10), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2 + i * 10))).intValue() : this.color, true);
/*     */         }
/*     */       } 
/*     */     } 
/* 341 */     boolean inHell = mc.field_71441_e.func_180494_b(mc.field_71439_g.func_180425_c()).func_185359_l().equals("Hell");
/* 342 */     int posX = (int)mc.field_71439_g.field_70165_t;
/* 343 */     int posY = (int)mc.field_71439_g.field_70163_u;
/* 344 */     int posZ = (int)mc.field_71439_g.field_70161_v;
/* 345 */     float nether = !inHell ? 0.125F : 8.0F;
/* 346 */     int hposX = (int)(mc.field_71439_g.field_70165_t * nether);
/* 347 */     int hposZ = (int)(mc.field_71439_g.field_70161_v * nether);
/* 348 */     if (((Boolean)this.renderingUp.getValue()).booleanValue()) {
/* 349 */       Phobos.notificationManager.handleNotifications(height - i + 16);
/*     */     } else {
/* 351 */       Phobos.notificationManager.handleNotifications(height - j + 16);
/*     */     } 
/* 353 */     i = (mc.field_71462_r instanceof net.minecraft.client.gui.GuiChat) ? 14 : 0;
/* 354 */     String coordinates = grayString + "XYZ §f" + posX + ", " + posY + ", " + posZ + " " + grayString + "[§f" + hposX + ", " + hposZ + grayString + "]";
/* 355 */     String text6 = (((Boolean)this.direction.getValue()).booleanValue() ? (Phobos.rotationManager.getDirection4D(false) + " ") : "") + (((Boolean)this.coords.getValue()).booleanValue() ? coordinates : "") + "";
/* 356 */     i += 10; i += 10; this.renderer.drawString(text6, 2.0F, (height - i), (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(height - i))).intValue() : this.color, true);
/* 357 */     if (((Boolean)this.armor.getValue()).booleanValue()) {
/* 358 */       renderArmorHUD(((Boolean)this.percent.getValue()).booleanValue());
/*     */     }
/* 360 */     if (((Boolean)this.totems.getValue()).booleanValue()) {
/* 361 */       renderTotemHUD();
/*     */     }
/* 363 */     if (this.greeter.getValue() != Greeter.NONE) {
/* 364 */       renderGreeter();
/*     */     }
/* 366 */     if (this.lag.getValue() != LagNotify.NONE) {
/* 367 */       renderLag();
/*     */     }
/* 369 */     if (((Boolean)this.hitMarkers.getValue()).booleanValue() && this.hitMarkerTimer > 0) {
/* 370 */       drawHitMarkers();
/*     */     }
/*     */   }
/*     */   
/*     */   public Map<String, Integer> getTextRadarPlayers() {
/* 375 */     return EntityUtil.getTextRadarPlayers();
/*     */   }
/*     */   
/*     */   public void renderGreeter() {
/* 379 */     int width = this.renderer.scaledWidth;
/* 380 */     String text = "";
/* 381 */     switch ((Greeter)this.greeter.getValue()) {
/*     */       case TIME:
/* 383 */         text = text + MathUtil.getTimeOfDay() + mc.field_71439_g.getDisplayNameString();
/*     */         break;
/*     */       
/*     */       case LONG:
/* 387 */         text = text + "Welcome to Phobos.eu " + mc.field_71439_g.getDisplayNameString() + " :^)";
/*     */         break;
/*     */       
/*     */       case CUSTOM:
/* 391 */         text = text + (String)this.spoofGreeter.getValue();
/*     */         break;
/*     */       
/*     */       default:
/* 395 */         text = text + "Welcome " + mc.field_71439_g.getDisplayNameString();
/*     */         break;
/*     */     } 
/* 398 */     this.renderer.drawString(text, width / 2.0F - this.renderer.getStringWidth(text) / 2.0F + 2.0F, 2.0F, (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(2))).intValue() : this.color, true);
/*     */   }
/*     */   
/*     */   public void renderLag() {
/* 402 */     int width = this.renderer.scaledWidth;
/* 403 */     if (Phobos.serverManager.isServerNotResponding()) {
/* 404 */       String text = ((this.lag.getValue() == LagNotify.GRAY) ? "§7" : "§c") + "Server not responding: " + MathUtil.round((float)Phobos.serverManager.serverRespondingTime() / 1000.0F, 1) + "s.";
/* 405 */       this.renderer.drawString(text, width / 2.0F - this.renderer.getStringWidth(text) / 2.0F + 2.0F, 20.0F, (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(20))).intValue() : this.color, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderArrayList() {}
/*     */   
/*     */   public void renderTotemHUD() {
/* 413 */     int width = this.renderer.scaledWidth;
/* 414 */     int height = this.renderer.scaledHeight;
/* 415 */     int totems = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_190929_cY)).mapToInt(ItemStack::func_190916_E).sum();
/* 416 */     if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
/* 417 */       totems += mc.field_71439_g.func_184592_cb().func_190916_E();
/*     */     }
/* 419 */     if (totems > 0) {
/* 420 */       GlStateManager.func_179098_w();
/* 421 */       int i = width / 2;
/* 422 */       boolean iteration = false;
/* 423 */       int y = height - 55 - ((mc.field_71439_g.func_70090_H() && mc.field_71442_b.func_78763_f()) ? 10 : 0);
/* 424 */       int x = i - 189 + 180 + 2;
/* 425 */       GlStateManager.func_179126_j();
/* 426 */       RenderUtil.itemRender.field_77023_b = 200.0F;
/* 427 */       RenderUtil.itemRender.func_180450_b(totem, x, y);
/* 428 */       RenderUtil.itemRender.func_180453_a(mc.field_71466_p, totem, x, y, "");
/* 429 */       RenderUtil.itemRender.field_77023_b = 0.0F;
/* 430 */       GlStateManager.func_179098_w();
/* 431 */       GlStateManager.func_179140_f();
/* 432 */       GlStateManager.func_179097_i();
/* 433 */       this.renderer.drawStringWithShadow(totems + "", (x + 19 - 2 - this.renderer.getStringWidth(totems + "")), (y + 9), 16777215);
/* 434 */       GlStateManager.func_179126_j();
/* 435 */       GlStateManager.func_179140_f();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void renderArmorHUD(boolean percent) {
/* 440 */     int width = this.renderer.scaledWidth;
/* 441 */     int height = this.renderer.scaledHeight;
/* 442 */     GlStateManager.func_179098_w();
/* 443 */     int i = width / 2;
/* 444 */     int iteration = 0;
/* 445 */     int y = height - 55 - ((mc.field_71439_g.func_70090_H() && mc.field_71442_b.func_78763_f()) ? 10 : 0);
/* 446 */     for (ItemStack is : mc.field_71439_g.field_71071_by.field_70460_b) {
/* 447 */       iteration++;
/* 448 */       if (is.func_190926_b())
/* 449 */         continue;  int x = i - 90 + (9 - iteration) * 20 + 2;
/* 450 */       GlStateManager.func_179126_j();
/* 451 */       RenderUtil.itemRender.field_77023_b = 200.0F;
/* 452 */       RenderUtil.itemRender.func_180450_b(is, x, y);
/* 453 */       RenderUtil.itemRender.func_180453_a(mc.field_71466_p, is, x, y, "");
/* 454 */       RenderUtil.itemRender.field_77023_b = 0.0F;
/* 455 */       GlStateManager.func_179098_w();
/* 456 */       GlStateManager.func_179140_f();
/* 457 */       GlStateManager.func_179097_i();
/* 458 */       String s = (is.func_190916_E() > 1) ? (is.func_190916_E() + "") : "";
/* 459 */       this.renderer.drawStringWithShadow(s, (x + 19 - 2 - this.renderer.getStringWidth(s)), (y + 9), 16777215);
/* 460 */       if (!percent)
/* 461 */         continue;  int dmg = 0;
/* 462 */       int itemDurability = is.func_77958_k() - is.func_77952_i();
/* 463 */       float green = (is.func_77958_k() - is.func_77952_i()) / is.func_77958_k();
/* 464 */       float red = 1.0F - green;
/* 465 */       dmg = percent ? (100 - (int)(red * 100.0F)) : itemDurability;
/* 466 */       this.renderer.drawStringWithShadow(dmg + "", (x + 8 - this.renderer.getStringWidth(dmg + "") / 2), (y - 11), ColorUtil.toRGBA((int)(red * 255.0F), (int)(green * 255.0F), 0));
/*     */     } 
/* 468 */     GlStateManager.func_179126_j();
/* 469 */     GlStateManager.func_179140_f();
/*     */   }
/*     */   
/*     */   public void drawHitMarkers() {
/* 473 */     ScaledResolution resolution = new ScaledResolution(mc);
/* 474 */     RenderUtil.drawLine(resolution.func_78326_a() / 2.0F - 4.0F, resolution.func_78328_b() / 2.0F - 4.0F, resolution.func_78326_a() / 2.0F - 8.0F, resolution.func_78328_b() / 2.0F - 8.0F, 1.0F, ColorUtil.toRGBA(255, 255, 255, 255));
/* 475 */     RenderUtil.drawLine(resolution.func_78326_a() / 2.0F + 4.0F, resolution.func_78328_b() / 2.0F - 4.0F, resolution.func_78326_a() / 2.0F + 8.0F, resolution.func_78328_b() / 2.0F - 8.0F, 1.0F, ColorUtil.toRGBA(255, 255, 255, 255));
/* 476 */     RenderUtil.drawLine(resolution.func_78326_a() / 2.0F - 4.0F, resolution.func_78328_b() / 2.0F + 4.0F, resolution.func_78326_a() / 2.0F - 8.0F, resolution.func_78328_b() / 2.0F + 8.0F, 1.0F, ColorUtil.toRGBA(255, 255, 255, 255));
/* 477 */     RenderUtil.drawLine(resolution.func_78326_a() / 2.0F + 4.0F, resolution.func_78328_b() / 2.0F + 4.0F, resolution.func_78326_a() / 2.0F + 8.0F, resolution.func_78328_b() / 2.0F + 8.0F, 1.0F, ColorUtil.toRGBA(255, 255, 255, 255));
/*     */   }
/*     */   
/*     */   public void drawTextRadar(int yOffset) {
/* 481 */     if (!this.players.isEmpty()) {
/* 482 */       int y = this.renderer.getFontHeight() + 7 + yOffset;
/* 483 */       for (Map.Entry<String, Integer> player : this.players.entrySet()) {
/* 484 */         String text = (String)player.getKey() + " ";
/* 485 */         int textheight = this.renderer.getFontHeight() + 1;
/* 486 */         this.renderer.drawString(text, 2.0F, y, (((Boolean)this.rolling.getValue()).booleanValue() && ((Boolean)this.rainbow.getValue()).booleanValue()) ? ((Integer)this.colorMap.get(Integer.valueOf(y))).intValue() : this.color, true);
/* 487 */         y += textheight;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public enum Sound {
/* 493 */     NONE,
/* 494 */     COD,
/* 495 */     CSGO;
/*     */   }
/*     */   
/*     */   public enum WaterMark
/*     */   {
/* 500 */     NONE,
/* 501 */     RENOSENSE,
/* 502 */     SKITTYHACK,
/* 503 */     CUSTOM;
/*     */   }
/*     */   
/*     */   public enum LagNotify
/*     */   {
/* 508 */     NONE,
/* 509 */     RED,
/* 510 */     GRAY;
/*     */   }
/*     */   
/*     */   public enum Greeter
/*     */   {
/* 515 */     NONE,
/* 516 */     NAME,
/* 517 */     TIME,
/* 518 */     LONG,
/* 519 */     CUSTOM;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\client\HUD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */