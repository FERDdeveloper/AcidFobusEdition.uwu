/*     */ package me.earth.phobos.features.modules.client;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.ClientEvent;
/*     */ import me.earth.phobos.event.events.PacketEvent;
/*     */ import me.earth.phobos.features.command.Command;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.manager.FileManager;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.play.server.SPacketSpawnObject;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentString;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class Notifications
/*     */   extends Module
/*     */ {
/*     */   private static final String fileName = "phobos/util/ModuleMessage_List.txt";
/*  24 */   private static final List<String> modules = new ArrayList<>();
/*  25 */   private static Notifications INSTANCE = new Notifications();
/*  26 */   private final Timer timer = new Timer();
/*  27 */   public Setting<Boolean> totemPops = register(new Setting("TotemPops", Boolean.valueOf(false)));
/*  28 */   public Setting<Boolean> totemNoti = register(new Setting("TotemNoti", Boolean.valueOf(true), v -> ((Boolean)this.totemPops.getValue()).booleanValue()));
/*  29 */   public Setting<Integer> delay = register(new Setting("Delay", Integer.valueOf(2000), Integer.valueOf(0), Integer.valueOf(5000), v -> ((Boolean)this.totemPops.getValue()).booleanValue(), "Delays messages."));
/*  30 */   public Setting<Boolean> clearOnLogout = register(new Setting("LogoutClear", Boolean.valueOf(false)));
/*  31 */   public Setting<Boolean> moduleMessage = register(new Setting("ModuleMessage", Boolean.valueOf(false)));
/*  32 */   public Setting<Boolean> list = register(new Setting("List", Boolean.valueOf(false), v -> ((Boolean)this.moduleMessage.getValue()).booleanValue()));
/*  33 */   public Setting<Boolean> watermark = register(new Setting("Watermark", Boolean.valueOf(true), v -> ((Boolean)this.moduleMessage.getValue()).booleanValue()));
/*  34 */   public Setting<Boolean> visualRange = register(new Setting("VisualRange", Boolean.valueOf(false)));
/*  35 */   public Setting<Boolean> coords = register(new Setting("Coords", Boolean.valueOf(true), v -> ((Boolean)this.visualRange.getValue()).booleanValue()));
/*  36 */   public Setting<Boolean> leaving = register(new Setting("Leaving", Boolean.valueOf(false), v -> ((Boolean)this.visualRange.getValue()).booleanValue()));
/*  37 */   public Setting<Boolean> pearls = register(new Setting("PearlNotifs", Boolean.valueOf(false)));
/*  38 */   public Setting<Boolean> crash = register(new Setting("Crash", Boolean.valueOf(false)));
/*  39 */   public Setting<Boolean> popUp = register(new Setting("PopUpVisualRange", Boolean.valueOf(false)));
/*  40 */   public Timer totemAnnounce = new Timer();
/*  41 */   private final Setting<Boolean> readfile = register(new Setting("LoadFile", Boolean.valueOf(false), v -> ((Boolean)this.moduleMessage.getValue()).booleanValue()));
/*  42 */   private List<EntityPlayer> knownPlayers = new ArrayList<>();
/*     */   private boolean check;
/*     */   
/*     */   public Notifications() {
/*  46 */     super("Notifications", "Sends Messages.", Module.Category.CLIENT, true, false, false);
/*  47 */     setInstance();
/*     */   }
/*     */   
/*     */   public static Notifications getInstance() {
/*  51 */     if (INSTANCE == null) {
/*  52 */       INSTANCE = new Notifications();
/*     */     }
/*  54 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   public static void displayCrash(Exception e) {
/*  58 */     Command.sendMessage("§cException caught: " + e.getMessage());
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  62 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLoad() {
/*  67 */     this.check = true;
/*  68 */     loadFile();
/*  69 */     this.check = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  74 */     this.knownPlayers = new ArrayList<>();
/*  75 */     if (!this.check) {
/*  76 */       loadFile();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  82 */     if (((Boolean)this.readfile.getValue()).booleanValue()) {
/*  83 */       if (!this.check) {
/*  84 */         Command.sendMessage("Loading File...");
/*  85 */         this.timer.reset();
/*  86 */         loadFile();
/*     */       } 
/*  88 */       this.check = true;
/*     */     } 
/*  90 */     if (this.check && this.timer.passedMs(750L)) {
/*  91 */       this.readfile.setValue(Boolean.valueOf(false));
/*  92 */       this.check = false;
/*     */     } 
/*  94 */     if (((Boolean)this.visualRange.getValue()).booleanValue()) {
/*  95 */       ArrayList<EntityPlayer> tickPlayerList = new ArrayList<>(mc.field_71441_e.field_73010_i);
/*  96 */       if (tickPlayerList.size() > 0) {
/*  97 */         for (EntityPlayer player : tickPlayerList) {
/*  98 */           if (player.func_70005_c_().equals(mc.field_71439_g.func_70005_c_()) || this.knownPlayers.contains(player))
/*     */             continue; 
/* 100 */           this.knownPlayers.add(player);
/* 101 */           if (Phobos.friendManager.isFriend(player)) {
/* 102 */             Command.sendMessage("Player §a" + player.func_70005_c_() + "§r entered your visual range" + (((Boolean)this.coords.getValue()).booleanValue() ? (" at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!") : "!"), ((Boolean)this.popUp.getValue()).booleanValue());
/*     */           } else {
/* 104 */             Command.sendMessage("Player §c" + player.func_70005_c_() + "§r entered your visual range" + (((Boolean)this.coords.getValue()).booleanValue() ? (" at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!") : "!"), ((Boolean)this.popUp.getValue()).booleanValue());
/*     */           } 
/*     */           return;
/*     */         } 
/*     */       }
/* 109 */       if (this.knownPlayers.size() > 0) {
/* 110 */         for (EntityPlayer player : this.knownPlayers) {
/* 111 */           if (tickPlayerList.contains(player))
/* 112 */             continue;  this.knownPlayers.remove(player);
/* 113 */           if (((Boolean)this.leaving.getValue()).booleanValue()) {
/* 114 */             if (Phobos.friendManager.isFriend(player)) {
/* 115 */               Command.sendMessage("Player §a" + player.func_70005_c_() + "§r left your visual range" + (((Boolean)this.coords.getValue()).booleanValue() ? (" at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!") : "!"), ((Boolean)this.popUp.getValue()).booleanValue());
/*     */             } else {
/* 117 */               Command.sendMessage("Player §c" + player.func_70005_c_() + "§r left your visual range" + (((Boolean)this.coords.getValue()).booleanValue() ? (" at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!") : "!"), ((Boolean)this.popUp.getValue()).booleanValue());
/*     */             } 
/*     */           }
/*     */           return;
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void loadFile() {
/* 127 */     List<String> fileInput = FileManager.readTextFileAllLines("phobos/util/ModuleMessage_List.txt");
/* 128 */     Iterator<String> i = fileInput.iterator();
/* 129 */     modules.clear();
/* 130 */     while (i.hasNext()) {
/* 131 */       String s = i.next();
/* 132 */       if (s.replaceAll("\\s", "").isEmpty())
/* 133 */         continue;  modules.add(s);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onReceivePacket(PacketEvent.Receive event) {
/* 139 */     if (event.getPacket() instanceof SPacketSpawnObject && ((Boolean)this.pearls.getValue()).booleanValue()) {
/* 140 */       SPacketSpawnObject packet = (SPacketSpawnObject)event.getPacket();
/* 141 */       EntityPlayer player = mc.field_71441_e.func_184137_a(packet.func_186880_c(), packet.func_186882_d(), packet.func_186881_e(), 1.0D, false);
/* 142 */       if (player == null) {
/*     */         return;
/*     */       }
/* 145 */       if (packet.func_149001_c() == 85) {
/* 146 */         Command.sendMessage("§cPearl thrown by " + player.func_70005_c_() + " at X:" + (int)packet.func_186880_c() + " Y:" + (int)packet.func_186882_d() + " Z:" + (int)packet.func_186881_e());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onToggleModule(ClientEvent event) {
/* 155 */     if (!((Boolean)this.moduleMessage.getValue()).booleanValue())
/*     */       return; 
/*     */     Module module;
/* 158 */     if (event.getStage() == 0 && !(module = (Module)event.getFeature()).equals(this) && (modules.contains(module.getDisplayName()) || !((Boolean)this.list.getValue()).booleanValue())) {
/* 159 */       int moduleNumber = 0;
/* 160 */       for (char character : module.getDisplayName().toCharArray()) {
/* 161 */         moduleNumber += character;
/* 162 */         moduleNumber *= 10;
/*     */       } 
/* 164 */       if (((Boolean)this.watermark.getValue()).booleanValue()) {
/* 165 */         TextComponentString textComponentString = new TextComponentString(Phobos.commandManager.getClientMessage() + " §r§c" + module.getDisplayName() + " disabled.");
/* 166 */         mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)textComponentString, moduleNumber);
/*     */       } else {
/* 168 */         TextComponentString textComponentString = new TextComponentString("§c" + module.getDisplayName() + " disabled.");
/* 169 */         mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)textComponentString, moduleNumber);
/*     */       } 
/*     */     } 
/* 172 */     if (event.getStage() == 1 && (modules.contains((module = (Module)event.getFeature()).getDisplayName()) || !((Boolean)this.list.getValue()).booleanValue())) {
/* 173 */       int moduleNumber = 0;
/* 174 */       for (char character : module.getDisplayName().toCharArray()) {
/* 175 */         moduleNumber += character;
/* 176 */         moduleNumber *= 10;
/*     */       } 
/* 178 */       if (((Boolean)this.watermark.getValue()).booleanValue()) {
/* 179 */         TextComponentString textComponentString = new TextComponentString(Phobos.commandManager.getClientMessage() + " §r§a" + module.getDisplayName() + " enabled.");
/* 180 */         mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)textComponentString, moduleNumber);
/*     */       } else {
/* 182 */         TextComponentString textComponentString = new TextComponentString("§a" + module.getDisplayName() + " enabled.");
/* 183 */         mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)textComponentString, moduleNumber);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\client\Notifications.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */