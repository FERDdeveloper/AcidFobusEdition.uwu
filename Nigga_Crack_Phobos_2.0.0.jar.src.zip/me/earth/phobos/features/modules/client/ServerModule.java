/*     */ package me.earth.phobos.features.modules.client;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import me.earth.phobos.event.events.PacketEvent;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import me.earth.phobos.mixin.mixins.accessors.IC00Handshake;
/*     */ import me.earth.phobos.util.TextUtil;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketChatMessage;
/*     */ import net.minecraft.network.play.client.CPacketKeepAlive;
/*     */ import net.minecraft.network.play.server.SPacketChat;
/*     */ import net.minecraft.network.play.server.SPacketKeepAlive;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class ServerModule
/*     */   extends Module
/*     */ {
/*     */   private static ServerModule instance;
/*  24 */   private final AtomicBoolean connected = new AtomicBoolean(false);
/*  25 */   private final Timer pingTimer = new Timer();
/*  26 */   private final List<Long> pingList = new ArrayList<>();
/*  27 */   public Setting<String> ip = register(new Setting("PhobosIP", "0.0.0.0.0"));
/*  28 */   public Setting<String> port = register((new Setting("Port", "0")).setRenderName(true));
/*  29 */   public Setting<String> serverIP = register(new Setting("ServerIP", "AnarchyHvH.eu"));
/*  30 */   public Setting<Boolean> noFML = register(new Setting("RemoveFML", Boolean.valueOf(false)));
/*  31 */   public Setting<Boolean> getName = register(new Setting("GetName", Boolean.valueOf(false)));
/*  32 */   public Setting<Boolean> average = register(new Setting("Average", Boolean.valueOf(false)));
/*  33 */   public Setting<Boolean> clear = register(new Setting("ClearPings", Boolean.valueOf(false)));
/*  34 */   public Setting<Boolean> oneWay = register(new Setting("OneWay", Boolean.valueOf(false)));
/*  35 */   public Setting<Integer> delay = register(new Setting("KeepAlives", Integer.valueOf(10), Integer.valueOf(1), Integer.valueOf(50)));
/*  36 */   private long currentPing = 0L;
/*  37 */   private long serverPing = 0L;
/*  38 */   private StringBuffer name = null;
/*  39 */   private long averagePing = 0L;
/*     */   
/*     */   public ServerModule() {
/*  42 */     super("PingBypass", "Manages Phobos`s internal Server", Module.Category.CLIENT, false, false, true);
/*  43 */     instance = this;
/*     */   }
/*     */   
/*     */   public static ServerModule getInstance() {
/*  47 */     if (instance == null) {
/*  48 */       instance = new ServerModule();
/*     */     }
/*  50 */     return instance;
/*     */   }
/*     */   
/*     */   public String getPlayerName() {
/*  54 */     if (this.name == null) {
/*  55 */       return null;
/*     */     }
/*  57 */     return this.name.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLogout() {
/*  62 */     this.averagePing = 0L;
/*  63 */     this.currentPing = 0L;
/*  64 */     this.serverPing = 0L;
/*  65 */     this.pingList.clear();
/*  66 */     this.connected.set(false);
/*  67 */     this.name = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  72 */     if (mc.func_147114_u() != null && isConnected()) {
/*  73 */       if (((Boolean)this.getName.getValue()).booleanValue()) {
/*  74 */         mc.func_147114_u().func_147297_a((Packet)new CPacketChatMessage("@Servername"));
/*  75 */         this.getName.setValue(Boolean.valueOf(false));
/*     */       } 
/*  77 */       if (this.pingTimer.passedMs((((Integer)this.delay.getValue()).intValue() * 1000))) {
/*  78 */         mc.func_147114_u().func_147297_a((Packet)new CPacketKeepAlive(100L));
/*  79 */         this.pingTimer.reset();
/*     */       } 
/*  81 */       if (((Boolean)this.clear.getValue()).booleanValue()) {
/*  82 */         this.pingList.clear();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.Receive event) {
/*  90 */     if (event.getPacket() instanceof SPacketChat)
/*  91 */     { SPacketChat packetChat = (SPacketChat)event.getPacket();
/*  92 */       if (packetChat.func_148915_c().func_150254_d().startsWith("@Client")) {
/*  93 */         this.name = new StringBuffer(TextUtil.stripColor(packetChat.func_148915_c().func_150254_d().replace("@Client", "")));
/*  94 */         event.setCanceled(true);
/*     */       }  }
/*  96 */     else { SPacketKeepAlive alive; if (event.getPacket() instanceof SPacketKeepAlive && (alive = (SPacketKeepAlive)event.getPacket()).func_149134_c() != 0L && alive.func_149134_c() < 1000L) {
/*  97 */         this.serverPing = alive.func_149134_c();
/*  98 */         this.currentPing = ((Boolean)this.oneWay.getValue()).booleanValue() ? (this.pingTimer.getPassedTimeMs() / 2L) : this.pingTimer.getPassedTimeMs();
/*  99 */         this.pingList.add(Long.valueOf(this.currentPing));
/* 100 */         this.averagePing = getAveragePing();
/*     */       }  }
/*     */   
/*     */   }
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.Send event) {
/*     */     IC00Handshake packet;
/*     */     String ip;
/* 108 */     if (event.getPacket() instanceof net.minecraft.network.handshake.client.C00Handshake && (ip = (packet = (IC00Handshake)event.getPacket()).getIp()).equals(this.ip.getValue())) {
/* 109 */       packet.setIp((String)this.serverIP.getValue());
/* 110 */       System.out.println(packet.getIp());
/* 111 */       this.connected.set(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/* 117 */     return this.averagePing + "ms";
/*     */   }
/*     */   
/*     */   private long getAveragePing() {
/* 121 */     if (!((Boolean)this.average.getValue()).booleanValue() || this.pingList.isEmpty()) {
/* 122 */       return this.currentPing;
/*     */     }
/* 124 */     int full = 0;
/* 125 */     for (Iterator<Long> iterator = this.pingList.iterator(); iterator.hasNext(); ) { long i = ((Long)iterator.next()).longValue();
/* 126 */       full = (int)(full + i); }
/*     */     
/* 128 */     return (full / this.pingList.size());
/*     */   }
/*     */   
/*     */   public boolean isConnected() {
/* 132 */     return this.connected.get();
/*     */   }
/*     */   
/*     */   public int getPort() {
/*     */     int result;
/*     */     try {
/* 138 */       result = Integer.parseInt((String)this.port.getValue());
/* 139 */     } catch (NumberFormatException e) {
/* 140 */       return -1;
/*     */     } 
/* 142 */     return result;
/*     */   }
/*     */   
/*     */   public long getServerPing() {
/* 146 */     return this.serverPing;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\modules\client\ServerModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */