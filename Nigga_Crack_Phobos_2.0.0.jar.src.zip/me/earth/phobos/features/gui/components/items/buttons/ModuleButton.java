/*     */ package me.earth.phobos.features.gui.components.items.buttons;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.features.gui.PhobosGui;
/*     */ import me.earth.phobos.features.gui.components.items.Item;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.modules.client.ClickGui;
/*     */ import me.earth.phobos.features.setting.Setting;
/*     */ import net.minecraft.client.audio.ISound;
/*     */ import net.minecraft.client.audio.PositionedSoundRecord;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleButton
/*     */   extends Button
/*     */ {
/*     */   private final Module module;
/*  21 */   private List<Item> items = new ArrayList<>();
/*     */   private boolean subOpen;
/*     */   
/*     */   public ModuleButton(Module module) {
/*  25 */     super(module.getName());
/*  26 */     this.module = module;
/*  27 */     initSettings();
/*     */   }
/*     */   
/*     */   public void initSettings() {
/*  31 */     ArrayList<Item> newItems = new ArrayList<>();
/*  32 */     if (!this.module.getSettings().isEmpty()) {
/*  33 */       for (Setting setting : this.module.getSettings()) {
/*  34 */         if (setting.getValue() instanceof Boolean && !setting.getName().equals("Enabled")) {
/*  35 */           newItems.add(new BooleanButton(setting));
/*     */         }
/*  37 */         if (setting.getValue() instanceof me.earth.phobos.features.setting.Bind && !this.module.getName().equalsIgnoreCase("Hud")) {
/*  38 */           newItems.add(new BindButton(setting));
/*     */         }
/*  40 */         if (setting.getValue() instanceof String || setting.getValue() instanceof Character) {
/*  41 */           newItems.add(new StringButton(setting));
/*     */         }
/*  43 */         if (setting.isNumberSetting()) {
/*  44 */           if (setting.hasRestriction()) {
/*  45 */             newItems.add(new Slider(setting));
/*     */             continue;
/*     */           } 
/*  48 */           newItems.add(new UnlimitedSlider(setting));
/*     */         } 
/*  50 */         if (!setting.isEnumSetting())
/*  51 */           continue;  newItems.add(new EnumButton(setting));
/*     */       } 
/*     */     }
/*  54 */     this.items = newItems;
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/*  59 */     super.drawScreen(mouseX, mouseY, partialTicks);
/*  60 */     if (!this.items.isEmpty()) {
/*  61 */       ClickGui gui = (ClickGui)Phobos.moduleManager.getModuleByClass(ClickGui.class);
/*  62 */       Phobos.textManager.drawStringWithShadow(((Boolean)gui.openCloseChange.getValue()).booleanValue() ? (this.subOpen ? (String)gui.close.getValue() : (String)gui.open.getValue()) : (String)gui.moduleButton.getValue(), this.x - 1.5F + this.width - 7.4F, this.y - 2.0F - PhobosGui.getClickGui().getTextOffset(), -1);
/*  63 */       if (this.subOpen) {
/*  64 */         float height = 1.0F;
/*  65 */         for (Item item : this.items) {
/*  66 */           if (!item.isHidden()) {
/*  67 */             item.setLocation(this.x + 1.0F, this.y + (height += 15.0F));
/*  68 */             item.setHeight(15);
/*  69 */             item.setWidth(this.width - 9);
/*  70 */             item.drawScreen(mouseX, mouseY, partialTicks);
/*     */           } 
/*  72 */           item.update();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
/*  80 */     super.mouseClicked(mouseX, mouseY, mouseButton);
/*  81 */     if (!this.items.isEmpty()) {
/*  82 */       if (mouseButton == 1 && isHovering(mouseX, mouseY)) {
/*  83 */         this.subOpen = !this.subOpen;
/*  84 */         mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
/*     */       } 
/*  86 */       if (this.subOpen) {
/*  87 */         for (Item item : this.items) {
/*  88 */           if (item.isHidden())
/*  89 */             continue;  item.mouseClicked(mouseX, mouseY, mouseButton);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onKeyTyped(char typedChar, int keyCode) {
/*  97 */     super.onKeyTyped(typedChar, keyCode);
/*  98 */     if (!this.items.isEmpty() && this.subOpen) {
/*  99 */       for (Item item : this.items) {
/* 100 */         if (item.isHidden())
/* 101 */           continue;  item.onKeyTyped(typedChar, keyCode);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 108 */     if (this.subOpen) {
/* 109 */       int height = 14;
/* 110 */       for (Item item : this.items) {
/* 111 */         if (item.isHidden())
/* 112 */           continue;  height += item.getHeight() + 1;
/*     */       } 
/* 114 */       return height + 2;
/*     */     } 
/* 116 */     return 14;
/*     */   }
/*     */   
/*     */   public Module getModule() {
/* 120 */     return this.module;
/*     */   }
/*     */ 
/*     */   
/*     */   public void toggle() {
/* 125 */     this.module.toggle();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getState() {
/* 130 */     return this.module.isEnabled();
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\gui\components\items\buttons\ModuleButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */