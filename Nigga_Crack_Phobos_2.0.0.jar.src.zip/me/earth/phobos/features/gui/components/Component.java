/*     */ package me.earth.phobos.features.gui.components;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.features.Feature;
/*     */ import me.earth.phobos.features.gui.PhobosGui;
/*     */ import me.earth.phobos.features.gui.components.items.Item;
/*     */ import me.earth.phobos.features.gui.components.items.buttons.Button;
/*     */ import me.earth.phobos.features.modules.client.ClickGui;
/*     */ import me.earth.phobos.features.modules.client.Colors;
/*     */ import me.earth.phobos.features.modules.client.HUD;
/*     */ import me.earth.phobos.util.ColorUtil;
/*     */ import me.earth.phobos.util.MathUtil;
/*     */ import me.earth.phobos.util.RenderUtil;
/*     */ import net.minecraft.client.audio.ISound;
/*     */ import net.minecraft.client.audio.PositionedSoundRecord;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ 
/*     */ 
/*     */ public class Component
/*     */   extends Feature
/*     */ {
/*  23 */   private final ArrayList<Item> items = new ArrayList<>();
/*     */   public boolean drag;
/*     */   private int x;
/*     */   private int y;
/*     */   private int x2;
/*     */   private int y2;
/*     */   private int width;
/*     */   private int height;
/*     */   private boolean open;
/*     */   private boolean hidden = false;
/*     */   
/*     */   public Component(String name, int x, int y, boolean open) {
/*  35 */     super(name);
/*  36 */     this.x = x;
/*  37 */     this.y = y;
/*  38 */     this.width = 88;
/*  39 */     this.height = 18;
/*  40 */     this.open = open;
/*  41 */     setupItems();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupItems() {}
/*     */   
/*     */   private void drag(int mouseX, int mouseY) {
/*  48 */     if (!this.drag) {
/*     */       return;
/*     */     }
/*  51 */     this.x = this.x2 + mouseX;
/*  52 */     this.y = this.y2 + mouseY;
/*     */   }
/*     */   
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/*  56 */     drag(mouseX, mouseY);
/*  57 */     float totalItemHeight = this.open ? (getTotalItemHeight() - 2.0F) : 0.0F;
/*  58 */     int color = -7829368;
/*  59 */     if (((Boolean)(ClickGui.getInstance()).devSettings.getValue()).booleanValue()) {
/*  60 */       int i = color = ((Boolean)(ClickGui.getInstance()).colorSync.getValue()).booleanValue() ? Colors.INSTANCE.getCurrentColorHex() : ColorUtil.toARGB(((Integer)(ClickGui.getInstance()).topRed.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).topGreen.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).topBlue.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).topAlpha.getValue()).intValue());
/*     */     }
/*  62 */     if (((Boolean)(ClickGui.getInstance()).rainbowRolling.getValue()).booleanValue() && ((Boolean)(ClickGui.getInstance()).colorSync.getValue()).booleanValue() && ((Boolean)Colors.INSTANCE.rainbow.getValue()).booleanValue()) {
/*  63 */       RenderUtil.drawGradientRect(this.x, this.y - 1.5F, this.width, (this.height - 4), ((Integer)(HUD.getInstance()).colorMap.get(Integer.valueOf(MathUtil.clamp(this.y, 0, this.renderer.scaledHeight)))).intValue(), ((Integer)(HUD.getInstance()).colorMap.get(Integer.valueOf(MathUtil.clamp(this.y + this.height - 4, 0, this.renderer.scaledHeight)))).intValue());
/*     */     } else {
/*  65 */       RenderUtil.drawRect(this.x, this.y - 1.5F, (this.x + this.width), (this.y + this.height - 6), color);
/*     */     } 
/*  67 */     if (this.open) {
/*  68 */       RenderUtil.drawRect(this.x, this.y + 12.5F, (this.x + this.width), (this.y + this.height) + totalItemHeight, 1996488704);
/*     */     }
/*  70 */     Phobos.textManager.drawStringWithShadow(getName(), this.x + 3.0F, this.y - 4.0F - PhobosGui.getClickGui().getTextOffset(), -1);
/*  71 */     if (this.open) {
/*  72 */       float y = (getY() + getHeight()) - 3.0F;
/*  73 */       for (Item item : getItems()) {
/*  74 */         if (item.isHidden())
/*  75 */           continue;  item.setLocation(this.x + 2.0F, y);
/*  76 */         item.setWidth(getWidth() - 4);
/*  77 */         item.drawScreen(mouseX, mouseY, partialTicks);
/*  78 */         y += item.getHeight() + 1.5F;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
/*  84 */     if (mouseButton == 0 && isHovering(mouseX, mouseY)) {
/*  85 */       this.x2 = this.x - mouseX;
/*  86 */       this.y2 = this.y - mouseY;
/*  87 */       PhobosGui.getClickGui().getComponents().forEach(component -> {
/*     */             if (component.drag) {
/*     */               component.drag = false;
/*     */             }
/*     */           });
/*  92 */       this.drag = true;
/*     */       return;
/*     */     } 
/*  95 */     if (mouseButton == 1 && isHovering(mouseX, mouseY)) {
/*  96 */       this.open = !this.open;
/*  97 */       mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
/*     */       return;
/*     */     } 
/* 100 */     if (!this.open) {
/*     */       return;
/*     */     }
/* 103 */     getItems().forEach(item -> item.mouseClicked(mouseX, mouseY, mouseButton));
/*     */   }
/*     */   
/*     */   public void mouseReleased(int mouseX, int mouseY, int releaseButton) {
/* 107 */     if (releaseButton == 0) {
/* 108 */       this.drag = false;
/*     */     }
/* 110 */     if (!this.open) {
/*     */       return;
/*     */     }
/* 113 */     getItems().forEach(item -> item.mouseReleased(mouseX, mouseY, releaseButton));
/*     */   }
/*     */   
/*     */   public void onKeyTyped(char typedChar, int keyCode) {
/* 117 */     if (!this.open) {
/*     */       return;
/*     */     }
/* 120 */     getItems().forEach(item -> item.onKeyTyped(typedChar, keyCode));
/*     */   }
/*     */   
/*     */   public void addButton(Button button) {
/* 124 */     this.items.add(button);
/*     */   }
/*     */   
/*     */   public int getX() {
/* 128 */     return this.x;
/*     */   }
/*     */   
/*     */   public void setX(int x) {
/* 132 */     this.x = x;
/*     */   }
/*     */   
/*     */   public int getY() {
/* 136 */     return this.y;
/*     */   }
/*     */   
/*     */   public void setY(int y) {
/* 140 */     this.y = y;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 144 */     return this.width;
/*     */   }
/*     */   
/*     */   public void setWidth(int width) {
/* 148 */     this.width = width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 152 */     return this.height;
/*     */   }
/*     */   
/*     */   public void setHeight(int height) {
/* 156 */     this.height = height;
/*     */   }
/*     */   
/*     */   public boolean isHidden() {
/* 160 */     return this.hidden;
/*     */   }
/*     */   
/*     */   public void setHidden(boolean hidden) {
/* 164 */     this.hidden = hidden;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 168 */     return this.open;
/*     */   }
/*     */   
/*     */   public final ArrayList<Item> getItems() {
/* 172 */     return this.items;
/*     */   }
/*     */   
/*     */   private boolean isHovering(int mouseX, int mouseY) {
/* 176 */     return (mouseX >= getX() && mouseX <= getX() + getWidth() && mouseY >= getY() && mouseY <= getY() + getHeight() - (this.open ? 2 : 0));
/*     */   }
/*     */   
/*     */   private float getTotalItemHeight() {
/* 180 */     float height = 0.0F;
/* 181 */     for (Item item : getItems()) {
/* 182 */       height += item.getHeight() + 1.5F;
/*     */     }
/* 184 */     return height;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\features\gui\components\Component.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */