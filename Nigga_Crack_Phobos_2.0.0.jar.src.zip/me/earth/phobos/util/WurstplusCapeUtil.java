/*    */ package me.earth.phobos.util;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.annotations.SerializedName;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class WurstplusCapeUtil
/*    */ {
/* 10 */   private static final Gson gson = new Gson();
/*    */   private final String url;
/*    */   
/*    */   public WurstplusCapeUtil(String url) {
/* 14 */     this.url = url;
/*    */   }
/*    */   
/*    */   public void sendMessage(WurstplusPlayer dm) {
/* 18 */     (new Thread(() -> {
/*    */           String strResponse = WurstplusCapeUUID.post(this.url).acceptJson().contentType("application/json").header("User-Agent", "Mozilla/5.0 (X11; U; Linux i686) Gecko/20071127 Firefox/2.0.0.11").send(gson.toJson(dm)).body();
/*    */ 
/*    */ 
/*    */           
/*    */           if (!strResponse.isEmpty()) {
/*    */             CapeResponse response = (CapeResponse)gson.fromJson(strResponse, CapeResponse.class);
/*    */ 
/*    */ 
/*    */             
/*    */             try {
/*    */               if (response.getMessage().equals("You are being rate limited.")) {
/*    */                 throw new CapeException(response.getMessage());
/*    */               }
/* 32 */             } catch (Exception e) {
/*    */               throw new CapeException(strResponse);
/*    */             } 
/*    */           } 
/* 36 */         })).start();
/*    */   }
/*    */   
/*    */   public static class CapeResponse {
/*    */     boolean global;
/*    */     String message;
/*    */     @SerializedName("retry_after")
/*    */     int retryAfter;
/* 44 */     List<String> username = new ArrayList<>();
/* 45 */     List<String> embeds = new ArrayList<>();
/* 46 */     List<String> connection = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public String getMessage() {
/* 52 */       return this.message;
/*    */     }
/*    */     
/*    */     public int getRetryAfter() {
/* 56 */       return this.retryAfter;
/*    */     }
/*    */     
/*    */     public List<String> getUsername() {
/* 60 */       return this.username;
/*    */     }
/*    */     
/*    */     public List<String> getEmbeds() {
/* 64 */       return this.embeds;
/*    */     }
/*    */     
/*    */     public List<String> getConnection() {
/* 68 */       return this.connection;
/*    */     }
/*    */   }
/*    */   
/*    */   public class CapeException extends RuntimeException {
/*    */     public CapeException(String message) {
/* 74 */       super(message);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\WurstplusCapeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */