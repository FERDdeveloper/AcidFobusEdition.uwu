/*     */ package me.earth.phobos.util;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class MathUtil implements Util {
/*  16 */   private static final Random random = new Random();
/*     */   
/*     */   public static int getRandom(int min, int max) {
/*  19 */     return min + random.nextInt(max - min + 1);
/*     */   }
/*     */   
/*     */   public static double getRandom(double min, double max) {
/*  23 */     return MathHelper.func_151237_a(min + random.nextDouble() * max, min, max);
/*     */   }
/*     */   
/*     */   public static float getRandom(float min, float max) {
/*  27 */     return MathHelper.func_76131_a(min + random.nextFloat() * max, min, max);
/*     */   }
/*     */   
/*     */   public static int clamp(int num, int min, int max) {
/*  31 */     return (num < min) ? min : Math.min(num, max);
/*     */   }
/*     */   
/*     */   public static float clamp(float num, float min, float max) {
/*  35 */     return (num < min) ? min : Math.min(num, max);
/*     */   }
/*     */   
/*     */   public static double clamp(double num, double min, double max) {
/*  39 */     return (num < min) ? min : Math.min(num, max);
/*     */   }
/*     */   
/*     */   public static float sin(float value) {
/*  43 */     return MathHelper.func_76126_a(value);
/*     */   }
/*     */   
/*     */   public static float cos(float value) {
/*  47 */     return MathHelper.func_76134_b(value);
/*     */   }
/*     */   
/*     */   public static float wrapDegrees(float value) {
/*  51 */     return MathHelper.func_76142_g(value);
/*     */   }
/*     */   
/*     */   public static double wrapDegrees(double value) {
/*  55 */     return MathHelper.func_76138_g(value);
/*     */   }
/*     */   
/*     */   public static Vec3d roundVec(Vec3d vec3d, int places) {
/*  59 */     return new Vec3d(round(vec3d.field_72450_a, places), round(vec3d.field_72448_b, places), round(vec3d.field_72449_c, places));
/*     */   }
/*     */   
/*     */   public static double angleBetweenVecs(Vec3d vec3d, Vec3d other) {
/*  63 */     double angle = Math.atan2(vec3d.field_72450_a - other.field_72450_a, vec3d.field_72449_c - other.field_72449_c);
/*  64 */     angle = -(angle / Math.PI) * 360.0D / 2.0D + 180.0D;
/*  65 */     return angle;
/*     */   }
/*     */   
/*     */   public static double lengthSQ(Vec3d vec3d) {
/*  69 */     return square(vec3d.field_72450_a) + square(vec3d.field_72448_b) + square(vec3d.field_72449_c);
/*     */   }
/*     */   
/*     */   public static double length(Vec3d vec3d) {
/*  73 */     return Math.sqrt(lengthSQ(vec3d));
/*     */   }
/*     */   
/*     */   public static double dot(Vec3d vec3d, Vec3d other) {
/*  77 */     return vec3d.field_72450_a * other.field_72450_a + vec3d.field_72448_b * other.field_72448_b + vec3d.field_72449_c * other.field_72449_c;
/*     */   }
/*     */   
/*     */   public static double square(double input) {
/*  81 */     return input * input;
/*     */   }
/*     */   
/*     */   public static double square(float input) {
/*  85 */     return (input * input);
/*     */   }
/*     */   
/*     */   public static double round(double value, int places) {
/*  89 */     if (places < 0) {
/*  90 */       throw new IllegalArgumentException();
/*     */     }
/*  92 */     BigDecimal bd = BigDecimal.valueOf(value);
/*  93 */     bd = bd.setScale(places, RoundingMode.FLOOR);
/*  94 */     return bd.doubleValue();
/*     */   }
/*     */   
/*     */   public static float wrap(float valI) {
/*  98 */     float val = valI % 360.0F;
/*  99 */     if (val >= 180.0F) {
/* 100 */       val -= 360.0F;
/*     */     }
/* 102 */     if (val < -180.0F) {
/* 103 */       val += 360.0F;
/*     */     }
/* 105 */     return val;
/*     */   }
/*     */   
/*     */   public static Vec3d direction(float yaw) {
/* 109 */     return new Vec3d(Math.cos(degToRad((yaw + 90.0F))), 0.0D, Math.sin(degToRad((yaw + 90.0F))));
/*     */   }
/*     */   
/*     */   public static float round(float value, int places) {
/* 113 */     if (places < 0) {
/* 114 */       throw new IllegalArgumentException();
/*     */     }
/* 116 */     BigDecimal bd = BigDecimal.valueOf(value);
/* 117 */     bd = bd.setScale(places, RoundingMode.FLOOR);
/* 118 */     return bd.floatValue();
/*     */   }
/*     */   
/*     */   public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map, boolean descending) {
/* 122 */     LinkedList<Map.Entry<K, V>> list = new LinkedList<>(map.entrySet());
/* 123 */     if (descending) {
/* 124 */       list.sort((Comparator)Map.Entry.comparingByValue(Comparator.reverseOrder()));
/*     */     } else {
/* 126 */       list.sort((Comparator)Map.Entry.comparingByValue());
/*     */     } 
/* 128 */     LinkedHashMap<Object, Object> result = new LinkedHashMap<>();
/* 129 */     for (Map.Entry<K, V> entry : list) {
/* 130 */       result.put(entry.getKey(), entry.getValue());
/*     */     }
/* 132 */     return (Map)result;
/*     */   }
/*     */   
/*     */   public static String getTimeOfDay() {
/* 136 */     Calendar c = Calendar.getInstance();
/* 137 */     int timeOfDay = c.get(11);
/* 138 */     if (timeOfDay < 12) {
/* 139 */       return "Good Morning ";
/*     */     }
/* 141 */     if (timeOfDay < 16) {
/* 142 */       return "Good Afternoon ";
/*     */     }
/* 144 */     if (timeOfDay < 21) {
/* 145 */       return "Good Evening ";
/*     */     }
/* 147 */     return "Good Night ";
/*     */   }
/*     */   
/*     */   public static double radToDeg(double rad) {
/* 151 */     return rad * 57.295780181884766D;
/*     */   }
/*     */   
/*     */   public static double degToRad(double deg) {
/* 155 */     return deg * 0.01745329238474369D;
/*     */   }
/*     */   
/*     */   public static double getIncremental(double val, double inc) {
/* 159 */     double one = 1.0D / inc;
/* 160 */     return Math.round(val * one) / one;
/*     */   }
/*     */   
/*     */   public static double[] directionSpeed(double speed) {
/* 164 */     float forward = mc.field_71439_g.field_71158_b.field_192832_b;
/* 165 */     float side = mc.field_71439_g.field_71158_b.field_78902_a;
/* 166 */     float yaw = mc.field_71439_g.field_70126_B + (mc.field_71439_g.field_70177_z - mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
/* 167 */     if (forward != 0.0F) {
/* 168 */       if (side > 0.0F) {
/* 169 */         yaw += ((forward > 0.0F) ? -45 : 45);
/* 170 */       } else if (side < 0.0F) {
/* 171 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*     */       } 
/* 173 */       side = 0.0F;
/* 174 */       if (forward > 0.0F) {
/* 175 */         forward = 1.0F;
/* 176 */       } else if (forward < 0.0F) {
/* 177 */         forward = -1.0F;
/*     */       } 
/*     */     } 
/* 180 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/* 181 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 182 */     double posX = forward * speed * cos + side * speed * sin;
/* 183 */     double posZ = forward * speed * sin - side * speed * cos;
/* 184 */     return new double[] { posX, posZ };
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getBlockBlocks(Entity entity) {
/* 188 */     ArrayList<Vec3d> vec3ds = new ArrayList<>();
/* 189 */     AxisAlignedBB bb = entity.func_174813_aQ();
/* 190 */     double y = entity.field_70163_u;
/* 191 */     double minX = round(bb.field_72340_a, 0);
/* 192 */     double minZ = round(bb.field_72339_c, 0);
/* 193 */     double maxX = round(bb.field_72336_d, 0);
/* 194 */     double maxZ = round(bb.field_72334_f, 0);
/* 195 */     if (minX != maxX) {
/* 196 */       Vec3d vec3d1 = new Vec3d(minX, y, minZ);
/* 197 */       Vec3d vec3d2 = new Vec3d(maxX, y, minZ);
/* 198 */       BlockPos pos1 = new BlockPos(vec3d1);
/* 199 */       BlockPos pos2 = new BlockPos(vec3d2);
/* 200 */       if (BlockUtil.isBlockUnSolid(pos1) && BlockUtil.isBlockUnSolid(pos2)) {
/* 201 */         vec3ds.add(vec3d1);
/* 202 */         vec3ds.add(vec3d2);
/*     */       } 
/* 204 */       if (minZ != maxZ) {
/* 205 */         Vec3d vec3d3 = new Vec3d(minX, y, maxZ);
/* 206 */         Vec3d vec3d4 = new Vec3d(maxX, y, maxZ);
/* 207 */         BlockPos pos3 = new BlockPos(vec3d1);
/* 208 */         BlockPos pos4 = new BlockPos(vec3d2);
/* 209 */         if (BlockUtil.isBlockUnSolid(pos3) && BlockUtil.isBlockUnSolid(pos4)) {
/* 210 */           vec3ds.add(vec3d3);
/* 211 */           vec3ds.add(vec3d4);
/* 212 */           return vec3ds;
/*     */         } 
/*     */       } 
/* 215 */       if (vec3ds.isEmpty()) {
/* 216 */         vec3ds.add(entity.func_174791_d());
/*     */       }
/* 218 */       return vec3ds;
/*     */     } 
/* 220 */     if (minZ != maxZ) {
/* 221 */       Vec3d vec3d1 = new Vec3d(minX, y, minZ);
/* 222 */       Vec3d vec3d2 = new Vec3d(minX, y, maxZ);
/* 223 */       BlockPos pos1 = new BlockPos(vec3d1);
/* 224 */       BlockPos pos2 = new BlockPos(vec3d2);
/* 225 */       if (BlockUtil.isBlockUnSolid(pos1) && BlockUtil.isBlockUnSolid(pos2)) {
/* 226 */         vec3ds.add(vec3d1);
/* 227 */         vec3ds.add(vec3d2);
/*     */       } 
/* 229 */       if (vec3ds.isEmpty()) {
/* 230 */         vec3ds.add(entity.func_174791_d());
/*     */       }
/* 232 */       return vec3ds;
/*     */     } 
/* 234 */     vec3ds.add(entity.func_174791_d());
/* 235 */     return vec3ds;
/*     */   }
/*     */   
/*     */   public static boolean areVec3dsAligned(Vec3d vec3d1, Vec3d vec3d2) {
/* 239 */     return areVec3dsAlignedRetarded(vec3d1, vec3d2);
/*     */   }
/*     */   
/*     */   public static boolean areVec3dsAlignedRetarded(Vec3d vec3d1, Vec3d vec3d2) {
/* 243 */     BlockPos pos1 = new BlockPos(vec3d1);
/* 244 */     BlockPos pos2 = new BlockPos(vec3d2.field_72450_a, vec3d1.field_72448_b, vec3d2.field_72449_c);
/* 245 */     return pos1.equals(pos2);
/*     */   }
/*     */   
/*     */   public static float[] calcAngle(Vec3d from, Vec3d to) {
/* 249 */     double difX = to.field_72450_a - from.field_72450_a;
/* 250 */     double difY = (to.field_72448_b - from.field_72448_b) * -1.0D;
/* 251 */     double difZ = to.field_72449_c - from.field_72449_c;
/* 252 */     double dist = MathHelper.func_76133_a(difX * difX + difZ * difZ);
/* 253 */     return new float[] { (float)MathHelper.func_76138_g(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D), (float)MathHelper.func_76138_g(Math.toDegrees(Math.atan2(difY, dist))) };
/*     */   }
/*     */   
/*     */   public static float[] calcAngleNoY(Vec3d from, Vec3d to) {
/* 257 */     double difX = to.field_72450_a - from.field_72450_a;
/* 258 */     double difZ = to.field_72449_c - from.field_72449_c;
/* 259 */     return new float[] { (float)MathHelper.func_76138_g(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D) };
/*     */   }
/*     */   
/*     */   public static Vec3d calculateLine(Vec3d x1, Vec3d x2, double distance) {
/* 263 */     double length = Math.sqrt(multiply(x2.field_72450_a - x1.field_72450_a) + multiply(x2.field_72448_b - x1.field_72448_b) + multiply(x2.field_72449_c - x1.field_72449_c));
/* 264 */     double unitSlopeX = (x2.field_72450_a - x1.field_72450_a) / length;
/* 265 */     double unitSlopeY = (x2.field_72448_b - x1.field_72448_b) / length;
/* 266 */     double unitSlopeZ = (x2.field_72449_c - x1.field_72449_c) / length;
/* 267 */     double x = x1.field_72450_a + unitSlopeX * distance;
/* 268 */     double y = x1.field_72448_b + unitSlopeY * distance;
/* 269 */     double z = x1.field_72449_c + unitSlopeZ * distance;
/* 270 */     return new Vec3d(x, y, z);
/*     */   }
/*     */   
/*     */   public static double multiply(double one) {
/* 274 */     return one * one;
/*     */   }
/*     */   
/*     */   public static Vec3d extrapolatePlayerPosition(EntityPlayer player, int ticks) {
/* 278 */     Vec3d lastPos = new Vec3d(player.field_70142_S, player.field_70137_T, player.field_70136_U);
/* 279 */     Vec3d currentPos = new Vec3d(player.field_70165_t, player.field_70163_u, player.field_70161_v);
/* 280 */     double distance = multiply(player.field_70159_w) + multiply(player.field_70181_x) + multiply(player.field_70179_y);
/* 281 */     Vec3d tempVec = calculateLine(lastPos, currentPos, distance * ticks);
/* 282 */     return new Vec3d(tempVec.field_72450_a, player.field_70163_u, tempVec.field_72449_c);
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\MathUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */