/*    */ package me.earth.phobos.util;
/*    */ import java.io.IOException;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.OpenOption;
/*    */ import java.nio.file.Path;
/*    */ import java.nio.file.Paths;
/*    */ import java.nio.file.StandardOpenOption;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ public class FileUtil {
/*    */   public static boolean appendTextFile(String data, String file) {
/*    */     try {
/* 15 */       Path path = Paths.get(file, new String[0]);
/* 16 */       Files.write(path, Collections.singletonList(data), StandardCharsets.UTF_8, new OpenOption[] { Files.exists(path, new java.nio.file.LinkOption[0]) ? StandardOpenOption.APPEND : StandardOpenOption.CREATE });
/* 17 */     } catch (IOException e) {
/* 18 */       System.out.println("WARNING: Unable to write file: " + file);
/* 19 */       return false;
/*    */     } 
/* 21 */     return true;
/*    */   }
/*    */   
/*    */   public static List<String> readTextFileAllLines(String file) {
/*    */     try {
/* 26 */       Path path = Paths.get(file, new String[0]);
/* 27 */       return Files.readAllLines(path, StandardCharsets.UTF_8);
/* 28 */     } catch (IOException e) {
/* 29 */       System.out.println("WARNING: Unable to read file, creating new file: " + file);
/* 30 */       appendTextFile("", file);
/* 31 */       return Collections.emptyList();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\FileUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */