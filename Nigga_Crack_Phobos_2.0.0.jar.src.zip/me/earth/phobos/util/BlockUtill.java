/*     */ package me.earth.phobos.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class BlockUtill
/*     */ {
/*     */   public static final List blackList;
/*     */   public static final List shulkerList;
/*  21 */   private static final Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*     */   public static IBlockState getState(BlockPos pos) {
/*  24 */     return mc.field_71441_e.func_180495_p(pos);
/*     */   }
/*     */   
/*     */   public static boolean checkForNeighbours(BlockPos blockPos) {
/*  28 */     if (!hasNeighbour(blockPos)) {
/*     */       
/*  30 */       for (EnumFacing side : EnumFacing.values()) {
/*  31 */         BlockPos neighbour = blockPos.func_177972_a(side);
/*  32 */         if (hasNeighbour(neighbour)) {
/*  33 */           return true;
/*     */         }
/*     */       } 
/*  36 */       return false;
/*     */     } 
/*  38 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean hasNeighbour(BlockPos blockPos) {
/*  42 */     for (EnumFacing side : EnumFacing.values()) {
/*  43 */       BlockPos neighbour = blockPos.func_177972_a(side);
/*  44 */       if (!mc.field_71441_e.func_180495_p(neighbour).func_185904_a().func_76222_j()) {
/*  45 */         return true;
/*     */       }
/*     */     } 
/*  48 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Block getBlock(BlockPos pos) {
/*  53 */     return getState(pos).func_177230_c();
/*     */   }
/*     */   
/*     */   public static Block getBlock(double x, double y, double z) {
/*  57 */     return mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
/*     */   }
/*     */   
/*     */   public static boolean canBeClicked(BlockPos pos) {
/*  61 */     return getBlock(pos).func_176209_a(getState(pos), false);
/*     */   }
/*     */   
/*     */   public static void faceVectorPacketInstant(Vec3d vec, Boolean roundAngles) {
/*  65 */     float[] rotations = getNeededRotations2(vec);
/*     */     
/*  67 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(rotations[0], roundAngles.booleanValue() ? MathHelper.func_180184_b((int)rotations[1], 360) : rotations[1], mc.field_71439_g.field_70122_E));
/*     */   }
/*     */   
/*     */   private static float[] getNeededRotations2(Vec3d vec) {
/*  71 */     Vec3d eyesPos = getEyesPos();
/*     */     
/*  73 */     double diffX = vec.field_72450_a - eyesPos.field_72450_a;
/*  74 */     double diffY = vec.field_72448_b - eyesPos.field_72448_b;
/*  75 */     double diffZ = vec.field_72449_c - eyesPos.field_72449_c;
/*     */     
/*  77 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*     */     
/*  79 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/*  80 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/*     */     
/*  82 */     return new float[] { mc.field_71439_g.field_70177_z + 
/*  83 */         MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z), mc.field_71439_g.field_70125_A + 
/*  84 */         MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A) };
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3d getEyesPos() {
/*  89 */     return new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v);
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getCircle(BlockPos loc, int y, float r, boolean hollow) {
/*  93 */     List<BlockPos> circleblocks = new ArrayList<>();
/*  94 */     int cx = loc.func_177958_n();
/*  95 */     int cz = loc.func_177952_p();
/*  96 */     for (int x = cx - (int)r; x <= cx + r; x++) {
/*  97 */       for (int z = cz - (int)r; z <= cz + r; z++) {
/*  98 */         double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z));
/*  99 */         if (dist < (r * r) && (!hollow || dist >= ((r - 1.0F) * (r - 1.0F)))) {
/* 100 */           BlockPos l = new BlockPos(x, y, z);
/* 101 */           circleblocks.add(l);
/*     */         } 
/*     */       } 
/*     */     } 
/* 105 */     return circleblocks;
/*     */   }
/*     */   
/*     */   static {
/* 109 */     blackList = Arrays.asList(new Block[] { Blocks.field_150477_bB, (Block)Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, (Block)Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z });
/* 110 */     shulkerList = Arrays.asList(new Block[] { Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA });
/*     */   }
/*     */ 
/*     */   
/*     */   public static EnumFacing getPlaceableSide(BlockPos pos) {
/* 115 */     for (EnumFacing side : EnumFacing.values()) {
/*     */       
/* 117 */       BlockPos neighbour = pos.func_177972_a(side);
/*     */       
/* 119 */       if (mc.field_71441_e.func_180495_p(neighbour).func_177230_c().func_176209_a(mc.field_71441_e.func_180495_p(neighbour), false)) {
/*     */ 
/*     */ 
/*     */         
/* 123 */         IBlockState blockState = mc.field_71441_e.func_180495_p(neighbour);
/* 124 */         if (!blockState.func_185904_a().func_76222_j()) {
/* 125 */           return side;
/*     */         }
/*     */       } 
/*     */     } 
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static EnumFacing getPlaceableSideExlude(BlockPos pos, EnumFacing excluding) {
/* 134 */     for (EnumFacing side : EnumFacing.values()) {
/*     */       
/* 136 */       if (side != excluding) {
/*     */         
/* 138 */         BlockPos neighbour = pos.func_177972_a(side);
/*     */         
/* 140 */         if (mc.field_71441_e.func_180495_p(neighbour).func_177230_c().func_176209_a(mc.field_71441_e.func_180495_p(neighbour), false)) {
/*     */ 
/*     */ 
/*     */           
/* 144 */           IBlockState blockState = mc.field_71441_e.func_180495_p(neighbour);
/* 145 */           if (!blockState.func_185904_a().func_76222_j()) {
/* 146 */             return side;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3d getCenterOfBlock(double playerX, double playerY, double playerZ) {
/* 156 */     double newX = Math.floor(playerX) + 0.5D;
/* 157 */     double newY = Math.floor(playerY);
/* 158 */     double newZ = Math.floor(playerZ) + 0.5D;
/*     */     
/* 160 */     return new Vec3d(newX, newY, newZ);
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\BlockUtill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */