/*   */ package me.earth.phobos.util;
/*   */ 
/*   */ import net.minecraft.client.Minecraft;
/*   */ 
/*   */ public interface Util {
/* 6 */   public static final Minecraft mc = Minecraft.func_71410_x();
/*   */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */