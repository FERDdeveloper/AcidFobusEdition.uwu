/*      */ package me.earth.phobos.util;
/*      */ import java.awt.Color;
/*      */ import java.nio.FloatBuffer;
/*      */ import java.nio.IntBuffer;
/*      */ import java.util.HashMap;
/*      */ import java.util.Objects;
/*      */ import me.earth.phobos.Phobos;
/*      */ import net.minecraft.block.material.Material;
/*      */ import net.minecraft.block.state.IBlockState;
/*      */ import net.minecraft.client.gui.ScaledResolution;
/*      */ import net.minecraft.client.model.ModelBiped;
/*      */ import net.minecraft.client.renderer.BufferBuilder;
/*      */ import net.minecraft.client.renderer.GlStateManager;
/*      */ import net.minecraft.client.renderer.OpenGlHelper;
/*      */ import net.minecraft.client.renderer.RenderGlobal;
/*      */ import net.minecraft.client.renderer.RenderItem;
/*      */ import net.minecraft.client.renderer.Tessellator;
/*      */ import net.minecraft.client.renderer.culling.Frustum;
/*      */ import net.minecraft.client.renderer.culling.ICamera;
/*      */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*      */ import net.minecraft.client.shader.Framebuffer;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.player.EntityPlayer;
/*      */ import net.minecraft.util.EnumFacing;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.Vec3d;
/*      */ import net.minecraft.world.World;
/*      */ import org.lwjgl.BufferUtils;
/*      */ import org.lwjgl.opengl.EXTFramebufferObject;
/*      */ import org.lwjgl.opengl.GL11;
/*      */ import org.lwjgl.util.glu.GLU;
/*      */ import org.lwjgl.util.glu.Sphere;
/*      */ 
/*      */ public class RenderUtil implements Util {
/*   36 */   private static final Frustum frustrum = new Frustum();
/*   37 */   private static final FloatBuffer screenCoords = BufferUtils.createFloatBuffer(3);
/*   38 */   private static final IntBuffer viewport = BufferUtils.createIntBuffer(16);
/*   39 */   private static final FloatBuffer modelView = BufferUtils.createFloatBuffer(16);
/*   40 */   private static final FloatBuffer projection = BufferUtils.createFloatBuffer(16);
/*   41 */   public static RenderItem itemRender = mc.func_175599_af();
/*   42 */   public static ICamera camera = (ICamera)new Frustum();
/*   43 */   private static boolean depth = GL11.glIsEnabled(2896);
/*   44 */   private static boolean texture = GL11.glIsEnabled(3042);
/*   45 */   private static boolean clean = GL11.glIsEnabled(3553);
/*   46 */   private static boolean bind = GL11.glIsEnabled(2929);
/*   47 */   private static boolean override = GL11.glIsEnabled(2848);
/*      */   
/*      */   public static void drawRectangleCorrectly(int x, int y, int w, int h, int color) {
/*   50 */     GL11.glLineWidth(1.0F);
/*   51 */     Gui.func_73734_a(x, y, x + w, y + h, color);
/*      */   }
/*      */   
/*      */   public static AxisAlignedBB interpolateAxis(AxisAlignedBB bb) {
/*   55 */     return new AxisAlignedBB(bb.field_72340_a - (mc.func_175598_ae()).field_78730_l, bb.field_72338_b - (mc.func_175598_ae()).field_78731_m, bb.field_72339_c - (mc.func_175598_ae()).field_78728_n, bb.field_72336_d - (mc.func_175598_ae()).field_78730_l, bb.field_72337_e - (mc.func_175598_ae()).field_78731_m, bb.field_72334_f - (mc.func_175598_ae()).field_78728_n);
/*      */   }
/*      */   
/*      */   public static void drawTexturedRect(int x, int y, int textureX, int textureY, int width, int height, int zLevel) {
/*   59 */     Tessellator tessellator = Tessellator.func_178181_a();
/*   60 */     BufferBuilder BufferBuilder2 = tessellator.func_178180_c();
/*   61 */     BufferBuilder2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*   62 */     BufferBuilder2.func_181662_b((x + 0), (y + height), zLevel).func_187315_a(((textureX + 0) * 0.00390625F), ((textureY + height) * 0.00390625F)).func_181675_d();
/*   63 */     BufferBuilder2.func_181662_b((x + width), (y + height), zLevel).func_187315_a(((textureX + width) * 0.00390625F), ((textureY + height) * 0.00390625F)).func_181675_d();
/*   64 */     BufferBuilder2.func_181662_b((x + width), (y + 0), zLevel).func_187315_a(((textureX + width) * 0.00390625F), ((textureY + 0) * 0.00390625F)).func_181675_d();
/*   65 */     BufferBuilder2.func_181662_b((x + 0), (y + 0), zLevel).func_187315_a(((textureX + 0) * 0.00390625F), ((textureY + 0) * 0.00390625F)).func_181675_d();
/*   66 */     tessellator.func_78381_a();
/*      */   }
/*      */   
/*      */   public static void drawGradientRect(int x, int y, int w, int h, int startColor, int endColor) {
/*   70 */     float f = (startColor >> 24 & 0xFF) / 255.0F;
/*   71 */     float f1 = (startColor >> 16 & 0xFF) / 255.0F;
/*   72 */     float f2 = (startColor >> 8 & 0xFF) / 255.0F;
/*   73 */     float f3 = (startColor & 0xFF) / 255.0F;
/*   74 */     float f4 = (endColor >> 24 & 0xFF) / 255.0F;
/*   75 */     float f5 = (endColor >> 16 & 0xFF) / 255.0F;
/*   76 */     float f6 = (endColor >> 8 & 0xFF) / 255.0F;
/*   77 */     float f7 = (endColor & 0xFF) / 255.0F;
/*   78 */     GlStateManager.func_179090_x();
/*   79 */     GlStateManager.func_179147_l();
/*   80 */     GlStateManager.func_179118_c();
/*   81 */     GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/*   82 */     GlStateManager.func_179103_j(7425);
/*   83 */     Tessellator tessellator = Tessellator.func_178181_a();
/*   84 */     BufferBuilder vertexbuffer = tessellator.func_178180_c();
/*   85 */     vertexbuffer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
/*   86 */     vertexbuffer.func_181662_b(x + w, y, 0.0D).func_181666_a(f1, f2, f3, f).func_181675_d();
/*   87 */     vertexbuffer.func_181662_b(x, y, 0.0D).func_181666_a(f1, f2, f3, f).func_181675_d();
/*   88 */     vertexbuffer.func_181662_b(x, y + h, 0.0D).func_181666_a(f5, f6, f7, f4).func_181675_d();
/*   89 */     vertexbuffer.func_181662_b(x + w, y + h, 0.0D).func_181666_a(f5, f6, f7, f4).func_181675_d();
/*   90 */     tessellator.func_78381_a();
/*   91 */     GlStateManager.func_179103_j(7424);
/*   92 */     GlStateManager.func_179084_k();
/*   93 */     GlStateManager.func_179141_d();
/*   94 */     GlStateManager.func_179098_w();
/*      */   }
/*      */   
/*      */   public static void drawGradientBlockOutline(BlockPos pos, Color startColor, Color endColor, float linewidth) {
/*   98 */     IBlockState iblockstate = mc.field_71441_e.func_180495_p(pos);
/*   99 */     Vec3d interp = EntityUtil.interpolateEntity((Entity)mc.field_71439_g, mc.func_184121_ak());
/*  100 */     drawGradientBlockOutline(iblockstate.func_185918_c((World)mc.field_71441_e, pos).func_186662_g(0.0020000000949949026D).func_72317_d(-interp.field_72450_a, -interp.field_72448_b, -interp.field_72449_c), startColor, endColor, linewidth);
/*      */   }
/*      */   
/*      */   public static void drawProperGradientBlockOutline(BlockPos pos, Color startColor, Color midColor, Color endColor, float linewidth) {
/*  104 */     IBlockState iblockstate = mc.field_71441_e.func_180495_p(pos);
/*  105 */     Vec3d interp = EntityUtil.interpolateEntity((Entity)mc.field_71439_g, mc.func_184121_ak());
/*  106 */     drawProperGradientBlockOutline(iblockstate.func_185918_c((World)mc.field_71441_e, pos).func_186662_g(0.0020000000949949026D).func_72317_d(-interp.field_72450_a, -interp.field_72448_b, -interp.field_72449_c), startColor, midColor, endColor, linewidth);
/*      */   }
/*      */   
/*      */   public static void drawProperGradientBlockOutline(AxisAlignedBB bb, Color startColor, Color midColor, Color endColor, float linewidth) {
/*  110 */     float red = endColor.getRed() / 255.0F;
/*  111 */     float green = endColor.getGreen() / 255.0F;
/*  112 */     float blue = endColor.getBlue() / 255.0F;
/*  113 */     float alpha = endColor.getAlpha() / 255.0F;
/*  114 */     float red1 = midColor.getRed() / 255.0F;
/*  115 */     float green1 = midColor.getGreen() / 255.0F;
/*  116 */     float blue1 = midColor.getBlue() / 255.0F;
/*  117 */     float alpha1 = midColor.getAlpha() / 255.0F;
/*  118 */     float red2 = startColor.getRed() / 255.0F;
/*  119 */     float green2 = startColor.getGreen() / 255.0F;
/*  120 */     float blue2 = startColor.getBlue() / 255.0F;
/*  121 */     float alpha2 = startColor.getAlpha() / 255.0F;
/*  122 */     double dif = (bb.field_72337_e - bb.field_72338_b) / 2.0D;
/*  123 */     GlStateManager.func_179094_E();
/*  124 */     GlStateManager.func_179147_l();
/*  125 */     GlStateManager.func_179097_i();
/*  126 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  127 */     GlStateManager.func_179090_x();
/*  128 */     GlStateManager.func_179132_a(false);
/*  129 */     GL11.glEnable(2848);
/*  130 */     GL11.glHint(3154, 4354);
/*  131 */     GL11.glLineWidth(linewidth);
/*  132 */     GL11.glBegin(1);
/*  133 */     GL11.glColor4d(red, green, blue, alpha);
/*  134 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c);
/*  135 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c);
/*  136 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c);
/*  137 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f);
/*  138 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f);
/*  139 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f);
/*  140 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f);
/*  141 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c);
/*  142 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c);
/*  143 */     GL11.glColor4d(red1, green1, blue1, alpha1);
/*  144 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b + dif, bb.field_72339_c);
/*  145 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b + dif, bb.field_72339_c);
/*  146 */     GL11.glColor4f(red2, green2, blue2, alpha2);
/*  147 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c);
/*  148 */     GL11.glColor4d(red, green, blue, alpha);
/*  149 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f);
/*  150 */     GL11.glColor4d(red1, green1, blue1, alpha1);
/*  151 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b + dif, bb.field_72334_f);
/*  152 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b + dif, bb.field_72334_f);
/*  153 */     GL11.glColor4d(red2, green2, blue2, alpha2);
/*  154 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f);
/*  155 */     GL11.glColor4d(red, green, blue, alpha);
/*  156 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f);
/*  157 */     GL11.glColor4d(red1, green1, blue1, alpha1);
/*  158 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b + dif, bb.field_72334_f);
/*  159 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b + dif, bb.field_72334_f);
/*  160 */     GL11.glColor4d(red2, green2, blue2, alpha2);
/*  161 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f);
/*  162 */     GL11.glColor4d(red, green, blue, alpha);
/*  163 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c);
/*  164 */     GL11.glColor4d(red1, green1, blue1, alpha1);
/*  165 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b + dif, bb.field_72339_c);
/*  166 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b + dif, bb.field_72339_c);
/*  167 */     GL11.glColor4d(red2, green2, blue2, alpha2);
/*  168 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c);
/*  169 */     GL11.glColor4d(red2, green2, blue2, alpha2);
/*  170 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c);
/*  171 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c);
/*  172 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c);
/*  173 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f);
/*  174 */     GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f);
/*  175 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f);
/*  176 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f);
/*  177 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c);
/*  178 */     GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c);
/*  179 */     GL11.glEnd();
/*  180 */     GL11.glDisable(2848);
/*  181 */     GlStateManager.func_179132_a(true);
/*  182 */     GlStateManager.func_179126_j();
/*  183 */     GlStateManager.func_179098_w();
/*  184 */     GlStateManager.func_179084_k();
/*  185 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawGradientBlockOutline(AxisAlignedBB bb, Color startColor, Color endColor, float linewidth) {
/*  189 */     float red = startColor.getRed() / 255.0F;
/*  190 */     float green = startColor.getGreen() / 255.0F;
/*  191 */     float blue = startColor.getBlue() / 255.0F;
/*  192 */     float alpha = startColor.getAlpha() / 255.0F;
/*  193 */     float red1 = endColor.getRed() / 255.0F;
/*  194 */     float green1 = endColor.getGreen() / 255.0F;
/*  195 */     float blue1 = endColor.getBlue() / 255.0F;
/*  196 */     float alpha1 = endColor.getAlpha() / 255.0F;
/*  197 */     GlStateManager.func_179094_E();
/*  198 */     GlStateManager.func_179147_l();
/*  199 */     GlStateManager.func_179097_i();
/*  200 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  201 */     GlStateManager.func_179090_x();
/*  202 */     GlStateManager.func_179132_a(false);
/*  203 */     GL11.glEnable(2848);
/*  204 */     GL11.glHint(3154, 4354);
/*  205 */     GL11.glLineWidth(linewidth);
/*  206 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  207 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  208 */     bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
/*  209 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  210 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  211 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  212 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  213 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  214 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  215 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  216 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  217 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  218 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  219 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  220 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  221 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  222 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  223 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  224 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  225 */     tessellator.func_78381_a();
/*  226 */     GL11.glDisable(2848);
/*  227 */     GlStateManager.func_179132_a(true);
/*  228 */     GlStateManager.func_179126_j();
/*  229 */     GlStateManager.func_179098_w();
/*  230 */     GlStateManager.func_179084_k();
/*  231 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawGradientFilledBox(BlockPos pos, Color startColor, Color endColor) {
/*  235 */     IBlockState iblockstate = mc.field_71441_e.func_180495_p(pos);
/*  236 */     Vec3d interp = EntityUtil.interpolateEntity((Entity)mc.field_71439_g, mc.func_184121_ak());
/*  237 */     drawGradientFilledBox(iblockstate.func_185918_c((World)mc.field_71441_e, pos).func_186662_g(0.0020000000949949026D).func_72317_d(-interp.field_72450_a, -interp.field_72448_b, -interp.field_72449_c), startColor, endColor);
/*      */   }
/*      */   
/*      */   public static void drawGradientFilledBox(AxisAlignedBB bb, Color startColor, Color endColor) {
/*  241 */     GlStateManager.func_179094_E();
/*  242 */     GlStateManager.func_179147_l();
/*  243 */     GlStateManager.func_179097_i();
/*  244 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  245 */     GlStateManager.func_179090_x();
/*  246 */     GlStateManager.func_179132_a(false);
/*  247 */     float alpha = endColor.getAlpha() / 255.0F;
/*  248 */     float red = endColor.getRed() / 255.0F;
/*  249 */     float green = endColor.getGreen() / 255.0F;
/*  250 */     float blue = endColor.getBlue() / 255.0F;
/*  251 */     float alpha1 = startColor.getAlpha() / 255.0F;
/*  252 */     float red1 = startColor.getRed() / 255.0F;
/*  253 */     float green1 = startColor.getGreen() / 255.0F;
/*  254 */     float blue1 = startColor.getBlue() / 255.0F;
/*  255 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  256 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  257 */     bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
/*  258 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  259 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  260 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  261 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  262 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  263 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  264 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  265 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  266 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  267 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  268 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  269 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  270 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  271 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  272 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  273 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  274 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  275 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  276 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  277 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  278 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  279 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  280 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  281 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  282 */     tessellator.func_78381_a();
/*  283 */     GlStateManager.func_179132_a(true);
/*  284 */     GlStateManager.func_179126_j();
/*  285 */     GlStateManager.func_179098_w();
/*  286 */     GlStateManager.func_179084_k();
/*  287 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawGradientRect(float x, float y, float w, float h, int startColor, int endColor) {
/*  291 */     float f = (startColor >> 24 & 0xFF) / 255.0F;
/*  292 */     float f1 = (startColor >> 16 & 0xFF) / 255.0F;
/*  293 */     float f2 = (startColor >> 8 & 0xFF) / 255.0F;
/*  294 */     float f3 = (startColor & 0xFF) / 255.0F;
/*  295 */     float f4 = (endColor >> 24 & 0xFF) / 255.0F;
/*  296 */     float f5 = (endColor >> 16 & 0xFF) / 255.0F;
/*  297 */     float f6 = (endColor >> 8 & 0xFF) / 255.0F;
/*  298 */     float f7 = (endColor & 0xFF) / 255.0F;
/*  299 */     GlStateManager.func_179090_x();
/*  300 */     GlStateManager.func_179147_l();
/*  301 */     GlStateManager.func_179118_c();
/*  302 */     GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/*  303 */     GlStateManager.func_179103_j(7425);
/*  304 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  305 */     BufferBuilder vertexbuffer = tessellator.func_178180_c();
/*  306 */     vertexbuffer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
/*  307 */     vertexbuffer.func_181662_b(x + w, y, 0.0D).func_181666_a(f1, f2, f3, f).func_181675_d();
/*  308 */     vertexbuffer.func_181662_b(x, y, 0.0D).func_181666_a(f1, f2, f3, f).func_181675_d();
/*  309 */     vertexbuffer.func_181662_b(x, y + h, 0.0D).func_181666_a(f5, f6, f7, f4).func_181675_d();
/*  310 */     vertexbuffer.func_181662_b(x + w, y + h, 0.0D).func_181666_a(f5, f6, f7, f4).func_181675_d();
/*  311 */     tessellator.func_78381_a();
/*  312 */     GlStateManager.func_179103_j(7424);
/*  313 */     GlStateManager.func_179084_k();
/*  314 */     GlStateManager.func_179141_d();
/*  315 */     GlStateManager.func_179098_w();
/*      */   }
/*      */   
/*      */   public static void blockESP(BlockPos b, Color c, double length, double length2) {
/*  319 */     blockEsp(b, c, length, length2);
/*      */   }
/*      */   
/*      */   public static void drawBoxESP(BlockPos pos, Color color, boolean secondC, Color secondColor, float lineWidth, boolean outline, boolean box, int boxAlpha, boolean air) {
/*  323 */     if (box) {
/*  324 */       drawBox(pos, new Color(color.getRed(), color.getGreen(), color.getBlue(), boxAlpha));
/*      */     }
/*  326 */     if (outline) {
/*  327 */       drawBlockOutline(pos, secondC ? secondColor : color, lineWidth, air);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void drawBoxESP(BlockPos pos, Color color, boolean secondC, Color secondColor, float lineWidth, boolean outline, boolean box, int boxAlpha, boolean air, double height) {
/*  332 */     if (box) {
/*  333 */       drawBox(pos, new Color(color.getRed(), color.getGreen(), color.getBlue(), boxAlpha), height);
/*      */     }
/*  335 */     if (outline) {
/*  336 */       drawBlockOutline(pos, secondC ? secondColor : color, lineWidth, air, height);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void glScissor(float x, float y, float x1, float y1, ScaledResolution sr) {
/*  341 */     GL11.glScissor((int)(x * sr.func_78325_e()), (int)(mc.field_71440_d - y1 * sr.func_78325_e()), (int)((x1 - x) * sr.func_78325_e()), (int)((y1 - y) * sr.func_78325_e()));
/*      */   }
/*      */   
/*      */   public static void drawLine(float x, float y, float x1, float y1, float thickness, int hex) {
/*  345 */     float red = (hex >> 16 & 0xFF) / 255.0F;
/*  346 */     float green = (hex >> 8 & 0xFF) / 255.0F;
/*  347 */     float blue = (hex & 0xFF) / 255.0F;
/*  348 */     float alpha = (hex >> 24 & 0xFF) / 255.0F;
/*  349 */     GlStateManager.func_179094_E();
/*  350 */     GlStateManager.func_179090_x();
/*  351 */     GlStateManager.func_179147_l();
/*  352 */     GlStateManager.func_179118_c();
/*  353 */     GlStateManager.func_179120_a(770, 771, 1, 0);
/*  354 */     GlStateManager.func_179103_j(7425);
/*  355 */     GL11.glLineWidth(thickness);
/*  356 */     GL11.glEnable(2848);
/*  357 */     GL11.glHint(3154, 4354);
/*  358 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  359 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  360 */     bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
/*  361 */     bufferbuilder.func_181662_b(x, y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  362 */     bufferbuilder.func_181662_b(x1, y1, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  363 */     tessellator.func_78381_a();
/*  364 */     GlStateManager.func_179103_j(7424);
/*  365 */     GL11.glDisable(2848);
/*  366 */     GlStateManager.func_179084_k();
/*  367 */     GlStateManager.func_179141_d();
/*  368 */     GlStateManager.func_179098_w();
/*  369 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawBox(BlockPos pos, Color color) {
/*  373 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - (mc.func_175598_ae()).field_78730_l, pos.func_177956_o() - (mc.func_175598_ae()).field_78731_m, pos.func_177952_p() - (mc.func_175598_ae()).field_78728_n, (pos.func_177958_n() + 1) - (mc.func_175598_ae()).field_78730_l, (pos.func_177956_o() + 1) - (mc.func_175598_ae()).field_78731_m, (pos.func_177952_p() + 1) - (mc.func_175598_ae()).field_78728_n);
/*  374 */     camera.func_78547_a(((Entity)Objects.requireNonNull((T)mc.func_175606_aa())).field_70165_t, (mc.func_175606_aa()).field_70163_u, (mc.func_175606_aa()).field_70161_v);
/*  375 */     if (camera.func_78546_a(new AxisAlignedBB(bb.field_72340_a + (mc.func_175598_ae()).field_78730_l, bb.field_72338_b + (mc.func_175598_ae()).field_78731_m, bb.field_72339_c + (mc.func_175598_ae()).field_78728_n, bb.field_72336_d + (mc.func_175598_ae()).field_78730_l, bb.field_72337_e + (mc.func_175598_ae()).field_78731_m, bb.field_72334_f + (mc.func_175598_ae()).field_78728_n))) {
/*  376 */       GlStateManager.func_179094_E();
/*  377 */       GlStateManager.func_179147_l();
/*  378 */       GlStateManager.func_179097_i();
/*  379 */       GlStateManager.func_179120_a(770, 771, 0, 1);
/*  380 */       GlStateManager.func_179090_x();
/*  381 */       GlStateManager.func_179132_a(false);
/*  382 */       GL11.glEnable(2848);
/*  383 */       GL11.glHint(3154, 4354);
/*  384 */       RenderGlobal.func_189696_b(bb, color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*  385 */       GL11.glDisable(2848);
/*  386 */       GlStateManager.func_179132_a(true);
/*  387 */       GlStateManager.func_179126_j();
/*  388 */       GlStateManager.func_179098_w();
/*  389 */       GlStateManager.func_179084_k();
/*  390 */       GlStateManager.func_179121_F();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void drawBetterGradientBox(BlockPos pos, Color startColor, Color endColor) {
/*  395 */     float red = startColor.getRed() / 255.0F;
/*  396 */     float green = startColor.getGreen() / 255.0F;
/*  397 */     float blue = startColor.getBlue() / 255.0F;
/*  398 */     float alpha = startColor.getAlpha() / 255.0F;
/*  399 */     float red1 = endColor.getRed() / 255.0F;
/*  400 */     float green1 = endColor.getGreen() / 255.0F;
/*  401 */     float blue1 = endColor.getBlue() / 255.0F;
/*  402 */     float alpha1 = endColor.getAlpha() / 255.0F;
/*  403 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - (mc.func_175598_ae()).field_78730_l, pos.func_177956_o() - (mc.func_175598_ae()).field_78731_m, pos.func_177952_p() - (mc.func_175598_ae()).field_78728_n, (pos.func_177958_n() + 1) - (mc.func_175598_ae()).field_78730_l, (pos.func_177956_o() + 1) - (mc.func_175598_ae()).field_78731_m, (pos.func_177952_p() + 1) - (mc.func_175598_ae()).field_78728_n);
/*  404 */     double offset = (bb.field_72337_e - bb.field_72338_b) / 2.0D;
/*  405 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  406 */     BufferBuilder builder = tessellator.func_178180_c();
/*  407 */     GlStateManager.func_179094_E();
/*  408 */     GlStateManager.func_179147_l();
/*  409 */     GlStateManager.func_179097_i();
/*  410 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  411 */     GlStateManager.func_179090_x();
/*  412 */     GlStateManager.func_179132_a(false);
/*  413 */     GL11.glEnable(2848);
/*  414 */     GL11.glHint(3154, 4354);
/*  415 */     builder.func_181668_a(5, DefaultVertexFormats.field_181706_f);
/*  416 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  417 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  418 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  419 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  420 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  421 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  422 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  423 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  424 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  425 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  426 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  427 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  428 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  429 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  430 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  431 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  432 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  433 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  434 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  435 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  436 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  437 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  438 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  439 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  440 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  441 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  442 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  443 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  444 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  445 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*      */   }
/*      */   
/*      */   public static void drawBetterGradientBox(BlockPos pos, Color startColor, Color midColor, Color endColor) {
/*  449 */     float red = startColor.getRed() / 255.0F;
/*  450 */     float green = startColor.getGreen() / 255.0F;
/*  451 */     float blue = startColor.getBlue() / 255.0F;
/*  452 */     float alpha = startColor.getAlpha() / 255.0F;
/*  453 */     float red1 = endColor.getRed() / 255.0F;
/*  454 */     float green1 = endColor.getGreen() / 255.0F;
/*  455 */     float blue1 = endColor.getBlue() / 255.0F;
/*  456 */     float alpha1 = endColor.getAlpha() / 255.0F;
/*  457 */     float red2 = midColor.getRed() / 255.0F;
/*  458 */     float green2 = midColor.getGreen() / 255.0F;
/*  459 */     float blue2 = midColor.getBlue() / 255.0F;
/*  460 */     float alpha2 = midColor.getAlpha() / 255.0F;
/*  461 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - (mc.func_175598_ae()).field_78730_l, pos.func_177956_o() - (mc.func_175598_ae()).field_78731_m, pos.func_177952_p() - (mc.func_175598_ae()).field_78728_n, (pos.func_177958_n() + 1) - (mc.func_175598_ae()).field_78730_l, (pos.func_177956_o() + 1) - (mc.func_175598_ae()).field_78731_m, (pos.func_177952_p() + 1) - (mc.func_175598_ae()).field_78728_n);
/*  462 */     double offset = (bb.field_72337_e - bb.field_72338_b) / 2.0D;
/*  463 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  464 */     BufferBuilder builder = tessellator.func_178180_c();
/*  465 */     GlStateManager.func_179094_E();
/*  466 */     GlStateManager.func_179147_l();
/*  467 */     GlStateManager.func_179097_i();
/*  468 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  469 */     GlStateManager.func_179090_x();
/*  470 */     GlStateManager.func_179132_a(false);
/*  471 */     GL11.glEnable(2848);
/*  472 */     GL11.glHint(3154, 4354);
/*  473 */     builder.func_181668_a(5, DefaultVertexFormats.field_181706_f);
/*  474 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  475 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  476 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  477 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  478 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b + offset, bb.field_72339_c).func_181666_a(red2, green2, blue2, alpha2).func_181675_d();
/*  479 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b + offset, bb.field_72334_f).func_181666_a(red2, green2, blue2, alpha2).func_181675_d();
/*  480 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b + offset, bb.field_72334_f).func_181666_a(red2, green2, blue2, alpha2).func_181675_d();
/*  481 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  482 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b + offset, bb.field_72334_f).func_181666_a(red2, green2, blue2, alpha2).func_181675_d();
/*  483 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  484 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b + offset, bb.field_72339_c).func_181666_a(red2, green2, blue2, alpha2).func_181675_d();
/*  485 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b + offset, bb.field_72339_c).func_181666_a(red2, green2, blue2, alpha2).func_181675_d();
/*  486 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b + offset, bb.field_72339_c).func_181666_a(red2, green2, blue2, alpha2).func_181675_d();
/*  487 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b + offset, bb.field_72334_f).func_181666_a(red2, green2, blue2, alpha2).func_181675_d();
/*  488 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  489 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  490 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  491 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b + offset, bb.field_72334_f).func_181666_a(red2, green2, blue2, alpha2).func_181675_d();
/*  492 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  493 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b + offset, bb.field_72334_f).func_181666_a(red2, green2, blue2, alpha2).func_181675_d();
/*  494 */     tessellator.func_78381_a();
/*  495 */     GL11.glDisable(2848);
/*  496 */     GlStateManager.func_179132_a(true);
/*  497 */     GlStateManager.func_179126_j();
/*  498 */     GlStateManager.func_179098_w();
/*  499 */     GlStateManager.func_179084_k();
/*  500 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawEvenBetterGradientBox(BlockPos pos, Color startColor, Color midColor, Color endColor) {
/*  504 */     float red = startColor.getRed() / 255.0F;
/*  505 */     float green = startColor.getGreen() / 255.0F;
/*  506 */     float blue = startColor.getBlue() / 255.0F;
/*  507 */     float alpha = startColor.getAlpha() / 255.0F;
/*  508 */     float red1 = endColor.getRed() / 255.0F;
/*  509 */     float green1 = endColor.getGreen() / 255.0F;
/*  510 */     float blue1 = endColor.getBlue() / 255.0F;
/*  511 */     float alpha1 = endColor.getAlpha() / 255.0F;
/*  512 */     float red2 = midColor.getRed() / 255.0F;
/*  513 */     float green2 = midColor.getGreen() / 255.0F;
/*  514 */     float blue2 = midColor.getBlue() / 255.0F;
/*  515 */     float alpha2 = midColor.getAlpha() / 255.0F;
/*  516 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - (mc.func_175598_ae()).field_78730_l, pos.func_177956_o() - (mc.func_175598_ae()).field_78731_m, pos.func_177952_p() - (mc.func_175598_ae()).field_78728_n, (pos.func_177958_n() + 1) - (mc.func_175598_ae()).field_78730_l, (pos.func_177956_o() + 1) - (mc.func_175598_ae()).field_78731_m, (pos.func_177952_p() + 1) - (mc.func_175598_ae()).field_78728_n);
/*  517 */     double offset = (bb.field_72337_e - bb.field_72338_b) / 2.0D;
/*  518 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  519 */     BufferBuilder builder = tessellator.func_178180_c();
/*  520 */     GlStateManager.func_179094_E();
/*  521 */     GlStateManager.func_179147_l();
/*  522 */     GlStateManager.func_179097_i();
/*  523 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  524 */     GlStateManager.func_179090_x();
/*  525 */     GlStateManager.func_179132_a(false);
/*  526 */     GL11.glEnable(2848);
/*  527 */     GL11.glHint(3154, 4354);
/*  528 */     builder.func_181668_a(5, DefaultVertexFormats.field_181706_f);
/*  529 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  530 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  531 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  532 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  533 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  534 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  535 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  536 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  537 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  538 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  539 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  540 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  541 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  542 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  543 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  544 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  545 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  546 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  547 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  548 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  549 */     builder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  550 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  551 */     builder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
/*  552 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  553 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  554 */     builder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  555 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  556 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  557 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  558 */     builder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  559 */     tessellator.func_78381_a();
/*  560 */     GL11.glDisable(2848);
/*  561 */     GlStateManager.func_179132_a(true);
/*  562 */     GlStateManager.func_179126_j();
/*  563 */     GlStateManager.func_179098_w();
/*  564 */     GlStateManager.func_179084_k();
/*  565 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawBox(BlockPos pos, Color color, double height) {
/*  569 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - (mc.func_175598_ae()).field_78730_l, pos.func_177956_o() - (mc.func_175598_ae()).field_78731_m, pos.func_177952_p() - (mc.func_175598_ae()).field_78728_n, (pos.func_177958_n() + 1) - (mc.func_175598_ae()).field_78730_l, (pos.func_177956_o() + 1) - (mc.func_175598_ae()).field_78731_m + height, (pos.func_177952_p() + 1) - (mc.func_175598_ae()).field_78728_n);
/*  570 */     camera.func_78547_a(((Entity)Objects.requireNonNull((T)mc.func_175606_aa())).field_70165_t, (mc.func_175606_aa()).field_70163_u, (mc.func_175606_aa()).field_70161_v);
/*  571 */     if (camera.func_78546_a(new AxisAlignedBB(bb.field_72340_a + (mc.func_175598_ae()).field_78730_l, bb.field_72338_b + (mc.func_175598_ae()).field_78731_m, bb.field_72339_c + (mc.func_175598_ae()).field_78728_n, bb.field_72336_d + (mc.func_175598_ae()).field_78730_l, bb.field_72337_e + (mc.func_175598_ae()).field_78731_m, bb.field_72334_f + (mc.func_175598_ae()).field_78728_n))) {
/*  572 */       GlStateManager.func_179094_E();
/*  573 */       GlStateManager.func_179147_l();
/*  574 */       GlStateManager.func_179097_i();
/*  575 */       GlStateManager.func_179120_a(770, 771, 0, 1);
/*  576 */       GlStateManager.func_179090_x();
/*  577 */       GlStateManager.func_179132_a(false);
/*  578 */       GL11.glEnable(2848);
/*  579 */       GL11.glHint(3154, 4354);
/*  580 */       RenderGlobal.func_189696_b(bb, color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*  581 */       GL11.glDisable(2848);
/*  582 */       GlStateManager.func_179132_a(true);
/*  583 */       GlStateManager.func_179126_j();
/*  584 */       GlStateManager.func_179098_w();
/*  585 */       GlStateManager.func_179084_k();
/*  586 */       GlStateManager.func_179121_F();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void drawBlockOutline(BlockPos pos, Color color, float linewidth, boolean air) {
/*  591 */     IBlockState iblockstate = mc.field_71441_e.func_180495_p(pos);
/*  592 */     if ((air || iblockstate.func_185904_a() != Material.field_151579_a) && mc.field_71441_e.func_175723_af().func_177746_a(pos)) {
/*  593 */       Vec3d interp = EntityUtil.interpolateEntity((Entity)mc.field_71439_g, mc.func_184121_ak());
/*  594 */       drawBlockOutline(iblockstate.func_185918_c((World)mc.field_71441_e, pos).func_186662_g(0.0020000000949949026D).func_72317_d(-interp.field_72450_a, -interp.field_72448_b, -interp.field_72449_c), color, linewidth);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void drawBlockOutline(BlockPos pos, Color color, float linewidth, boolean air, double height) {
/*  599 */     IBlockState iblockstate = mc.field_71441_e.func_180495_p(pos);
/*  600 */     if ((air || iblockstate.func_185904_a() != Material.field_151579_a) && mc.field_71441_e.func_175723_af().func_177746_a(pos)) {
/*  601 */       AxisAlignedBB blockAxis = new AxisAlignedBB(pos.func_177958_n() - (mc.func_175598_ae()).field_78730_l, pos.func_177956_o() - (mc.func_175598_ae()).field_78731_m, pos.func_177952_p() - (mc.func_175598_ae()).field_78728_n, (pos.func_177958_n() + 1) - (mc.func_175598_ae()).field_78730_l, (pos.func_177956_o() + 1) - (mc.func_175598_ae()).field_78731_m + height, (pos.func_177952_p() + 1) - (mc.func_175598_ae()).field_78728_n);
/*  602 */       drawBlockOutline(blockAxis.func_186662_g(0.0020000000949949026D), color, linewidth);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void drawBlockOutline(AxisAlignedBB bb, Color color, float linewidth) {
/*  607 */     float red = color.getRed() / 255.0F;
/*  608 */     float green = color.getGreen() / 255.0F;
/*  609 */     float blue = color.getBlue() / 255.0F;
/*  610 */     float alpha = color.getAlpha() / 255.0F;
/*  611 */     GlStateManager.func_179094_E();
/*  612 */     GlStateManager.func_179147_l();
/*  613 */     GlStateManager.func_179097_i();
/*  614 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  615 */     GlStateManager.func_179090_x();
/*  616 */     GlStateManager.func_179132_a(false);
/*  617 */     GL11.glEnable(2848);
/*  618 */     GL11.glHint(3154, 4354);
/*  619 */     GL11.glLineWidth(linewidth);
/*  620 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  621 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  622 */     bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
/*  623 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  624 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  625 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  626 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  627 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  628 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  629 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  630 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  631 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  632 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  633 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  634 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  635 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  636 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  637 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  638 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  639 */     tessellator.func_78381_a();
/*  640 */     GL11.glDisable(2848);
/*  641 */     GlStateManager.func_179132_a(true);
/*  642 */     GlStateManager.func_179126_j();
/*  643 */     GlStateManager.func_179098_w();
/*  644 */     GlStateManager.func_179084_k();
/*  645 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawBoxESP(BlockPos pos, Color color, float lineWidth, boolean outline, boolean box, int boxAlpha) {
/*  649 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - (mc.func_175598_ae()).field_78730_l, pos.func_177956_o() - (mc.func_175598_ae()).field_78731_m, pos.func_177952_p() - (mc.func_175598_ae()).field_78728_n, (pos.func_177958_n() + 1) - (mc.func_175598_ae()).field_78730_l, (pos.func_177956_o() + 1) - (mc.func_175598_ae()).field_78731_m, (pos.func_177952_p() + 1) - (mc.func_175598_ae()).field_78728_n);
/*  650 */     camera.func_78547_a(((Entity)Objects.requireNonNull((T)mc.func_175606_aa())).field_70165_t, (mc.func_175606_aa()).field_70163_u, (mc.func_175606_aa()).field_70161_v);
/*  651 */     if (camera.func_78546_a(new AxisAlignedBB(bb.field_72340_a + (mc.func_175598_ae()).field_78730_l, bb.field_72338_b + (mc.func_175598_ae()).field_78731_m, bb.field_72339_c + (mc.func_175598_ae()).field_78728_n, bb.field_72336_d + (mc.func_175598_ae()).field_78730_l, bb.field_72337_e + (mc.func_175598_ae()).field_78731_m, bb.field_72334_f + (mc.func_175598_ae()).field_78728_n))) {
/*  652 */       GlStateManager.func_179094_E();
/*  653 */       GlStateManager.func_179147_l();
/*  654 */       GlStateManager.func_179097_i();
/*  655 */       GlStateManager.func_179120_a(770, 771, 0, 1);
/*  656 */       GlStateManager.func_179090_x();
/*  657 */       GlStateManager.func_179132_a(false);
/*  658 */       GL11.glEnable(2848);
/*  659 */       GL11.glHint(3154, 4354);
/*  660 */       GL11.glLineWidth(lineWidth);
/*  661 */       double dist = mc.field_71439_g.func_70011_f((pos.func_177958_n() + 0.5F), (pos.func_177956_o() + 0.5F), (pos.func_177952_p() + 0.5F)) * 0.75D;
/*  662 */       if (box) {
/*  663 */         RenderGlobal.func_189696_b(bb, color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, boxAlpha / 255.0F);
/*      */       }
/*  665 */       if (outline) {
/*  666 */         RenderGlobal.func_189694_a(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c, bb.field_72336_d, bb.field_72337_e, bb.field_72334_f, color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*      */       }
/*  668 */       GL11.glDisable(2848);
/*  669 */       GlStateManager.func_179132_a(true);
/*  670 */       GlStateManager.func_179126_j();
/*  671 */       GlStateManager.func_179098_w();
/*  672 */       GlStateManager.func_179084_k();
/*  673 */       GlStateManager.func_179121_F();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void drawText(BlockPos pos, String text) {
/*  678 */     if (pos == null || text == null) {
/*      */       return;
/*      */     }
/*  681 */     GlStateManager.func_179094_E();
/*  682 */     glBillboardDistanceScaled(pos.func_177958_n() + 0.5F, pos.func_177956_o() + 0.5F, pos.func_177952_p() + 0.5F, (EntityPlayer)mc.field_71439_g, 1.0F);
/*  683 */     GlStateManager.func_179097_i();
/*  684 */     GlStateManager.func_179137_b(-(Phobos.textManager.getStringWidth(text) / 2.0D), 0.0D, 0.0D);
/*  685 */     Phobos.textManager.drawStringWithShadow(text, 0.0F, 0.0F, -5592406);
/*  686 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawOutlinedBlockESP(BlockPos pos, Color color, float linewidth) {
/*  690 */     IBlockState iblockstate = mc.field_71441_e.func_180495_p(pos);
/*  691 */     Vec3d interp = EntityUtil.interpolateEntity((Entity)mc.field_71439_g, mc.func_184121_ak());
/*  692 */     drawBoundingBox(iblockstate.func_185918_c((World)mc.field_71441_e, pos).func_186662_g(0.0020000000949949026D).func_72317_d(-interp.field_72450_a, -interp.field_72448_b, -interp.field_72449_c), linewidth, ColorUtil.toRGBA(color));
/*      */   }
/*      */   
/*      */   public static void blockEsp(BlockPos blockPos, Color c, double length, double length2) {
/*  696 */     double x = blockPos.func_177958_n() - mc.field_175616_W.field_78725_b;
/*  697 */     double y = blockPos.func_177956_o() - mc.field_175616_W.field_78726_c;
/*  698 */     double z = blockPos.func_177952_p() - mc.field_175616_W.field_78723_d;
/*  699 */     GL11.glPushMatrix();
/*  700 */     GL11.glBlendFunc(770, 771);
/*  701 */     GL11.glEnable(3042);
/*  702 */     GL11.glLineWidth(2.0F);
/*  703 */     GL11.glDisable(3553);
/*  704 */     GL11.glDisable(2929);
/*  705 */     GL11.glDepthMask(false);
/*  706 */     GL11.glColor4d((c.getRed() / 255.0F), (c.getGreen() / 255.0F), (c.getBlue() / 255.0F), 0.25D);
/*  707 */     drawColorBox(new AxisAlignedBB(x, y, z, x + length2, y + 1.0D, z + length), 0.0F, 0.0F, 0.0F, 0.0F);
/*  708 */     GL11.glColor4d(0.0D, 0.0D, 0.0D, 0.5D);
/*  709 */     drawSelectionBoundingBox(new AxisAlignedBB(x, y, z, x + length2, y + 1.0D, z + length));
/*  710 */     GL11.glLineWidth(2.0F);
/*  711 */     GL11.glEnable(3553);
/*  712 */     GL11.glEnable(2929);
/*  713 */     GL11.glDepthMask(true);
/*  714 */     GL11.glDisable(3042);
/*  715 */     GL11.glPopMatrix();
/*  716 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */   }
/*      */   
/*      */   public static void drawRect(float x, float y, float w, float h, int color) {
/*  720 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/*  721 */     float red = (color >> 16 & 0xFF) / 255.0F;
/*  722 */     float green = (color >> 8 & 0xFF) / 255.0F;
/*  723 */     float blue = (color & 0xFF) / 255.0F;
/*  724 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  725 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  726 */     GlStateManager.func_179147_l();
/*  727 */     GlStateManager.func_179090_x();
/*  728 */     GlStateManager.func_179120_a(770, 771, 1, 0);
/*  729 */     bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
/*  730 */     bufferbuilder.func_181662_b(x, h, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  731 */     bufferbuilder.func_181662_b(w, h, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  732 */     bufferbuilder.func_181662_b(w, y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  733 */     bufferbuilder.func_181662_b(x, y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  734 */     tessellator.func_78381_a();
/*  735 */     GlStateManager.func_179098_w();
/*  736 */     GlStateManager.func_179084_k();
/*      */   }
/*      */   
/*      */   public static void drawColorBox(AxisAlignedBB axisalignedbb, float red, float green, float blue, float alpha) {
/*  740 */     Tessellator ts = Tessellator.func_178181_a();
/*  741 */     BufferBuilder vb = ts.func_178180_c();
/*  742 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  743 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  744 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  745 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  746 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  747 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  748 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  749 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  750 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  751 */     ts.func_78381_a();
/*  752 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  753 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  754 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  755 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  756 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  757 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  758 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  759 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  760 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  761 */     ts.func_78381_a();
/*  762 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  763 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  764 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  765 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  766 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  767 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  768 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  769 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  770 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  771 */     ts.func_78381_a();
/*  772 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  773 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  774 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  775 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  776 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  777 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  778 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  779 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  780 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  781 */     ts.func_78381_a();
/*  782 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  783 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  784 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  785 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  786 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  787 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  788 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  789 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  790 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  791 */     ts.func_78381_a();
/*  792 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  793 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  794 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  795 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  796 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  797 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  798 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  799 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  800 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  801 */     ts.func_78381_a();
/*      */   }
/*      */   
/*      */   public static void drawSelectionBoundingBox(AxisAlignedBB boundingBox) {
/*  805 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  806 */     BufferBuilder vertexbuffer = tessellator.func_178180_c();
/*  807 */     vertexbuffer.func_181668_a(3, DefaultVertexFormats.field_181705_e);
/*  808 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
/*  809 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
/*  810 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
/*  811 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
/*  812 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
/*  813 */     tessellator.func_78381_a();
/*  814 */     vertexbuffer.func_181668_a(3, DefaultVertexFormats.field_181705_e);
/*  815 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
/*  816 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
/*  817 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
/*  818 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
/*  819 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
/*  820 */     tessellator.func_78381_a();
/*  821 */     vertexbuffer.func_181668_a(1, DefaultVertexFormats.field_181705_e);
/*  822 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
/*  823 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
/*  824 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
/*  825 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
/*  826 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
/*  827 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
/*  828 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
/*  829 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
/*  830 */     tessellator.func_78381_a();
/*      */   }
/*      */   
/*      */   public static void glrendermethod() {
/*  834 */     GL11.glEnable(3042);
/*  835 */     GL11.glBlendFunc(770, 771);
/*  836 */     GL11.glEnable(2848);
/*  837 */     GL11.glLineWidth(2.0F);
/*  838 */     GL11.glDisable(3553);
/*  839 */     GL11.glEnable(2884);
/*  840 */     GL11.glDisable(2929);
/*  841 */     double viewerPosX = (mc.func_175598_ae()).field_78730_l;
/*  842 */     double viewerPosY = (mc.func_175598_ae()).field_78731_m;
/*  843 */     double viewerPosZ = (mc.func_175598_ae()).field_78728_n;
/*  844 */     GL11.glPushMatrix();
/*  845 */     GL11.glTranslated(-viewerPosX, -viewerPosY, -viewerPosZ);
/*      */   }
/*      */   
/*      */   public static void glStart(float n, float n2, float n3, float n4) {
/*  849 */     glrendermethod();
/*  850 */     GL11.glColor4f(n, n2, n3, n4);
/*      */   }
/*      */   
/*      */   public static void glEnd() {
/*  854 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  855 */     GL11.glPopMatrix();
/*  856 */     GL11.glEnable(2929);
/*  857 */     GL11.glEnable(3553);
/*  858 */     GL11.glDisable(3042);
/*  859 */     GL11.glDisable(2848);
/*      */   }
/*      */   
/*      */   public static AxisAlignedBB getBoundingBox(BlockPos blockPos) {
/*  863 */     return mc.field_71441_e.func_180495_p(blockPos).func_185900_c((IBlockAccess)mc.field_71441_e, blockPos).func_186670_a(blockPos);
/*      */   }
/*      */   
/*      */   public static void drawOutlinedBox(AxisAlignedBB axisAlignedBB) {
/*  867 */     GL11.glBegin(1);
/*  868 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  869 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  870 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  871 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  872 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  873 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  874 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  875 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  876 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  877 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  878 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  879 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  880 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  881 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  882 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  883 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  884 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  885 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  886 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  887 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  888 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  889 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  890 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  891 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  892 */     GL11.glEnd();
/*      */   }
/*      */   
/*      */   public static void drawFilledBoxESPN(BlockPos pos, Color color) {
/*  896 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - (mc.func_175598_ae()).field_78730_l, pos.func_177956_o() - (mc.func_175598_ae()).field_78731_m, pos.func_177952_p() - (mc.func_175598_ae()).field_78728_n, (pos.func_177958_n() + 1) - (mc.func_175598_ae()).field_78730_l, (pos.func_177956_o() + 1) - (mc.func_175598_ae()).field_78731_m, (pos.func_177952_p() + 1) - (mc.func_175598_ae()).field_78728_n);
/*  897 */     int rgba = ColorUtil.toRGBA(color);
/*  898 */     drawFilledBox(bb, rgba);
/*      */   }
/*      */   
/*      */   public static void drawFilledBox(AxisAlignedBB bb, int color) {
/*  902 */     GlStateManager.func_179094_E();
/*  903 */     GlStateManager.func_179147_l();
/*  904 */     GlStateManager.func_179097_i();
/*  905 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  906 */     GlStateManager.func_179090_x();
/*  907 */     GlStateManager.func_179132_a(false);
/*  908 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/*  909 */     float red = (color >> 16 & 0xFF) / 255.0F;
/*  910 */     float green = (color >> 8 & 0xFF) / 255.0F;
/*  911 */     float blue = (color & 0xFF) / 255.0F;
/*  912 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  913 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  914 */     bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
/*  915 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  916 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  917 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  918 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  919 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  920 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  921 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  922 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  923 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  924 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  925 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  926 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  927 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  928 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  929 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  930 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  931 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  932 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  933 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  934 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  935 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  936 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  937 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  938 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  939 */     tessellator.func_78381_a();
/*  940 */     GlStateManager.func_179132_a(true);
/*  941 */     GlStateManager.func_179126_j();
/*  942 */     GlStateManager.func_179098_w();
/*  943 */     GlStateManager.func_179084_k();
/*  944 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawBoundingBox(AxisAlignedBB bb, float width, int color) {
/*  948 */     GlStateManager.func_179094_E();
/*  949 */     GlStateManager.func_179147_l();
/*  950 */     GlStateManager.func_179097_i();
/*  951 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  952 */     GlStateManager.func_179090_x();
/*  953 */     GlStateManager.func_179132_a(false);
/*  954 */     GL11.glEnable(2848);
/*  955 */     GL11.glHint(3154, 4354);
/*  956 */     GL11.glLineWidth(width);
/*  957 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/*  958 */     float red = (color >> 16 & 0xFF) / 255.0F;
/*  959 */     float green = (color >> 8 & 0xFF) / 255.0F;
/*  960 */     float blue = (color & 0xFF) / 255.0F;
/*  961 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  962 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  963 */     bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
/*  964 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  965 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  966 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  967 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  968 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  969 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  970 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  971 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  972 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  973 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  974 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  975 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  976 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  977 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  978 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  979 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  980 */     tessellator.func_78381_a();
/*  981 */     GL11.glDisable(2848);
/*  982 */     GlStateManager.func_179132_a(true);
/*  983 */     GlStateManager.func_179126_j();
/*  984 */     GlStateManager.func_179098_w();
/*  985 */     GlStateManager.func_179084_k();
/*  986 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void glBillboard(float x, float y, float z) {
/*  990 */     float scale = 0.02666667F;
/*  991 */     GlStateManager.func_179137_b(x - (mc.func_175598_ae()).field_78725_b, y - (mc.func_175598_ae()).field_78726_c, z - (mc.func_175598_ae()).field_78723_d);
/*  992 */     GlStateManager.func_187432_a(0.0F, 1.0F, 0.0F);
/*  993 */     GlStateManager.func_179114_b(-mc.field_71439_g.field_70177_z, 0.0F, 1.0F, 0.0F);
/*  994 */     GlStateManager.func_179114_b(mc.field_71439_g.field_70125_A, (mc.field_71474_y.field_74320_O == 2) ? -1.0F : 1.0F, 0.0F, 0.0F);
/*  995 */     GlStateManager.func_179152_a(-scale, -scale, scale);
/*      */   }
/*      */   
/*      */   public static void glBillboardDistanceScaled(float x, float y, float z, EntityPlayer player, float scale) {
/*  999 */     glBillboard(x, y, z);
/* 1000 */     int distance = (int)player.func_70011_f(x, y, z);
/* 1001 */     float scaleDistance = distance / 2.0F / (2.0F + 2.0F - scale);
/* 1002 */     if (scaleDistance < 1.0F) {
/* 1003 */       scaleDistance = 1.0F;
/*      */     }
/* 1005 */     GlStateManager.func_179152_a(scaleDistance, scaleDistance, scaleDistance);
/*      */   }
/*      */   
/*      */   public static void drawColoredBoundingBox(AxisAlignedBB bb, float width, float red, float green, float blue, float alpha) {
/* 1009 */     GlStateManager.func_179094_E();
/* 1010 */     GlStateManager.func_179147_l();
/* 1011 */     GlStateManager.func_179097_i();
/* 1012 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/* 1013 */     GlStateManager.func_179090_x();
/* 1014 */     GlStateManager.func_179132_a(false);
/* 1015 */     GL11.glEnable(2848);
/* 1016 */     GL11.glHint(3154, 4354);
/* 1017 */     GL11.glLineWidth(width);
/* 1018 */     Tessellator tessellator = Tessellator.func_178181_a();
/* 1019 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/* 1020 */     bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
/* 1021 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, 0.0F).func_181675_d();
/* 1022 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1023 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1024 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1025 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1026 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1027 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1028 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1029 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1030 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1031 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1032 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, 0.0F).func_181675_d();
/* 1033 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1034 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, 0.0F).func_181675_d();
/* 1035 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1036 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, 0.0F).func_181675_d();
/* 1037 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1038 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, 0.0F).func_181675_d();
/* 1039 */     tessellator.func_78381_a();
/* 1040 */     GL11.glDisable(2848);
/* 1041 */     GlStateManager.func_179132_a(true);
/* 1042 */     GlStateManager.func_179126_j();
/* 1043 */     GlStateManager.func_179098_w();
/* 1044 */     GlStateManager.func_179084_k();
/* 1045 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawSphere(double x, double y, double z, float size, int slices, int stacks) {
/* 1049 */     Sphere s = new Sphere();
/* 1050 */     GL11.glPushMatrix();
/* 1051 */     GL11.glBlendFunc(770, 771);
/* 1052 */     GL11.glEnable(3042);
/* 1053 */     GL11.glLineWidth(1.2F);
/* 1054 */     GL11.glDisable(3553);
/* 1055 */     GL11.glDisable(2929);
/* 1056 */     GL11.glDepthMask(false);
/* 1057 */     s.setDrawStyle(100013);
/* 1058 */     GL11.glTranslated(x - mc.field_175616_W.field_78725_b, y - mc.field_175616_W.field_78726_c, z - mc.field_175616_W.field_78723_d);
/* 1059 */     s.draw(size, slices, stacks);
/* 1060 */     GL11.glLineWidth(2.0F);
/* 1061 */     GL11.glEnable(3553);
/* 1062 */     GL11.glEnable(2929);
/* 1063 */     GL11.glDepthMask(true);
/* 1064 */     GL11.glDisable(3042);
/* 1065 */     GL11.glPopMatrix();
/*      */   }
/*      */   
/*      */   public static void GLPre(float lineWidth) {
/* 1069 */     depth = GL11.glIsEnabled(2896);
/* 1070 */     texture = GL11.glIsEnabled(3042);
/* 1071 */     clean = GL11.glIsEnabled(3553);
/* 1072 */     bind = GL11.glIsEnabled(2929);
/* 1073 */     override = GL11.glIsEnabled(2848);
/* 1074 */     GLPre(depth, texture, clean, bind, override, lineWidth);
/*      */   }
/*      */   
/*      */   public static void GlPost() {
/* 1078 */     GLPost(depth, texture, clean, bind, override);
/*      */   }
/*      */   
/*      */   private static void GLPre(boolean depth, boolean texture, boolean clean, boolean bind, boolean override, float lineWidth) {
/* 1082 */     if (depth) {
/* 1083 */       GL11.glDisable(2896);
/*      */     }
/* 1085 */     if (!texture) {
/* 1086 */       GL11.glEnable(3042);
/*      */     }
/* 1088 */     GL11.glLineWidth(lineWidth);
/* 1089 */     if (clean) {
/* 1090 */       GL11.glDisable(3553);
/*      */     }
/* 1092 */     if (bind) {
/* 1093 */       GL11.glDisable(2929);
/*      */     }
/* 1095 */     if (!override) {
/* 1096 */       GL11.glEnable(2848);
/*      */     }
/* 1098 */     GlStateManager.func_187401_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/* 1099 */     GL11.glHint(3154, 4354);
/* 1100 */     GlStateManager.func_179132_a(false);
/*      */   }
/*      */   
/*      */   public static float[][] getBipedRotations(ModelBiped biped) {
/* 1104 */     float[][] rotations = new float[5][];
/* 1105 */     float[] headRotation = { biped.field_78116_c.field_78795_f, biped.field_78116_c.field_78796_g, biped.field_78116_c.field_78808_h };
/* 1106 */     rotations[0] = headRotation;
/* 1107 */     float[] rightArmRotation = { biped.field_178723_h.field_78795_f, biped.field_178723_h.field_78796_g, biped.field_178723_h.field_78808_h };
/* 1108 */     rotations[1] = rightArmRotation;
/* 1109 */     float[] leftArmRotation = { biped.field_178724_i.field_78795_f, biped.field_178724_i.field_78796_g, biped.field_178724_i.field_78808_h };
/* 1110 */     rotations[2] = leftArmRotation;
/* 1111 */     float[] rightLegRotation = { biped.field_178721_j.field_78795_f, biped.field_178721_j.field_78796_g, biped.field_178721_j.field_78808_h };
/* 1112 */     rotations[3] = rightLegRotation;
/* 1113 */     float[] leftLegRotation = { biped.field_178722_k.field_78795_f, biped.field_178722_k.field_78796_g, biped.field_178722_k.field_78808_h };
/* 1114 */     rotations[4] = leftLegRotation;
/* 1115 */     return rotations;
/*      */   }
/*      */   
/*      */   private static void GLPost(boolean depth, boolean texture, boolean clean, boolean bind, boolean override) {
/* 1119 */     GlStateManager.func_179132_a(true);
/* 1120 */     if (!override) {
/* 1121 */       GL11.glDisable(2848);
/*      */     }
/* 1123 */     if (bind) {
/* 1124 */       GL11.glEnable(2929);
/*      */     }
/* 1126 */     if (clean) {
/* 1127 */       GL11.glEnable(3553);
/*      */     }
/* 1129 */     if (!texture) {
/* 1130 */       GL11.glDisable(3042);
/*      */     }
/* 1132 */     if (depth) {
/* 1133 */       GL11.glEnable(2896);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void drawArc(float cx, float cy, float r, float start_angle, float end_angle, int num_segments) {
/* 1138 */     GL11.glBegin(4);
/* 1139 */     int i = (int)(num_segments / 360.0F / start_angle) + 1;
/* 1140 */     while (i <= num_segments / 360.0F / end_angle) {
/* 1141 */       double previousangle = 6.283185307179586D * (i - 1) / num_segments;
/* 1142 */       double angle = 6.283185307179586D * i / num_segments;
/* 1143 */       GL11.glVertex2d(cx, cy);
/* 1144 */       GL11.glVertex2d(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r);
/* 1145 */       GL11.glVertex2d(cx + Math.cos(previousangle) * r, cy + Math.sin(previousangle) * r);
/* 1146 */       i++;
/*      */     } 
/* 1148 */     glEnd();
/*      */   }
/*      */   
/*      */   public static void drawArcOutline(float cx, float cy, float r, float start_angle, float end_angle, int num_segments) {
/* 1152 */     GL11.glBegin(2);
/* 1153 */     int i = (int)(num_segments / 360.0F / start_angle) + 1;
/* 1154 */     while (i <= num_segments / 360.0F / end_angle) {
/* 1155 */       double angle = 6.283185307179586D * i / num_segments;
/* 1156 */       GL11.glVertex2d(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r);
/* 1157 */       i++;
/*      */     } 
/* 1159 */     glEnd();
/*      */   }
/*      */   
/*      */   public static void drawCircleOutline(float x, float y, float radius) {
/* 1163 */     drawCircleOutline(x, y, radius, 0, 360, 40);
/*      */   }
/*      */   
/*      */   public static void drawCircleOutline(float x, float y, float radius, int start, int end, int segments) {
/* 1167 */     drawArcOutline(x, y, radius, start, end, segments);
/*      */   }
/*      */   
/*      */   public static void drawCircle(float x, float y, float radius) {
/* 1171 */     drawCircle(x, y, radius, 0, 360, 64);
/*      */   }
/*      */   
/*      */   public static void drawCircle(float x, float y, float radius, int start, int end, int segments) {
/* 1175 */     drawArc(x, y, radius, start, end, segments);
/*      */   }
/*      */   
/*      */   public static void drawOutlinedRoundedRectangle(int x, int y, int width, int height, float radius, float dR, float dG, float dB, float dA, float outlineWidth) {
/* 1179 */     drawRoundedRectangle(x, y, width, height, radius);
/* 1180 */     GL11.glColor4f(dR, dG, dB, dA);
/* 1181 */     drawRoundedRectangle(x + outlineWidth, y + outlineWidth, width - outlineWidth * 2.0F, height - outlineWidth * 2.0F, radius);
/*      */   }
/*      */   
/*      */   public static void drawRectangle(float x, float y, float width, float height) {
/* 1185 */     GL11.glEnable(3042);
/* 1186 */     GL11.glBlendFunc(770, 771);
/* 1187 */     GL11.glBegin(2);
/* 1188 */     GL11.glVertex2d(width, 0.0D);
/* 1189 */     GL11.glVertex2d(0.0D, 0.0D);
/* 1190 */     GL11.glVertex2d(0.0D, height);
/* 1191 */     GL11.glVertex2d(width, height);
/* 1192 */     glEnd();
/*      */   }
/*      */   
/*      */   public static void drawRectangleXY(float x, float y, float width, float height) {
/* 1196 */     GL11.glEnable(3042);
/* 1197 */     GL11.glBlendFunc(770, 771);
/* 1198 */     GL11.glBegin(2);
/* 1199 */     GL11.glVertex2d((x + width), y);
/* 1200 */     GL11.glVertex2d(x, y);
/* 1201 */     GL11.glVertex2d(x, (y + height));
/* 1202 */     GL11.glVertex2d((x + width), (y + height));
/* 1203 */     glEnd();
/*      */   }
/*      */   
/*      */   public static void drawFilledRectangle(float x, float y, float width, float height) {
/* 1207 */     GL11.glEnable(3042);
/* 1208 */     GL11.glBlendFunc(770, 771);
/* 1209 */     GL11.glBegin(7);
/* 1210 */     GL11.glVertex2d((x + width), y);
/* 1211 */     GL11.glVertex2d(x, y);
/* 1212 */     GL11.glVertex2d(x, (y + height));
/* 1213 */     GL11.glVertex2d((x + width), (y + height));
/* 1214 */     glEnd();
/*      */   }
/*      */   
/*      */   public static Vec3d to2D(double x, double y, double z) {
/* 1218 */     GL11.glGetFloat(2982, modelView);
/* 1219 */     GL11.glGetFloat(2983, projection);
/* 1220 */     GL11.glGetInteger(2978, viewport);
/* 1221 */     boolean result = GLU.gluProject((float)x, (float)y, (float)z, modelView, projection, viewport, screenCoords);
/* 1222 */     if (result) {
/* 1223 */       return new Vec3d(screenCoords.get(0), (Display.getHeight() - screenCoords.get(1)), screenCoords.get(2));
/*      */     }
/* 1225 */     return null;
/*      */   }
/*      */   
/*      */   public static void drawTracerPointer(float x, float y, float size, float widthDiv, float heightDiv, boolean outline, float outlineWidth, int color) {
/* 1229 */     boolean blend = GL11.glIsEnabled(3042);
/* 1230 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/* 1231 */     GL11.glEnable(3042);
/* 1232 */     GL11.glDisable(3553);
/* 1233 */     GL11.glBlendFunc(770, 771);
/* 1234 */     GL11.glEnable(2848);
/* 1235 */     GL11.glPushMatrix();
/* 1236 */     hexColor(color);
/* 1237 */     GL11.glBegin(7);
/* 1238 */     GL11.glVertex2d(x, y);
/* 1239 */     GL11.glVertex2d((x - size / widthDiv), (y + size));
/* 1240 */     GL11.glVertex2d(x, (y + size / heightDiv));
/* 1241 */     GL11.glVertex2d((x + size / widthDiv), (y + size));
/* 1242 */     GL11.glVertex2d(x, y);
/* 1243 */     GL11.glEnd();
/* 1244 */     if (outline) {
/* 1245 */       GL11.glLineWidth(outlineWidth);
/* 1246 */       GL11.glColor4f(0.0F, 0.0F, 0.0F, alpha);
/* 1247 */       GL11.glBegin(2);
/* 1248 */       GL11.glVertex2d(x, y);
/* 1249 */       GL11.glVertex2d((x - size / widthDiv), (y + size));
/* 1250 */       GL11.glVertex2d(x, (y + size / heightDiv));
/* 1251 */       GL11.glVertex2d((x + size / widthDiv), (y + size));
/* 1252 */       GL11.glVertex2d(x, y);
/* 1253 */       GL11.glEnd();
/*      */     } 
/* 1255 */     GL11.glPopMatrix();
/* 1256 */     GL11.glEnable(3553);
/* 1257 */     if (!blend) {
/* 1258 */       GL11.glDisable(3042);
/*      */     }
/* 1260 */     GL11.glDisable(2848);
/*      */   }
/*      */   
/*      */   public static int getRainbow(int speed, int offset, float s, float b) {
/* 1264 */     float hue = (float)((System.currentTimeMillis() + offset) % speed);
/* 1265 */     return Color.getHSBColor(hue /= speed, s, b).getRGB();
/*      */   }
/*      */   
/*      */   public static void hexColor(int hexColor) {
/* 1269 */     float red = (hexColor >> 16 & 0xFF) / 255.0F;
/* 1270 */     float green = (hexColor >> 8 & 0xFF) / 255.0F;
/* 1271 */     float blue = (hexColor & 0xFF) / 255.0F;
/* 1272 */     float alpha = (hexColor >> 24 & 0xFF) / 255.0F;
/* 1273 */     GL11.glColor4f(red, green, blue, alpha);
/*      */   }
/*      */   
/*      */   public static boolean isInViewFrustrum(Entity entity) {
/* 1277 */     return (isInViewFrustrum(entity.func_174813_aQ()) || entity.field_70158_ak);
/*      */   }
/*      */   
/*      */   public static boolean isInViewFrustrum(AxisAlignedBB bb) {
/* 1281 */     Entity current = Minecraft.func_71410_x().func_175606_aa();
/* 1282 */     frustrum.func_78547_a(current.field_70165_t, current.field_70163_u, current.field_70161_v);
/* 1283 */     return frustrum.func_78546_a(bb);
/*      */   }
/*      */   
/*      */   public static void drawRoundedRectangle(float x, float y, float width, float height, float radius) {
/* 1287 */     GL11.glEnable(3042);
/* 1288 */     drawArc(x + width - radius, y + height - radius, radius, 0.0F, 90.0F, 16);
/* 1289 */     drawArc(x + radius, y + height - radius, radius, 90.0F, 180.0F, 16);
/* 1290 */     drawArc(x + radius, y + radius, radius, 180.0F, 270.0F, 16);
/* 1291 */     drawArc(x + width - radius, y + radius, radius, 270.0F, 360.0F, 16);
/* 1292 */     GL11.glBegin(4);
/* 1293 */     GL11.glVertex2d((x + width - radius), y);
/* 1294 */     GL11.glVertex2d((x + radius), y);
/* 1295 */     GL11.glVertex2d((x + width - radius), (y + radius));
/* 1296 */     GL11.glVertex2d((x + width - radius), (y + radius));
/* 1297 */     GL11.glVertex2d((x + radius), y);
/* 1298 */     GL11.glVertex2d((x + radius), (y + radius));
/* 1299 */     GL11.glVertex2d((x + width), (y + radius));
/* 1300 */     GL11.glVertex2d(x, (y + radius));
/* 1301 */     GL11.glVertex2d(x, (y + height - radius));
/* 1302 */     GL11.glVertex2d((x + width), (y + radius));
/* 1303 */     GL11.glVertex2d(x, (y + height - radius));
/* 1304 */     GL11.glVertex2d((x + width), (y + height - radius));
/* 1305 */     GL11.glVertex2d((x + width - radius), (y + height - radius));
/* 1306 */     GL11.glVertex2d((x + radius), (y + height - radius));
/* 1307 */     GL11.glVertex2d((x + width - radius), (y + height));
/* 1308 */     GL11.glVertex2d((x + width - radius), (y + height));
/* 1309 */     GL11.glVertex2d((x + radius), (y + height - radius));
/* 1310 */     GL11.glVertex2d((x + radius), (y + height));
/* 1311 */     glEnd();
/*      */   }
/*      */   
/*      */   public static void renderOne(float lineWidth) {
/* 1315 */     checkSetupFBO();
/* 1316 */     GL11.glPushAttrib(1048575);
/* 1317 */     GL11.glDisable(3008);
/* 1318 */     GL11.glDisable(3553);
/* 1319 */     GL11.glDisable(2896);
/* 1320 */     GL11.glEnable(3042);
/* 1321 */     GL11.glBlendFunc(770, 771);
/* 1322 */     GL11.glLineWidth(lineWidth);
/* 1323 */     GL11.glEnable(2848);
/* 1324 */     GL11.glEnable(2960);
/* 1325 */     GL11.glClear(1024);
/* 1326 */     GL11.glClearStencil(15);
/* 1327 */     GL11.glStencilFunc(512, 1, 15);
/* 1328 */     GL11.glStencilOp(7681, 7681, 7681);
/* 1329 */     GL11.glPolygonMode(1032, 6913);
/*      */   }
/*      */   
/*      */   public static void renderTwo() {
/* 1333 */     GL11.glStencilFunc(512, 0, 15);
/* 1334 */     GL11.glStencilOp(7681, 7681, 7681);
/* 1335 */     GL11.glPolygonMode(1032, 6914);
/*      */   }
/*      */   
/*      */   public static void renderThree() {
/* 1339 */     GL11.glStencilFunc(514, 1, 15);
/* 1340 */     GL11.glStencilOp(7680, 7680, 7680);
/* 1341 */     GL11.glPolygonMode(1032, 6913);
/*      */   }
/*      */   
/*      */   public static void renderFour(Color color) {
/* 1345 */     setColor(color);
/* 1346 */     GL11.glDepthMask(false);
/* 1347 */     GL11.glDisable(2929);
/* 1348 */     GL11.glEnable(10754);
/* 1349 */     GL11.glPolygonOffset(1.0F, -2000000.0F);
/* 1350 */     OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, 240.0F, 240.0F);
/*      */   }
/*      */   
/*      */   public static void renderFive() {
/* 1354 */     GL11.glPolygonOffset(1.0F, 2000000.0F);
/* 1355 */     GL11.glDisable(10754);
/* 1356 */     GL11.glEnable(2929);
/* 1357 */     GL11.glDepthMask(true);
/* 1358 */     GL11.glDisable(2960);
/* 1359 */     GL11.glDisable(2848);
/* 1360 */     GL11.glHint(3154, 4352);
/* 1361 */     GL11.glEnable(3042);
/* 1362 */     GL11.glEnable(2896);
/* 1363 */     GL11.glEnable(3553);
/* 1364 */     GL11.glEnable(3008);
/* 1365 */     GL11.glPopAttrib();
/*      */   }
/*      */   
/*      */   public static void setColor(Color color) {
/* 1369 */     GL11.glColor4d(color.getRed() / 255.0D, color.getGreen() / 255.0D, color.getBlue() / 255.0D, color.getAlpha() / 255.0D);
/*      */   }
/*      */   
/*      */   public static void checkSetupFBO() {
/* 1373 */     Framebuffer fbo = mc.field_147124_at;
/* 1374 */     if (fbo != null && fbo.field_147624_h > -1) {
/* 1375 */       setupFBO(fbo);
/* 1376 */       fbo.field_147624_h = -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void setupFBO(Framebuffer fbo) {
/* 1381 */     EXTFramebufferObject.glDeleteRenderbuffersEXT(fbo.field_147624_h);
/* 1382 */     int stencilDepthBufferID = EXTFramebufferObject.glGenRenderbuffersEXT();
/* 1383 */     EXTFramebufferObject.glBindRenderbufferEXT(36161, stencilDepthBufferID);
/* 1384 */     EXTFramebufferObject.glRenderbufferStorageEXT(36161, 34041, mc.field_71443_c, mc.field_71440_d);
/* 1385 */     EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36128, 36161, stencilDepthBufferID);
/* 1386 */     EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36096, 36161, stencilDepthBufferID);
/*      */   }
/*      */   
/*      */   public static class RenderTesselator
/*      */     extends Tessellator {
/* 1391 */     public static RenderTesselator INSTANCE = new RenderTesselator();
/*      */     
/*      */     public RenderTesselator() {
/* 1394 */       super(2097152);
/*      */     }
/*      */     
/*      */     public static void prepare(int mode) {
/* 1398 */       prepareGL();
/* 1399 */       begin(mode);
/*      */     }
/*      */     
/*      */     public static void prepareGL() {
/* 1403 */       GL11.glBlendFunc(770, 771);
/* 1404 */       GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 1405 */       GlStateManager.func_187441_d(1.5F);
/* 1406 */       GlStateManager.func_179090_x();
/* 1407 */       GlStateManager.func_179132_a(false);
/* 1408 */       GlStateManager.func_179147_l();
/* 1409 */       GlStateManager.func_179097_i();
/* 1410 */       GlStateManager.func_179140_f();
/* 1411 */       GlStateManager.func_179129_p();
/* 1412 */       GlStateManager.func_179141_d();
/* 1413 */       GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
/*      */     }
/*      */     
/*      */     public static void begin(int mode) {
/* 1417 */       INSTANCE.func_178180_c().func_181668_a(mode, DefaultVertexFormats.field_181706_f);
/*      */     }
/*      */     
/*      */     public static void release() {
/* 1421 */       render();
/* 1422 */       releaseGL();
/*      */     }
/*      */     
/*      */     public static void render() {
/* 1426 */       INSTANCE.func_78381_a();
/*      */     }
/*      */     
/*      */     public static void releaseGL() {
/* 1430 */       GlStateManager.func_179089_o();
/* 1431 */       GlStateManager.func_179132_a(true);
/* 1432 */       GlStateManager.func_179098_w();
/* 1433 */       GlStateManager.func_179147_l();
/* 1434 */       GlStateManager.func_179126_j();
/*      */     }
/*      */     
/*      */     public static void drawBox(BlockPos blockPos, int argb, int sides) {
/* 1438 */       int a = argb >>> 24 & 0xFF;
/* 1439 */       int r = argb >>> 16 & 0xFF;
/* 1440 */       int g = argb >>> 8 & 0xFF;
/* 1441 */       int b = argb & 0xFF;
/* 1442 */       drawBox(blockPos, r, g, b, a, sides);
/*      */     }
/*      */     
/*      */     public static void drawBox(float x, float y, float z, int argb, int sides) {
/* 1446 */       int a = argb >>> 24 & 0xFF;
/* 1447 */       int r = argb >>> 16 & 0xFF;
/* 1448 */       int g = argb >>> 8 & 0xFF;
/* 1449 */       int b = argb & 0xFF;
/* 1450 */       drawBox(INSTANCE.func_178180_c(), x, y, z, 1.0F, 1.0F, 1.0F, r, g, b, a, sides);
/*      */     }
/*      */     
/*      */     public static void drawBox(BlockPos blockPos, int r, int g, int b, int a, int sides) {
/* 1454 */       drawBox(INSTANCE.func_178180_c(), blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), 1.0F, 1.0F, 1.0F, r, g, b, a, sides);
/*      */     }
/*      */     
/*      */     public static BufferBuilder getBufferBuilder() {
/* 1458 */       return INSTANCE.func_178180_c();
/*      */     }
/*      */     
/*      */     public static void drawBox(BufferBuilder buffer, float x, float y, float z, float w, float h, float d, int r, int g, int b, int a, int sides) {
/* 1462 */       if ((sides & 0x1) != 0) {
/* 1463 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1464 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1465 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1466 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1468 */       if ((sides & 0x2) != 0) {
/* 1469 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1470 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1471 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1472 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1474 */       if ((sides & 0x4) != 0) {
/* 1475 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1476 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1477 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1478 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1480 */       if ((sides & 0x8) != 0) {
/* 1481 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1482 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1483 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1484 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1486 */       if ((sides & 0x10) != 0) {
/* 1487 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1488 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1489 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1490 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1492 */       if ((sides & 0x20) != 0) {
/* 1493 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1494 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1495 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1496 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/*      */     }
/*      */     
/*      */     public static void drawLines(BufferBuilder buffer, float x, float y, float z, float w, float h, float d, int r, int g, int b, int a, int sides) {
/* 1501 */       if ((sides & 0x11) != 0) {
/* 1502 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1503 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1505 */       if ((sides & 0x12) != 0) {
/* 1506 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1507 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1509 */       if ((sides & 0x21) != 0) {
/* 1510 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1511 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1513 */       if ((sides & 0x22) != 0) {
/* 1514 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1515 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1517 */       if ((sides & 0x5) != 0) {
/* 1518 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1519 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1521 */       if ((sides & 0x6) != 0) {
/* 1522 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1523 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1525 */       if ((sides & 0x9) != 0) {
/* 1526 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1527 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1529 */       if ((sides & 0xA) != 0) {
/* 1530 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1531 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1533 */       if ((sides & 0x14) != 0) {
/* 1534 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1535 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1537 */       if ((sides & 0x24) != 0) {
/* 1538 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1539 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1541 */       if ((sides & 0x18) != 0) {
/* 1542 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1543 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1545 */       if ((sides & 0x28) != 0) {
/* 1546 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1547 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/*      */     }
/*      */     
/*      */     public static void drawBoundingBox(AxisAlignedBB bb, float width, float red, float green, float blue, float alpha) {
/* 1552 */       GlStateManager.func_179094_E();
/* 1553 */       GlStateManager.func_179147_l();
/* 1554 */       GlStateManager.func_179097_i();
/* 1555 */       GlStateManager.func_179120_a(770, 771, 0, 1);
/* 1556 */       GlStateManager.func_179090_x();
/* 1557 */       GlStateManager.func_179132_a(false);
/* 1558 */       GL11.glEnable(2848);
/* 1559 */       GL11.glHint(3154, 4354);
/* 1560 */       GL11.glLineWidth(width);
/* 1561 */       Tessellator tessellator = Tessellator.func_178181_a();
/* 1562 */       BufferBuilder bufferbuilder = tessellator.func_178180_c();
/* 1563 */       bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
/* 1564 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1565 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1566 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1567 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1568 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1569 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1570 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1571 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1572 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1573 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1574 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1575 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1576 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1577 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1578 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1579 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1580 */       tessellator.func_78381_a();
/* 1581 */       GL11.glDisable(2848);
/* 1582 */       GlStateManager.func_179132_a(true);
/* 1583 */       GlStateManager.func_179126_j();
/* 1584 */       GlStateManager.func_179098_w();
/* 1585 */       GlStateManager.func_179084_k();
/* 1586 */       GlStateManager.func_179121_F();
/*      */     }
/*      */     
/*      */     public static void drawFullBox(AxisAlignedBB bb, BlockPos blockPos, float width, int argb, int alpha2) {
/* 1590 */       int a = argb >>> 24 & 0xFF;
/* 1591 */       int r = argb >>> 16 & 0xFF;
/* 1592 */       int g = argb >>> 8 & 0xFF;
/* 1593 */       int b = argb & 0xFF;
/* 1594 */       drawFullBox(bb, blockPos, width, r, g, b, a, alpha2);
/*      */     }
/*      */     
/*      */     public static void drawFullBox(AxisAlignedBB bb, BlockPos blockPos, float width, int red, int green, int blue, int alpha, int alpha2) {
/* 1598 */       prepare(7);
/* 1599 */       drawBox(blockPos, red, green, blue, alpha, 63);
/* 1600 */       release();
/* 1601 */       drawBoundingBox(bb, width, red, green, blue, alpha2);
/*      */     }
/*      */     
/*      */     public static void drawHalfBox(BlockPos blockPos, int argb, int sides) {
/* 1605 */       int a = argb >>> 24 & 0xFF;
/* 1606 */       int r = argb >>> 16 & 0xFF;
/* 1607 */       int g = argb >>> 8 & 0xFF;
/* 1608 */       int b = argb & 0xFF;
/* 1609 */       drawHalfBox(blockPos, r, g, b, a, sides);
/*      */     }
/*      */     
/*      */     public static void drawHalfBox(BlockPos blockPos, int r, int g, int b, int a, int sides) {
/* 1613 */       drawBox(INSTANCE.func_178180_c(), blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), 1.0F, 0.5F, 1.0F, r, g, b, a, sides);
/*      */     }
/*      */   }
/*      */   
/*      */   public static final class GeometryMasks {
/* 1618 */     public static final HashMap<EnumFacing, Integer> FACEMAP = new HashMap<>();
/*      */     
/*      */     static {
/* 1621 */       FACEMAP.put(EnumFacing.DOWN, Integer.valueOf(1));
/* 1622 */       FACEMAP.put(EnumFacing.WEST, Integer.valueOf(16));
/* 1623 */       FACEMAP.put(EnumFacing.NORTH, Integer.valueOf(4));
/* 1624 */       FACEMAP.put(EnumFacing.SOUTH, Integer.valueOf(8));
/* 1625 */       FACEMAP.put(EnumFacing.EAST, Integer.valueOf(32));
/* 1626 */       FACEMAP.put(EnumFacing.UP, Integer.valueOf(2));
/*      */     }
/*      */     
/*      */     public static final class Line {
/*      */       public static final int DOWN_WEST = 17;
/*      */       public static final int UP_WEST = 18;
/*      */       public static final int DOWN_EAST = 33;
/*      */       public static final int UP_EAST = 34;
/*      */       public static final int DOWN_NORTH = 5;
/*      */       public static final int UP_NORTH = 6;
/*      */       public static final int DOWN_SOUTH = 9;
/*      */       public static final int UP_SOUTH = 10;
/*      */       public static final int NORTH_WEST = 20;
/*      */       public static final int NORTH_EAST = 36;
/*      */       public static final int SOUTH_WEST = 24;
/*      */       public static final int SOUTH_EAST = 40;
/*      */       public static final int ALL = 63;
/*      */     }
/*      */     
/*      */     public static final class Quad {
/*      */       public static final int DOWN = 1;
/*      */       public static final int UP = 2;
/*      */       public static final int NORTH = 4;
/*      */       public static final int SOUTH = 8;
/*      */       public static final int WEST = 16;
/*      */       public static final int EAST = 32;
/*      */       public static final int ALL = 63;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\RenderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */