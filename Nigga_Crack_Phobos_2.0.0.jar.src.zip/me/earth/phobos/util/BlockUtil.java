/*     */ package me.earth.phobos.util;
/*     */ 
/*     */ import com.google.common.util.concurrent.AtomicDouble;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.stream.Collectors;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.features.command.Command;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketAnimation;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockUtil implements Util {
/*  35 */   public static final List<Block> blackList = Arrays.asList(new Block[] { Blocks.field_150477_bB, (Block)Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, (Block)Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z, Blocks.field_150415_aT, Blocks.field_150381_bn });
/*  36 */   public static final List<Block> shulkerList = Arrays.asList(new Block[] { Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA });
/*  37 */   public static List<Block> unSolidBlocks = Arrays.asList(new Block[] { (Block)Blocks.field_150356_k, Blocks.field_150457_bL, Blocks.field_150433_aE, Blocks.field_150404_cg, Blocks.field_185764_cQ, (Block)Blocks.field_150465_bP, Blocks.field_150457_bL, Blocks.field_150473_bD, (Block)Blocks.field_150479_bC, Blocks.field_150471_bO, Blocks.field_150442_at, Blocks.field_150430_aB, Blocks.field_150468_ap, (Block)Blocks.field_150441_bU, (Block)Blocks.field_150455_bV, (Block)Blocks.field_150413_aR, (Block)Blocks.field_150416_aS, Blocks.field_150437_az, Blocks.field_150429_aA, (Block)Blocks.field_150488_af, Blocks.field_150350_a, (Block)Blocks.field_150427_aO, Blocks.field_150384_bq, (Block)Blocks.field_150355_j, (Block)Blocks.field_150358_i, (Block)Blocks.field_150353_l, (Block)Blocks.field_150356_k, Blocks.field_150345_g, (Block)Blocks.field_150328_O, (Block)Blocks.field_150327_N, (Block)Blocks.field_150338_P, (Block)Blocks.field_150337_Q, Blocks.field_150464_aj, Blocks.field_150459_bM, Blocks.field_150469_bN, Blocks.field_185773_cZ, (Block)Blocks.field_150436_aH, Blocks.field_150393_bb, Blocks.field_150394_bc, Blocks.field_150392_bi, Blocks.field_150388_bm, Blocks.field_150375_by, Blocks.field_185766_cS, Blocks.field_185765_cR, (Block)Blocks.field_150329_H, (Block)Blocks.field_150330_I, Blocks.field_150395_bd, (Block)Blocks.field_150480_ab, Blocks.field_150448_aq, Blocks.field_150408_cc, Blocks.field_150319_E, Blocks.field_150318_D, Blocks.field_150478_aa });
/*     */ 
/*     */   
/*     */   public static List<BlockPos> getBlockSphere(float breakRange, Class clazz) {
/*  41 */     NonNullList positions = NonNullList.func_191196_a();
/*  42 */     positions.addAll((Collection)getSphere(EntityUtil.getPlayerPos((EntityPlayer)mc.field_71439_g), breakRange, (int)breakRange, false, true, 0).stream().filter(pos -> clazz.isInstance(mc.field_71441_e.func_180495_p(pos).func_177230_c())).collect(Collectors.toList()));
/*  43 */     return (List<BlockPos>)positions;
/*     */   }
/*     */   
/*     */   public static List<EnumFacing> getPossibleSides(BlockPos pos) {
/*  47 */     ArrayList<EnumFacing> facings = new ArrayList<>();
/*  48 */     if (mc.field_71441_e == null || pos == null) {
/*  49 */       return facings;
/*     */     }
/*  51 */     for (EnumFacing side : EnumFacing.values()) {
/*  52 */       BlockPos neighbour = pos.func_177972_a(side);
/*  53 */       IBlockState blockState = mc.field_71441_e.func_180495_p(neighbour);
/*  54 */       if (blockState != null && blockState.func_177230_c().func_176209_a(blockState, false) && !blockState.func_185904_a().func_76222_j())
/*     */       {
/*  56 */         facings.add(side); } 
/*     */     } 
/*  58 */     return facings;
/*     */   }
/*     */   
/*     */   public static EnumFacing getFirstFacing(BlockPos pos) {
/*  62 */     Iterator<EnumFacing> iterator = getPossibleSides(pos).iterator();
/*  63 */     if (iterator.hasNext()) {
/*  64 */       EnumFacing facing = iterator.next();
/*  65 */       return facing;
/*     */     } 
/*  67 */     return null;
/*     */   }
/*     */   
/*     */   public static EnumFacing getRayTraceFacing(BlockPos pos) {
/*  71 */     RayTraceResult result = mc.field_71441_e.func_72933_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(pos.func_177958_n() + 0.5D, pos.func_177958_n() - 0.5D, pos.func_177958_n() + 0.5D));
/*  72 */     if (result == null || result.field_178784_b == null) {
/*  73 */       return EnumFacing.UP;
/*     */     }
/*  75 */     return result.field_178784_b;
/*     */   }
/*     */   
/*     */   public static int isPositionPlaceable(BlockPos pos, boolean rayTrace) {
/*  79 */     return isPositionPlaceable(pos, rayTrace, true);
/*     */   }
/*     */   
/*     */   public static int isPositionPlaceable(BlockPos pos, boolean rayTrace, boolean entityCheck) {
/*  83 */     Block block = mc.field_71441_e.func_180495_p(pos).func_177230_c();
/*  84 */     if (!(block instanceof net.minecraft.block.BlockAir) && !(block instanceof net.minecraft.block.BlockLiquid) && !(block instanceof net.minecraft.block.BlockTallGrass) && !(block instanceof net.minecraft.block.BlockFire) && !(block instanceof net.minecraft.block.BlockDeadBush) && !(block instanceof net.minecraft.block.BlockSnow)) {
/*  85 */       return 0;
/*     */     }
/*  87 */     if (!rayTracePlaceCheck(pos, rayTrace, 0.0F)) {
/*  88 */       return -1;
/*     */     }
/*  90 */     if (entityCheck) {
/*  91 */       for (Entity entity : mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(pos))) {
/*  92 */         if (entity instanceof net.minecraft.entity.item.EntityItem || entity instanceof net.minecraft.entity.item.EntityXPOrb)
/*  93 */           continue;  return 1;
/*     */       } 
/*     */     }
/*  96 */     for (EnumFacing side : getPossibleSides(pos)) {
/*  97 */       if (!canBeClicked(pos.func_177972_a(side)))
/*  98 */         continue;  return 3;
/*     */     } 
/* 100 */     return 2;
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction, boolean packet) {
/* 104 */     if (packet) {
/* 105 */       float f = (float)(vec.field_72450_a - pos.func_177958_n());
/* 106 */       float f1 = (float)(vec.field_72448_b - pos.func_177956_o());
/* 107 */       float f2 = (float)(vec.field_72449_c - pos.func_177952_p());
/* 108 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2));
/*     */     } else {
/* 110 */       mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, pos, direction, vec, hand);
/*     */     } 
/* 112 */     mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 113 */     mc.field_71467_ac = 4;
/*     */   }
/*     */   
/*     */   public static void rightClickBlockLegit(BlockPos pos, float range, boolean rotate, EnumHand hand, AtomicDouble Yaw2, AtomicDouble Pitch, AtomicBoolean rotating, boolean packet) {
/* 117 */     Vec3d eyesPos = RotationUtil.getEyesPos();
/* 118 */     Vec3d posVec = (new Vec3d((Vec3i)pos)).func_72441_c(0.5D, 0.5D, 0.5D);
/* 119 */     double distanceSqPosVec = eyesPos.func_72436_e(posVec); EnumFacing[] arrayOfEnumFacing; int i; byte b;
/* 120 */     for (arrayOfEnumFacing = EnumFacing.values(), i = arrayOfEnumFacing.length, b = 0; b < i; ) { EnumFacing side = arrayOfEnumFacing[b];
/* 121 */       Vec3d hitVec = posVec.func_178787_e((new Vec3d(side.func_176730_m())).func_186678_a(0.5D));
/* 122 */       double distanceSqHitVec = eyesPos.func_72436_e(hitVec);
/* 123 */       if (distanceSqHitVec > MathUtil.square(range) || distanceSqHitVec >= distanceSqPosVec || mc.field_71441_e.func_147447_a(eyesPos, hitVec, false, true, false) != null) {
/*     */         b++; continue;
/* 125 */       }  if (rotate) {
/* 126 */         float[] rotations = RotationUtil.getLegitRotations(hitVec);
/* 127 */         Yaw2.set(rotations[0]);
/* 128 */         Pitch.set(rotations[1]);
/* 129 */         rotating.set(true);
/*     */       } 
/* 131 */       rightClickBlock(pos, hitVec, hand, side, packet);
/* 132 */       mc.field_71439_g.func_184609_a(hand);
/* 133 */       mc.field_71467_ac = 4; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean placeBlock(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean isSneaking) {
/* 139 */     boolean sneaking = false;
/* 140 */     EnumFacing side = getFirstFacing(pos);
/* 141 */     if (side == null) {
/* 142 */       return isSneaking;
/*     */     }
/* 144 */     BlockPos neighbour = pos.func_177972_a(side);
/* 145 */     EnumFacing opposite = side.func_176734_d();
/* 146 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(opposite.func_176730_m())).func_186678_a(0.5D));
/* 147 */     Block neighbourBlock = mc.field_71441_e.func_180495_p(neighbour).func_177230_c();
/* 148 */     if (!mc.field_71439_g.func_70093_af() && (blackList.contains(neighbourBlock) || shulkerList.contains(neighbourBlock))) {
/* 149 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
/* 150 */       mc.field_71439_g.func_70095_a(true);
/* 151 */       sneaking = true;
/*     */     } 
/* 153 */     if (rotate) {
/* 154 */       RotationUtil.faceVector(hitVec, true);
/*     */     }
/* 156 */     rightClickBlock(neighbour, hitVec, hand, opposite, packet);
/* 157 */     mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 158 */     mc.field_71467_ac = 4;
/* 159 */     return (sneaking || isSneaking);
/*     */   }
/*     */   
/*     */   public static boolean placeBlockSmartRotate(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean isSneaking) {
/* 163 */     boolean sneaking = false;
/* 164 */     EnumFacing side = getFirstFacing(pos);
/* 165 */     if (side == null) {
/* 166 */       return isSneaking;
/*     */     }
/* 168 */     BlockPos neighbour = pos.func_177972_a(side);
/* 169 */     EnumFacing opposite = side.func_176734_d();
/* 170 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(opposite.func_176730_m())).func_186678_a(0.5D));
/* 171 */     Block neighbourBlock = mc.field_71441_e.func_180495_p(neighbour).func_177230_c();
/* 172 */     if (!mc.field_71439_g.func_70093_af() && (blackList.contains(neighbourBlock) || shulkerList.contains(neighbourBlock))) {
/* 173 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
/* 174 */       sneaking = true;
/*     */     } 
/* 176 */     if (rotate) {
/* 177 */       Phobos.rotationManager.lookAtVec3d(hitVec);
/*     */     }
/* 179 */     rightClickBlock(neighbour, hitVec, hand, opposite, packet);
/* 180 */     mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 181 */     mc.field_71467_ac = 4;
/* 182 */     return (sneaking || isSneaking);
/*     */   }
/*     */   
/*     */   public static void placeBlockStopSneaking(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean isSneaking) {
/* 186 */     boolean sneaking = placeBlockSmartRotate(pos, hand, rotate, packet, isSneaking);
/* 187 */     if (!isSneaking && sneaking) {
/* 188 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */     }
/*     */   }
/*     */   
/*     */   public static Vec3d[] getHelpingBlocks(Vec3d vec3d) {
/* 193 */     return new Vec3d[] { new Vec3d(vec3d.field_72450_a, vec3d.field_72448_b - 1.0D, vec3d.field_72449_c), new Vec3d((vec3d.field_72450_a != 0.0D) ? (vec3d.field_72450_a * 2.0D) : vec3d.field_72450_a, vec3d.field_72448_b, (vec3d.field_72450_a != 0.0D) ? vec3d.field_72449_c : (vec3d.field_72449_c * 2.0D)), new Vec3d((vec3d.field_72450_a == 0.0D) ? (vec3d.field_72450_a + 1.0D) : vec3d.field_72450_a, vec3d.field_72448_b, (vec3d.field_72450_a == 0.0D) ? vec3d.field_72449_c : (vec3d.field_72449_c + 1.0D)), new Vec3d((vec3d.field_72450_a == 0.0D) ? (vec3d.field_72450_a - 1.0D) : vec3d.field_72450_a, vec3d.field_72448_b, (vec3d.field_72450_a == 0.0D) ? vec3d.field_72449_c : (vec3d.field_72449_c - 1.0D)), new Vec3d(vec3d.field_72450_a, vec3d.field_72448_b + 1.0D, vec3d.field_72449_c) };
/*     */   }
/*     */   
/*     */   public static List<BlockPos> possiblePlacePositions(float placeRange) {
/* 197 */     NonNullList positions = NonNullList.func_191196_a();
/* 198 */     positions.addAll((Collection)getSphere(EntityUtil.getPlayerPos((EntityPlayer)mc.field_71439_g), placeRange, (int)placeRange, false, true, 0).stream().filter(BlockUtil::canPlaceCrystal).collect(Collectors.toList()));
/* 199 */     return (List<BlockPos>)positions;
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getSphere(BlockPos pos, float r, int h, boolean hollow, boolean sphere, int plus_y) {
/* 203 */     ArrayList<BlockPos> circleblocks = new ArrayList<>();
/* 204 */     int cx = pos.func_177958_n();
/* 205 */     int cy = pos.func_177956_o();
/* 206 */     int cz = pos.func_177952_p();
/* 207 */     int x = cx - (int)r;
/* 208 */     while (x <= cx + r) {
/* 209 */       int z = cz - (int)r;
/* 210 */       while (z <= cz + r) {
/* 211 */         int y = sphere ? (cy - (int)r) : cy;
/*     */         while (true) {
/* 213 */           float f = y;
/* 214 */           float f2 = sphere ? (cy + r) : (cy + h);
/* 215 */           if (f >= f2)
/* 216 */             break;  double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0));
/* 217 */           if (dist < (r * r) && (!hollow || dist >= ((r - 1.0F) * (r - 1.0F)))) {
/* 218 */             BlockPos l = new BlockPos(x, y + plus_y, z);
/* 219 */             circleblocks.add(l);
/*     */           } 
/* 221 */           y++;
/*     */         } 
/* 223 */         z++;
/*     */       } 
/* 225 */       x++;
/*     */     } 
/* 227 */     return circleblocks;
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getDisc(BlockPos pos, float r) {
/* 231 */     ArrayList<BlockPos> circleblocks = new ArrayList<>();
/* 232 */     int cx = pos.func_177958_n();
/* 233 */     int cy = pos.func_177956_o();
/* 234 */     int cz = pos.func_177952_p();
/* 235 */     int x = cx - (int)r;
/* 236 */     while (x <= cx + r) {
/* 237 */       int z = cz - (int)r;
/* 238 */       while (z <= cz + r) {
/* 239 */         double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z));
/* 240 */         if (dist < (r * r)) {
/* 241 */           BlockPos position = new BlockPos(x, cy, z);
/* 242 */           circleblocks.add(position);
/*     */         } 
/* 244 */         z++;
/*     */       } 
/* 246 */       x++;
/*     */     } 
/* 248 */     return circleblocks;
/*     */   }
/*     */   
/*     */   public static boolean canPlaceCrystal(BlockPos blockPos) {
/* 252 */     BlockPos boost = blockPos.func_177982_a(0, 1, 0);
/* 253 */     BlockPos boost2 = blockPos.func_177982_a(0, 2, 0);
/*     */     try {
/* 255 */       return ((mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150343_Z) && mc.field_71441_e.func_180495_p(boost).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(boost2).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost)).isEmpty() && mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2)).isEmpty());
/* 256 */     } catch (Exception e) {
/* 257 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static List<BlockPos> possiblePlacePositions(float placeRange, boolean specialEntityCheck, boolean oneDot15) {
/* 262 */     NonNullList positions = NonNullList.func_191196_a();
/* 263 */     positions.addAll((Collection)getSphere(EntityUtil.getPlayerPos((EntityPlayer)mc.field_71439_g), placeRange, (int)placeRange, false, true, 0).stream().filter(pos -> canPlaceCrystal(pos, specialEntityCheck, oneDot15)).collect(Collectors.toList()));
/* 264 */     return (List<BlockPos>)positions;
/*     */   }
/*     */   
/*     */   public static boolean canPlaceCrystal(BlockPos blockPos, boolean specialEntityCheck, boolean oneDot15) {
/* 268 */     BlockPos boost = blockPos.func_177982_a(0, 1, 0);
/* 269 */     BlockPos boost2 = blockPos.func_177982_a(0, 2, 0);
/*     */     try {
/* 271 */       if (mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150357_h && mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150343_Z) {
/* 272 */         return false;
/*     */       }
/* 274 */       if ((!oneDot15 && mc.field_71441_e.func_180495_p(boost2).func_177230_c() != Blocks.field_150350_a) || mc.field_71441_e.func_180495_p(boost).func_177230_c() != Blocks.field_150350_a) {
/* 275 */         return false;
/*     */       }
/* 277 */       for (Entity entity : mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost))) {
/* 278 */         if (entity.field_70128_L || (specialEntityCheck && entity instanceof net.minecraft.entity.item.EntityEnderCrystal))
/* 279 */           continue;  return false;
/*     */       } 
/* 281 */       if (!oneDot15) {
/* 282 */         for (Entity entity : mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2))) {
/* 283 */           if (entity.field_70128_L || (specialEntityCheck && entity instanceof net.minecraft.entity.item.EntityEnderCrystal))
/* 284 */             continue;  return false;
/*     */         } 
/*     */       }
/* 287 */     } catch (Exception ignored) {
/* 288 */       return false;
/*     */     } 
/* 290 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean canBeClicked(BlockPos pos) {
/* 294 */     return getBlock(pos).func_176209_a(getState(pos), false);
/*     */   }
/*     */   
/*     */   private static Block getBlock(BlockPos pos) {
/* 298 */     return getState(pos).func_177230_c();
/*     */   }
/*     */   
/*     */   private static IBlockState getState(BlockPos pos) {
/* 302 */     return mc.field_71441_e.func_180495_p(pos);
/*     */   }
/*     */   
/*     */   public static boolean isBlockAboveEntitySolid(Entity entity) {
/* 306 */     if (entity != null) {
/* 307 */       BlockPos pos = new BlockPos(entity.field_70165_t, entity.field_70163_u + 2.0D, entity.field_70161_v);
/* 308 */       return isBlockSolid(pos);
/*     */     } 
/* 310 */     return false;
/*     */   }
/*     */   
/*     */   public static void debugPos(String message, BlockPos pos) {
/* 314 */     Command.sendMessage(message + pos.func_177958_n() + "x, " + pos.func_177956_o() + "y, " + pos.func_177952_p() + "z");
/*     */   }
/*     */   
/*     */   public static void placeCrystalOnBlock(BlockPos pos, EnumHand hand, boolean swing, boolean exactHand) {
/* 318 */     RayTraceResult result = mc.field_71441_e.func_72933_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(pos.func_177958_n() + 0.5D, pos.func_177956_o() - 0.5D, pos.func_177952_p() + 0.5D));
/* 319 */     EnumFacing facing = (result == null || result.field_178784_b == null) ? EnumFacing.UP : result.field_178784_b;
/* 320 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(pos, facing, hand, 0.0F, 0.0F, 0.0F));
/* 321 */     if (swing) {
/* 322 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketAnimation(exactHand ? hand : EnumHand.MAIN_HAND));
/*     */     }
/*     */   }
/*     */   
/*     */   public static BlockPos[] toBlockPos(Vec3d[] vec3ds) {
/* 327 */     BlockPos[] list = new BlockPos[vec3ds.length];
/* 328 */     for (int i = 0; i < vec3ds.length; i++) {
/* 329 */       list[i] = new BlockPos(vec3ds[i]);
/*     */     }
/* 331 */     return list;
/*     */   }
/*     */   
/*     */   public static Vec3d posToVec3d(BlockPos pos) {
/* 335 */     return new Vec3d((Vec3i)pos);
/*     */   }
/*     */   
/*     */   public static BlockPos vec3dToPos(Vec3d vec3d) {
/* 339 */     return new BlockPos(vec3d);
/*     */   }
/*     */   
/*     */   public static Boolean isPosInFov(BlockPos pos) {
/* 343 */     int dirnumber = RotationUtil.getDirection4D();
/* 344 */     if (dirnumber == 0 && pos.func_177952_p() - (mc.field_71439_g.func_174791_d()).field_72449_c < 0.0D) {
/* 345 */       return Boolean.valueOf(false);
/*     */     }
/* 347 */     if (dirnumber == 1 && pos.func_177958_n() - (mc.field_71439_g.func_174791_d()).field_72450_a > 0.0D) {
/* 348 */       return Boolean.valueOf(false);
/*     */     }
/* 350 */     if (dirnumber == 2 && pos.func_177952_p() - (mc.field_71439_g.func_174791_d()).field_72449_c > 0.0D) {
/* 351 */       return Boolean.valueOf(false);
/*     */     }
/* 353 */     return Boolean.valueOf((dirnumber != 3 || pos.func_177958_n() - (mc.field_71439_g.func_174791_d()).field_72450_a >= 0.0D));
/*     */   }
/*     */   
/*     */   public static boolean isBlockBelowEntitySolid(Entity entity) {
/* 357 */     if (entity != null) {
/* 358 */       BlockPos pos = new BlockPos(entity.field_70165_t, entity.field_70163_u - 1.0D, entity.field_70161_v);
/* 359 */       return isBlockSolid(pos);
/*     */     } 
/* 361 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isBlockSolid(BlockPos pos) {
/* 365 */     return !isBlockUnSolid(pos);
/*     */   }
/*     */   
/*     */   public static boolean isBlockUnSolid(BlockPos pos) {
/* 369 */     return isBlockUnSolid(mc.field_71441_e.func_180495_p(pos).func_177230_c());
/*     */   }
/*     */   
/*     */   public static boolean isBlockUnSolid(Block block) {
/* 373 */     return unSolidBlocks.contains(block);
/*     */   }
/*     */   
/*     */   public static Vec3d[] convertVec3ds(Vec3d vec3d, Vec3d[] input) {
/* 377 */     Vec3d[] output = new Vec3d[input.length];
/* 378 */     for (int i = 0; i < input.length; i++) {
/* 379 */       output[i] = vec3d.func_178787_e(input[i]);
/*     */     }
/* 381 */     return output;
/*     */   }
/*     */   
/*     */   public static Vec3d[] convertVec3ds(EntityPlayer entity, Vec3d[] input) {
/* 385 */     return convertVec3ds(entity.func_174791_d(), input);
/*     */   }
/*     */   
/*     */   public static boolean canBreak(BlockPos pos) {
/* 389 */     IBlockState blockState = mc.field_71441_e.func_180495_p(pos);
/* 390 */     Block block = blockState.func_177230_c();
/* 391 */     return (block.func_176195_g(blockState, (World)mc.field_71441_e, pos) != -1.0F);
/*     */   }
/*     */   
/*     */   public static boolean isValidBlock(BlockPos pos) {
/* 395 */     Block block = mc.field_71441_e.func_180495_p(pos).func_177230_c();
/* 396 */     return (!(block instanceof net.minecraft.block.BlockLiquid) && block.func_149688_o(null) != Material.field_151579_a);
/*     */   }
/*     */   
/*     */   public static boolean isScaffoldPos(BlockPos pos) {
/* 400 */     return (mc.field_71441_e.func_175623_d(pos) || mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150431_aC || mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150329_H || mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockLiquid);
/*     */   }
/*     */   
/*     */   public static boolean rayTracePlaceCheck(BlockPos pos, boolean shouldCheck, float height) {
/* 404 */     return (!shouldCheck || mc.field_71441_e.func_147447_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(pos.func_177958_n(), (pos.func_177956_o() + height), pos.func_177952_p()), false, true, false) == null);
/*     */   }
/*     */   
/*     */   public static boolean rayTracePlaceCheck(BlockPos pos, boolean shouldCheck) {
/* 408 */     return rayTracePlaceCheck(pos, shouldCheck, 1.0F);
/*     */   }
/*     */   
/*     */   public static boolean rayTracePlaceCheck(BlockPos pos) {
/* 412 */     return rayTracePlaceCheck(pos, true);
/*     */   }
/*     */   
/*     */   public static boolean isInHole() {
/* 416 */     BlockPos blockPos = new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
/* 417 */     IBlockState blockState = mc.field_71441_e.func_180495_p(blockPos);
/* 418 */     return isBlockValid(blockState, blockPos);
/*     */   }
/*     */   
/*     */   public static double getNearestBlockBelow() {
/* 422 */     for (double y = mc.field_71439_g.field_70163_u; y > 0.0D; ) {
/* 423 */       if (mc.field_71441_e.func_180495_p(new BlockPos(mc.field_71439_g.field_70165_t, y, mc.field_71439_g.field_70161_v)).func_177230_c() instanceof net.minecraft.block.BlockSlab || mc.field_71441_e.func_180495_p(new BlockPos(mc.field_71439_g.field_70165_t, y, mc.field_71439_g.field_70161_v)).func_177230_c().func_176223_P().func_185890_d((IBlockAccess)mc.field_71441_e, new BlockPos(0, 0, 0)) == null) {
/*     */         y -= 0.001D; continue;
/* 425 */       }  return y;
/*     */     } 
/* 427 */     return -1.0D;
/*     */   }
/*     */   
/*     */   public static boolean isBlockValid(IBlockState blockState, BlockPos blockPos) {
/* 431 */     if (blockState.func_177230_c() != Blocks.field_150350_a) {
/* 432 */       return false;
/*     */     }
/* 434 */     if (mc.field_71439_g.func_174818_b(blockPos) < 1.0D) {
/* 435 */       return false;
/*     */     }
/* 437 */     if (mc.field_71441_e.func_180495_p(blockPos.func_177984_a()).func_177230_c() != Blocks.field_150350_a) {
/* 438 */       return false;
/*     */     }
/* 440 */     if (mc.field_71441_e.func_180495_p(blockPos.func_177981_b(2)).func_177230_c() != Blocks.field_150350_a) {
/* 441 */       return false;
/*     */     }
/* 443 */     return (isBedrockHole(blockPos) || isObbyHole(blockPos) || isBothHole(blockPos) || isElseHole(blockPos));
/*     */   } public static boolean isObbyHole(BlockPos blockPos) { BlockPos[] arrayOfBlockPos;
/*     */     int i;
/*     */     byte b;
/* 447 */     for (arrayOfBlockPos = getTouchingBlocks(blockPos), i = arrayOfBlockPos.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos[b];
/* 448 */       IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
/* 449 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && touchingState.func_177230_c() == Blocks.field_150343_Z) { b++; continue; }
/* 450 */        return false; }
/*     */     
/* 452 */     return true; }
/*     */   public static boolean isBedrockHole(BlockPos blockPos) { BlockPos[] arrayOfBlockPos;
/*     */     int i;
/*     */     byte b;
/* 456 */     for (arrayOfBlockPos = getTouchingBlocks(blockPos), i = arrayOfBlockPos.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos[b];
/* 457 */       IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
/* 458 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && touchingState.func_177230_c() == Blocks.field_150357_h) { b++; continue; }
/* 459 */        return false; }
/*     */     
/* 461 */     return true; }
/*     */   public static boolean isBothHole(BlockPos blockPos) { BlockPos[] arrayOfBlockPos;
/*     */     int i;
/*     */     byte b;
/* 465 */     for (arrayOfBlockPos = getTouchingBlocks(blockPos), i = arrayOfBlockPos.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos[b];
/* 466 */       IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
/* 467 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && (touchingState.func_177230_c() == Blocks.field_150357_h || touchingState.func_177230_c() == Blocks.field_150343_Z)) {
/*     */         b++; continue;
/* 469 */       }  return false; }
/*     */     
/* 471 */     return true; } public static boolean isElseHole(BlockPos blockPos) {
/*     */     BlockPos[] arrayOfBlockPos;
/*     */     int i;
/*     */     byte b;
/* 475 */     for (arrayOfBlockPos = getTouchingBlocks(blockPos), i = arrayOfBlockPos.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos[b];
/* 476 */       IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
/* 477 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && touchingState.func_185913_b()) { b++; continue; }
/* 478 */        return false; }
/*     */     
/* 480 */     return true;
/*     */   }
/*     */   
/*     */   public static BlockPos[] getTouchingBlocks(BlockPos blockPos) {
/* 484 */     return new BlockPos[] { blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b() };
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\BlockUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */