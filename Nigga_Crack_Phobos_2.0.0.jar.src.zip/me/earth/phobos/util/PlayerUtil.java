/*     */ package me.earth.phobos.util;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.mojang.util.UUIDTypeAdapter;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Scanner;
/*     */ import java.util.UUID;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import me.earth.phobos.features.command.Command;
/*     */ import net.minecraft.client.network.NetHandlerPlayClient;
/*     */ import net.minecraft.client.network.NetworkPlayerInfo;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONObject;
/*     */ import org.json.simple.JSONValue;
/*     */ 
/*     */ public class PlayerUtil implements Util {
/*  28 */   private static final JsonParser PARSER = new JsonParser();
/*  29 */   public static Timer timer = new Timer();
/*     */   
/*     */   public static String getNameFromUUID(UUID uuid) {
/*     */     try {
/*  33 */       lookUpName process = new lookUpName(uuid);
/*  34 */       Thread thread = new Thread(process);
/*  35 */       thread.start();
/*  36 */       thread.join();
/*  37 */       return process.getName();
/*  38 */     } catch (Exception e) {
/*  39 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getNameFromUUID(String uuid) {
/*     */     try {
/*  45 */       lookUpName process = new lookUpName(uuid);
/*  46 */       Thread thread = new Thread(process);
/*  47 */       thread.start();
/*  48 */       thread.join();
/*  49 */       return process.getName();
/*  50 */     } catch (Exception e) {
/*  51 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static UUID getUUIDFromName(String name) {
/*     */     try {
/*  57 */       lookUpUUID process = new lookUpUUID(name);
/*  58 */       Thread thread = new Thread(process);
/*  59 */       thread.start();
/*  60 */       thread.join();
/*  61 */       return process.getUUID();
/*  62 */     } catch (Exception e) {
/*  63 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String requestIDs(String data) {
/*     */     try {
/*  69 */       String query = "https://api.mojang.com/profiles/minecraft";
/*  70 */       URL url = new URL(query);
/*  71 */       HttpURLConnection conn = (HttpURLConnection)url.openConnection();
/*  72 */       conn.setConnectTimeout(5000);
/*  73 */       conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
/*  74 */       conn.setDoOutput(true);
/*  75 */       conn.setDoInput(true);
/*  76 */       conn.setRequestMethod("POST");
/*  77 */       OutputStream os = conn.getOutputStream();
/*  78 */       os.write(data.getBytes(StandardCharsets.UTF_8));
/*  79 */       os.close();
/*  80 */       BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
/*  81 */       String res = convertStreamToString(in);
/*  82 */       in.close();
/*  83 */       conn.disconnect();
/*  84 */       return res;
/*  85 */     } catch (Exception e) {
/*  86 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String convertStreamToString(InputStream is) {
/*  91 */     Scanner s = (new Scanner(is)).useDelimiter("\\A");
/*  92 */     return s.hasNext() ? s.next() : "/";
/*     */   }
/*     */   
/*     */   public static List<String> getHistoryOfNames(UUID id) {
/*     */     try {
/*  97 */       JsonArray array = getResources(new URL("https://api.mojang.com/user/profiles/" + getIdNoHyphens(id) + "/names"), "GET").getAsJsonArray();
/*  98 */       ArrayList<String> temp = Lists.newArrayList();
/*  99 */       for (JsonElement e : array) {
/* 100 */         JsonObject node = e.getAsJsonObject();
/* 101 */         String name = node.get("name").getAsString();
/* 102 */         long changedAt = node.has("changedToAt") ? node.get("changedToAt").getAsLong() : 0L;
/* 103 */         temp.add(name + "§8" + (new Date(changedAt)).toString());
/*     */       } 
/* 105 */       Collections.sort(temp);
/* 106 */       return temp;
/* 107 */     } catch (Exception ignored) {
/* 108 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getIdNoHyphens(UUID uuid) {
/* 113 */     return uuid.toString().replaceAll("-", "");
/*     */   }
/*     */   
/*     */   private static JsonElement getResources(URL url, String request) throws Exception {
/* 117 */     return getResources(url, request, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static JsonElement getResources(URL url, String request, JsonElement element) throws Exception {
/* 124 */     HttpsURLConnection connection = null;
/*     */     
/*     */     try {
/* 127 */       connection = (HttpsURLConnection)url.openConnection();
/* 128 */       connection.setDoOutput(true);
/* 129 */       connection.setRequestMethod(request);
/* 130 */       connection.setRequestProperty("Content-Type", "application/json");
/* 131 */       if (element != null) {
/* 132 */         DataOutputStream output = new DataOutputStream(connection.getOutputStream());
/* 133 */         output.writeBytes(AdvancementManager.field_192783_b.toJson(element));
/* 134 */         output.close();
/*     */       } 
/* 136 */       Scanner scanner = new Scanner(connection.getInputStream());
/* 137 */       StringBuilder builder = new StringBuilder();
/* 138 */       while (scanner.hasNextLine()) {
/* 139 */         builder.append(scanner.nextLine());
/* 140 */         builder.append('\n');
/*     */       } 
/* 142 */       scanner.close();
/* 143 */       String json = builder.toString();
/* 144 */       JsonElement data = PARSER.parse(json), jsonElement = data;
/* 145 */       return jsonElement;
/*     */     } finally {
/* 147 */       if (connection != null)
/* 148 */         connection.disconnect(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class lookUpName
/*     */     implements Runnable
/*     */   {
/*     */     private final String uuid;
/*     */     private final UUID uuidID;
/*     */     private volatile String name;
/*     */     
/*     */     public lookUpName(String input) {
/* 160 */       this.uuid = input;
/* 161 */       this.uuidID = UUID.fromString(input);
/*     */     }
/*     */     
/*     */     public lookUpName(UUID input) {
/* 165 */       this.uuidID = input;
/* 166 */       this.uuid = input.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 171 */       this.name = lookUpName();
/*     */     }
/*     */     
/*     */     public String lookUpName() {
/* 175 */       EntityPlayer player = null;
/* 176 */       if (Util.mc.field_71441_e != null) {
/* 177 */         player = Util.mc.field_71441_e.func_152378_a(this.uuidID);
/*     */       }
/* 179 */       if (player == null) {
/* 180 */         String url = "https://api.mojang.com/user/profiles/" + this.uuid.replace("-", "") + "/names";
/*     */         try {
/* 182 */           String nameJson = IOUtils.toString(new URL(url));
/* 183 */           JSONArray nameValue = (JSONArray)JSONValue.parseWithException(nameJson);
/* 184 */           String playerSlot = nameValue.get(nameValue.size() - 1).toString();
/* 185 */           JSONObject nameObject = (JSONObject)JSONValue.parseWithException(playerSlot);
/* 186 */           return nameObject.get("name").toString();
/* 187 */         } catch (IOException|org.json.simple.parser.ParseException e) {
/* 188 */           e.printStackTrace();
/* 189 */           return null;
/*     */         } 
/*     */       } 
/* 192 */       return player.func_70005_c_();
/*     */     }
/*     */     
/*     */     public String getName() {
/* 196 */       return this.name;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class lookUpUUID
/*     */     implements Runnable {
/*     */     private final String name;
/*     */     private volatile UUID uuid;
/*     */     
/*     */     public lookUpUUID(String name) {
/* 206 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       NetworkPlayerInfo profile;
/*     */       try {
/* 213 */         ArrayList<NetworkPlayerInfo> infoMap = new ArrayList<>(((NetHandlerPlayClient)Objects.<NetHandlerPlayClient>requireNonNull(Util.mc.func_147114_u())).func_175106_d());
/* 214 */         profile = infoMap.stream().filter(networkPlayerInfo -> networkPlayerInfo.func_178845_a().getName().equalsIgnoreCase(this.name)).findFirst().orElse(null);
/* 215 */         assert profile != null;
/* 216 */         this.uuid = profile.func_178845_a().getId();
/* 217 */       } catch (Exception e) {
/* 218 */         profile = null;
/*     */       } 
/* 220 */       if (profile == null) {
/* 221 */         Command.sendMessage("Player isn't online. Looking up UUID..");
/* 222 */         String s = PlayerUtil.requestIDs("[\"" + this.name + "\"]");
/* 223 */         if (s == null || s.isEmpty()) {
/* 224 */           Command.sendMessage("Couldn't find player ID. Are you connected to the internet? (0)");
/*     */         } else {
/* 226 */           JsonElement element = (new JsonParser()).parse(s);
/* 227 */           if (element.getAsJsonArray().size() == 0) {
/* 228 */             Command.sendMessage("Couldn't find player ID. (1)");
/*     */           } else {
/*     */             try {
/* 231 */               String id = element.getAsJsonArray().get(0).getAsJsonObject().get("id").getAsString();
/* 232 */               this.uuid = UUIDTypeAdapter.fromString(id);
/* 233 */             } catch (Exception e) {
/* 234 */               e.printStackTrace();
/* 235 */               Command.sendMessage("Couldn't find player ID. (2)");
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public UUID getUUID() {
/* 243 */       return this.uuid;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 247 */       return this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\PlayerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */