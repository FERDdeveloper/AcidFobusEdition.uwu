/*      */ package me.earth.phobos.util;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.Closeable;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.Flushable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.io.Writer;
/*      */ import java.net.HttpURLConnection;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.Proxy;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLEncoder;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.security.AccessController;
/*      */ import java.security.GeneralSecurityException;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.SecureRandom;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.zip.GZIPInputStream;
/*      */ import javax.net.ssl.HostnameVerifier;
/*      */ import javax.net.ssl.HttpsURLConnection;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.SSLSession;
/*      */ import javax.net.ssl.SSLSocketFactory;
/*      */ import javax.net.ssl.TrustManager;
/*      */ import javax.net.ssl.X509TrustManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WurstplusCapeUUID
/*      */ {
/*      */   public static final String CHARSET_UTF8 = "UTF-8";
/*      */   public static final String CONTENT_TYPE_FORM = "application/x-www-form-urlencoded";
/*      */   public static final String CONTENT_TYPE_JSON = "application/json";
/*      */   public static final String ENCODING_GZIP = "gzip";
/*      */   public static final String HEADER_ACCEPT = "Accept";
/*      */   public static final String HEADER_ACCEPT_CHARSET = "Accept-Charset";
/*      */   public static final String HEADER_ACCEPT_ENCODING = "Accept-Encoding";
/*      */   public static final String HEADER_AUTHORIZATION = "Authorization";
/*      */   public static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*      */   public static final String HEADER_CONTENT_ENCODING = "Content-Encoding";
/*      */   public static final String HEADER_CONTENT_LENGTH = "Content-Length";
/*      */   public static final String HEADER_CONTENT_TYPE = "Content-Type";
/*      */   public static final String HEADER_DATE = "Date";
/*      */   public static final String HEADER_ETAG = "ETag";
/*      */   public static final String HEADER_EXPIRES = "Expires";
/*      */   public static final String HEADER_IF_NONE_MATCH = "If-None-Match";
/*      */   public static final String HEADER_LAST_MODIFIED = "Last-Modified";
/*      */   public static final String HEADER_LOCATION = "Location";
/*      */   public static final String HEADER_PROXY_AUTHORIZATION = "Proxy-Authorization";
/*      */   public static final String HEADER_REFERER = "Referer";
/*      */   public static final String HEADER_SERVER = "Server";
/*      */   public static final String HEADER_USER_AGENT = "User-Agent";
/*      */   public static final String METHOD_DELETE = "DELETE";
/*      */   public static final String METHOD_GET = "GET";
/*      */   public static final String METHOD_HEAD = "HEAD";
/*      */   public static final String METHOD_OPTIONS = "OPTIONS";
/*      */   public static final String METHOD_POST = "POST";
/*      */   public static final String METHOD_PATCH = "PATCH";
/*      */   public static final String METHOD_PUT = "PUT";
/*      */   public static final String METHOD_TRACE = "TRACE";
/*      */   public static final String PARAM_CHARSET = "charset";
/*      */   private static final String BOUNDARY = "00content0boundary00";
/*      */   private static final String CONTENT_TYPE_MULTIPART = "multipart/form-data; boundary=00content0boundary00";
/*      */   private static final String CRLF = "\r\n";
/*  185 */   private static final String[] EMPTY_STRINGS = new String[0];
/*      */   
/*      */   private static SSLSocketFactory TRUSTED_FACTORY;
/*      */   
/*      */   private static HostnameVerifier TRUSTED_VERIFIER;
/*      */   
/*      */   private static String getValidCharset(String charset) {
/*  192 */     if (charset != null && charset.length() > 0) {
/*  193 */       return charset;
/*      */     }
/*  195 */     return "UTF-8";
/*      */   }
/*      */ 
/*      */   
/*      */   private static SSLSocketFactory getTrustedFactory() throws HttpRequestException {
/*  200 */     if (TRUSTED_FACTORY == null) {
/*  201 */       TrustManager[] trustAllCerts = { new X509TrustManager()
/*      */           {
/*      */             public X509Certificate[] getAcceptedIssuers() {
/*  204 */               return new X509Certificate[0];
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public void checkClientTrusted(X509Certificate[] chain, String authType) {}
/*      */ 
/*      */ 
/*      */             
/*      */             public void checkServerTrusted(X509Certificate[] chain, String authType) {}
/*      */           } };
/*      */       try {
/*  216 */         SSLContext context = SSLContext.getInstance("TLS");
/*  217 */         context.init(null, trustAllCerts, new SecureRandom());
/*  218 */         TRUSTED_FACTORY = context.getSocketFactory();
/*  219 */       } catch (GeneralSecurityException e) {
/*  220 */         IOException ioException = new IOException("Security exception configuring SSL context");
/*      */         
/*  222 */         ioException.initCause(e);
/*  223 */         throw new HttpRequestException(ioException);
/*      */       } 
/*      */     } 
/*      */     
/*  227 */     return TRUSTED_FACTORY;
/*      */   }
/*      */   
/*      */   private static HostnameVerifier getTrustedVerifier() {
/*  231 */     if (TRUSTED_VERIFIER == null) {
/*  232 */       TRUSTED_VERIFIER = new HostnameVerifier()
/*      */         {
/*      */           public boolean verify(String hostname, SSLSession session) {
/*  235 */             return true;
/*      */           }
/*      */         };
/*      */     }
/*  239 */     return TRUSTED_VERIFIER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static StringBuilder addPathSeparator(String baseUrl, StringBuilder result) {
/*  248 */     if (baseUrl.indexOf(':') + 2 == baseUrl.lastIndexOf('/'))
/*  249 */       result.append('/'); 
/*  250 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static StringBuilder addParamPrefix(String baseUrl, StringBuilder result) {
/*  256 */     int queryStart = baseUrl.indexOf('?');
/*  257 */     int lastChar = result.length() - 1;
/*  258 */     if (queryStart == -1) {
/*  259 */       result.append('?');
/*  260 */     } else if (queryStart < lastChar && baseUrl.charAt(lastChar) != '&') {
/*  261 */       result.append('&');
/*  262 */     }  return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static StringBuilder addParam(Object key, Object<Object> value, StringBuilder result) {
/*  267 */     if (value != null && value.getClass().isArray()) {
/*  268 */       value = (Object<Object>)arrayToList(value);
/*      */     }
/*  270 */     if (value instanceof Iterable) {
/*  271 */       Iterator<?> iterator = ((Iterable)value).iterator();
/*  272 */       while (iterator.hasNext()) {
/*  273 */         result.append(key);
/*  274 */         result.append("[]=");
/*  275 */         Object element = iterator.next();
/*  276 */         if (element != null)
/*  277 */           result.append(element); 
/*  278 */         if (iterator.hasNext())
/*  279 */           result.append("&"); 
/*      */       } 
/*      */     } else {
/*  282 */       result.append(key);
/*  283 */       result.append("=");
/*  284 */       if (value != null) {
/*  285 */         result.append(value);
/*      */       }
/*      */     } 
/*  288 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface ConnectionFactory
/*      */   {
/*  315 */     public static final ConnectionFactory DEFAULT = new ConnectionFactory() {
/*      */         public HttpURLConnection create(URL url) throws IOException {
/*  317 */           return (HttpURLConnection)url.openConnection();
/*      */         }
/*      */         
/*      */         public HttpURLConnection create(URL url, Proxy proxy) throws IOException {
/*  321 */           return (HttpURLConnection)url.openConnection(proxy);
/*      */         }
/*      */       };
/*      */     HttpURLConnection create(URL param1URL) throws IOException;
/*      */     HttpURLConnection create(URL param1URL, Proxy param1Proxy) throws IOException; }
/*  326 */   private static ConnectionFactory CONNECTION_FACTORY = ConnectionFactory.DEFAULT;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setConnectionFactory(ConnectionFactory connectionFactory) {
/*  332 */     if (connectionFactory == null) {
/*  333 */       CONNECTION_FACTORY = ConnectionFactory.DEFAULT;
/*      */     } else {
/*  335 */       CONNECTION_FACTORY = connectionFactory;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface UploadProgress
/*      */   {
/*  351 */     public static final UploadProgress DEFAULT = new UploadProgress()
/*      */       {
/*      */         public void onUpload(long uploaded, long total) {}
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void onUpload(long param1Long1, long param1Long2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Base64
/*      */   {
/*      */     private static final byte EQUALS_SIGN = 61;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String PREFERRED_ENCODING = "US-ASCII";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  382 */     private static final byte[] _STANDARD_ALPHABET = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static byte[] encode3to4(byte[] source, int srcOffset, int numSigBytes, byte[] destination, int destOffset) {
/*  432 */       byte[] ALPHABET = _STANDARD_ALPHABET;
/*      */       
/*  434 */       int inBuff = ((numSigBytes > 0) ? (source[srcOffset] << 24 >>> 8) : 0) | ((numSigBytes > 1) ? (source[srcOffset + 1] << 24 >>> 16) : 0) | ((numSigBytes > 2) ? (source[srcOffset + 2] << 24 >>> 24) : 0);
/*      */ 
/*      */ 
/*      */       
/*  438 */       switch (numSigBytes) {
/*      */         case 3:
/*  440 */           destination[destOffset] = ALPHABET[inBuff >>> 18];
/*  441 */           destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/*  442 */           destination[destOffset + 2] = ALPHABET[inBuff >>> 6 & 0x3F];
/*  443 */           destination[destOffset + 3] = ALPHABET[inBuff & 0x3F];
/*  444 */           return destination;
/*      */         
/*      */         case 2:
/*  447 */           destination[destOffset] = ALPHABET[inBuff >>> 18];
/*  448 */           destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/*  449 */           destination[destOffset + 2] = ALPHABET[inBuff >>> 6 & 0x3F];
/*  450 */           destination[destOffset + 3] = 61;
/*  451 */           return destination;
/*      */         
/*      */         case 1:
/*  454 */           destination[destOffset] = ALPHABET[inBuff >>> 18];
/*  455 */           destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/*  456 */           destination[destOffset + 2] = 61;
/*  457 */           destination[destOffset + 3] = 61;
/*  458 */           return destination;
/*      */       } 
/*      */       
/*  461 */       return destination;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static String encode(String string) {
/*      */       byte[] bytes;
/*      */       try {
/*  474 */         bytes = string.getBytes("US-ASCII");
/*  475 */       } catch (UnsupportedEncodingException e) {
/*  476 */         bytes = string.getBytes();
/*      */       } 
/*  478 */       return encodeBytes(bytes);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static String encodeBytes(byte[] source) {
/*  494 */       return encodeBytes(source, 0, source.length);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static String encodeBytes(byte[] source, int off, int len) {
/*  514 */       byte[] encoded = encodeBytesToBytes(source, off, len);
/*      */       try {
/*  516 */         return new String(encoded, "US-ASCII");
/*  517 */       } catch (UnsupportedEncodingException uue) {
/*  518 */         return new String(encoded);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static byte[] encodeBytesToBytes(byte[] source, int off, int len) {
/*  543 */       if (source == null) {
/*  544 */         throw new NullPointerException("Cannot serialize a null array.");
/*      */       }
/*  546 */       if (off < 0) {
/*  547 */         throw new IllegalArgumentException("Cannot have negative offset: " + off);
/*      */       }
/*      */       
/*  550 */       if (len < 0) {
/*  551 */         throw new IllegalArgumentException("Cannot have length offset: " + len);
/*      */       }
/*  553 */       if (off + len > source.length) {
/*  554 */         throw new IllegalArgumentException(
/*      */             
/*  556 */             String.format("Cannot have offset of %d and length of %d with array of length %d", new Object[] {
/*      */                 
/*  558 */                 Integer.valueOf(off), Integer.valueOf(len), Integer.valueOf(source.length)
/*      */               }));
/*      */       }
/*  561 */       int encLen = len / 3 * 4 + ((len % 3 > 0) ? 4 : 0);
/*      */       
/*  563 */       byte[] outBuff = new byte[encLen];
/*      */       
/*  565 */       int d = 0;
/*  566 */       int e = 0;
/*  567 */       int len2 = len - 2;
/*  568 */       for (; d < len2; d += 3, e += 4) {
/*  569 */         encode3to4(source, d + off, 3, outBuff, e);
/*      */       }
/*  571 */       if (d < len) {
/*  572 */         encode3to4(source, d + off, len - d, outBuff, e);
/*  573 */         e += 4;
/*      */       } 
/*      */       
/*  576 */       if (e <= outBuff.length - 1) {
/*  577 */         byte[] finalOut = new byte[e];
/*  578 */         System.arraycopy(outBuff, 0, finalOut, 0, e);
/*  579 */         return finalOut;
/*      */       } 
/*  581 */       return outBuff;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HttpRequestException
/*      */     extends RuntimeException
/*      */   {
/*      */     private static final long serialVersionUID = -1170466989781746231L;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HttpRequestException(IOException cause) {
/*  598 */       super(cause);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IOException getCause() {
/*  608 */       return (IOException)super.getCause();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static abstract class Operation<V>
/*      */     implements Callable<V>
/*      */   {
/*      */     protected abstract V run() throws WurstplusCapeUUID.HttpRequestException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected abstract void done() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public V call() throws WurstplusCapeUUID.HttpRequestException {
/*  637 */       boolean thrown = false;
/*      */       try {
/*  639 */         return run();
/*  640 */       } catch (HttpRequestException e) {
/*  641 */         thrown = true;
/*  642 */         throw e;
/*  643 */       } catch (IOException e) {
/*  644 */         thrown = true;
/*  645 */         throw new WurstplusCapeUUID.HttpRequestException(e);
/*      */       } finally {
/*      */         try {
/*  648 */           done();
/*  649 */         } catch (IOException e) {
/*  650 */           if (!thrown) {
/*  651 */             throw new WurstplusCapeUUID.HttpRequestException(e);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static abstract class CloseOperation<V>
/*      */     extends Operation<V>
/*      */   {
/*      */     private final Closeable closeable;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean ignoreCloseExceptions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected CloseOperation(Closeable closeable, boolean ignoreCloseExceptions) {
/*  677 */       this.closeable = closeable;
/*  678 */       this.ignoreCloseExceptions = ignoreCloseExceptions;
/*      */     }
/*      */ 
/*      */     
/*      */     protected void done() throws IOException {
/*  683 */       if (this.closeable instanceof Flushable)
/*  684 */         ((Flushable)this.closeable).flush(); 
/*  685 */       if (this.ignoreCloseExceptions) {
/*      */         try {
/*  687 */           this.closeable.close();
/*  688 */         } catch (IOException iOException) {}
/*      */       }
/*      */       else {
/*      */         
/*  692 */         this.closeable.close();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static abstract class FlushOperation<V>
/*      */     extends Operation<V>
/*      */   {
/*      */     private final Flushable flushable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected FlushOperation(Flushable flushable) {
/*  712 */       this.flushable = flushable;
/*      */     }
/*      */ 
/*      */     
/*      */     protected void done() throws IOException {
/*  717 */       this.flushable.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class RequestOutputStream
/*      */     extends BufferedOutputStream
/*      */   {
/*      */     private final CharsetEncoder encoder;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public RequestOutputStream(OutputStream stream, String charset, int bufferSize) {
/*  737 */       super(stream, bufferSize);
/*      */       
/*  739 */       this.encoder = Charset.forName(WurstplusCapeUUID.getValidCharset(charset)).newEncoder();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public RequestOutputStream write(String value) throws IOException {
/*  750 */       ByteBuffer bytes = this.encoder.encode(CharBuffer.wrap(value));
/*      */       
/*  752 */       write(bytes.array(), 0, bytes.limit());
/*      */       
/*  754 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static List<Object> arrayToList(Object array) {
/*  764 */     if (array instanceof Object[]) {
/*  765 */       return Arrays.asList((Object[])array);
/*      */     }
/*  767 */     List<Object> result = new ArrayList();
/*      */     
/*  769 */     if (array instanceof int[]) {
/*  770 */       for (int value : (int[])array) result.add(Integer.valueOf(value)); 
/*  771 */     } else if (array instanceof boolean[]) {
/*  772 */       for (boolean value : (boolean[])array) result.add(Boolean.valueOf(value)); 
/*  773 */     } else if (array instanceof long[]) {
/*  774 */       for (long value : (long[])array) result.add(Long.valueOf(value)); 
/*  775 */     } else if (array instanceof float[]) {
/*  776 */       for (float value : (float[])array) result.add(Float.valueOf(value)); 
/*  777 */     } else if (array instanceof double[]) {
/*  778 */       for (double value : (double[])array) result.add(Double.valueOf(value)); 
/*  779 */     } else if (array instanceof short[]) {
/*  780 */       for (short value : (short[])array) result.add(Short.valueOf(value)); 
/*  781 */     } else if (array instanceof byte[]) {
/*  782 */       for (byte value : (byte[])array) result.add(Byte.valueOf(value)); 
/*  783 */     } else if (array instanceof char[]) {
/*  784 */       for (char value : (char[])array) result.add(Character.valueOf(value)); 
/*  785 */     }  return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encode(CharSequence url) throws HttpRequestException {
/*      */     URL parsed;
/*      */     try {
/*  805 */       parsed = new URL(url.toString());
/*  806 */     } catch (IOException e) {
/*  807 */       throw new HttpRequestException(e);
/*      */     } 
/*      */     
/*  810 */     String host = parsed.getHost();
/*  811 */     int port = parsed.getPort();
/*  812 */     if (port != -1) {
/*  813 */       host = host + ':' + Integer.toString(port);
/*      */     }
/*      */     
/*      */     try {
/*  817 */       String encoded = (new URI(parsed.getProtocol(), host, parsed.getPath(), parsed.getQuery(), null)).toASCIIString();
/*  818 */       int paramsStart = encoded.indexOf('?');
/*  819 */       if (paramsStart > 0 && paramsStart + 1 < encoded.length())
/*      */       {
/*  821 */         encoded = encoded.substring(0, paramsStart + 1) + encoded.substring(paramsStart + 1).replace("+", "%2B"); } 
/*  822 */       return encoded;
/*  823 */     } catch (URISyntaxException e) {
/*  824 */       IOException io = new IOException("Parsing URI failed");
/*  825 */       io.initCause(e);
/*  826 */       throw new HttpRequestException(io);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String append(CharSequence url, Map<?, ?> params) {
/*  841 */     String baseUrl = url.toString();
/*  842 */     if (params == null || params.isEmpty()) {
/*  843 */       return baseUrl;
/*      */     }
/*  845 */     StringBuilder result = new StringBuilder(baseUrl);
/*      */     
/*  847 */     addPathSeparator(baseUrl, result);
/*  848 */     addParamPrefix(baseUrl, result);
/*      */ 
/*      */     
/*  851 */     Iterator<?> iterator = params.entrySet().iterator();
/*  852 */     Map.Entry<?, ?> entry = (Map.Entry<?, ?>)iterator.next();
/*  853 */     addParam(entry.getKey().toString(), entry.getValue(), result);
/*      */     
/*  855 */     while (iterator.hasNext()) {
/*  856 */       result.append('&');
/*  857 */       entry = (Map.Entry<?, ?>)iterator.next();
/*  858 */       addParam(entry.getKey().toString(), entry.getValue(), result);
/*      */     } 
/*      */     
/*  861 */     return result.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String append(CharSequence url, Object... params) {
/*  876 */     String baseUrl = url.toString();
/*  877 */     if (params == null || params.length == 0) {
/*  878 */       return baseUrl;
/*      */     }
/*  880 */     if (params.length % 2 != 0) {
/*  881 */       throw new IllegalArgumentException("Must specify an even number of parameter names/values");
/*      */     }
/*      */     
/*  884 */     StringBuilder result = new StringBuilder(baseUrl);
/*      */     
/*  886 */     addPathSeparator(baseUrl, result);
/*  887 */     addParamPrefix(baseUrl, result);
/*      */     
/*  889 */     addParam(params[0], params[1], result);
/*      */     
/*  891 */     for (int i = 2; i < params.length; i += 2) {
/*  892 */       result.append('&');
/*  893 */       addParam(params[i], params[i + 1], result);
/*      */     } 
/*      */     
/*  896 */     return result.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID get(CharSequence url) throws HttpRequestException {
/*  908 */     return new WurstplusCapeUUID(url, "GET");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID get(URL url) throws HttpRequestException {
/*  919 */     return new WurstplusCapeUUID(url, "GET");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID get(CharSequence baseUrl, Map<?, ?> params, boolean encode) {
/*  938 */     String url = append(baseUrl, params);
/*  939 */     return get(encode ? encode(url) : url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID get(CharSequence baseUrl, boolean encode, Object... params) {
/*  959 */     String url = append(baseUrl, params);
/*  960 */     return get(encode ? encode(url) : url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID post(CharSequence url) throws HttpRequestException {
/*  972 */     return new WurstplusCapeUUID(url, "POST");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID post(URL url) throws HttpRequestException {
/*  983 */     return new WurstplusCapeUUID(url, "POST");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID post(CharSequence baseUrl, Map<?, ?> params, boolean encode) {
/* 1002 */     String url = append(baseUrl, params);
/* 1003 */     return post(encode ? encode(url) : url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID post(CharSequence baseUrl, boolean encode, Object... params) {
/* 1023 */     String url = append(baseUrl, params);
/* 1024 */     return post(encode ? encode(url) : url);
/*      */   }
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID patch(CharSequence url) throws HttpRequestException {
/* 1029 */     return new WurstplusCapeUUID(url, "PATCH");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID put(CharSequence url) throws HttpRequestException {
/* 1040 */     return new WurstplusCapeUUID(url, "PUT");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID put(URL url) throws HttpRequestException {
/* 1051 */     return new WurstplusCapeUUID(url, "PUT");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID put(CharSequence baseUrl, Map<?, ?> params, boolean encode) {
/* 1070 */     String url = append(baseUrl, params);
/* 1071 */     return put(encode ? encode(url) : url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID put(CharSequence baseUrl, boolean encode, Object... params) {
/* 1091 */     String url = append(baseUrl, params);
/* 1092 */     return put(encode ? encode(url) : url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID delete(CharSequence url) throws HttpRequestException {
/* 1104 */     return new WurstplusCapeUUID(url, "DELETE");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID delete(URL url) throws HttpRequestException {
/* 1115 */     return new WurstplusCapeUUID(url, "DELETE");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID delete(CharSequence baseUrl, Map<?, ?> params, boolean encode) {
/* 1134 */     String url = append(baseUrl, params);
/* 1135 */     return delete(encode ? encode(url) : url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID delete(CharSequence baseUrl, boolean encode, Object... params) {
/* 1155 */     String url = append(baseUrl, params);
/* 1156 */     return delete(encode ? encode(url) : url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID head(CharSequence url) throws HttpRequestException {
/* 1168 */     return new WurstplusCapeUUID(url, "HEAD");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID head(URL url) throws HttpRequestException {
/* 1179 */     return new WurstplusCapeUUID(url, "HEAD");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID head(CharSequence baseUrl, Map<?, ?> params, boolean encode) {
/* 1198 */     String url = append(baseUrl, params);
/* 1199 */     return head(encode ? encode(url) : url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID head(CharSequence baseUrl, boolean encode, Object... params) {
/* 1219 */     String url = append(baseUrl, params);
/* 1220 */     return head(encode ? encode(url) : url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID options(CharSequence url) throws HttpRequestException {
/* 1232 */     return new WurstplusCapeUUID(url, "OPTIONS");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID options(URL url) throws HttpRequestException {
/* 1243 */     return new WurstplusCapeUUID(url, "OPTIONS");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID trace(CharSequence url) throws HttpRequestException {
/* 1255 */     return new WurstplusCapeUUID(url, "TRACE");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WurstplusCapeUUID trace(URL url) throws HttpRequestException {
/* 1266 */     return new WurstplusCapeUUID(url, "TRACE");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void keepAlive(boolean keepAlive) {
/* 1277 */     setProperty("http.keepAlive", Boolean.toString(keepAlive));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void maxConnections(int maxConnections) {
/* 1288 */     setProperty("http.maxConnections", Integer.toString(maxConnections));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void proxyHost(String host) {
/* 1300 */     setProperty("http.proxyHost", host);
/* 1301 */     setProperty("https.proxyHost", host);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void proxyPort(int port) {
/* 1313 */     String portValue = Integer.toString(port);
/* 1314 */     setProperty("http.proxyPort", portValue);
/* 1315 */     setProperty("https.proxyPort", portValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void nonProxyHosts(String... hosts) {
/* 1328 */     if (hosts != null && hosts.length > 0) {
/* 1329 */       StringBuilder separated = new StringBuilder();
/* 1330 */       int last = hosts.length - 1;
/* 1331 */       for (int i = 0; i < last; i++)
/* 1332 */         separated.append(hosts[i]).append('|'); 
/* 1333 */       separated.append(hosts[last]);
/* 1334 */       setProperty("http.nonProxyHosts", separated.toString());
/*      */     } else {
/* 1336 */       setProperty("http.nonProxyHosts", null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String setProperty(final String name, final String value) {
/*      */     PrivilegedAction<String> action;
/* 1350 */     if (value != null) {
/* 1351 */       action = new PrivilegedAction<String>()
/*      */         {
/*      */           public String run() {
/* 1354 */             return System.setProperty(name, value);
/*      */           }
/*      */         };
/*      */     } else {
/* 1358 */       action = new PrivilegedAction<String>()
/*      */         {
/*      */           public String run() {
/* 1361 */             return System.clearProperty(name); }
/*      */         };
/*      */     } 
/* 1364 */     return AccessController.<String>doPrivileged(action);
/*      */   }
/*      */   
/* 1367 */   private HttpURLConnection connection = null;
/*      */   
/*      */   private final URL url;
/*      */   
/*      */   private final String requestMethod;
/*      */   
/*      */   private RequestOutputStream output;
/*      */   
/*      */   private boolean multipart;
/*      */   
/*      */   private boolean form;
/*      */   
/*      */   private boolean ignoreCloseExceptions = true;
/*      */   
/*      */   private boolean uncompress = false;
/*      */   
/* 1383 */   private int bufferSize = 8192;
/*      */   
/* 1385 */   private long totalSize = -1L;
/*      */   
/* 1387 */   private long totalWritten = 0L;
/*      */   
/*      */   private String httpProxyHost;
/*      */   
/*      */   private int httpProxyPort;
/*      */   
/* 1393 */   private UploadProgress progress = UploadProgress.DEFAULT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID(CharSequence url, String method) throws HttpRequestException {
/*      */     try {
/* 1405 */       this.url = new URL(url.toString());
/* 1406 */     } catch (MalformedURLException e) {
/* 1407 */       throw new HttpRequestException(e);
/*      */     } 
/* 1409 */     this.requestMethod = method;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID(URL url, String method) throws HttpRequestException {
/* 1421 */     this.url = url;
/* 1422 */     this.requestMethod = method;
/*      */   }
/*      */   
/*      */   private Proxy createProxy() {
/* 1426 */     return new Proxy(Proxy.Type.HTTP, new InetSocketAddress(this.httpProxyHost, this.httpProxyPort));
/*      */   }
/*      */   
/*      */   private HttpURLConnection createConnection() {
/*      */     try {
/*      */       HttpURLConnection connection;
/* 1432 */       if (this.httpProxyHost != null) {
/* 1433 */         connection = CONNECTION_FACTORY.create(this.url, createProxy());
/*      */       } else {
/* 1435 */         connection = CONNECTION_FACTORY.create(this.url);
/* 1436 */       }  connection.setRequestMethod(this.requestMethod);
/* 1437 */       return connection;
/* 1438 */     } catch (IOException e) {
/* 1439 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1445 */     return method() + ' ' + url();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpURLConnection getConnection() {
/* 1454 */     if (this.connection == null)
/* 1455 */       this.connection = createConnection(); 
/* 1456 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID ignoreCloseExceptions(boolean ignore) {
/* 1469 */     this.ignoreCloseExceptions = ignore;
/* 1470 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ignoreCloseExceptions() {
/* 1480 */     return this.ignoreCloseExceptions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int code() throws HttpRequestException {
/*      */     try {
/* 1491 */       closeOutput();
/* 1492 */       return getConnection().getResponseCode();
/* 1493 */     } catch (IOException e) {
/* 1494 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID code(AtomicInteger output) throws HttpRequestException {
/* 1508 */     output.set(code());
/* 1509 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ok() throws HttpRequestException {
/* 1519 */     return (200 == code());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean created() throws HttpRequestException {
/* 1529 */     return (201 == code());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean noContent() throws HttpRequestException {
/* 1539 */     return (204 == code());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean serverError() throws HttpRequestException {
/* 1549 */     return (500 == code());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean badRequest() throws HttpRequestException {
/* 1559 */     return (400 == code());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean notFound() throws HttpRequestException {
/* 1569 */     return (404 == code());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean notModified() throws HttpRequestException {
/* 1579 */     return (304 == code());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String message() throws HttpRequestException {
/*      */     try {
/* 1590 */       closeOutput();
/* 1591 */       return getConnection().getResponseMessage();
/* 1592 */     } catch (IOException e) {
/* 1593 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID disconnect() {
/* 1603 */     getConnection().disconnect();
/* 1604 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID chunk(int size) {
/* 1614 */     getConnection().setChunkedStreamingMode(size);
/* 1615 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID bufferSize(int size) {
/* 1630 */     if (size < 1)
/* 1631 */       throw new IllegalArgumentException("Size must be greater than zero"); 
/* 1632 */     this.bufferSize = size;
/* 1633 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int bufferSize() {
/* 1644 */     return this.bufferSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID uncompress(boolean uncompress) {
/* 1666 */     this.uncompress = uncompress;
/* 1667 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ByteArrayOutputStream byteStream() {
/* 1676 */     int size = contentLength();
/* 1677 */     if (size > 0) {
/* 1678 */       return new ByteArrayOutputStream(size);
/*      */     }
/* 1680 */     return new ByteArrayOutputStream();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String body(String charset) throws HttpRequestException {
/* 1694 */     ByteArrayOutputStream output = byteStream();
/*      */     try {
/* 1696 */       copy(buffer(), output);
/* 1697 */       return output.toString(getValidCharset(charset));
/* 1698 */     } catch (IOException e) {
/* 1699 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String body() throws HttpRequestException {
/* 1711 */     return body(charset());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID body(AtomicReference<String> output) throws HttpRequestException {
/* 1723 */     output.set(body());
/* 1724 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID body(AtomicReference<String> output, String charset) throws HttpRequestException {
/* 1737 */     output.set(body(charset));
/* 1738 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBodyEmpty() throws HttpRequestException {
/* 1749 */     return (contentLength() == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] bytes() throws HttpRequestException {
/* 1759 */     ByteArrayOutputStream output = byteStream();
/*      */     try {
/* 1761 */       copy(buffer(), output);
/* 1762 */     } catch (IOException e) {
/* 1763 */       throw new HttpRequestException(e);
/*      */     } 
/* 1765 */     return output.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedInputStream buffer() throws HttpRequestException {
/* 1776 */     return new BufferedInputStream(stream(), this.bufferSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream stream() throws HttpRequestException {
/*      */     InputStream stream;
/* 1787 */     if (code() < 400) {
/*      */       try {
/* 1789 */         stream = getConnection().getInputStream();
/* 1790 */       } catch (IOException e) {
/* 1791 */         throw new HttpRequestException(e);
/*      */       } 
/*      */     } else {
/* 1794 */       stream = getConnection().getErrorStream();
/* 1795 */       if (stream == null) {
/*      */         try {
/* 1797 */           stream = getConnection().getInputStream();
/* 1798 */         } catch (IOException e) {
/* 1799 */           if (contentLength() > 0) {
/* 1800 */             throw new HttpRequestException(e);
/*      */           }
/* 1802 */           stream = new ByteArrayInputStream(new byte[0]);
/*      */         } 
/*      */       }
/*      */     } 
/* 1806 */     if (!this.uncompress || !"gzip".equals(contentEncoding())) {
/* 1807 */       return stream;
/*      */     }
/*      */     try {
/* 1810 */       return new GZIPInputStream(stream);
/* 1811 */     } catch (IOException e) {
/* 1812 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStreamReader reader(String charset) throws HttpRequestException {
/*      */     try {
/* 1829 */       return new InputStreamReader(stream(), getValidCharset(charset));
/* 1830 */     } catch (UnsupportedEncodingException e) {
/* 1831 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStreamReader reader() throws HttpRequestException {
/* 1843 */     return reader(charset());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedReader bufferedReader(String charset) throws HttpRequestException {
/* 1858 */     return new BufferedReader(reader(charset), this.bufferSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedReader bufferedReader() throws HttpRequestException {
/* 1870 */     return bufferedReader(charset());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID receive(File file) throws HttpRequestException {
/*      */     final OutputStream output;
/*      */     try {
/* 1883 */       output = new BufferedOutputStream(new FileOutputStream(file), this.bufferSize);
/* 1884 */     } catch (FileNotFoundException e) {
/* 1885 */       throw new HttpRequestException(e);
/*      */     } 
/* 1887 */     return (new CloseOperation<WurstplusCapeUUID>(output, this.ignoreCloseExceptions)
/*      */       {
/*      */         protected WurstplusCapeUUID run() throws WurstplusCapeUUID.HttpRequestException, IOException
/*      */         {
/* 1891 */           return WurstplusCapeUUID.this.receive(output);
/*      */         }
/* 1893 */       }).call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID receive(OutputStream output) throws HttpRequestException {
/*      */     try {
/* 1906 */       return copy(buffer(), output);
/* 1907 */     } catch (IOException e) {
/* 1908 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID receive(PrintStream output) throws HttpRequestException {
/* 1921 */     return receive(output);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID receive(final Appendable appendable) throws HttpRequestException {
/* 1933 */     final BufferedReader reader = bufferedReader();
/* 1934 */     return (new CloseOperation<WurstplusCapeUUID>(reader, this.ignoreCloseExceptions)
/*      */       {
/*      */         public WurstplusCapeUUID run() throws IOException
/*      */         {
/* 1938 */           CharBuffer buffer = CharBuffer.allocate(WurstplusCapeUUID.this.bufferSize);
/*      */           int read;
/* 1940 */           while ((read = reader.read(buffer)) != -1) {
/* 1941 */             buffer.rewind();
/* 1942 */             appendable.append(buffer, 0, read);
/* 1943 */             buffer.rewind();
/*      */           } 
/* 1945 */           return WurstplusCapeUUID.this;
/*      */         }
/* 1947 */       }).call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID receive(final Writer writer) throws HttpRequestException {
/* 1958 */     final BufferedReader reader = bufferedReader();
/* 1959 */     return (new CloseOperation<WurstplusCapeUUID>(reader, this.ignoreCloseExceptions)
/*      */       {
/*      */         public WurstplusCapeUUID run() throws IOException
/*      */         {
/* 1963 */           return WurstplusCapeUUID.this.copy(reader, writer);
/*      */         }
/* 1965 */       }).call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID readTimeout(int timeout) {
/* 1975 */     getConnection().setReadTimeout(timeout);
/* 1976 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID connectTimeout(int timeout) {
/* 1986 */     getConnection().setConnectTimeout(timeout);
/* 1987 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID header(String name, String value) {
/* 1998 */     getConnection().setRequestProperty(name, value);
/* 1999 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID header(String name, Number value) {
/* 2010 */     return header(name, (value != null) ? value.toString() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID headers(Map<String, String> headers) {
/* 2021 */     if (!headers.isEmpty())
/* 2022 */       for (Map.Entry<String, String> header : headers.entrySet())
/* 2023 */         header(header);  
/* 2024 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID header(Map.Entry<String, String> header) {
/* 2034 */     return header(header.getKey(), header.getValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String header(String name) throws HttpRequestException {
/* 2045 */     closeOutputQuietly();
/* 2046 */     return getConnection().getHeaderField(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, List<String>> headers() throws HttpRequestException {
/* 2056 */     closeOutputQuietly();
/* 2057 */     return getConnection().getHeaderFields();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long dateHeader(String name) throws HttpRequestException {
/* 2069 */     return dateHeader(name, -1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long dateHeader(String name, long defaultValue) throws HttpRequestException {
/* 2083 */     closeOutputQuietly();
/* 2084 */     return getConnection().getHeaderFieldDate(name, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int intHeader(String name) throws HttpRequestException {
/* 2096 */     return intHeader(name, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int intHeader(String name, int defaultValue) throws HttpRequestException {
/* 2111 */     closeOutputQuietly();
/* 2112 */     return getConnection().getHeaderFieldInt(name, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] headers(String name) {
/* 2122 */     Map<String, List<String>> headers = headers();
/* 2123 */     if (headers == null || headers.isEmpty()) {
/* 2124 */       return EMPTY_STRINGS;
/*      */     }
/* 2126 */     List<String> values = headers.get(name);
/* 2127 */     if (values != null && !values.isEmpty()) {
/* 2128 */       return values.<String>toArray(new String[values.size()]);
/*      */     }
/* 2130 */     return EMPTY_STRINGS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String parameter(String headerName, String paramName) {
/* 2141 */     return getParam(header(headerName), paramName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, String> parameters(String headerName) {
/* 2154 */     return getParams(header(headerName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, String> getParams(String header) {
/* 2164 */     if (header == null || header.length() == 0) {
/* 2165 */       return Collections.emptyMap();
/*      */     }
/* 2167 */     int headerLength = header.length();
/* 2168 */     int start = header.indexOf(';') + 1;
/* 2169 */     if (start == 0 || start == headerLength) {
/* 2170 */       return Collections.emptyMap();
/*      */     }
/* 2172 */     int end = header.indexOf(';', start);
/* 2173 */     if (end == -1) {
/* 2174 */       end = headerLength;
/*      */     }
/* 2176 */     Map<String, String> params = new LinkedHashMap<>();
/* 2177 */     while (start < end) {
/* 2178 */       int nameEnd = header.indexOf('=', start);
/* 2179 */       if (nameEnd != -1 && nameEnd < end) {
/* 2180 */         String name = header.substring(start, nameEnd).trim();
/* 2181 */         if (name.length() > 0) {
/* 2182 */           String value = header.substring(nameEnd + 1, end).trim();
/* 2183 */           int length = value.length();
/* 2184 */           if (length != 0)
/* 2185 */             if (length > 2 && '"' == value.charAt(0) && '"' == value
/* 2186 */               .charAt(length - 1)) {
/* 2187 */               params.put(name, value.substring(1, length - 1));
/*      */             } else {
/* 2189 */               params.put(name, value);
/*      */             }  
/*      */         } 
/*      */       } 
/* 2193 */       start = end + 1;
/* 2194 */       end = header.indexOf(';', start);
/* 2195 */       if (end == -1) {
/* 2196 */         end = headerLength;
/*      */       }
/*      */     } 
/* 2199 */     return params;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getParam(String value, String paramName) {
/* 2210 */     if (value == null || value.length() == 0) {
/* 2211 */       return null;
/*      */     }
/* 2213 */     int length = value.length();
/* 2214 */     int start = value.indexOf(';') + 1;
/* 2215 */     if (start == 0 || start == length) {
/* 2216 */       return null;
/*      */     }
/* 2218 */     int end = value.indexOf(';', start);
/* 2219 */     if (end == -1) {
/* 2220 */       end = length;
/*      */     }
/* 2222 */     while (start < end) {
/* 2223 */       int nameEnd = value.indexOf('=', start);
/* 2224 */       if (nameEnd != -1 && nameEnd < end && paramName
/* 2225 */         .equals(value.substring(start, nameEnd).trim())) {
/* 2226 */         String paramValue = value.substring(nameEnd + 1, end).trim();
/* 2227 */         int valueLength = paramValue.length();
/* 2228 */         if (valueLength != 0) {
/* 2229 */           if (valueLength > 2 && '"' == paramValue.charAt(0) && '"' == paramValue
/* 2230 */             .charAt(valueLength - 1)) {
/* 2231 */             return paramValue.substring(1, valueLength - 1);
/*      */           }
/* 2233 */           return paramValue;
/*      */         } 
/*      */       } 
/* 2236 */       start = end + 1;
/* 2237 */       end = value.indexOf(';', start);
/* 2238 */       if (end == -1) {
/* 2239 */         end = length;
/*      */       }
/*      */     } 
/* 2242 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String charset() {
/* 2251 */     return parameter("Content-Type", "charset");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID userAgent(String userAgent) {
/* 2261 */     return header("User-Agent", userAgent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID referer(String referer) {
/* 2271 */     return header("Referer", referer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID useCaches(boolean useCaches) {
/* 2281 */     getConnection().setUseCaches(useCaches);
/* 2282 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID acceptEncoding(String acceptEncoding) {
/* 2292 */     return header("Accept-Encoding", acceptEncoding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID acceptGzipEncoding() {
/* 2302 */     return acceptEncoding("gzip");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID acceptCharset(String acceptCharset) {
/* 2312 */     return header("Accept-Charset", acceptCharset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String contentEncoding() {
/* 2321 */     return header("Content-Encoding");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String server() {
/* 2330 */     return header("Server");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long date() {
/* 2339 */     return dateHeader("Date");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String cacheControl() {
/* 2348 */     return header("Cache-Control");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String eTag() {
/* 2357 */     return header("ETag");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long expires() {
/* 2366 */     return dateHeader("Expires");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long lastModified() {
/* 2375 */     return dateHeader("Last-Modified");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String location() {
/* 2384 */     return header("Location");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID authorization(String authorization) {
/* 2394 */     return header("Authorization", authorization);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID proxyAuthorization(String proxyAuthorization) {
/* 2404 */     return header("Proxy-Authorization", proxyAuthorization);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID basic(String name, String password) {
/* 2416 */     return authorization("Basic " + Base64.encode(name + ':' + password));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID proxyBasic(String name, String password) {
/* 2428 */     return proxyAuthorization("Basic " + Base64.encode(name + ':' + password));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID ifModifiedSince(long ifModifiedSince) {
/* 2438 */     getConnection().setIfModifiedSince(ifModifiedSince);
/* 2439 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID ifNoneMatch(String ifNoneMatch) {
/* 2449 */     return header("If-None-Match", ifNoneMatch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID contentType(String contentType) {
/* 2459 */     return contentType(contentType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID contentType(String contentType, String charset) {
/* 2470 */     if (charset != null && charset.length() > 0) {
/* 2471 */       String separator = "; charset=";
/* 2472 */       return header("Content-Type", contentType + "; charset=" + charset);
/*      */     } 
/* 2474 */     return header("Content-Type", contentType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String contentType() {
/* 2483 */     return header("Content-Type");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int contentLength() {
/* 2492 */     return intHeader("Content-Length");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID contentLength(String contentLength) {
/* 2502 */     return contentLength(Integer.parseInt(contentLength));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID contentLength(int contentLength) {
/* 2512 */     getConnection().setFixedLengthStreamingMode(contentLength);
/* 2513 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID accept(String accept) {
/* 2523 */     return header("Accept", accept);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID acceptJson() {
/* 2532 */     return accept("application/json");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected WurstplusCapeUUID copy(final InputStream input, final OutputStream output) throws IOException {
/* 2545 */     return (new CloseOperation<WurstplusCapeUUID>(input, this.ignoreCloseExceptions)
/*      */       {
/*      */         public WurstplusCapeUUID run() throws IOException
/*      */         {
/* 2549 */           byte[] buffer = new byte[WurstplusCapeUUID.this.bufferSize];
/*      */           int read;
/* 2551 */           while ((read = input.read(buffer)) != -1) {
/* 2552 */             output.write(buffer, 0, read);
/* 2553 */             WurstplusCapeUUID.this.totalWritten = WurstplusCapeUUID.this.totalWritten + read;
/* 2554 */             WurstplusCapeUUID.this.progress.onUpload(WurstplusCapeUUID.this.totalWritten, WurstplusCapeUUID.this.totalSize);
/*      */           } 
/* 2556 */           return WurstplusCapeUUID.this;
/*      */         }
/* 2558 */       }).call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected WurstplusCapeUUID copy(final Reader input, final Writer output) throws IOException {
/* 2571 */     return (new CloseOperation<WurstplusCapeUUID>(input, this.ignoreCloseExceptions)
/*      */       {
/*      */         public WurstplusCapeUUID run() throws IOException
/*      */         {
/* 2575 */           char[] buffer = new char[WurstplusCapeUUID.this.bufferSize];
/*      */           int read;
/* 2577 */           while ((read = input.read(buffer)) != -1) {
/* 2578 */             output.write(buffer, 0, read);
/* 2579 */             WurstplusCapeUUID.this.totalWritten = WurstplusCapeUUID.this.totalWritten + read;
/* 2580 */             WurstplusCapeUUID.this.progress.onUpload(WurstplusCapeUUID.this.totalWritten, -1L);
/*      */           } 
/* 2582 */           return WurstplusCapeUUID.this;
/*      */         }
/* 2584 */       }).call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID progress(UploadProgress callback) {
/* 2594 */     if (callback == null) {
/* 2595 */       this.progress = UploadProgress.DEFAULT;
/*      */     } else {
/* 2597 */       this.progress = callback;
/* 2598 */     }  return this;
/*      */   }
/*      */   
/*      */   private WurstplusCapeUUID incrementTotalSize(long size) {
/* 2602 */     if (this.totalSize == -1L)
/* 2603 */       this.totalSize = 0L; 
/* 2604 */     this.totalSize += size;
/* 2605 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected WurstplusCapeUUID closeOutput() throws IOException {
/* 2616 */     progress(null);
/* 2617 */     if (this.output == null)
/* 2618 */       return this; 
/* 2619 */     if (this.multipart)
/* 2620 */       this.output.write("\r\n--00content0boundary00--\r\n"); 
/* 2621 */     if (this.ignoreCloseExceptions) {
/*      */       try {
/* 2623 */         this.output.close();
/* 2624 */       } catch (IOException iOException) {}
/*      */     }
/*      */     else {
/*      */       
/* 2628 */       this.output.close();
/* 2629 */     }  this.output = null;
/* 2630 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected WurstplusCapeUUID closeOutputQuietly() throws HttpRequestException {
/*      */     try {
/* 2642 */       return closeOutput();
/* 2643 */     } catch (IOException e) {
/* 2644 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected WurstplusCapeUUID openOutput() throws IOException {
/* 2655 */     if (this.output != null)
/* 2656 */       return this; 
/* 2657 */     getConnection().setDoOutput(true);
/* 2658 */     String charset = getParam(
/* 2659 */         getConnection().getRequestProperty("Content-Type"), "charset");
/* 2660 */     this.output = new RequestOutputStream(getConnection().getOutputStream(), charset, this.bufferSize);
/*      */     
/* 2662 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected WurstplusCapeUUID startPart() throws IOException {
/* 2672 */     if (!this.multipart) {
/* 2673 */       this.multipart = true;
/* 2674 */       contentType("multipart/form-data; boundary=00content0boundary00").openOutput();
/* 2675 */       this.output.write("--00content0boundary00\r\n");
/*      */     } else {
/* 2677 */       this.output.write("\r\n--00content0boundary00\r\n");
/* 2678 */     }  return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected WurstplusCapeUUID writePartHeader(String name, String filename) throws IOException {
/* 2691 */     return writePartHeader(name, filename, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected WurstplusCapeUUID writePartHeader(String name, String filename, String contentType) throws IOException {
/* 2705 */     StringBuilder partBuffer = new StringBuilder();
/* 2706 */     partBuffer.append("form-data; name=\"").append(name);
/* 2707 */     if (filename != null)
/* 2708 */       partBuffer.append("\"; filename=\"").append(filename); 
/* 2709 */     partBuffer.append('"');
/* 2710 */     partHeader("Content-Disposition", partBuffer.toString());
/* 2711 */     if (contentType != null)
/* 2712 */       partHeader("Content-Type", contentType); 
/* 2713 */     return send("\r\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID part(String name, String part) {
/* 2724 */     return part(name, (String)null, part);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID part(String name, String filename, String part) throws HttpRequestException {
/* 2738 */     return part(name, filename, (String)null, part);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID part(String name, String filename, String contentType, String part) throws HttpRequestException {
/*      */     try {
/* 2755 */       startPart();
/* 2756 */       writePartHeader(name, filename, contentType);
/* 2757 */       this.output.write(part);
/* 2758 */     } catch (IOException e) {
/* 2759 */       throw new HttpRequestException(e);
/*      */     } 
/* 2761 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID part(String name, Number part) throws HttpRequestException {
/* 2774 */     return part(name, (String)null, part);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID part(String name, String filename, Number part) throws HttpRequestException {
/* 2788 */     return part(name, filename, (part != null) ? part.toString() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID part(String name, File part) throws HttpRequestException {
/* 2801 */     return part(name, (String)null, part);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID part(String name, String filename, File part) throws HttpRequestException {
/* 2815 */     return part(name, filename, (String)null, part);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID part(String name, String filename, String contentType, File part) throws HttpRequestException {
/*      */     InputStream stream;
/*      */     try {
/* 2833 */       stream = new BufferedInputStream(new FileInputStream(part));
/* 2834 */       incrementTotalSize(part.length());
/* 2835 */     } catch (IOException e) {
/* 2836 */       throw new HttpRequestException(e);
/*      */     } 
/* 2838 */     return part(name, filename, contentType, stream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID part(String name, InputStream part) throws HttpRequestException {
/* 2851 */     return part(name, (String)null, (String)null, part);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID part(String name, String filename, String contentType, InputStream part) throws HttpRequestException {
/*      */     try {
/* 2869 */       startPart();
/* 2870 */       writePartHeader(name, filename, contentType);
/* 2871 */       copy(part, this.output);
/* 2872 */     } catch (IOException e) {
/* 2873 */       throw new HttpRequestException(e);
/*      */     } 
/* 2875 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID partHeader(String name, String value) throws HttpRequestException {
/* 2888 */     return send(name).send(": ").send(value).send("\r\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID send(File input) throws HttpRequestException {
/*      */     InputStream stream;
/*      */     try {
/* 2901 */       stream = new BufferedInputStream(new FileInputStream(input));
/* 2902 */       incrementTotalSize(input.length());
/* 2903 */     } catch (FileNotFoundException e) {
/* 2904 */       throw new HttpRequestException(e);
/*      */     } 
/* 2906 */     return send(stream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID send(byte[] input) throws HttpRequestException {
/* 2917 */     if (input != null)
/* 2918 */       incrementTotalSize(input.length); 
/* 2919 */     return send(new ByteArrayInputStream(input));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID send(InputStream input) throws HttpRequestException {
/*      */     try {
/* 2933 */       openOutput();
/* 2934 */       copy(input, this.output);
/* 2935 */     } catch (IOException e) {
/* 2936 */       throw new HttpRequestException(e);
/*      */     } 
/* 2938 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID send(final Reader input) throws HttpRequestException {
/*      */     try {
/* 2952 */       openOutput();
/* 2953 */     } catch (IOException e) {
/* 2954 */       throw new HttpRequestException(e);
/*      */     } 
/*      */     
/* 2957 */     final Writer writer = new OutputStreamWriter(this.output, this.output.encoder.charset());
/* 2958 */     return (new FlushOperation<WurstplusCapeUUID>(writer)
/*      */       {
/*      */         protected WurstplusCapeUUID run() throws IOException
/*      */         {
/* 2962 */           return WurstplusCapeUUID.this.copy(input, writer);
/*      */         }
/* 2964 */       }).call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID send(CharSequence value) throws HttpRequestException {
/*      */     try {
/* 2979 */       openOutput();
/* 2980 */       this.output.write(value.toString());
/* 2981 */     } catch (IOException e) {
/* 2982 */       throw new HttpRequestException(e);
/*      */     } 
/* 2984 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStreamWriter writer() throws HttpRequestException {
/*      */     try {
/* 2995 */       openOutput();
/* 2996 */       return new OutputStreamWriter(this.output, this.output.encoder.charset());
/* 2997 */     } catch (IOException e) {
/* 2998 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID form(Map<?, ?> values) throws HttpRequestException {
/* 3013 */     return form(values, "UTF-8");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID form(Map.Entry<?, ?> entry) throws HttpRequestException {
/* 3027 */     return form(entry, "UTF-8");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID form(Map.Entry<?, ?> entry, String charset) throws HttpRequestException {
/* 3043 */     return form(entry.getKey(), entry.getValue(), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID form(Object name, Object value) throws HttpRequestException {
/* 3059 */     return form(name, value, "UTF-8");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID form(Object name, Object value, String charset) throws HttpRequestException {
/* 3076 */     boolean first = !this.form;
/* 3077 */     if (first) {
/* 3078 */       contentType("application/x-www-form-urlencoded", charset);
/* 3079 */       this.form = true;
/*      */     } 
/* 3081 */     charset = getValidCharset(charset);
/*      */     try {
/* 3083 */       openOutput();
/* 3084 */       if (!first)
/* 3085 */         this.output.write(38); 
/* 3086 */       this.output.write(URLEncoder.encode(name.toString(), charset));
/* 3087 */       this.output.write(61);
/* 3088 */       if (value != null)
/* 3089 */         this.output.write(URLEncoder.encode(value.toString(), charset)); 
/* 3090 */     } catch (IOException e) {
/* 3091 */       throw new HttpRequestException(e);
/*      */     } 
/* 3093 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID form(Map<?, ?> values, String charset) throws HttpRequestException {
/* 3106 */     if (!values.isEmpty())
/* 3107 */       for (Map.Entry<?, ?> entry : values.entrySet())
/* 3108 */         form(entry, charset);  
/* 3109 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID trustAllCerts() throws HttpRequestException {
/* 3121 */     HttpURLConnection connection = getConnection();
/* 3122 */     if (connection instanceof HttpsURLConnection)
/* 3123 */       ((HttpsURLConnection)connection)
/* 3124 */         .setSSLSocketFactory(getTrustedFactory()); 
/* 3125 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID trustAllHosts() {
/* 3138 */     HttpURLConnection connection = getConnection();
/* 3139 */     if (connection instanceof HttpsURLConnection)
/* 3140 */       ((HttpsURLConnection)connection)
/* 3141 */         .setHostnameVerifier(getTrustedVerifier()); 
/* 3142 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL url() {
/* 3151 */     return getConnection().getURL();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String method() {
/* 3160 */     return getConnection().getRequestMethod();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID useProxy(String proxyHost, int proxyPort) {
/* 3172 */     if (this.connection != null) {
/* 3173 */       throw new IllegalStateException("The connection has already been created. This method must be called before reading or writing to the request.");
/*      */     }
/* 3175 */     this.httpProxyHost = proxyHost;
/* 3176 */     this.httpProxyPort = proxyPort;
/* 3177 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WurstplusCapeUUID followRedirects(boolean followRedirects) {
/* 3188 */     getConnection().setInstanceFollowRedirects(followRedirects);
/* 3189 */     return this;
/*      */   }
/*      */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\WurstplusCapeUUID.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */