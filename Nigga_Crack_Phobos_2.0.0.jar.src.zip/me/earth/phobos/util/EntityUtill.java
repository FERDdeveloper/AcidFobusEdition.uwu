/*     */ package me.earth.phobos.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import me.earth.phobos.Phobos;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityUtill
/*     */ {
/*  24 */   private static final Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*     */   public static Block isColliding(double posX, double posY, double posZ) {
/*  27 */     Block block = null;
/*  28 */     if (mc.field_71439_g != null) {
/*  29 */       AxisAlignedBB bb = (mc.field_71439_g.func_184187_bx() != null) ? mc.field_71439_g.func_184187_bx().func_174813_aQ().func_191195_a(0.0D, 0.0D, 0.0D).func_72317_d(posX, posY, posZ) : mc.field_71439_g.func_174813_aQ().func_191195_a(0.0D, 0.0D, 0.0D).func_72317_d(posX, posY, posZ);
/*  30 */       int y = (int)bb.field_72338_b;
/*  31 */       for (int x = MathHelper.func_76128_c(bb.field_72340_a); x < MathHelper.func_76128_c(bb.field_72336_d) + 1; x++) {
/*  32 */         for (int z = MathHelper.func_76128_c(bb.field_72339_c); z < MathHelper.func_76128_c(bb.field_72334_f) + 1; z++) {
/*  33 */           block = mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
/*     */         }
/*     */       } 
/*     */     } 
/*  37 */     return block;
/*     */   }
/*     */   
/*     */   public static boolean isInLiquid() {
/*  41 */     if (mc.field_71439_g != null) {
/*  42 */       if (mc.field_71439_g.field_70143_R >= 3.0F) {
/*  43 */         return false;
/*     */       }
/*  45 */       boolean inLiquid = false;
/*  46 */       AxisAlignedBB bb = (mc.field_71439_g.func_184187_bx() != null) ? mc.field_71439_g.func_184187_bx().func_174813_aQ() : mc.field_71439_g.func_174813_aQ();
/*  47 */       int y = (int)bb.field_72338_b;
/*  48 */       for (int x = MathHelper.func_76128_c(bb.field_72340_a); x < MathHelper.func_76128_c(bb.field_72336_d) + 1; x++) {
/*  49 */         for (int z = MathHelper.func_76128_c(bb.field_72339_c); z < MathHelper.func_76128_c(bb.field_72334_f) + 1; z++) {
/*  50 */           Block block = mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
/*  51 */           if (!(block instanceof net.minecraft.block.BlockAir)) {
/*  52 */             if (!(block instanceof net.minecraft.block.BlockLiquid)) {
/*  53 */               return false;
/*     */             }
/*  55 */             inLiquid = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*  59 */       return inLiquid;
/*     */     } 
/*  61 */     return false;
/*     */   }
/*     */   
/*     */   public static void setTimer(float speed) {
/*  65 */     (Minecraft.func_71410_x()).field_71428_T.field_194149_e = 50.0F / speed;
/*     */   }
/*     */   
/*     */   public static void resetTimer() {
/*  69 */     (Minecraft.func_71410_x()).field_71428_T.field_194149_e = 50.0F;
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedAmount(Entity entity, double ticks) {
/*  73 */     return getInterpolatedAmount(entity, ticks, ticks, ticks);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedPos(Entity entity, float ticks) {
/*  77 */     return (new Vec3d(entity.field_70142_S, entity.field_70137_T, entity.field_70136_U)).func_178787_e(getInterpolatedAmount(entity, ticks));
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedAmount(Entity entity, double x, double y, double z) {
/*  81 */     return new Vec3d((entity.field_70165_t - entity.field_70142_S) * x, (entity.field_70163_u - entity.field_70137_T) * y, (entity.field_70161_v - entity.field_70136_U) * z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float clamp(float val, float min, float max) {
/*  89 */     if (val <= min) {
/*  90 */       val = min;
/*     */     }
/*  92 */     if (val >= max) {
/*  93 */       val = max;
/*     */     }
/*  95 */     return val;
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getSphere(BlockPos loc, float r, int h, boolean hollow, boolean sphere, int plus_y) {
/*  99 */     List<BlockPos> circleblocks = new ArrayList<>();
/* 100 */     int cx = loc.func_177958_n();
/* 101 */     int cy = loc.func_177956_o();
/* 102 */     int cz = loc.func_177952_p();
/* 103 */     for (int x = cx - (int)r; x <= cx + r; x++) {
/* 104 */       for (int z = cz - (int)r; z <= cz + r; ) {
/* 105 */         int y = sphere ? (cy - (int)r) : cy; for (;; z++) { if (y < (sphere ? (cy + r) : (cy + h))) {
/* 106 */             double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0));
/* 107 */             if (dist < (r * r) && (!hollow || dist >= ((r - 1.0F) * (r - 1.0F)))) {
/* 108 */               BlockPos l = new BlockPos(x, y + plus_y, z);
/* 109 */               circleblocks.add(l);
/*     */             }  y++; continue;
/*     */           }  }
/*     */       
/*     */       } 
/* 114 */     }  return circleblocks;
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getSquare(BlockPos pos1, BlockPos pos2) {
/* 118 */     List<BlockPos> squareBlocks = new ArrayList<>();
/* 119 */     int x1 = pos1.func_177958_n();
/* 120 */     int y1 = pos1.func_177956_o();
/* 121 */     int z1 = pos1.func_177952_p();
/* 122 */     int x2 = pos2.func_177958_n();
/* 123 */     int y2 = pos2.func_177956_o();
/* 124 */     int z2 = pos2.func_177952_p();
/* 125 */     for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
/* 126 */       for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
/* 127 */         for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
/* 128 */           squareBlocks.add(new BlockPos(x, y, z));
/*     */         }
/*     */       } 
/*     */     } 
/* 132 */     return squareBlocks;
/*     */   }
/*     */   
/*     */   public static double[] calculateLookAt(double px, double py, double pz, Entity me) {
/* 136 */     double dirx = me.field_70165_t - px;
/* 137 */     double diry = me.field_70163_u - py;
/* 138 */     double dirz = me.field_70161_v - pz;
/*     */     
/* 140 */     double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
/*     */     
/* 142 */     dirx /= len;
/* 143 */     diry /= len;
/* 144 */     dirz /= len;
/*     */     
/* 146 */     double pitch = Math.asin(diry);
/* 147 */     double yaw = Math.atan2(dirz, dirx);
/*     */     
/* 149 */     pitch = pitch * 180.0D / Math.PI;
/* 150 */     yaw = yaw * 180.0D / Math.PI;
/*     */     
/* 152 */     yaw += 90.0D;
/*     */     
/* 154 */     return new double[] { yaw, pitch };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean basicChecksEntity(Entity pl) {
/* 160 */     return (pl.func_70005_c_().equals(mc.field_71439_g.func_70005_c_()) || Phobos.friendManager.isFriend(pl.func_70005_c_()) || pl.field_70128_L);
/*     */   }
/*     */   
/*     */   public static BlockPos getPosition(Entity pl) {
/* 164 */     return new BlockPos(Math.floor(pl.field_70165_t), Math.floor(pl.field_70163_u), Math.floor(pl.field_70161_v));
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getBlocksIn(Entity pl) {
/* 168 */     List<BlockPos> blocks = new ArrayList<>();
/* 169 */     AxisAlignedBB bb = pl.func_174813_aQ();
/* 170 */     for (double x = Math.floor(bb.field_72340_a); x < Math.ceil(bb.field_72336_d); x++) {
/* 171 */       double y; for (y = Math.floor(bb.field_72338_b); y < Math.ceil(bb.field_72337_e); y++) {
/* 172 */         double z; for (z = Math.floor(bb.field_72339_c); z < Math.ceil(bb.field_72334_f); z++) {
/* 173 */           blocks.add(new BlockPos(x, y, z));
/*     */         }
/*     */       } 
/*     */     } 
/* 177 */     return blocks;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\EntityUtill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */