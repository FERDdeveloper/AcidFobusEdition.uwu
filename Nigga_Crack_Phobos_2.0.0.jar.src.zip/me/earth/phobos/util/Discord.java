/*    */ package me.earth.phobos.util;
/*    */ 
/*    */ import club.minnced.discord.rpc.DiscordEventHandlers;
/*    */ import club.minnced.discord.rpc.DiscordRPC;
/*    */ import club.minnced.discord.rpc.DiscordRichPresence;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Discord
/*    */ {
/* 11 */   private static String discordID = "826652734106501121";
/* 12 */   private static DiscordRichPresence discordRichPresence = new DiscordRichPresence();
/* 13 */   private static DiscordRPC discordRPC = DiscordRPC.INSTANCE;
/*    */   
/* 15 */   private static String clientVersion = "1.6";
/*    */   
/*    */   public static void startRPC() {
/* 18 */     DiscordEventHandlers eventHandlers = new DiscordEventHandlers();
/* 19 */     eventHandlers.disconnected = ((var1, var2) -> System.out.println("Discord RPC disconnected, var1: " + var1 + ", var2: " + var2));
/*    */     
/* 21 */     discordRPC.Discord_Initialize(discordID, eventHandlers, true, null);
/*    */     
/* 23 */     discordRichPresence.startTimestamp = System.currentTimeMillis() / 1000L;
/* 24 */     discordRichPresence.details = clientVersion;
/* 25 */     discordRichPresence.largeImageKey = "large";
/* 26 */     discordRichPresence.largeImageText = "discord.gg/AqKCkGCd";
/* 27 */     discordRichPresence.state = null;
/* 28 */     discordRPC.Discord_UpdatePresence(discordRichPresence);
/*    */   }
/*    */   
/*    */   public static void stopRPC() {
/* 32 */     discordRPC.Discord_Shutdown();
/* 33 */     discordRPC.Discord_ClearPresence();
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\Discord.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */