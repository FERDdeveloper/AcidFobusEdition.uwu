/*    */ package me.earth.phobos.util;
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ 
/*    */ public class WurstplusPlayer {
/*  6 */   private static final Gson gson = new Gson();
/*  7 */   private static final Gson PRETTY_PRINTING = (new GsonBuilder()).setPrettyPrinting().create();
/*    */   
/*    */   public String toJson() {
/* 10 */     return gson.toJson(this);
/*    */   }
/*    */   public String toJson(boolean prettyPrinting) {
/* 13 */     return prettyPrinting ? PRETTY_PRINTING.toJson(this) : gson.toJson(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\WurstplusPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */