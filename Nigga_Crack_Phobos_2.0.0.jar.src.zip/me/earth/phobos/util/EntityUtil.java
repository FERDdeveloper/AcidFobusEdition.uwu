/*     */ package me.earth.phobos.util;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.math.RoundingMode;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.features.modules.client.Managers;
/*     */ import me.earth.phobos.features.modules.combat.Killaura;
/*     */ import me.earth.phobos.features.modules.player.Blink;
/*     */ import me.earth.phobos.features.modules.player.FakePlayer;
/*     */ import me.earth.phobos.features.modules.player.Freecam;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.EnumCreatureType;
/*     */ import net.minecraft.entity.monster.EntityEnderman;
/*     */ import net.minecraft.entity.monster.EntityIronGolem;
/*     */ import net.minecraft.entity.monster.EntityPigZombie;
/*     */ import net.minecraft.entity.passive.EntityWolf;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Enchantments;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.MovementInput;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityUtil
/*     */   implements Util
/*     */ {
/*  54 */   public static final Vec3d[] antiDropOffsetList = new Vec3d[] { new Vec3d(0.0D, -2.0D, 0.0D) };
/*  55 */   public static final Vec3d[] platformOffsetList = new Vec3d[] { new Vec3d(0.0D, -1.0D, 0.0D), new Vec3d(0.0D, -1.0D, -1.0D), new Vec3d(0.0D, -1.0D, 1.0D), new Vec3d(-1.0D, -1.0D, 0.0D), new Vec3d(1.0D, -1.0D, 0.0D) };
/*  56 */   public static final Vec3d[] legOffsetList = new Vec3d[] { new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D) };
/*  57 */   public static final Vec3d[] OffsetList = new Vec3d[] { new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(0.0D, 1.0D, -1.0D), new Vec3d(0.0D, 2.0D, 0.0D) };
/*  58 */   public static final Vec3d[] headpiece = new Vec3d[] { new Vec3d(0.0D, 2.0D, 0.0D) };
/*  59 */   public static final Vec3d[] offsetsNoHead = new Vec3d[] { new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(0.0D, 1.0D, -1.0D) };
/*  60 */   public static final Vec3d[] antiStepOffsetList = new Vec3d[] { new Vec3d(-1.0D, 2.0D, 0.0D), new Vec3d(1.0D, 2.0D, 0.0D), new Vec3d(0.0D, 2.0D, 1.0D), new Vec3d(0.0D, 2.0D, -1.0D) };
/*  61 */   public static final Vec3d[] antiScaffoldOffsetList = new Vec3d[] { new Vec3d(0.0D, 3.0D, 0.0D) };
/*     */   
/*     */   public static void attackEntity(Entity entity, boolean packet, boolean swingArm) {
/*  64 */     if (packet) {
/*  65 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(entity));
/*     */     } else {
/*  67 */       mc.field_71442_b.func_78764_a((EntityPlayer)mc.field_71439_g, entity);
/*     */     } 
/*  69 */     if (swingArm) {
/*  70 */       mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Vec3d interpolateEntity(Entity entity, float time) {
/*  75 */     return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * time, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * time, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * time);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedPos(Entity entity, float partialTicks) {
/*  79 */     return (new Vec3d(entity.field_70142_S, entity.field_70137_T, entity.field_70136_U)).func_178787_e(getInterpolatedAmount(entity, partialTicks));
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedRenderPos(Entity entity, float partialTicks) {
/*  83 */     return getInterpolatedPos(entity, partialTicks).func_178786_a((mc.func_175598_ae()).field_78725_b, (mc.func_175598_ae()).field_78726_c, (mc.func_175598_ae()).field_78723_d);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedRenderPos(Vec3d vec) {
/*  87 */     return (new Vec3d(vec.field_72450_a, vec.field_72448_b, vec.field_72449_c)).func_178786_a((mc.func_175598_ae()).field_78725_b, (mc.func_175598_ae()).field_78726_c, (mc.func_175598_ae()).field_78723_d);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedAmount(Entity entity, double x, double y, double z) {
/*  91 */     return new Vec3d((entity.field_70165_t - entity.field_70142_S) * x, (entity.field_70163_u - entity.field_70137_T) * y, (entity.field_70161_v - entity.field_70136_U) * z);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedAmount(Entity entity, Vec3d vec) {
/*  95 */     return getInterpolatedAmount(entity, vec.field_72450_a, vec.field_72448_b, vec.field_72449_c);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedAmount(Entity entity, float partialTicks) {
/*  99 */     return getInterpolatedAmount(entity, partialTicks, partialTicks, partialTicks);
/*     */   }
/*     */   
/*     */   public static boolean isPassive(Entity entity) {
/* 103 */     if (entity instanceof EntityWolf && ((EntityWolf)entity).func_70919_bu()) {
/* 104 */       return false;
/*     */     }
/* 106 */     if (entity instanceof net.minecraft.entity.EntityAgeable || entity instanceof net.minecraft.entity.passive.EntityAmbientCreature || entity instanceof net.minecraft.entity.passive.EntitySquid) {
/* 107 */       return true;
/*     */     }
/* 109 */     return (entity instanceof EntityIronGolem && ((EntityIronGolem)entity).func_70643_av() == null);
/*     */   }
/*     */   
/*     */   public static boolean isSafe(Entity entity, int height, boolean floor) {
/* 113 */     return (getUnsafeBlocks(entity, height, floor).size() == 0);
/*     */   }
/*     */   
/*     */   public static boolean stopSneaking(boolean isSneaking) {
/* 117 */     if (isSneaking && mc.field_71439_g != null) {
/* 118 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */     }
/* 120 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isSafe(Entity entity) {
/* 124 */     return isSafe(entity, 0, false);
/*     */   }
/*     */   
/*     */   public static BlockPos getPlayerPos(EntityPlayer player) {
/* 128 */     return new BlockPos(Math.floor(player.field_70165_t), Math.floor(player.field_70163_u), Math.floor(player.field_70161_v));
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUnsafeBlocks(Entity entity, int height, boolean floor) {
/* 132 */     return getUnsafeBlocksFromVec3d(entity.func_174791_d(), height, floor);
/*     */   }
/*     */   
/*     */   public static boolean isMobAggressive(Entity entity) {
/* 136 */     if (entity instanceof EntityPigZombie) {
/* 137 */       if (((EntityPigZombie)entity).func_184734_db() || ((EntityPigZombie)entity).func_175457_ck()) {
/* 138 */         return true;
/*     */       }
/*     */     } else {
/* 141 */       if (entity instanceof EntityWolf) {
/* 142 */         return (((EntityWolf)entity).func_70919_bu() && !mc.field_71439_g.equals(((EntityWolf)entity).func_70902_q()));
/*     */       }
/* 144 */       if (entity instanceof EntityEnderman) {
/* 145 */         return ((EntityEnderman)entity).func_70823_r();
/*     */       }
/*     */     } 
/* 148 */     return isHostileMob(entity);
/*     */   }
/*     */   
/*     */   public static boolean isNeutralMob(Entity entity) {
/* 152 */     return (entity instanceof EntityPigZombie || entity instanceof EntityWolf || entity instanceof EntityEnderman);
/*     */   }
/*     */   
/*     */   public static boolean isProjectile(Entity entity) {
/* 156 */     return (entity instanceof net.minecraft.entity.projectile.EntityShulkerBullet || entity instanceof net.minecraft.entity.projectile.EntityFireball);
/*     */   }
/*     */   
/*     */   public static boolean isVehicle(Entity entity) {
/* 160 */     return (entity instanceof net.minecraft.entity.item.EntityBoat || entity instanceof net.minecraft.entity.item.EntityMinecart);
/*     */   }
/*     */   
/*     */   public static boolean isFriendlyMob(Entity entity) {
/* 164 */     return ((entity.isCreatureType(EnumCreatureType.CREATURE, false) && !isNeutralMob(entity)) || entity.isCreatureType(EnumCreatureType.AMBIENT, false) || entity instanceof net.minecraft.entity.passive.EntityVillager || entity instanceof EntityIronGolem || (isNeutralMob(entity) && !isMobAggressive(entity)));
/*     */   }
/*     */   
/*     */   public static boolean isHostileMob(Entity entity) {
/* 168 */     return (entity.isCreatureType(EnumCreatureType.MONSTER, false) && !isNeutralMob(entity));
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUnsafeBlocksFromVec3d(Vec3d pos, int height, boolean floor) {
/* 172 */     ArrayList<Vec3d> vec3ds = new ArrayList<>();
/* 173 */     for (Vec3d vector : getOffsets(height, floor)) {
/* 174 */       BlockPos targetPos = (new BlockPos(pos)).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
/* 175 */       Block block = mc.field_71441_e.func_180495_p(targetPos).func_177230_c();
/* 176 */       if (block instanceof net.minecraft.block.BlockAir || block instanceof net.minecraft.block.BlockLiquid || block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockFire || block instanceof net.minecraft.block.BlockDeadBush || block instanceof net.minecraft.block.BlockSnow)
/*     */       {
/* 178 */         vec3ds.add(vector); } 
/*     */     } 
/* 180 */     return vec3ds;
/*     */   }
/*     */   
/*     */   public static boolean isInHole(Entity entity) {
/* 184 */     return isBlockValid(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
/*     */   }
/*     */   
/*     */   public static boolean isBlockValid(BlockPos blockPos) {
/* 188 */     return (isBedrockHole(blockPos) || isObbyHole(blockPos) || isBothHole(blockPos));
/*     */   } public static boolean isObbyHole(BlockPos blockPos) { BlockPos[] touchingBlocks;
/*     */     BlockPos[] arrayOfBlockPos1;
/*     */     int i;
/*     */     byte b;
/* 193 */     for (arrayOfBlockPos1 = touchingBlocks = new BlockPos[] { blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b() }, i = arrayOfBlockPos1.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos1[b];
/* 194 */       IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
/* 195 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && touchingState.func_177230_c() == Blocks.field_150343_Z) { b++; continue; }
/* 196 */        return false; }
/*     */     
/* 198 */     return true; }
/*     */   public static boolean isBedrockHole(BlockPos blockPos) { BlockPos[] touchingBlocks;
/*     */     BlockPos[] arrayOfBlockPos1;
/*     */     int i;
/*     */     byte b;
/* 203 */     for (arrayOfBlockPos1 = touchingBlocks = new BlockPos[] { blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b() }, i = arrayOfBlockPos1.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos1[b];
/* 204 */       IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
/* 205 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && touchingState.func_177230_c() == Blocks.field_150357_h) { b++; continue; }
/* 206 */        return false; }
/*     */     
/* 208 */     return true; } public static boolean isBothHole(BlockPos blockPos) {
/*     */     BlockPos[] touchingBlocks;
/*     */     BlockPos[] arrayOfBlockPos1;
/*     */     int i;
/*     */     byte b;
/* 213 */     for (arrayOfBlockPos1 = touchingBlocks = new BlockPos[] { blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b() }, i = arrayOfBlockPos1.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos1[b];
/* 214 */       IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
/* 215 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && (touchingState.func_177230_c() == Blocks.field_150357_h || touchingState.func_177230_c() == Blocks.field_150343_Z)) {
/*     */         b++; continue;
/* 217 */       }  return false; }
/*     */     
/* 219 */     return true;
/*     */   }
/*     */   
/*     */   public static Vec3d[] getUnsafeBlockArray(Entity entity, int height, boolean floor) {
/* 223 */     List<Vec3d> list = getUnsafeBlocks(entity, height, floor);
/* 224 */     Vec3d[] array = new Vec3d[list.size()];
/* 225 */     return list.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static Vec3d[] getUnsafeBlockArrayFromVec3d(Vec3d pos, int height, boolean floor) {
/* 229 */     List<Vec3d> list = getUnsafeBlocksFromVec3d(pos, height, floor);
/* 230 */     Vec3d[] array = new Vec3d[list.size()];
/* 231 */     return list.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static double getDst(Vec3d vec) {
/* 235 */     return mc.field_71439_g.func_174791_d().func_72438_d(vec);
/*     */   }
/*     */   
/*     */   public static boolean isTrapped(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 239 */     return (getUntrappedBlocks(player, antiScaffold, antiStep, legs, platform, antiDrop).size() == 0);
/*     */   }
/*     */   
/*     */   public static boolean isTrappedExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace, boolean noScaffoldExtend) {
/* 243 */     return (getUntrappedBlocksExtended(extension, player, antiScaffold, antiStep, legs, platform, antiDrop, raytrace, noScaffoldExtend).size() == 0);
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUntrappedBlocks(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 247 */     ArrayList<Vec3d> vec3ds = new ArrayList<>();
/* 248 */     if (!antiStep && getUnsafeBlocks((Entity)player, 2, false).size() == 4) {
/* 249 */       vec3ds.addAll(getUnsafeBlocks((Entity)player, 2, false));
/*     */     }
/* 251 */     for (int i = 0; i < (getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop)).length; i++) {
/* 252 */       Vec3d vector = getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop)[i];
/* 253 */       BlockPos targetPos = (new BlockPos(player.func_174791_d())).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
/* 254 */       Block block = mc.field_71441_e.func_180495_p(targetPos).func_177230_c();
/* 255 */       if (block instanceof net.minecraft.block.BlockAir || block instanceof net.minecraft.block.BlockLiquid || block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockFire || block instanceof net.minecraft.block.BlockDeadBush || block instanceof net.minecraft.block.BlockSnow)
/*     */       {
/* 257 */         vec3ds.add(vector); } 
/*     */     } 
/* 259 */     return vec3ds;
/*     */   }
/*     */   
/*     */   public static boolean isInWater(Entity entity) {
/* 263 */     if (entity == null) {
/* 264 */       return false;
/*     */     }
/* 266 */     double y = entity.field_70163_u + 0.01D;
/* 267 */     for (int x = MathHelper.func_76128_c(entity.field_70165_t); x < MathHelper.func_76143_f(entity.field_70165_t); x++) {
/* 268 */       for (int z = MathHelper.func_76128_c(entity.field_70161_v); z < MathHelper.func_76143_f(entity.field_70161_v); ) {
/* 269 */         BlockPos pos = new BlockPos(x, (int)y, z);
/* 270 */         if (!(mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) { z++; continue; }
/* 271 */          return true;
/*     */       } 
/*     */     } 
/* 274 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isDrivenByPlayer(Entity entityIn) {
/* 278 */     return (mc.field_71439_g != null && entityIn != null && entityIn.equals(mc.field_71439_g.func_184187_bx()));
/*     */   }
/*     */   
/*     */   public static boolean isPlayer(Entity entity) {
/* 282 */     return entity instanceof EntityPlayer;
/*     */   }
/*     */   
/*     */   public static boolean isAboveWater(Entity entity) {
/* 286 */     return isAboveWater(entity, false);
/*     */   }
/*     */   
/*     */   public static boolean isAboveWater(Entity entity, boolean packet) {
/* 290 */     if (entity == null) {
/* 291 */       return false;
/*     */     }
/* 293 */     double y = entity.field_70163_u - (packet ? 0.03D : (isPlayer(entity) ? 0.2D : 0.5D));
/* 294 */     for (int x = MathHelper.func_76128_c(entity.field_70165_t); x < MathHelper.func_76143_f(entity.field_70165_t); x++) {
/* 295 */       for (int z = MathHelper.func_76128_c(entity.field_70161_v); z < MathHelper.func_76143_f(entity.field_70161_v); ) {
/* 296 */         BlockPos pos = new BlockPos(x, MathHelper.func_76128_c(y), z);
/* 297 */         if (!(mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) { z++; continue; }
/* 298 */          return true;
/*     */       } 
/*     */     } 
/* 301 */     return false;
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUntrappedBlocksExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace, boolean noScaffoldExtend) {
/* 305 */     ArrayList<Vec3d> placeTargets = new ArrayList<>();
/* 306 */     if (extension == 1) {
/* 307 */       placeTargets.addAll(targets(player.func_174791_d(), antiScaffold, antiStep, legs, platform, antiDrop, raytrace));
/*     */     } else {
/* 309 */       int extend = 1;
/* 310 */       for (Vec3d vec3d : MathUtil.getBlockBlocks((Entity)player)) {
/* 311 */         if (extend > extension)
/* 312 */           break;  placeTargets.addAll(targets(vec3d, !noScaffoldExtend, antiStep, legs, platform, antiDrop, raytrace));
/* 313 */         extend++;
/*     */       } 
/*     */     } 
/* 316 */     ArrayList<Vec3d> removeList = new ArrayList<>();
/* 317 */     for (Vec3d vec3d : placeTargets) {
/* 318 */       BlockPos pos = new BlockPos(vec3d);
/* 319 */       if (BlockUtil.isPositionPlaceable(pos, raytrace) != -1)
/* 320 */         continue;  removeList.add(vec3d);
/*     */     } 
/* 322 */     for (Vec3d vec3d : removeList) {
/* 323 */       placeTargets.remove(vec3d);
/*     */     }
/* 325 */     return placeTargets;
/*     */   }
/*     */   
/*     */   public static List<Vec3d> targets(Vec3d vec3d, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/* 329 */     ArrayList<Vec3d> placeTargets = new ArrayList<>();
/* 330 */     if (antiDrop) {
/* 331 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiDropOffsetList));
/*     */     }
/* 333 */     if (platform) {
/* 334 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, platformOffsetList));
/*     */     }
/* 336 */     if (legs) {
/* 337 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, legOffsetList));
/*     */     }
/* 339 */     Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, OffsetList));
/* 340 */     if (antiStep) {
/* 341 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiStepOffsetList));
/*     */     } else {
/* 343 */       List<Vec3d> vec3ds = getUnsafeBlocksFromVec3d(vec3d, 2, false);
/* 344 */       if (vec3ds.size() == 4)
/*     */       {
/* 346 */         for (Vec3d vector : vec3ds) {
/* 347 */           BlockPos position = (new BlockPos(vec3d)).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
/* 348 */           switch (BlockUtil.isPositionPlaceable(position, raytrace)) {
/*     */             case 0:
/*     */               break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             case 3:
/* 358 */               placeTargets.add(vec3d.func_178787_e(vector));
/*     */           } 
/*     */         
/*     */         } 
/*     */       }
/*     */     } 
/* 364 */     if (antiScaffold) {
/* 365 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiScaffoldOffsetList));
/*     */     }
/* 367 */     return placeTargets;
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getOffsetList(int y, boolean floor) {
/* 371 */     ArrayList<Vec3d> offsets = new ArrayList<>();
/* 372 */     offsets.add(new Vec3d(-1.0D, y, 0.0D));
/* 373 */     offsets.add(new Vec3d(1.0D, y, 0.0D));
/* 374 */     offsets.add(new Vec3d(0.0D, y, -1.0D));
/* 375 */     offsets.add(new Vec3d(0.0D, y, 1.0D));
/* 376 */     if (floor) {
/* 377 */       offsets.add(new Vec3d(0.0D, (y - 1), 0.0D));
/*     */     }
/* 379 */     return offsets;
/*     */   }
/*     */   
/*     */   public static Vec3d[] getOffsets(int y, boolean floor) {
/* 383 */     List<Vec3d> offsets = getOffsetList(y, floor);
/* 384 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 385 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static Vec3d[] getTrapOffsets(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 389 */     List<Vec3d> offsets = getTrapOffsetsList(antiScaffold, antiStep, legs, platform, antiDrop);
/* 390 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 391 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getTrapOffsetsList(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 395 */     ArrayList<Vec3d> offsets = new ArrayList<>(getOffsetList(1, false));
/* 396 */     offsets.add(new Vec3d(0.0D, 2.0D, 0.0D));
/* 397 */     if (antiScaffold) {
/* 398 */       offsets.add(new Vec3d(0.0D, 3.0D, 0.0D));
/*     */     }
/* 400 */     if (antiStep) {
/* 401 */       offsets.addAll(getOffsetList(2, false));
/*     */     }
/* 403 */     if (legs) {
/* 404 */       offsets.addAll(getOffsetList(0, false));
/*     */     }
/* 406 */     if (platform) {
/* 407 */       offsets.addAll(getOffsetList(-1, false));
/* 408 */       offsets.add(new Vec3d(0.0D, -1.0D, 0.0D));
/*     */     } 
/* 410 */     if (antiDrop) {
/* 411 */       offsets.add(new Vec3d(0.0D, -2.0D, 0.0D));
/*     */     }
/* 413 */     return offsets;
/*     */   }
/*     */   
/*     */   public static Vec3d[] getHeightOffsets(int min, int max) {
/* 417 */     ArrayList<Vec3d> offsets = new ArrayList<>();
/* 418 */     for (int i = min; i <= max; i++) {
/* 419 */       offsets.add(new Vec3d(0.0D, i, 0.0D));
/*     */     }
/* 421 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 422 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static BlockPos getRoundedBlockPos(Entity entity) {
/* 426 */     return new BlockPos(MathUtil.roundVec(entity.func_174791_d(), 0));
/*     */   }
/*     */   
/*     */   public static boolean isLiving(Entity entity) {
/* 430 */     return entity instanceof EntityLivingBase;
/*     */   }
/*     */   
/*     */   public static boolean isAlive(Entity entity) {
/* 434 */     return (isLiving(entity) && !entity.field_70128_L && ((EntityLivingBase)entity).func_110143_aJ() > 0.0F);
/*     */   }
/*     */   
/*     */   public static boolean isDead(Entity entity) {
/* 438 */     return !isAlive(entity);
/*     */   }
/*     */   
/*     */   public static float getHealth(Entity entity) {
/* 442 */     if (isLiving(entity)) {
/* 443 */       EntityLivingBase livingBase = (EntityLivingBase)entity;
/* 444 */       return livingBase.func_110143_aJ() + livingBase.func_110139_bj();
/*     */     } 
/* 446 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public static float getHealth(Entity entity, boolean absorption) {
/* 450 */     if (isLiving(entity)) {
/* 451 */       EntityLivingBase livingBase = (EntityLivingBase)entity;
/* 452 */       return livingBase.func_110143_aJ() + (absorption ? livingBase.func_110139_bj() : 0.0F);
/*     */     } 
/* 454 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public static boolean canEntityFeetBeSeen(Entity entityIn) {
/* 458 */     return (mc.field_71441_e.func_147447_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70165_t + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(entityIn.field_70165_t, entityIn.field_70163_u, entityIn.field_70161_v), false, true, false) == null);
/*     */   }
/*     */   
/*     */   public static boolean isntValid(Entity entity, double range) {
/* 462 */     return (entity == null || isDead(entity) || entity.equals(mc.field_71439_g) || (entity instanceof EntityPlayer && Phobos.friendManager.isFriend(entity.func_70005_c_())) || mc.field_71439_g.func_70068_e(entity) > MathUtil.square(range));
/*     */   }
/*     */   
/*     */   public static boolean isValid(Entity entity, double range) {
/* 466 */     return !isntValid(entity, range);
/*     */   }
/*     */   
/*     */   public static boolean holdingWeapon(EntityPlayer player) {
/* 470 */     return (player.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemSword || player.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemAxe);
/*     */   }
/*     */   
/*     */   public static double getMaxSpeed() {
/* 474 */     double maxModifier = 0.2873D;
/* 475 */     if (mc.field_71439_g.func_70644_a(Objects.<Potion>requireNonNull(Potion.func_188412_a(1)))) {
/* 476 */       maxModifier *= 1.0D + 0.2D * (((PotionEffect)Objects.<PotionEffect>requireNonNull(mc.field_71439_g.func_70660_b(Objects.<Potion>requireNonNull(Potion.func_188412_a(1))))).func_76458_c() + 1);
/*     */     }
/* 478 */     return maxModifier;
/*     */   }
/*     */   
/*     */   public static void mutliplyEntitySpeed(Entity entity, double multiplier) {
/* 482 */     if (entity != null) {
/* 483 */       entity.field_70159_w *= multiplier;
/* 484 */       entity.field_70179_y *= multiplier;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isEntityMoving(Entity entity) {
/* 489 */     if (entity == null) {
/* 490 */       return false;
/*     */     }
/* 492 */     if (entity instanceof EntityPlayer) {
/* 493 */       return (mc.field_71474_y.field_74351_w.func_151470_d() || mc.field_71474_y.field_74368_y.func_151470_d() || mc.field_71474_y.field_74370_x.func_151470_d() || mc.field_71474_y.field_74366_z.func_151470_d());
/*     */     }
/* 495 */     return (entity.field_70159_w != 0.0D || entity.field_70181_x != 0.0D || entity.field_70179_y != 0.0D);
/*     */   }
/*     */   
/*     */   public static boolean movementKey() {
/* 499 */     return (mc.field_71439_g.field_71158_b.field_187255_c || mc.field_71439_g.field_71158_b.field_187258_f || mc.field_71439_g.field_71158_b.field_187257_e || mc.field_71439_g.field_71158_b.field_187256_d || mc.field_71439_g.field_71158_b.field_78901_c || mc.field_71439_g.field_71158_b.field_78899_d);
/*     */   }
/*     */   
/*     */   public static double getEntitySpeed(Entity entity) {
/* 503 */     if (entity != null) {
/* 504 */       double distTraveledLastTickX = entity.field_70165_t - entity.field_70169_q;
/* 505 */       double distTraveledLastTickZ = entity.field_70161_v - entity.field_70166_s;
/* 506 */       double speed = MathHelper.func_76133_a(distTraveledLastTickX * distTraveledLastTickX + distTraveledLastTickZ * distTraveledLastTickZ);
/* 507 */       return speed * 20.0D;
/*     */     } 
/* 509 */     return 0.0D;
/*     */   }
/*     */   
/*     */   public static boolean holding32k(EntityPlayer player) {
/* 513 */     return is32k(player.func_184614_ca());
/*     */   }
/*     */   
/*     */   public static boolean is32k(ItemStack stack) {
/* 517 */     if (stack == null) {
/* 518 */       return false;
/*     */     }
/* 520 */     if (stack.func_77978_p() == null) {
/* 521 */       return false;
/*     */     }
/* 523 */     NBTTagList enchants = (NBTTagList)stack.func_77978_p().func_74781_a("ench");
/* 524 */     if (enchants == null) {
/* 525 */       return false;
/*     */     }
/* 527 */     for (int i = 0; i < enchants.func_74745_c(); ) {
/* 528 */       NBTTagCompound enchant = enchants.func_150305_b(i);
/* 529 */       if (enchant.func_74762_e("id") != 16) { i++; continue; }
/* 530 */        int lvl = enchant.func_74762_e("lvl");
/* 531 */       if (lvl < 42)
/* 532 */         break;  return true;
/*     */     } 
/* 534 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean simpleIs32k(ItemStack stack) {
/* 538 */     return (EnchantmentHelper.func_77506_a(Enchantments.field_185302_k, stack) >= 1000);
/*     */   }
/*     */   
/*     */   public static void moveEntityStrafe(double speed, Entity entity) {
/* 542 */     if (entity != null) {
/* 543 */       MovementInput movementInput = mc.field_71439_g.field_71158_b;
/* 544 */       double forward = movementInput.field_192832_b;
/* 545 */       double strafe = movementInput.field_78902_a;
/* 546 */       float yaw = mc.field_71439_g.field_70177_z;
/* 547 */       if (forward == 0.0D && strafe == 0.0D) {
/* 548 */         entity.field_70159_w = 0.0D;
/* 549 */         entity.field_70179_y = 0.0D;
/*     */       } else {
/* 551 */         if (forward != 0.0D) {
/* 552 */           if (strafe > 0.0D) {
/* 553 */             yaw += ((forward > 0.0D) ? -45 : 45);
/* 554 */           } else if (strafe < 0.0D) {
/* 555 */             yaw += ((forward > 0.0D) ? 45 : -45);
/*     */           } 
/* 557 */           strafe = 0.0D;
/* 558 */           if (forward > 0.0D) {
/* 559 */             forward = 1.0D;
/* 560 */           } else if (forward < 0.0D) {
/* 561 */             forward = -1.0D;
/*     */           } 
/*     */         } 
/* 564 */         entity.field_70159_w = forward * speed * Math.cos(Math.toRadians((yaw + 90.0F))) + strafe * speed * Math.sin(Math.toRadians((yaw + 90.0F)));
/* 565 */         entity.field_70179_y = forward * speed * Math.sin(Math.toRadians((yaw + 90.0F))) - strafe * speed * Math.cos(Math.toRadians((yaw + 90.0F)));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean rayTraceHitCheck(Entity entity, boolean shouldCheck) {
/* 571 */     return (!shouldCheck || mc.field_71439_g.func_70685_l(entity));
/*     */   }
/*     */   
/*     */   public static Color getColor(Entity entity, int red, int green, int blue, int alpha, boolean colorFriends) {
/* 575 */     Color color = new Color(red / 255.0F, green / 255.0F, blue / 255.0F, alpha / 255.0F);
/* 576 */     if (entity instanceof EntityPlayer) {
/* 577 */       if (colorFriends && Phobos.friendManager.isFriend((EntityPlayer)entity)) {
/* 578 */         color = new Color(0.33333334F, 1.0F, 1.0F, alpha / 255.0F);
/*     */       }
/* 580 */       Killaura killaura = (Killaura)Phobos.moduleManager.getModuleByClass(Killaura.class);
/* 581 */       if (((Boolean)killaura.info.getValue()).booleanValue() && 
/* 582 */         Killaura.target != null && 
/* 583 */         Killaura.target.equals(entity)) {
/* 584 */         color = new Color(1.0F, 0.0F, 0.0F, alpha / 255.0F);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 589 */     return color;
/*     */   }
/*     */   
/*     */   public static boolean isFakePlayer(EntityPlayer player) {
/* 593 */     Freecam freecam = Freecam.getInstance();
/* 594 */     FakePlayer fakePlayer = FakePlayer.getInstance();
/* 595 */     Blink blink = Blink.getInstance();
/* 596 */     int playerID = player.func_145782_y();
/* 597 */     if (freecam.isOn() && playerID == 69420) {
/* 598 */       return true;
/*     */     }
/* 600 */     if (fakePlayer.isOn()) {
/* 601 */       for (Iterator<Integer> iterator = fakePlayer.fakePlayerIdList.iterator(); iterator.hasNext(); ) { int id = ((Integer)iterator.next()).intValue();
/* 602 */         if (id != playerID)
/* 603 */           continue;  return true; }
/*     */     
/*     */     }
/* 606 */     if (blink.isOn()) {
/* 607 */       return (playerID == 6942069);
/*     */     }
/* 609 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isMoving() {
/* 613 */     return (mc.field_71439_g.field_191988_bg != 0.0D || mc.field_71439_g.field_70702_br != 0.0D);
/*     */   }
/*     */   
/*     */   public static EntityPlayer getClosestEnemy(double distance) {
/* 617 */     EntityPlayer closest = null;
/* 618 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 619 */       if (isntValid((Entity)player, distance))
/* 620 */         continue;  if (closest == null) {
/* 621 */         closest = player;
/*     */         continue;
/*     */       } 
/* 624 */       if (mc.field_71439_g.func_70068_e((Entity)player) >= mc.field_71439_g.func_70068_e((Entity)closest))
/*     */         continue; 
/* 626 */       closest = player;
/*     */     } 
/* 628 */     return closest;
/*     */   }
/*     */   
/*     */   public static boolean checkCollide() {
/* 632 */     if (mc.field_71439_g.func_70093_af()) {
/* 633 */       return false;
/*     */     }
/* 635 */     if (mc.field_71439_g.func_184187_bx() != null && (mc.field_71439_g.func_184187_bx()).field_70143_R >= 3.0F) {
/* 636 */       return false;
/*     */     }
/* 638 */     return (mc.field_71439_g.field_70143_R < 3.0F);
/*     */   }
/*     */   
/*     */   public static boolean isInLiquid() {
/* 642 */     if (mc.field_71439_g.field_70143_R >= 3.0F) {
/* 643 */       return false;
/*     */     }
/* 645 */     boolean inLiquid = false;
/* 646 */     AxisAlignedBB bb = (mc.field_71439_g.func_184187_bx() != null) ? mc.field_71439_g.func_184187_bx().func_174813_aQ() : mc.field_71439_g.func_174813_aQ();
/* 647 */     int y = (int)bb.field_72338_b;
/* 648 */     for (int x = MathHelper.func_76128_c(bb.field_72340_a); x < MathHelper.func_76128_c(bb.field_72336_d) + 1; x++) {
/* 649 */       for (int z = MathHelper.func_76128_c(bb.field_72339_c); z < MathHelper.func_76128_c(bb.field_72334_f) + 1; z++) {
/* 650 */         Block block = mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
/* 651 */         if (!(block instanceof net.minecraft.block.BlockAir)) {
/* 652 */           if (!(block instanceof net.minecraft.block.BlockLiquid)) {
/* 653 */             return false;
/*     */           }
/* 655 */           inLiquid = true;
/*     */         } 
/*     */       } 
/* 658 */     }  return inLiquid;
/*     */   }
/*     */   
/*     */   public static boolean isOnLiquid(double offset) {
/* 662 */     if (mc.field_71439_g.field_70143_R >= 3.0F) {
/* 663 */       return false;
/*     */     }
/* 665 */     AxisAlignedBB bb = (mc.field_71439_g.func_184187_bx() != null) ? mc.field_71439_g.func_184187_bx().func_174813_aQ().func_191195_a(0.0D, 0.0D, 0.0D).func_72317_d(0.0D, -offset, 0.0D) : mc.field_71439_g.func_174813_aQ().func_191195_a(0.0D, 0.0D, 0.0D).func_72317_d(0.0D, -offset, 0.0D);
/* 666 */     boolean onLiquid = false;
/* 667 */     int y = (int)bb.field_72338_b;
/* 668 */     for (int x = MathHelper.func_76128_c(bb.field_72340_a); x < MathHelper.func_76128_c(bb.field_72336_d + 1.0D); x++) {
/* 669 */       for (int z = MathHelper.func_76128_c(bb.field_72339_c); z < MathHelper.func_76128_c(bb.field_72334_f + 1.0D); z++) {
/* 670 */         Block block = mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
/* 671 */         if (block != Blocks.field_150350_a) {
/* 672 */           if (!(block instanceof net.minecraft.block.BlockLiquid)) {
/* 673 */             return false;
/*     */           }
/* 675 */           onLiquid = true;
/*     */         } 
/*     */       } 
/* 678 */     }  return onLiquid;
/*     */   }
/*     */   
/*     */   public static boolean isAboveLiquid(Entity entity) {
/* 682 */     if (entity == null) {
/* 683 */       return false;
/*     */     }
/* 685 */     double n = entity.field_70163_u + 0.01D;
/* 686 */     for (int i = MathHelper.func_76128_c(entity.field_70165_t); i < MathHelper.func_76143_f(entity.field_70165_t); i++) {
/* 687 */       for (int j = MathHelper.func_76128_c(entity.field_70161_v); j < MathHelper.func_76143_f(entity.field_70161_v); ) {
/* 688 */         if (!(mc.field_71441_e.func_180495_p(new BlockPos(i, (int)n, j)).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) {
/*     */           j++; continue;
/* 690 */         }  return true;
/*     */       } 
/*     */     } 
/* 693 */     return false;
/*     */   }
/*     */   
/*     */   public static BlockPos getPlayerPosWithEntity() {
/* 697 */     return new BlockPos((mc.field_71439_g.func_184187_bx() != null) ? (mc.field_71439_g.func_184187_bx()).field_70165_t : mc.field_71439_g.field_70165_t, (mc.field_71439_g.func_184187_bx() != null) ? (mc.field_71439_g.func_184187_bx()).field_70163_u : mc.field_71439_g.field_70163_u, (mc.field_71439_g.func_184187_bx() != null) ? (mc.field_71439_g.func_184187_bx()).field_70161_v : mc.field_71439_g.field_70161_v);
/*     */   }
/*     */   
/*     */   public static boolean checkForLiquid(Entity entity, boolean b) {
/* 701 */     if (entity == null) {
/* 702 */       return false;
/*     */     }
/* 704 */     double posY = entity.field_70163_u;
/* 705 */     double n = b ? 0.03D : ((entity instanceof EntityPlayer) ? 0.2D : 0.5D);
/* 706 */     double n2 = posY - n;
/* 707 */     for (int i = MathHelper.func_76128_c(entity.field_70165_t); i < MathHelper.func_76143_f(entity.field_70165_t); i++) {
/* 708 */       for (int j = MathHelper.func_76128_c(entity.field_70161_v); j < MathHelper.func_76143_f(entity.field_70161_v); ) {
/* 709 */         if (!(mc.field_71441_e.func_180495_p(new BlockPos(i, MathHelper.func_76128_c(n2), j)).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) {
/*     */           j++; continue;
/* 711 */         }  return true;
/*     */       } 
/*     */     } 
/* 714 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isOnLiquid() {
/* 718 */     double y = mc.field_71439_g.field_70163_u - 0.03D;
/* 719 */     for (int x = MathHelper.func_76128_c(mc.field_71439_g.field_70165_t); x < MathHelper.func_76143_f(mc.field_71439_g.field_70165_t); x++) {
/* 720 */       for (int z = MathHelper.func_76128_c(mc.field_71439_g.field_70161_v); z < MathHelper.func_76143_f(mc.field_71439_g.field_70161_v); ) {
/* 721 */         BlockPos pos = new BlockPos(x, MathHelper.func_76128_c(y), z);
/* 722 */         if (!(mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) { z++; continue; }
/* 723 */          return true;
/*     */       } 
/*     */     } 
/* 726 */     return false;
/*     */   }
/*     */   
/*     */   public static double[] forward(double speed) {
/* 730 */     float forward = mc.field_71439_g.field_71158_b.field_192832_b;
/* 731 */     float side = mc.field_71439_g.field_71158_b.field_78902_a;
/* 732 */     float yaw = mc.field_71439_g.field_70126_B + (mc.field_71439_g.field_70177_z - mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
/* 733 */     if (forward != 0.0F) {
/* 734 */       if (side > 0.0F) {
/* 735 */         yaw += ((forward > 0.0F) ? -45 : 45);
/* 736 */       } else if (side < 0.0F) {
/* 737 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*     */       } 
/* 739 */       side = 0.0F;
/* 740 */       if (forward > 0.0F) {
/* 741 */         forward = 1.0F;
/* 742 */       } else if (forward < 0.0F) {
/* 743 */         forward = -1.0F;
/*     */       } 
/*     */     } 
/* 746 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/* 747 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 748 */     double posX = forward * speed * cos + side * speed * sin;
/* 749 */     double posZ = forward * speed * sin - side * speed * cos;
/* 750 */     return new double[] { posX, posZ };
/*     */   }
/*     */   
/*     */   public static Map<String, Integer> getTextRadarPlayers() {
/* 754 */     Map<String, Integer> output = new HashMap<>();
/* 755 */     DecimalFormat dfHealth = new DecimalFormat("#.#");
/* 756 */     dfHealth.setRoundingMode(RoundingMode.CEILING);
/* 757 */     DecimalFormat dfDistance = new DecimalFormat("#.#");
/* 758 */     dfDistance.setRoundingMode(RoundingMode.CEILING);
/* 759 */     StringBuilder healthSB = new StringBuilder();
/* 760 */     StringBuilder distanceSB = new StringBuilder();
/* 761 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 762 */       if ((player.func_82150_aj() && !((Boolean)(Managers.getInstance()).tRadarInv.getValue()).booleanValue()) || player.func_70005_c_().equals(mc.field_71439_g.func_70005_c_()))
/*     */         continue; 
/* 764 */       int hpRaw = (int)getHealth((Entity)player);
/* 765 */       String hp = dfHealth.format(hpRaw);
/* 766 */       healthSB.append("§");
/* 767 */       if (hpRaw >= 20) {
/* 768 */         healthSB.append("a");
/* 769 */       } else if (hpRaw >= 10) {
/* 770 */         healthSB.append("e");
/* 771 */       } else if (hpRaw >= 5) {
/* 772 */         healthSB.append("6");
/*     */       } else {
/* 774 */         healthSB.append("c");
/*     */       } 
/* 776 */       healthSB.append(hp);
/* 777 */       int distanceInt = (int)mc.field_71439_g.func_70032_d((Entity)player);
/* 778 */       String distance = dfDistance.format(distanceInt);
/* 779 */       distanceSB.append("§");
/* 780 */       if (distanceInt >= 25) {
/* 781 */         distanceSB.append("a");
/* 782 */       } else if (distanceInt > 10) {
/* 783 */         distanceSB.append("6");
/* 784 */       } else if (distanceInt >= 50) {
/* 785 */         distanceSB.append("7");
/*     */       } else {
/* 787 */         distanceSB.append("c");
/*     */       } 
/* 789 */       distanceSB.append(distance);
/* 790 */       output.put(healthSB.toString() + " " + (Phobos.friendManager.isFriend(player) ? "§b" : "§r") + player.func_70005_c_() + " " + distanceSB.toString() + " §f" + Phobos.totemPopManager.getTotemPopString(player) + Phobos.potionManager.getTextRadarPotion(player), Integer.valueOf((int)mc.field_71439_g.func_70032_d((Entity)player)));
/* 791 */       healthSB.setLength(0);
/* 792 */       distanceSB.setLength(0);
/*     */     } 
/* 794 */     if (!output.isEmpty()) {
/* 795 */       output = MathUtil.sortByValue(output, false);
/*     */     }
/* 797 */     return output;
/*     */   }
/*     */   
/*     */   public static void swingArmNoPacket(EnumHand hand, EntityLivingBase entity) {
/* 801 */     ItemStack stack = entity.func_184586_b(hand);
/* 802 */     if (!stack.func_190926_b() && stack.func_77973_b().onEntitySwing(entity, stack)) {
/*     */       return;
/*     */     }
/* 805 */     if (!entity.field_82175_bq || entity.field_110158_av >= getArmSwingAnimationEnd(entity) / 2 || entity.field_110158_av < 0) {
/* 806 */       entity.field_110158_av = -1;
/* 807 */       entity.field_82175_bq = true;
/* 808 */       entity.field_184622_au = hand;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isAboveBlock(Entity entity, BlockPos blockPos) {
/* 813 */     return (entity.field_70163_u >= blockPos.func_177956_o());
/*     */   }
/*     */   
/*     */   public static int getArmSwingAnimationEnd(EntityLivingBase entity) {
/* 817 */     if (entity.func_70644_a(MobEffects.field_76422_e)) {
/* 818 */       return 6 - 1 + entity.func_70660_b(MobEffects.field_76422_e).func_76458_c();
/*     */     }
/* 820 */     return entity.func_70644_a(MobEffects.field_76419_f) ? (6 + (1 + entity.func_70660_b(MobEffects.field_76419_f).func_76458_c()) * 2) : 6;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\EntityUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */