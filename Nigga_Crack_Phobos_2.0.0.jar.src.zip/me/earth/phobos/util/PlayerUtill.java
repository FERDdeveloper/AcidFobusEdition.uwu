/*     */ package me.earth.phobos.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class PlayerUtill
/*     */ {
/*  14 */   private static final Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*     */   public static BlockPos getPlayerPos() {
/*  17 */     return new BlockPos(Math.floor(mc.field_71439_g.field_70165_t), Math.floor(mc.field_71439_g.field_70163_u), Math.floor(mc.field_71439_g.field_70161_v));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityPlayer findClosestTarget(double rangeMax, EntityPlayer aimTarget) {
/*  23 */     rangeMax *= rangeMax;
/*  24 */     List<EntityPlayer> playerList = mc.field_71441_e.field_73010_i;
/*     */     
/*  26 */     EntityPlayer closestTarget = null;
/*     */     
/*  28 */     for (EntityPlayer entityPlayer : playerList) {
/*     */       
/*  30 */       if (EntityUtill.basicChecksEntity((Entity)entityPlayer)) {
/*     */         continue;
/*     */       }
/*  33 */       if (aimTarget == null && mc.field_71439_g.func_70068_e((Entity)entityPlayer) <= rangeMax) {
/*  34 */         closestTarget = entityPlayer;
/*     */         continue;
/*     */       } 
/*  37 */       if (aimTarget != null && mc.field_71439_g.func_70068_e((Entity)entityPlayer) <= rangeMax && mc.field_71439_g.func_70068_e((Entity)entityPlayer) < mc.field_71439_g.func_70068_e((Entity)aimTarget)) {
/*  38 */         closestTarget = entityPlayer;
/*     */       }
/*     */     } 
/*  41 */     return closestTarget;
/*     */   }
/*     */ 
/*     */   
/*     */   public static EntityPlayer findClosestTarget() {
/*  46 */     List<EntityPlayer> playerList = mc.field_71441_e.field_73010_i;
/*     */     
/*  48 */     EntityPlayer closestTarget = null;
/*     */     
/*  50 */     for (EntityPlayer entityPlayer : playerList) {
/*  51 */       if (EntityUtill.basicChecksEntity((Entity)entityPlayer)) {
/*     */         continue;
/*     */       }
/*  54 */       if (closestTarget == null) {
/*  55 */         closestTarget = entityPlayer;
/*     */         continue;
/*     */       } 
/*  58 */       if (mc.field_71439_g.func_70068_e((Entity)entityPlayer) < mc.field_71439_g.func_70068_e((Entity)closestTarget)) {
/*  59 */         closestTarget = entityPlayer;
/*     */       }
/*     */     } 
/*     */     
/*  63 */     return closestTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityPlayer findLookingPlayer(double rangeMax) {
/*  69 */     ArrayList<EntityPlayer> listPlayer = new ArrayList<>();
/*     */     
/*  71 */     for (EntityPlayer playerSin : mc.field_71441_e.field_73010_i) {
/*  72 */       if (EntityUtill.basicChecksEntity((Entity)playerSin))
/*     */         continue; 
/*  74 */       if (mc.field_71439_g.func_70032_d((Entity)playerSin) <= rangeMax) {
/*  75 */         listPlayer.add(playerSin);
/*     */       }
/*     */     } 
/*     */     
/*  79 */     EntityPlayer target = null;
/*     */     
/*  81 */     Vec3d positionEyes = mc.field_71439_g.func_174824_e(mc.func_184121_ak());
/*  82 */     Vec3d rotationEyes = mc.field_71439_g.func_70676_i(mc.func_184121_ak());
/*     */     
/*  84 */     int precision = 2;
/*     */     
/*  86 */     for (int i = 0; i < (int)rangeMax; i++) {
/*     */       
/*  88 */       for (int j = precision; j > 0; j--) {
/*     */         
/*  90 */         for (EntityPlayer targetTemp : listPlayer) {
/*     */           
/*  92 */           AxisAlignedBB playerBox = targetTemp.func_174813_aQ();
/*     */           
/*  94 */           double xArray = positionEyes.field_72450_a + rotationEyes.field_72450_a * i + rotationEyes.field_72450_a / j;
/*  95 */           double yArray = positionEyes.field_72448_b + rotationEyes.field_72448_b * i + rotationEyes.field_72448_b / j;
/*  96 */           double zArray = positionEyes.field_72449_c + rotationEyes.field_72449_c * i + rotationEyes.field_72449_c / j;
/*     */           
/*  98 */           if (playerBox.field_72337_e >= yArray && playerBox.field_72338_b <= yArray && playerBox.field_72336_d >= xArray && playerBox.field_72340_a <= xArray && playerBox.field_72334_f >= zArray && playerBox.field_72339_c <= zArray)
/*     */           {
/*     */ 
/*     */             
/* 102 */             target = targetTemp;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     return target;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobo\\util\PlayerUtill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */