/*    */ package me.earth.phobos.manager;
/*    */ 
/*    */ import me.earth.phobos.util.Util;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*    */ 
/*    */ public class InventoryManager
/*    */   implements Util {
/*  9 */   private int recoverySlot = -1;
/*    */   
/*    */   public void update() {
/* 12 */     if (this.recoverySlot != -1) {
/* 13 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange((this.recoverySlot == 8) ? 7 : (this.recoverySlot + 1)));
/* 14 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.recoverySlot));
/* 15 */       mc.field_71439_g.field_71071_by.field_70461_c = this.recoverySlot;
/* 16 */       mc.field_71442_b.func_78750_j();
/* 17 */       this.recoverySlot = -1;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void recoverSilent(int slot) {
/* 22 */     this.recoverySlot = slot;
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\manager\InventoryManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */