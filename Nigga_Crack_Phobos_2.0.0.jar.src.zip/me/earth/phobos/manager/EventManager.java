/*     */ package me.earth.phobos.manager;
/*     */ 
/*     */ import com.google.common.base.Strings;
/*     */ import java.util.Objects;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.event.events.ConnectionEvent;
/*     */ import me.earth.phobos.event.events.PacketEvent;
/*     */ import me.earth.phobos.event.events.Render2DEvent;
/*     */ import me.earth.phobos.event.events.Render3DEvent;
/*     */ import me.earth.phobos.event.events.TotemPopEvent;
/*     */ import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
/*     */ import me.earth.phobos.features.Feature;
/*     */ import me.earth.phobos.features.command.Command;
/*     */ import me.earth.phobos.features.modules.client.Managers;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.play.server.SPacketEntityStatus;
/*     */ import net.minecraft.network.play.server.SPacketPlayerListItem;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.ClientChatEvent;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ import net.minecraftforge.client.event.RenderWorldLastEvent;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*     */ import net.minecraftforge.fml.common.network.FMLNetworkEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventManager
/*     */   extends Feature
/*     */ {
/*  46 */   private final Timer timer = new Timer();
/*  47 */   private final Timer logoutTimer = new Timer();
/*  48 */   private final AtomicBoolean tickOngoing = new AtomicBoolean(false);
/*  49 */   private final Timer switchTimer = new Timer();
/*     */   private boolean keyTimeout;
/*     */   
/*     */   public void init() {
/*  53 */     MinecraftForge.EVENT_BUS.register(this);
/*     */   }
/*     */   
/*     */   public void onUnload() {
/*  57 */     MinecraftForge.EVENT_BUS.unregister(this);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdate(LivingEvent.LivingUpdateEvent event) {
/*  62 */     if (!Feature.fullNullCheck() && (event.getEntity().func_130014_f_()).field_72995_K && event.getEntityLiving().equals(mc.field_71439_g)) {
/*  63 */       Phobos.potionManager.update();
/*  64 */       Phobos.totemPopManager.onUpdate();
/*  65 */       Phobos.inventoryManager.update();
/*  66 */       Phobos.holeManager.update();
/*  67 */       Phobos.safetyManager.onUpdate();
/*  68 */       Phobos.moduleManager.onUpdate();
/*  69 */       Phobos.timerManager.update();
/*  70 */       if (this.timer.passedMs(((Integer)(Managers.getInstance()).moduleListUpdates.getValue()).intValue())) {
/*  71 */         Phobos.moduleManager.sortModules(true);
/*  72 */         Phobos.moduleManager.alphabeticallySortModules();
/*  73 */         this.timer.reset();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onTickHighest(TickEvent.ClientTickEvent event) {
/*  80 */     if (event.phase == TickEvent.Phase.START) {
/*  81 */       this.tickOngoing.set(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.LOWEST)
/*     */   public void onTickLowest(TickEvent.ClientTickEvent event) {
/*  87 */     if (event.phase == TickEvent.Phase.END) {
/*  88 */       this.tickOngoing.set(false);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean ticksOngoing() {
/*  93 */     return this.tickOngoing.get();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onClientConnect(FMLNetworkEvent.ClientConnectedToServerEvent event) {
/*  98 */     this.logoutTimer.reset();
/*  99 */     Phobos.moduleManager.onLogin();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onClientDisconnect(FMLNetworkEvent.ClientDisconnectionFromServerEvent event) {
/* 104 */     Phobos.moduleManager.onLogout();
/* 105 */     Phobos.totemPopManager.onLogout();
/* 106 */     Phobos.potionManager.onLogout();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onTick(TickEvent.ClientTickEvent event) {
/* 111 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/* 114 */     Phobos.moduleManager.onTick();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/* 119 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/* 122 */     if (event.getStage() == 0) {
/* 123 */       Phobos.baritoneManager.onUpdateWalkingPlayer();
/* 124 */       Phobos.speedManager.updateValues();
/* 125 */       Phobos.rotationManager.updateRotations();
/* 126 */       Phobos.positionManager.updatePosition();
/*     */     } 
/* 128 */     if (event.getStage() == 1) {
/* 129 */       Phobos.rotationManager.restoreRotations();
/* 130 */       Phobos.positionManager.restorePosition();
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.Send event) {
/* 136 */     if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketHeldItemChange) {
/* 137 */       this.switchTimer.reset();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isOnSwitchCoolDown() {
/* 142 */     return !this.switchTimer.passedMs(500L);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.Receive event) {
/* 147 */     if (event.getStage() != 0) {
/*     */       return;
/*     */     }
/* 150 */     Phobos.serverManager.onPacketReceived();
/* 151 */     if (event.getPacket() instanceof SPacketEntityStatus) {
/* 152 */       SPacketEntityStatus packet = (SPacketEntityStatus)event.getPacket();
/* 153 */       if (packet.func_149160_c() == 35 && packet.func_149161_a((World)mc.field_71441_e) instanceof EntityPlayer) {
/* 154 */         EntityPlayer player = (EntityPlayer)packet.func_149161_a((World)mc.field_71441_e);
/* 155 */         MinecraftForge.EVENT_BUS.post((Event)new TotemPopEvent(player));
/* 156 */         Phobos.totemPopManager.onTotemPop(player);
/* 157 */         Phobos.potionManager.onTotemPop(player);
/*     */       } 
/* 159 */     } else if (event.getPacket() instanceof SPacketPlayerListItem && !Feature.fullNullCheck() && this.logoutTimer.passedS(1.0D)) {
/* 160 */       SPacketPlayerListItem packet2 = (SPacketPlayerListItem)event.getPacket();
/* 161 */       if (!SPacketPlayerListItem.Action.ADD_PLAYER.equals(packet2.func_179768_b()) && !SPacketPlayerListItem.Action.REMOVE_PLAYER.equals(packet2.func_179768_b())) {
/*     */         return;
/*     */       }
/* 164 */       packet2.func_179767_a().stream().filter(Objects::nonNull).filter(data -> (!Strings.isNullOrEmpty(data.func_179962_a().getName()) || data.func_179962_a().getId() != null)).forEach(data -> {
/*     */             String name;
/*     */             EntityPlayer entity;
/*     */             SPacketPlayerListItem sPacketPlayerListItem = (SPacketPlayerListItem)event.getPacket();
/*     */             UUID id = data.func_179962_a().getId();
/*     */             switch (sPacketPlayerListItem.func_179768_b()) {
/*     */               case ADD_PLAYER:
/*     */                 name = data.func_179962_a().getName();
/*     */                 MinecraftForge.EVENT_BUS.post((Event)new ConnectionEvent(0, id, name));
/*     */                 break;
/*     */ 
/*     */ 
/*     */               
/*     */               case REMOVE_PLAYER:
/*     */                 entity = mc.field_71441_e.func_152378_a(id);
/*     */                 if (entity != null) {
/*     */                   String logoutName = entity.func_70005_c_();
/*     */                   MinecraftForge.EVENT_BUS.post((Event)new ConnectionEvent(1, entity, id, logoutName));
/*     */                   break;
/*     */                 } 
/*     */                 MinecraftForge.EVENT_BUS.post((Event)new ConnectionEvent(2, id, null));
/*     */                 break;
/*     */             } 
/*     */ 
/*     */           
/*     */           });
/* 190 */     } else if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketTimeUpdate) {
/* 191 */       Phobos.serverManager.update();
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onWorldRender(RenderWorldLastEvent event) {
/* 197 */     if (event.isCanceled()) {
/*     */       return;
/*     */     }
/* 200 */     mc.field_71424_I.func_76320_a("phobos");
/* 201 */     GlStateManager.func_179090_x();
/* 202 */     GlStateManager.func_179147_l();
/* 203 */     GlStateManager.func_179118_c();
/* 204 */     GlStateManager.func_179120_a(770, 771, 1, 0);
/* 205 */     GlStateManager.func_179103_j(7425);
/* 206 */     GlStateManager.func_179097_i();
/* 207 */     GlStateManager.func_187441_d(1.0F);
/* 208 */     Render3DEvent render3dEvent = new Render3DEvent(event.getPartialTicks());
/* 209 */     Phobos.moduleManager.onRender3D(render3dEvent);
/* 210 */     GlStateManager.func_187441_d(1.0F);
/* 211 */     GlStateManager.func_179103_j(7424);
/* 212 */     GlStateManager.func_179084_k();
/* 213 */     GlStateManager.func_179141_d();
/* 214 */     GlStateManager.func_179098_w();
/* 215 */     GlStateManager.func_179126_j();
/* 216 */     GlStateManager.func_179089_o();
/* 217 */     GlStateManager.func_179089_o();
/* 218 */     GlStateManager.func_179132_a(true);
/* 219 */     GlStateManager.func_179098_w();
/* 220 */     GlStateManager.func_179147_l();
/* 221 */     GlStateManager.func_179126_j();
/* 222 */     mc.field_71424_I.func_76319_b();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void renderHUD(RenderGameOverlayEvent.Post event) {
/* 227 */     if (event.getType() == RenderGameOverlayEvent.ElementType.HOTBAR) {
/* 228 */       Phobos.textManager.updateResolution();
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.LOW)
/*     */   public void onRenderGameOverlayEvent(RenderGameOverlayEvent.Text event) {
/* 234 */     if (event.getType().equals(RenderGameOverlayEvent.ElementType.TEXT)) {
/* 235 */       ScaledResolution resolution = new ScaledResolution(mc);
/* 236 */       Render2DEvent render2DEvent = new Render2DEvent(event.getPartialTicks(), resolution);
/* 237 */       Phobos.moduleManager.onRender2D(render2DEvent);
/* 238 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onChatSent(ClientChatEvent event) {
/* 244 */     if (event.getMessage().startsWith(Command.getCommandPrefix())) {
/* 245 */       event.setCanceled(true);
/*     */       try {
/* 247 */         mc.field_71456_v.func_146158_b().func_146239_a(event.getMessage());
/* 248 */         if (event.getMessage().length() > 1) {
/* 249 */           Phobos.commandManager.executeCommand(event.getMessage().substring(Command.getCommandPrefix().length() - 1));
/*     */         } else {
/* 251 */           Command.sendMessage("Please enter a command.");
/*     */         } 
/* 253 */       } catch (Exception e) {
/* 254 */         e.printStackTrace();
/* 255 */         Command.sendMessage("Â§cAn error occurred while running this command. Check the log!");
/*     */       } 
/* 257 */       event.setMessage("");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\manager\EventManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */