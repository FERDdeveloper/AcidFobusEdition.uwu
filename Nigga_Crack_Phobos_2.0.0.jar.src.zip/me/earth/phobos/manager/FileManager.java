/*     */ package me.earth.phobos.manager;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.OpenOption;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.StandardOpenOption;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.features.Feature;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ 
/*     */ public class FileManager extends Feature {
/*  20 */   private final Path base = getMkDirectory(getRoot(), new String[] { "phobos" });
/*  21 */   private final Path config = getMkDirectory(this.base, new String[] { "config" });
/*     */   
/*     */   public FileManager() {
/*  24 */     getMkDirectory(this.base, new String[] { "util" });
/*  25 */     for (Module.Category category : Phobos.moduleManager.getCategories()) {
/*  26 */       getMkDirectory(this.config, new String[] { category.getName() });
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean appendTextFile(String data, String file) {
/*     */     try {
/*  32 */       Path path = Paths.get(file, new String[0]);
/*  33 */       Files.write(path, Collections.singletonList(data), StandardCharsets.UTF_8, new OpenOption[] { Files.exists(path, new java.nio.file.LinkOption[0]) ? StandardOpenOption.APPEND : StandardOpenOption.CREATE });
/*  34 */     } catch (IOException e) {
/*  35 */       System.out.println("WARNING: Unable to write file: " + file);
/*  36 */       return false;
/*     */     } 
/*  38 */     return true;
/*     */   }
/*     */   
/*     */   public static List<String> readTextFileAllLines(String file) {
/*     */     try {
/*  43 */       Path path = Paths.get(file, new String[0]);
/*  44 */       return Files.readAllLines(path, StandardCharsets.UTF_8);
/*  45 */     } catch (IOException e) {
/*  46 */       System.out.println("WARNING: Unable to read file, creating new file: " + file);
/*  47 */       appendTextFile("", file);
/*  48 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */   
/*     */   private String[] expandPath(String fullPath) {
/*  53 */     return fullPath.split(":?\\\\\\\\|\\/");
/*     */   }
/*     */   
/*     */   private Stream<String> expandPaths(String... paths) {
/*  57 */     return Arrays.<String>stream(paths).map(this::expandPath).flatMap(Arrays::stream);
/*     */   }
/*     */   
/*     */   private Path lookupPath(Path root, String... paths) {
/*  61 */     return Paths.get(root.toString(), paths);
/*     */   }
/*     */   
/*     */   private Path getRoot() {
/*  65 */     return Paths.get("", new String[0]);
/*     */   }
/*     */   
/*     */   private void createDirectory(Path dir) {
/*     */     try {
/*  70 */       if (!Files.isDirectory(dir, new java.nio.file.LinkOption[0])) {
/*  71 */         if (Files.exists(dir, new java.nio.file.LinkOption[0])) {
/*  72 */           Files.delete(dir);
/*     */         }
/*  74 */         Files.createDirectories(dir, (FileAttribute<?>[])new FileAttribute[0]);
/*     */       } 
/*  76 */     } catch (IOException e) {
/*  77 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Path getMkDirectory(Path parent, String... paths) {
/*  82 */     if (paths.length < 1) {
/*  83 */       return parent;
/*     */     }
/*  85 */     Path dir = lookupPath(parent, paths);
/*  86 */     createDirectory(dir);
/*  87 */     return dir;
/*     */   }
/*     */   
/*     */   public Path getBasePath() {
/*  91 */     return this.base;
/*     */   }
/*     */   
/*     */   public Path getBaseResolve(String... paths) {
/*  95 */     String[] names = expandPaths(paths).<String>toArray(x$0 -> new String[x$0]);
/*  96 */     if (names.length < 1) {
/*  97 */       throw new IllegalArgumentException("missing path");
/*     */     }
/*  99 */     return lookupPath(getBasePath(), names);
/*     */   }
/*     */   
/*     */   public Path getMkBaseResolve(String... paths) {
/* 103 */     Path path = getBaseResolve(paths);
/* 104 */     createDirectory(path.getParent());
/* 105 */     return path;
/*     */   }
/*     */   
/*     */   public Path getConfig() {
/* 109 */     return getBasePath().resolve("config");
/*     */   }
/*     */   
/*     */   public Path getCache() {
/* 113 */     return getBasePath().resolve("cache");
/*     */   }
/*     */   
/*     */   public Path getMkBaseDirectory(String... names) {
/* 117 */     return getMkDirectory(getBasePath(), new String[] { expandPaths(names).collect(Collectors.joining(File.separator)) });
/*     */   }
/*     */   
/*     */   public Path getMkConfigDirectory(String... names) {
/* 121 */     return getMkDirectory(getConfig(), new String[] { expandPaths(names).collect(Collectors.joining(File.separator)) });
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\manager\FileManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */