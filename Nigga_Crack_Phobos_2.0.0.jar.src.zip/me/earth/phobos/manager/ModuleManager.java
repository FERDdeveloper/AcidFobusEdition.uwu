/*     */ package me.earth.phobos.manager;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import me.earth.phobos.event.events.Render2DEvent;
/*     */ import me.earth.phobos.event.events.Render3DEvent;
/*     */ import me.earth.phobos.features.Feature;
/*     */ import me.earth.phobos.features.modules.Module;
/*     */ import me.earth.phobos.features.modules.client.Media;
/*     */ import me.earth.phobos.features.modules.client.ServerModule;
/*     */ import me.earth.phobos.features.modules.combat.AntiCrystal;
/*     */ import me.earth.phobos.features.modules.combat.ArmorMessage;
/*     */ import me.earth.phobos.features.modules.combat.Offhand;
/*     */ import me.earth.phobos.features.modules.combat.Webaura;
/*     */ import me.earth.phobos.features.modules.misc.AntiPackets;
/*     */ import me.earth.phobos.features.modules.misc.AutoGG;
/*     */ import me.earth.phobos.features.modules.misc.Companion;
/*     */ import me.earth.phobos.features.modules.misc.MobOwner;
/*     */ import me.earth.phobos.features.modules.misc.NoAFK;
/*     */ import me.earth.phobos.features.modules.movement.SafeWalk;
/*     */ import me.earth.phobos.features.modules.player.TimerSpeed;
/*     */ import me.earth.phobos.features.modules.render.Tracer;
/*     */ 
/*     */ public class ModuleManager extends Feature {
/*  26 */   public ArrayList<Module> modules = new ArrayList<>();
/*  27 */   public List<Module> sortedModules = new ArrayList<>();
/*  28 */   public List<Module> alphabeticallySortedModules = new ArrayList<>();
/*  29 */   public Map<Module, Color> moduleColorMap = new HashMap<>();
/*     */   
/*     */   public void init() {
/*  32 */     this.modules.add(new QueueSkip());
/*  33 */     this.modules.add(new Offhand());
/*  34 */     this.modules.add(new Surround());
/*  35 */     this.modules.add(new AutoTrap());
/*  36 */     this.modules.add(new AutoCrystal());
/*  37 */     this.modules.add(new Criticals());
/*  38 */     this.modules.add(new BowSpam());
/*  39 */     this.modules.add(new Killaura());
/*  40 */     this.modules.add(new HoleFiller());
/*  41 */     this.modules.add(new Selftrap());
/*  42 */     this.modules.add(new Webaura());
/*  43 */     this.modules.add(new AutoArmor());
/*  44 */     this.modules.add(new AntiTrap());
/*  45 */     this.modules.add(new BedBomb());
/*  46 */     this.modules.add(new ArmorMessage());
/*  47 */     this.modules.add(new Crasher());
/*  48 */     this.modules.add(new Auto32k());
/*  49 */     this.modules.add(new AntiCrystal());
/*  50 */     this.modules.add(new AnvilAura());
/*  51 */     this.modules.add(new GodModule());
/*  52 */     this.modules.add(new ChatModifier());
/*  53 */     this.modules.add(new BetterPortals());
/*  54 */     this.modules.add(new BuildHeight());
/*  55 */     this.modules.add(new NoHandShake());
/*  56 */     this.modules.add(new AutoRespawn());
/*  57 */     this.modules.add(new NoRotate());
/*  58 */     this.modules.add(new MCF());
/*  59 */     this.modules.add(new PingSpoof());
/*  60 */     this.modules.add(new NoSoundLag());
/*  61 */     this.modules.add(new AutoLog());
/*  62 */     this.modules.add(new KitDelete());
/*  63 */     this.modules.add(new Exploits());
/*  64 */     this.modules.add(new Spammer());
/*  65 */     this.modules.add(new AntiVanish());
/*  66 */     this.modules.add(new ExtraTab());
/*  67 */     this.modules.add(new MobOwner());
/*  68 */     this.modules.add(new Nuker());
/*  69 */     this.modules.add(new AutoReconnect());
/*  70 */     this.modules.add(new NoAFK());
/*  71 */     this.modules.add(new Tracker());
/*  72 */     this.modules.add(new AntiPackets());
/*  73 */     this.modules.add(new Logger());
/*  74 */     this.modules.add(new Translator());
/*  75 */     this.modules.add(new AutoGG());
/*  76 */     this.modules.add(new Godmode());
/*  77 */     this.modules.add(new Companion());
/*  78 */     this.modules.add(new Bypass());
/*  79 */     this.modules.add(new Strafe());
/*  80 */     this.modules.add(new Velocity());
/*  81 */     this.modules.add(new Speed());
/*  82 */     this.modules.add(new Step());
/*  83 */     this.modules.add(new Sprint());
/*  84 */     this.modules.add(new AntiLevitate());
/*  85 */     this.modules.add(new Phase());
/*  86 */     this.modules.add(new Static());
/*  87 */     this.modules.add(new TPSpeed());
/*  88 */     this.modules.add(new Flight());
/*  89 */     this.modules.add(new ElytraFlight());
/*  90 */     this.modules.add(new NoSlowDown());
/*  91 */     this.modules.add(new HoleTP());
/*  92 */     this.modules.add(new NoFall());
/*  93 */     this.modules.add(new IceSpeed());
/*  94 */     this.modules.add(new AutoWalk());
/*  95 */     this.modules.add(new TestPhase());
/*  96 */     this.modules.add(new LongJump());
/*  97 */     this.modules.add(new LagBlock());
/*  98 */     this.modules.add(new FastSwim());
/*  99 */     this.modules.add(new StairSpeed());
/* 100 */     this.modules.add(new Reach());
/* 101 */     this.modules.add(new LiquidInteract());
/* 102 */     this.modules.add(new FakePlayer());
/* 103 */     this.modules.add(new TimerSpeed());
/* 104 */     this.modules.add(new FastPlace());
/* 105 */     this.modules.add(new Freecam());
/* 106 */     this.modules.add(new Speedmine());
/* 107 */     this.modules.add(new SafeWalk());
/* 108 */     this.modules.add(new Blink());
/* 109 */     this.modules.add(new MultiTask());
/* 110 */     this.modules.add(new BlockTweaks());
/* 111 */     this.modules.add(new XCarry());
/* 112 */     this.modules.add(new Replenish());
/* 113 */     this.modules.add(new NoHunger());
/* 114 */     this.modules.add(new Jesus());
/* 115 */     this.modules.add(new Scaffold());
/* 116 */     this.modules.add(new EchestBP());
/* 117 */     this.modules.add(new TpsSync());
/* 118 */     this.modules.add(new MCP());
/* 119 */     this.modules.add(new TrueDurability());
/* 120 */     this.modules.add(new Yaw());
/* 121 */     this.modules.add(new NoDDoS());
/* 122 */     this.modules.add(new StorageESP());
/* 123 */     this.modules.add(new NoRender());
/* 124 */     this.modules.add(new SmallShield());
/* 125 */     this.modules.add(new Fullbright());
/* 126 */     this.modules.add(new Nametags());
/* 127 */     this.modules.add(new CameraClip());
/* 128 */     this.modules.add(new Chams());
/* 129 */     this.modules.add(new Skeleton());
/* 130 */     this.modules.add(new ESP());
/* 131 */     this.modules.add(new HoleESP());
/* 132 */     this.modules.add(new BlockHighlight());
/* 133 */     this.modules.add(new Trajectories());
/* 134 */     this.modules.add(new Tracer());
/* 135 */     this.modules.add(new LogoutSpots());
/* 136 */     this.modules.add(new XRay());
/* 137 */     this.modules.add(new PortalESP());
/* 138 */     this.modules.add(new Ranges());
/* 139 */     this.modules.add(new OffscreenESP());
/* 140 */     this.modules.add(new HandColor());
/* 141 */     this.modules.add(new VoidESP());
/* 142 */     this.modules.add(new Cosmetics());
/* 143 */     this.modules.add(new Notifications());
/* 144 */     this.modules.add(new HUD());
/* 145 */     this.modules.add(new ToolTips());
/* 146 */     this.modules.add(new FontMod());
/* 147 */     this.modules.add(new ClickGui());
/* 148 */     this.modules.add(new Managers());
/* 149 */     this.modules.add(new Components());
/* 150 */     this.modules.add(new StreamerMode());
/* 151 */     this.modules.add(new Capes());
/* 152 */     this.modules.add(new Colors());
/* 153 */     this.modules.add(new ServerModule());
/* 154 */     this.modules.add(new Screens());
/* 155 */     this.modules.add(new Media());
/* 156 */     this.modules.add(new AutoDupe());
/* 157 */     this.moduleColorMap.put((Module)getModuleByClass(AntiTrap.class), new Color(128, 53, 69));
/* 158 */     this.moduleColorMap.put((Module)getModuleByClass(AnvilAura.class), new Color(90, 227, 96));
/* 159 */     this.moduleColorMap.put((Module)getModuleByClass(ArmorMessage.class), new Color(255, 51, 51));
/* 160 */     this.moduleColorMap.put((Module)getModuleByClass(Auto32k.class), new Color(185, 212, 144));
/* 161 */     this.moduleColorMap.put((Module)getModuleByClass(AutoArmor.class), new Color(74, 227, 206));
/* 162 */     this.moduleColorMap.put((Module)getModuleByClass(AutoCrystal.class), new Color(255, 15, 43));
/* 163 */     this.moduleColorMap.put((Module)getModuleByClass(AutoTrap.class), new Color(193, 49, 244));
/* 164 */     this.moduleColorMap.put((Module)getModuleByClass(BedBomb.class), new Color(185, 80, 195));
/* 165 */     this.moduleColorMap.put((Module)getModuleByClass(BowSpam.class), new Color(204, 191, 153));
/* 166 */     this.moduleColorMap.put((Module)getModuleByClass(Crasher.class), new Color(208, 66, 9));
/* 167 */     this.moduleColorMap.put((Module)getModuleByClass(Criticals.class), new Color(204, 151, 184));
/* 168 */     this.moduleColorMap.put((Module)getModuleByClass(HoleFiller.class), new Color(166, 55, 110));
/* 169 */     this.moduleColorMap.put((Module)getModuleByClass(Killaura.class), new Color(255, 37, 0));
/* 170 */     this.moduleColorMap.put((Module)getModuleByClass(Offhand.class), new Color(185, 212, 144));
/* 171 */     this.moduleColorMap.put((Module)getModuleByClass(Selftrap.class), new Color(22, 127, 145));
/* 172 */     this.moduleColorMap.put((Module)getModuleByClass(Surround.class), new Color(100, 0, 150));
/* 173 */     this.moduleColorMap.put((Module)getModuleByClass(Webaura.class), new Color(11, 161, 121));
/* 174 */     this.moduleColorMap.put((Module)getModuleByClass(AntiCrystal.class), new Color(255, 161, 121));
/* 175 */     this.moduleColorMap.put((Module)getModuleByClass(AntiPackets.class), new Color(155, 186, 115));
/* 176 */     this.moduleColorMap.put((Module)getModuleByClass(AntiVanish.class), new Color(25, 209, 135));
/* 177 */     this.moduleColorMap.put((Module)getModuleByClass(AutoGG.class), new Color(240, 49, 110));
/* 178 */     this.moduleColorMap.put((Module)getModuleByClass(AutoLog.class), new Color(176, 176, 176));
/* 179 */     this.moduleColorMap.put((Module)getModuleByClass(AutoReconnect.class), new Color(17, 85, 153));
/* 180 */     this.moduleColorMap.put((Module)getModuleByClass(BetterPortals.class), new Color(71, 214, 187));
/* 181 */     this.moduleColorMap.put((Module)getModuleByClass(BuildHeight.class), new Color(64, 136, 199));
/* 182 */     this.moduleColorMap.put((Module)getModuleByClass(Bypass.class), new Color(194, 214, 81));
/* 183 */     this.moduleColorMap.put((Module)getModuleByClass(Companion.class), new Color(140, 252, 146));
/* 184 */     this.moduleColorMap.put((Module)getModuleByClass(ChatModifier.class), new Color(255, 59, 216));
/* 185 */     this.moduleColorMap.put((Module)getModuleByClass(Exploits.class), new Color(255, 0, 0));
/* 186 */     this.moduleColorMap.put((Module)getModuleByClass(ExtraTab.class), new Color(161, 113, 173));
/* 187 */     this.moduleColorMap.put((Module)getModuleByClass(Godmode.class), new Color(1, 35, 95));
/* 188 */     this.moduleColorMap.put((Module)getModuleByClass(KitDelete.class), new Color(229, 194, 255));
/* 189 */     this.moduleColorMap.put((Module)getModuleByClass(Logger.class), new Color(186, 0, 109));
/* 190 */     this.moduleColorMap.put((Module)getModuleByClass(MCF.class), new Color(17, 85, 255));
/* 191 */     this.moduleColorMap.put((Module)getModuleByClass(MobOwner.class), new Color(255, 254, 204));
/* 192 */     this.moduleColorMap.put((Module)getModuleByClass(NoAFK.class), new Color(80, 5, 98));
/* 193 */     this.moduleColorMap.put((Module)getModuleByClass(NoHandShake.class), new Color(173, 232, 139));
/* 194 */     this.moduleColorMap.put((Module)getModuleByClass(NoRotate.class), new Color(69, 81, 223));
/* 195 */     this.moduleColorMap.put((Module)getModuleByClass(NoSoundLag.class), new Color(255, 56, 0));
/* 196 */     this.moduleColorMap.put((Module)getModuleByClass(Nuker.class), new Color(152, 169, 17));
/* 197 */     this.moduleColorMap.put((Module)getModuleByClass(PingSpoof.class), new Color(23, 214, 187));
/* 198 */     this.moduleColorMap.put((Module)getModuleByClass(Spammer.class), new Color(140, 87, 166));
/* 199 */     this.moduleColorMap.put((Module)getModuleByClass(ToolTips.class), new Color(209, 125, 156));
/* 200 */     this.moduleColorMap.put((Module)getModuleByClass(Translator.class), new Color(74, 82, 15));
/* 201 */     this.moduleColorMap.put((Module)getModuleByClass(Tracker.class), new Color(0, 255, 225));
/* 202 */     this.moduleColorMap.put((Module)getModuleByClass(OffscreenESP.class), new Color(193, 219, 20));
/* 203 */     this.moduleColorMap.put((Module)getModuleByClass(BlockHighlight.class), new Color(103, 182, 224));
/* 204 */     this.moduleColorMap.put((Module)getModuleByClass(CameraClip.class), new Color(247, 169, 107));
/* 205 */     this.moduleColorMap.put((Module)getModuleByClass(Chams.class), new Color(34, 152, 34));
/* 206 */     this.moduleColorMap.put((Module)getModuleByClass(ESP.class), new Color(255, 27, 155));
/* 207 */     this.moduleColorMap.put((Module)getModuleByClass(Fullbright.class), new Color(255, 164, 107));
/* 208 */     this.moduleColorMap.put((Module)getModuleByClass(HandColor.class), new Color(96, 138, 92));
/* 209 */     this.moduleColorMap.put((Module)getModuleByClass(HoleESP.class), new Color(95, 83, 130));
/* 210 */     this.moduleColorMap.put((Module)getModuleByClass(LogoutSpots.class), new Color(2, 135, 134));
/* 211 */     this.moduleColorMap.put((Module)getModuleByClass(Nametags.class), new Color(98, 82, 223));
/* 212 */     this.moduleColorMap.put((Module)getModuleByClass(NoRender.class), new Color(255, 164, 107));
/* 213 */     this.moduleColorMap.put((Module)getModuleByClass(PortalESP.class), new Color(26, 242, 62));
/* 214 */     this.moduleColorMap.put((Module)getModuleByClass(Ranges.class), new Color(144, 212, 196));
/* 215 */     this.moduleColorMap.put((Module)getModuleByClass(Skeleton.class), new Color(219, 219, 219));
/* 216 */     this.moduleColorMap.put((Module)getModuleByClass(SmallShield.class), new Color(145, 223, 187));
/* 217 */     this.moduleColorMap.put((Module)getModuleByClass(StorageESP.class), new Color(97, 81, 223));
/* 218 */     this.moduleColorMap.put((Module)getModuleByClass(Tracer.class), new Color(255, 107, 107));
/* 219 */     this.moduleColorMap.put((Module)getModuleByClass(Trajectories.class), new Color(98, 18, 223));
/* 220 */     this.moduleColorMap.put((Module)getModuleByClass(VoidESP.class), new Color(68, 178, 142));
/* 221 */     this.moduleColorMap.put((Module)getModuleByClass(XRay.class), new Color(217, 118, 37));
/* 222 */     this.moduleColorMap.put((Module)getModuleByClass(AntiLevitate.class), new Color(206, 255, 255));
/* 223 */     this.moduleColorMap.put((Module)getModuleByClass(AutoWalk.class), new Color(153, 153, 170));
/* 224 */     this.moduleColorMap.put((Module)getModuleByClass(ElytraFlight.class), new Color(55, 161, 201));
/* 225 */     this.moduleColorMap.put((Module)getModuleByClass(Flight.class), new Color(186, 164, 178));
/* 226 */     this.moduleColorMap.put((Module)getModuleByClass(HoleTP.class), new Color(68, 178, 142));
/* 227 */     this.moduleColorMap.put((Module)getModuleByClass(IceSpeed.class), new Color(33, 193, 247));
/* 228 */     this.moduleColorMap.put((Module)getModuleByClass(LongJump.class), new Color(228, 27, 213));
/* 229 */     this.moduleColorMap.put((Module)getModuleByClass(NoFall.class), new Color(61, 204, 78));
/* 230 */     this.moduleColorMap.put((Module)getModuleByClass(NoSlowDown.class), new Color(61, 204, 78));
/* 231 */     this.moduleColorMap.put((Module)getModuleByClass(TestPhase.class), new Color(238, 59, 27));
/* 232 */     this.moduleColorMap.put((Module)getModuleByClass(Phase.class), new Color(186, 144, 212));
/* 233 */     this.moduleColorMap.put((Module)getModuleByClass(SafeWalk.class), new Color(182, 186, 164));
/* 234 */     this.moduleColorMap.put((Module)getModuleByClass(Speed.class), new Color(55, 161, 196));
/* 235 */     this.moduleColorMap.put((Module)getModuleByClass(Sprint.class), new Color(148, 184, 142));
/* 236 */     this.moduleColorMap.put((Module)getModuleByClass(Static.class), new Color(86, 53, 98));
/* 237 */     this.moduleColorMap.put((Module)getModuleByClass(Step.class), new Color(144, 212, 203));
/* 238 */     this.moduleColorMap.put((Module)getModuleByClass(Strafe.class), new Color(0, 204, 255));
/* 239 */     this.moduleColorMap.put((Module)getModuleByClass(TPSpeed.class), new Color(20, 177, 142));
/* 240 */     this.moduleColorMap.put((Module)getModuleByClass(Velocity.class), new Color(115, 134, 140));
/* 241 */     this.moduleColorMap.put((Module)getModuleByClass(NoDDoS.class), new Color(67, 191, 181));
/* 242 */     this.moduleColorMap.put((Module)getModuleByClass(Blink.class), new Color(144, 184, 141));
/* 243 */     this.moduleColorMap.put((Module)getModuleByClass(BlockTweaks.class), new Color(89, 223, 235));
/* 244 */     this.moduleColorMap.put((Module)getModuleByClass(EchestBP.class), new Color(255, 243, 30));
/* 245 */     this.moduleColorMap.put((Module)getModuleByClass(FakePlayer.class), new Color(37, 192, 170));
/* 246 */     this.moduleColorMap.put((Module)getModuleByClass(FastPlace.class), new Color(217, 118, 37));
/* 247 */     this.moduleColorMap.put((Module)getModuleByClass(Freecam.class), new Color(206, 232, 128));
/* 248 */     this.moduleColorMap.put((Module)getModuleByClass(Jesus.class), new Color(136, 221, 235));
/* 249 */     this.moduleColorMap.put((Module)getModuleByClass(LiquidInteract.class), new Color(85, 223, 235));
/* 250 */     this.moduleColorMap.put((Module)getModuleByClass(MCP.class), new Color(153, 68, 170));
/* 251 */     this.moduleColorMap.put((Module)getModuleByClass(MultiTask.class), new Color(17, 223, 235));
/* 252 */     this.moduleColorMap.put((Module)getModuleByClass(NoHunger.class), new Color(86, 53, 98));
/* 253 */     this.moduleColorMap.put((Module)getModuleByClass(Reach.class), new Color(9, 223, 187));
/* 254 */     this.moduleColorMap.put((Module)getModuleByClass(Replenish.class), new Color(153, 223, 235));
/* 255 */     this.moduleColorMap.put((Module)getModuleByClass(Scaffold.class), new Color(152, 166, 113));
/* 256 */     this.moduleColorMap.put((Module)getModuleByClass(Speedmine.class), new Color(152, 166, 113));
/* 257 */     this.moduleColorMap.put((Module)getModuleByClass(TimerSpeed.class), new Color(255, 133, 18));
/* 258 */     this.moduleColorMap.put((Module)getModuleByClass(TpsSync.class), new Color(93, 144, 153));
/* 259 */     this.moduleColorMap.put((Module)getModuleByClass(TrueDurability.class), new Color(254, 161, 51));
/* 260 */     this.moduleColorMap.put((Module)getModuleByClass(XCarry.class), new Color(254, 161, 51));
/* 261 */     this.moduleColorMap.put((Module)getModuleByClass(Yaw.class), new Color(115, 39, 141));
/* 262 */     this.moduleColorMap.put((Module)getModuleByClass(Capes.class), new Color(26, 135, 104));
/* 263 */     this.moduleColorMap.put((Module)getModuleByClass(ClickGui.class), new Color(26, 81, 135));
/* 264 */     this.moduleColorMap.put((Module)getModuleByClass(Colors.class), new Color(135, 133, 26));
/* 265 */     this.moduleColorMap.put((Module)getModuleByClass(Components.class), new Color(135, 26, 26));
/* 266 */     this.moduleColorMap.put((Module)getModuleByClass(FontMod.class), new Color(135, 26, 88));
/* 267 */     this.moduleColorMap.put((Module)getModuleByClass(HUD.class), new Color(110, 26, 135));
/* 268 */     this.moduleColorMap.put((Module)getModuleByClass(Managers.class), new Color(26, 90, 135));
/* 269 */     this.moduleColorMap.put((Module)getModuleByClass(Notifications.class), new Color(170, 153, 255));
/* 270 */     this.moduleColorMap.put((Module)getModuleByClass(ServerModule.class), new Color(60, 110, 175));
/* 271 */     this.moduleColorMap.put((Module)getModuleByClass(Media.class), new Color(138, 45, 13));
/* 272 */     this.moduleColorMap.put((Module)getModuleByClass(Screens.class), new Color(165, 89, 101));
/* 273 */     this.moduleColorMap.put((Module)getModuleByClass(StreamerMode.class), new Color(0, 0, 0));
/* 274 */     for (Module module : this.modules) {
/* 275 */       module.animation.start();
/*     */     }
/*     */   }
/*     */   
/*     */   public Module getModuleByName(String name) {
/* 280 */     for (Module module : this.modules) {
/* 281 */       if (!module.getName().equalsIgnoreCase(name))
/* 282 */         continue;  return module;
/*     */     } 
/* 284 */     return null;
/*     */   }
/*     */   
/*     */   public <T extends Module> T getModuleByClass(Class<T> clazz) {
/* 288 */     for (Module module : this.modules) {
/* 289 */       if (!clazz.isInstance(module))
/* 290 */         continue;  return (T)module;
/*     */     } 
/* 292 */     return null;
/*     */   }
/*     */   
/*     */   public void enableModule(Class<Module> clazz) {
/* 296 */     Object module = getModuleByClass(clazz);
/* 297 */     if (module != null) {
/* 298 */       ((Module)module).enable();
/*     */     }
/*     */   }
/*     */   
/*     */   public void disableModule(Class<Module> clazz) {
/* 303 */     Object module = getModuleByClass(clazz);
/* 304 */     if (module != null) {
/* 305 */       ((Module)module).disable();
/*     */     }
/*     */   }
/*     */   
/*     */   public void enableModule(String name) {
/* 310 */     Module module = getModuleByName(name);
/* 311 */     if (module != null) {
/* 312 */       module.enable();
/*     */     }
/*     */   }
/*     */   
/*     */   public void disableModule(String name) {
/* 317 */     Module module = getModuleByName(name);
/* 318 */     if (module != null) {
/* 319 */       module.disable();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isModuleEnabled(String name) {
/* 324 */     Module module = getModuleByName(name);
/* 325 */     return (module != null && module.isOn());
/*     */   }
/*     */   
/*     */   public boolean isModuleEnabled(Class<Module> clazz) {
/* 329 */     Object module = getModuleByClass(clazz);
/* 330 */     return (module != null && ((Module)module).isOn());
/*     */   }
/*     */   
/*     */   public Module getModuleByDisplayName(String displayName) {
/* 334 */     for (Module module : this.modules) {
/* 335 */       if (!module.getDisplayName().equalsIgnoreCase(displayName))
/* 336 */         continue;  return module;
/*     */     } 
/* 338 */     return null;
/*     */   }
/*     */   
/*     */   public ArrayList<Module> getEnabledModules() {
/* 342 */     ArrayList<Module> enabledModules = new ArrayList<>();
/* 343 */     for (Module module : this.modules) {
/* 344 */       if (!module.isEnabled() && !module.isSliding())
/* 345 */         continue;  enabledModules.add(module);
/*     */     } 
/* 347 */     return enabledModules;
/*     */   }
/*     */   
/*     */   public ArrayList<Module> getModulesByCategory(Module.Category category) {
/* 351 */     ArrayList<Module> modulesCategory = new ArrayList<>();
/* 352 */     this.modules.forEach(module -> {
/*     */           if (module.getCategory() == category) {
/*     */             modulesCategory.add(module);
/*     */           }
/*     */         });
/* 357 */     return modulesCategory;
/*     */   }
/*     */   
/*     */   public List<Module.Category> getCategories() {
/* 361 */     return Arrays.asList(Module.Category.values());
/*     */   }
/*     */   
/*     */   public void onLoad() {
/* 365 */     this.modules.stream().filter(Module::listening).forEach(MinecraftForge.EVENT_BUS::register);
/* 366 */     this.modules.forEach(Module::onLoad);
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/* 370 */     this.modules.stream().filter(Feature::isEnabled).forEach(Module::onUpdate);
/*     */   }
/*     */   
/*     */   public void onTick() {
/* 374 */     this.modules.stream().filter(Feature::isEnabled).forEach(Module::onTick);
/*     */   }
/*     */   
/*     */   public void onRender2D(Render2DEvent event) {
/* 378 */     this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender2D(event));
/*     */   }
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/* 382 */     this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender3D(event));
/*     */   }
/*     */   
/*     */   public void sortModules(boolean reverse) {
/* 386 */     this.sortedModules = (List<Module>)getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(module -> Integer.valueOf(this.renderer.getStringWidth(module.getFullArrayString()) * (reverse ? -1 : 1)))).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public void alphabeticallySortModules() {
/* 390 */     this.alphabeticallySortedModules = (List<Module>)getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(Module::getDisplayName)).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public void onLogout() {
/* 394 */     this.modules.forEach(Module::onLogout);
/*     */   }
/*     */   
/*     */   public void onLogin() {
/* 398 */     this.modules.forEach(Module::onLogin);
/*     */   }
/*     */   
/*     */   public void onUnload() {
/* 402 */     this.modules.forEach(MinecraftForge.EVENT_BUS::unregister);
/* 403 */     this.modules.forEach(Module::onUnload);
/*     */   }
/*     */   
/*     */   public void onUnloadPost() {
/* 407 */     for (Module module : this.modules) {
/* 408 */       module.enabled.setValue(Boolean.valueOf(false));
/*     */     }
/*     */   }
/*     */   
/*     */   public void onKeyPressed(int eventKey) {
/* 413 */     if (eventKey == 0 || !Keyboard.getEventKeyState() || mc.field_71462_r instanceof me.earth.phobos.features.gui.PhobosGui) {
/*     */       return;
/*     */     }
/* 416 */     this.modules.forEach(module -> {
/*     */           if (module.getBind().getKey() == eventKey) {
/*     */             module.toggle();
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public List<Module> getAnimationModules(Module.Category category) {
/* 424 */     ArrayList<Module> animationModules = new ArrayList<>();
/* 425 */     for (Module module : getEnabledModules()) {
/* 426 */       if (module.getCategory() != category || module.isDisabled() || !module.isSliding() || !module.isDrawn())
/*     */         continue; 
/* 428 */       animationModules.add(module);
/*     */     } 
/* 430 */     return animationModules;
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\manager\ModuleManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */