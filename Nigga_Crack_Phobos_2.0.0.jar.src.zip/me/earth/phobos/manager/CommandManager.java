/*    */ package me.earth.phobos.manager;
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedList;
/*    */ import me.earth.phobos.features.command.Command;
/*    */ import me.earth.phobos.features.command.commands.BindCommand;
/*    */ import me.earth.phobos.features.command.commands.ConfigCommand;
/*    */ import me.earth.phobos.features.command.commands.CrashCommand;
/*    */ import me.earth.phobos.features.command.commands.ReloadSoundCommand;
/*    */ import me.earth.phobos.features.command.commands.XrayCommand;
/*    */ 
/*    */ public class CommandManager extends Feature {
/* 12 */   private String clientMessage = "<Phobos.eu>";
/* 13 */   private String prefix = ".";
/* 14 */   private final ArrayList<Command> commands = new ArrayList<>();
/*    */   
/*    */   public CommandManager() {
/* 17 */     super("Command");
/* 18 */     this.commands.add(new BindCommand());
/* 19 */     this.commands.add(new ModuleCommand());
/* 20 */     this.commands.add(new PrefixCommand());
/* 21 */     this.commands.add(new ConfigCommand());
/* 22 */     this.commands.add(new FriendCommand());
/* 23 */     this.commands.add(new HelpCommand());
/* 24 */     this.commands.add(new ReloadCommand());
/* 25 */     this.commands.add(new UnloadCommand());
/* 26 */     this.commands.add(new ReloadSoundCommand());
/* 27 */     this.commands.add(new PeekCommand());
/* 28 */     this.commands.add(new XrayCommand());
/* 29 */     this.commands.add(new BookCommand());
/* 30 */     this.commands.add(new CrashCommand());
/* 31 */     this.commands.add(new HistoryCommand());
/* 32 */     this.commands.add(new BaritoneNoStop());
/*    */   }
/*    */   
/*    */   public static String[] removeElement(String[] input, int indexToDelete) {
/* 36 */     LinkedList<String> result = new LinkedList<>();
/* 37 */     for (int i = 0; i < input.length; i++) {
/* 38 */       if (i != indexToDelete)
/* 39 */         result.add(input[i]); 
/*    */     } 
/* 41 */     return result.<String>toArray(input);
/*    */   }
/*    */   
/*    */   private static String strip(String str, String key) {
/* 45 */     if (str.startsWith(key) && str.endsWith(key)) {
/* 46 */       return str.substring(key.length(), str.length() - key.length());
/*    */     }
/* 48 */     return str;
/*    */   }
/*    */   
/*    */   public void executeCommand(String command) {
/* 52 */     String[] parts = command.split(" (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
/* 53 */     String name = parts[0].substring(1);
/* 54 */     String[] args = removeElement(parts, 0);
/* 55 */     for (int i = 0; i < args.length; i++) {
/* 56 */       if (args[i] != null)
/* 57 */         args[i] = strip(args[i], "\""); 
/*    */     } 
/* 59 */     for (Command c : this.commands) {
/* 60 */       if (!c.getName().equalsIgnoreCase(name))
/* 61 */         continue;  c.execute(parts);
/*    */       return;
/*    */     } 
/* 64 */     Command.sendMessage("Unknown command. try 'commands' for a list of commands.");
/*    */   }
/*    */   
/*    */   public Command getCommandByName(String name) {
/* 68 */     for (Command command : this.commands) {
/* 69 */       if (!command.getName().equals(name))
/* 70 */         continue;  return command;
/*    */     } 
/* 72 */     return null;
/*    */   }
/*    */   
/*    */   public ArrayList<Command> getCommands() {
/* 76 */     return this.commands;
/*    */   }
/*    */   
/*    */   public String getClientMessage() {
/* 80 */     return this.clientMessage;
/*    */   }
/*    */   
/*    */   public void setClientMessage(String clientMessage) {
/* 84 */     this.clientMessage = clientMessage;
/*    */   }
/*    */   
/*    */   public String getPrefix() {
/* 88 */     return this.prefix;
/*    */   }
/*    */   
/*    */   public void setPrefix(String prefix) {
/* 92 */     this.prefix = prefix;
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\manager\CommandManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */