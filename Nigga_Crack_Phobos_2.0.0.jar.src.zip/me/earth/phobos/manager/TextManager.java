/*     */ package me.earth.phobos.manager;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import me.earth.phobos.Phobos;
/*     */ import me.earth.phobos.features.Feature;
/*     */ import me.earth.phobos.features.gui.font.CustomFont;
/*     */ import me.earth.phobos.features.modules.client.FontMod;
/*     */ import me.earth.phobos.util.Timer;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ 
/*     */ public class TextManager
/*     */   extends Feature
/*     */ {
/*  14 */   private final Timer idleTimer = new Timer();
/*     */   public int scaledWidth;
/*     */   public int scaledHeight;
/*     */   public int scaleFactor;
/*  18 */   private CustomFont customFont = new CustomFont(new Font("Verdana", 0, 17), true, false);
/*     */   private boolean idling;
/*     */   
/*     */   public TextManager() {
/*  22 */     updateResolution();
/*     */   }
/*     */   
/*     */   public void init(boolean startup) {
/*  26 */     FontMod cFont = Phobos.moduleManager.<FontMod>getModuleByClass(FontMod.class);
/*     */     try {
/*  28 */       setFontRenderer(new Font((String)cFont.fontName.getValue(), ((Integer)cFont.fontStyle.getValue()).intValue(), ((Integer)cFont.fontSize.getValue()).intValue()), ((Boolean)cFont.antiAlias.getValue()).booleanValue(), ((Boolean)cFont.fractionalMetrics.getValue()).booleanValue());
/*  29 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawStringWithShadow(String text, float x, float y, int color) {
/*  35 */     drawString(text, x, y, color, true);
/*     */   }
/*     */   
/*     */   public float drawString(String text, float x, float y, int color, boolean shadow) {
/*  39 */     if (Phobos.moduleManager.isModuleEnabled(FontMod.class)) {
/*  40 */       if (shadow) {
/*  41 */         return this.customFont.drawStringWithShadow(text, x, y, color);
/*     */       }
/*  43 */       return this.customFont.drawString(text, x, y, color);
/*     */     } 
/*  45 */     return mc.field_71466_p.func_175065_a(text, x, y, color, shadow);
/*     */   }
/*     */   
/*     */   public int getStringWidth(String text) {
/*  49 */     if (Phobos.moduleManager.isModuleEnabled(FontMod.class)) {
/*  50 */       return this.customFont.getStringWidth(text);
/*     */     }
/*  52 */     return mc.field_71466_p.func_78256_a(text);
/*     */   }
/*     */   
/*     */   public int getFontHeight() {
/*  56 */     if (Phobos.moduleManager.isModuleEnabled(FontMod.class)) {
/*  57 */       String text = "A";
/*  58 */       return this.customFont.getStringHeight(text);
/*     */     } 
/*  60 */     return mc.field_71466_p.field_78288_b;
/*     */   }
/*     */   
/*     */   public void setFontRenderer(Font font, boolean antiAlias, boolean fractionalMetrics) {
/*  64 */     this.customFont = new CustomFont(font, antiAlias, fractionalMetrics);
/*     */   }
/*     */   
/*     */   public Font getCurrentFont() {
/*  68 */     return this.customFont.getFont();
/*     */   }
/*     */   
/*     */   public void updateResolution() {
/*  72 */     this.scaledWidth = mc.field_71443_c;
/*  73 */     this.scaledHeight = mc.field_71440_d;
/*  74 */     this.scaleFactor = 1;
/*  75 */     boolean flag = mc.func_152349_b();
/*  76 */     int i = mc.field_71474_y.field_74335_Z;
/*  77 */     if (i == 0) {
/*  78 */       i = 1000;
/*     */     }
/*  80 */     while (this.scaleFactor < i && this.scaledWidth / (this.scaleFactor + 1) >= 320 && this.scaledHeight / (this.scaleFactor + 1) >= 240) {
/*  81 */       this.scaleFactor++;
/*     */     }
/*  83 */     if (flag && this.scaleFactor % 2 != 0 && this.scaleFactor != 1) {
/*  84 */       this.scaleFactor--;
/*     */     }
/*  86 */     double scaledWidthD = this.scaledWidth / this.scaleFactor;
/*  87 */     double scaledHeightD = this.scaledHeight / this.scaleFactor;
/*  88 */     this.scaledWidth = MathHelper.func_76143_f(scaledWidthD);
/*  89 */     this.scaledHeight = MathHelper.func_76143_f(scaledHeightD);
/*     */   }
/*     */   
/*     */   public String getIdleSign() {
/*  93 */     if (this.idleTimer.passedMs(500L)) {
/*  94 */       this.idling = !this.idling;
/*  95 */       this.idleTimer.reset();
/*     */     } 
/*  97 */     if (this.idling) {
/*  98 */       return "_";
/*     */     }
/* 100 */     return "";
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\manager\TextManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */