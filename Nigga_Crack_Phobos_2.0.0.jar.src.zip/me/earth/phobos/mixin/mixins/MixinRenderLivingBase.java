/*     */ package me.earth.phobos.mixin.mixins;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import me.earth.phobos.event.events.RenderEntityModelEvent;
/*     */ import me.earth.phobos.features.modules.client.Colors;
/*     */ import me.earth.phobos.features.modules.render.Chams;
/*     */ import me.earth.phobos.features.modules.render.ESP;
/*     */ import me.earth.phobos.features.modules.render.Skeleton;
/*     */ import me.earth.phobos.util.EntityUtil;
/*     */ import me.earth.phobos.util.RenderUtil;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ @Mixin({RenderLivingBase.class})
/*     */ public abstract class MixinRenderLivingBase<T extends EntityLivingBase>
/*     */   extends Render<T>
/*     */ {
/*     */   public MixinRenderLivingBase(RenderManager renderManagerIn, ModelBase modelBaseIn, float shadowSizeIn) {
/*  29 */     super(renderManagerIn);
/*     */   }
/*     */   
/*     */   @Redirect(method = {"renderModel"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/ModelBase;render(Lnet/minecraft/entity/Entity;FFFFFF)V"))
/*     */   private void renderModelHook(ModelBase modelBase, Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/*  34 */     boolean cancel = false;
/*  35 */     if (Skeleton.getInstance().isEnabled() || ESP.getInstance().isEnabled()) {
/*  36 */       RenderEntityModelEvent event = new RenderEntityModelEvent(0, modelBase, entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/*  37 */       if (Skeleton.getInstance().isEnabled()) {
/*  38 */         Skeleton.getInstance().onRenderModel(event);
/*     */       }
/*  40 */       if (ESP.getInstance().isEnabled()) {
/*  41 */         ESP.getInstance().onRenderModel(event);
/*  42 */         if (event.isCanceled()) {
/*  43 */           cancel = true;
/*     */         }
/*     */       } 
/*     */     } 
/*  47 */     if (Chams.getInstance().isEnabled() && entityIn instanceof net.minecraft.entity.player.EntityPlayer && ((Boolean)(Chams.getInstance()).colored.getValue()).booleanValue()) {
/*  48 */       GL11.glPushAttrib(1048575);
/*  49 */       GL11.glDisable(3008);
/*  50 */       GL11.glDisable(3553);
/*  51 */       GL11.glDisable(2896);
/*  52 */       GL11.glEnable(3042);
/*  53 */       GL11.glBlendFunc(770, 771);
/*  54 */       GL11.glLineWidth(1.5F);
/*  55 */       GL11.glEnable(2960);
/*  56 */       if (((Boolean)(Chams.getInstance()).rainbow.getValue()).booleanValue()) {
/*  57 */         Color rainbowColor1 = ((Boolean)(Chams.getInstance()).colorSync.getValue()).booleanValue() ? Colors.INSTANCE.getCurrentColor() : new Color(RenderUtil.getRainbow(((Integer)(Chams.getInstance()).speed.getValue()).intValue() * 100, 0, ((Integer)(Chams.getInstance()).saturation.getValue()).intValue() / 100.0F, ((Integer)(Chams.getInstance()).brightness.getValue()).intValue() / 100.0F));
/*  58 */         Color rainbowColor = EntityUtil.getColor(entityIn, rainbowColor1.getRed(), rainbowColor1.getGreen(), rainbowColor1.getBlue(), ((Integer)(Chams.getInstance()).alpha.getValue()).intValue(), true);
/*  59 */         GL11.glDisable(2929);
/*  60 */         GL11.glDepthMask(false);
/*  61 */         GL11.glEnable(10754);
/*  62 */         GL11.glColor4f(rainbowColor.getRed() / 255.0F, rainbowColor.getGreen() / 255.0F, rainbowColor.getBlue() / 255.0F, ((Integer)(Chams.getInstance()).alpha.getValue()).intValue() / 255.0F);
/*  63 */         modelBase.func_78088_a(entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/*  64 */         GL11.glEnable(2929);
/*  65 */         GL11.glDepthMask(true);
/*  66 */       } else if (((Boolean)(Chams.getInstance()).xqz.getValue()).booleanValue()) {
/*  67 */         Color hiddenColor = ((Boolean)(Chams.getInstance()).colorSync.getValue()).booleanValue() ? EntityUtil.getColor(entityIn, ((Integer)(Chams.getInstance()).red.getValue()).intValue(), ((Integer)(Chams.getInstance()).green.getValue()).intValue(), ((Integer)(Chams.getInstance()).blue.getValue()).intValue(), ((Integer)(Chams.getInstance()).alpha.getValue()).intValue(), true) : EntityUtil.getColor(entityIn, ((Integer)(Chams.getInstance()).red.getValue()).intValue(), ((Integer)(Chams.getInstance()).green.getValue()).intValue(), ((Integer)(Chams.getInstance()).blue.getValue()).intValue(), ((Integer)(Chams.getInstance()).alpha.getValue()).intValue(), true);
/*  68 */         Color visibleColor = ((Boolean)(Chams.getInstance()).colorSync.getValue()).booleanValue() ? EntityUtil.getColor(entityIn, ((Integer)(Chams.getInstance()).red.getValue()).intValue(), ((Integer)(Chams.getInstance()).green.getValue()).intValue(), ((Integer)(Chams.getInstance()).blue.getValue()).intValue(), ((Integer)(Chams.getInstance()).alpha.getValue()).intValue(), true) : EntityUtil.getColor(entityIn, ((Integer)(Chams.getInstance()).red.getValue()).intValue(), ((Integer)(Chams.getInstance()).green.getValue()).intValue(), ((Integer)(Chams.getInstance()).blue.getValue()).intValue(), ((Integer)(Chams.getInstance()).alpha.getValue()).intValue(), true);
/*  69 */         GL11.glDisable(2929);
/*  70 */         GL11.glDepthMask(false);
/*  71 */         GL11.glEnable(10754);
/*  72 */         GL11.glColor4f(hiddenColor.getRed() / 255.0F, hiddenColor.getGreen() / 255.0F, hiddenColor.getBlue() / 255.0F, ((Integer)(Chams.getInstance()).alpha.getValue()).intValue() / 255.0F);
/*  73 */         modelBase.func_78088_a(entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/*  74 */         GL11.glEnable(2929);
/*  75 */         GL11.glDepthMask(true);
/*  76 */         GL11.glColor4f(visibleColor.getRed() / 255.0F, visibleColor.getGreen() / 255.0F, visibleColor.getBlue() / 255.0F, ((Integer)(Chams.getInstance()).alpha.getValue()).intValue() / 255.0F);
/*  77 */         modelBase.func_78088_a(entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/*     */       } else {
/*  79 */         Color visibleColor = ((Boolean)(Chams.getInstance()).colorSync.getValue()).booleanValue() ? Colors.INSTANCE.getCurrentColor() : EntityUtil.getColor(entityIn, ((Integer)(Chams.getInstance()).red.getValue()).intValue(), ((Integer)(Chams.getInstance()).green.getValue()).intValue(), ((Integer)(Chams.getInstance()).blue.getValue()).intValue(), ((Integer)(Chams.getInstance()).alpha.getValue()).intValue(), true);
/*  80 */         GL11.glDisable(2929);
/*  81 */         GL11.glDepthMask(false);
/*  82 */         GL11.glEnable(10754);
/*  83 */         GL11.glColor4f(visibleColor.getRed() / 255.0F, visibleColor.getGreen() / 255.0F, visibleColor.getBlue() / 255.0F, ((Integer)(Chams.getInstance()).alpha.getValue()).intValue() / 255.0F);
/*  84 */         modelBase.func_78088_a(entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/*  85 */         GL11.glEnable(2929);
/*  86 */         GL11.glDepthMask(true);
/*     */       } 
/*  88 */       GL11.glEnable(3042);
/*  89 */       GL11.glEnable(2896);
/*  90 */       GL11.glEnable(3553);
/*  91 */       GL11.glEnable(3008);
/*  92 */       GL11.glPopAttrib();
/*  93 */     } else if (!cancel) {
/*  94 */       modelBase.func_78088_a(entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject(method = {"doRender"}, at = {@At("HEAD")})
/*     */   public void doRenderPre(T entity, double x, double y, double z, float entityYaw, float partialTicks, CallbackInfo info) {
/* 100 */     if (Chams.getInstance().isEnabled() && !((Boolean)(Chams.getInstance()).colored.getValue()).booleanValue() && entity != null) {
/* 101 */       GL11.glEnable(32823);
/* 102 */       GL11.glPolygonOffset(1.0F, -1100000.0F);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject(method = {"doRender"}, at = {@At("RETURN")})
/*     */   public void doRenderPost(T entity, double x, double y, double z, float entityYaw, float partialTicks, CallbackInfo info) {
/* 108 */     if (Chams.getInstance().isEnabled() && !((Boolean)(Chams.getInstance()).colored.getValue()).booleanValue() && entity != null) {
/* 109 */       GL11.glPolygonOffset(1.0F, 1000000.0F);
/* 110 */       GL11.glDisable(32823);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\mixin\mixins\MixinRenderLivingBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */