/*    */ package me.earth.phobos.mixin.mixins;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import javax.annotation.Nullable;
/*    */ import me.earth.phobos.features.modules.client.Capes;
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.client.network.NetworkPlayerInfo;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({AbstractClientPlayer.class})
/*    */ public abstract class MixinAbstractClientPlayer {
/*    */   @Shadow
/*    */   @Nullable
/*    */   protected abstract NetworkPlayerInfo func_175155_b();
/*    */   
/*    */   @Inject(method = {"getLocationCape"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void getLocationCape(CallbackInfoReturnable<ResourceLocation> callbackInfoReturnable) {
/* 23 */     if (Capes.getInstance().isEnabled()) {
/* 24 */       NetworkPlayerInfo info = func_175155_b();
/* 25 */       UUID uuid = null;
/* 26 */       if (info != null) {
/* 27 */         uuid = func_175155_b().func_178845_a().getId();
/*    */       }
/* 29 */       ResourceLocation cape = Capes.getCapeResource((AbstractClientPlayer)this);
/* 30 */       if (uuid != null && Capes.hasCape(uuid))
/* 31 */         callbackInfoReturnable.setReturnValue(cape); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\42060\Downloads\Nigga_Crack_Phobos_2.0.0.jar!\me\earth\phobos\mixin\mixins\MixinAbstractClientPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */